"""Cut the photos of the desserts Keeta does not have out of Why!'s own Instagram menu story (screenshots, Nov 2026)
into assets/menu/, next to the Keeta ones (tools/menu_photos.py), and add them to assets/menu/photos.json.

Each story page shows one product on a plate on a light grey ground, with its price card above it. The plate is cut out
below the card and the cut is made square by drawing its own edges on, so the photo sits in its tile like the others.

usage: python3 tools/story_photos.py      (the screenshots are the files sent in the chat, under /mnt/user-data/uploads)
"""
import json
from pathlib import Path
import numpy as np
from PIL import Image
from menu_photos import OUT, webp, tile

UP = Path("/mnt/user-data/uploads")
SIDE = 816
# key: (screenshot, the box around the plate: left, top, right, bottom, and the price card's corner inside it, painted over)
SRC = {
    "french_toast_mix": ("3e9d8b15", (70, 905, 1110, 1640), None),
    "french_toast_choc": ("62255130", (70, 905, 1110, 1630), None),
    "choc_waffle": ("38137bc7", (95, 815, 1150, 1640), (225, 815, 600, 890)),
    "breakfast": ("31c1b648", (276, 1414, 888, 1940), None),   # the offer's own yellow card, inside its white frame
}


def cut(name, box, card):
    im = Image.open(UP / f"{name}-image.png").convert("RGB")
    a = np.asarray(im.crop(box)).astype(float)
    ground = np.median(a[-8:].reshape(-1, 3), 0)
    if card:
        a[card[1] - box[1]:card[3] - box[1], card[0] - box[0]:card[2] - box[0]] = ground
    h, w = a.shape[:2]
    s = max(h, w)
    dy, dx = s - h, s - w   # the ground is drawn on from the cut's own edges, fading to its colour, so no seam shows
    top, left = dy // 2, dx // 2
    a = np.pad(a, ((top, dy - top), (left, dx - left), (0, 0)), mode="edge")
    yy, xx = np.mgrid[0:s, 0:s]
    far = np.maximum(np.maximum(np.clip((top - yy) / max(top, 1), 0, 1), np.clip((yy - (top + h - 1)) / max(dy - top, 1), 0, 1)),
                     np.maximum(np.clip((left - xx) / max(left, 1), 0, 1), np.clip((xx - (left + w - 1)) / max(dx - left, 1), 0, 1)))
    a = a * (1 - far[..., None]) + ground * far[..., None]
    return Image.fromarray(a.round().astype(np.uint8)).resize((SIDE, SIDE), Image.LANCZOS)


def main():
    meta = json.loads((OUT / "photos.json").read_text())
    for key, (name, box, card) in SRC.items():
        im = cut(name, box, card)
        (OUT / f"{key}.webp").write_bytes(webp(im, 84))
        (OUT / f"{key}-t.webp").write_bytes(webp(im.resize((320, 320), Image.LANCZOS), 80))
        bg, f = tile(im)
        meta[key] = {"bg": bg, "f": f}
        print(key, bg, f)
    (OUT / "photos.json").write_text(json.dumps(meta, indent=1, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
