#!/usr/bin/env python3
"""Why! server: orders, staff sign-in, delivery drivers, the menu (products, categories, photos) and the settings the admin changes.

Python 3 standard library only (http.server, sqlite3, hashlib, secrets, threading). One process, one SQLite file.

    python3 why_server.py serve  --db /var/lib/why/why.db --port 8787      run the server (behind Caddy)
    python3 why_server.py setpin --role admin --db /var/lib/why/why.db     set or change a staff PIN (typed, hidden)
    python3 why_server.py check  --db /var/lib/why/why.db                  print what is in the database

Who talks to it
    customer app   /api/public  /api/orders  /api/my/sync  /api/my/collect      identified by a random device key (X-Dev)
    everyone       /api/catalog  /api/img/<id>  /api/img/<id>/t                    the menu and the branches, and the photos (large and small)
    reception      /api/recv/...                                                 PIN, cookie why_recv
    admin          /api/admin/...                                                PIN, cookie why_admin
    driver         /api/driver/...                                               name + PIN, cookie why_driver

Staff screens keep a long request open (/state?rev=N&wait=25) and get the new state the moment anything changes.

The menu and the branches live in the database: the first start copies the "seed" of catalog.json into it, then the admin
adds, edits and deletes products, categories and branches and uploads the photos. Every page gets them with their revision
(crev) and asks again only when that changed. A deleted product or branch is kept, marked "gone", so old orders still
show what was ordered and where.
"""
import argparse
import base64
import binascii
import datetime
import getpass
import hashlib
import hmac
import http.server
import io
import json
import math
import mimetypes
import os
import queue
import re
import secrets
import socketserver
import sqlite3
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from contextlib import contextmanager
from pathlib import Path

VERSION = "0.7.7"
HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------- small helpers


def now_ms():
    return int(time.time() * 1000)


def half_up(x):
    """JavaScript Math.round for the positive numbers we deal with."""
    return int(math.floor(x + 0.5))


def sar(cents):
    return cents / 100.0


def clean(s, n):
    """Trim, drop control characters, cap the length. Names and addresses are stored as typed (the screens escape them)."""
    s = re.sub(r"[\x00-\x1f\x7f]+", " ", str(s if s is not None else ""))
    return re.sub(r"\s+", " ", s).strip()[:n]


def clean_text(s, n, lines=8):
    """Like clean(), but keeps line breaks (a description): at most `lines` lines, no blank runs."""
    s = str(s if s is not None else "").replace("\r\n", "\n").replace("\r", "\n")
    rows = [re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]+", " ", r)).strip() for r in s.split("\n")]
    text = re.sub(r"\n{3,}", "\n\n", "\n".join(rows)).strip("\n")
    return "\n".join(text.split("\n")[:lines])[:n].strip()


def pair(v, n, text=False):
    """A text in both languages, {"ar": ..., "en": ...}; either may be empty."""
    v = v if isinstance(v, dict) else {}
    f = (lambda x: clean_text(x, n)) if text else (lambda x: clean(x, n))
    return {"ar": f(v.get("ar")), "en": f(v.get("en"))}


def or_none(v):
    return v if v and (v.get("ar") or v.get("en")) else None


def image_info(data):
    """(type, width, height) of a JPEG, PNG or WebP file, read from its header only; None for anything else."""
    try:
        if data[:8] == b"\x89PNG\r\n\x1a\n" and data[12:16] == b"IHDR":
            w, h = struct.unpack(">II", data[16:24])
            return "image/png", w, h
        if data[:3] == b"\xff\xd8\xff":
            i = 2
            while i + 9 < len(data):
                if data[i] != 0xFF:
                    return None
                m = data[i + 1]
                if m == 0xFF:
                    i += 1
                    continue
                if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
                    i += 2
                    continue
                n = struct.unpack(">H", data[i + 2:i + 4])[0]
                if 0xC0 <= m <= 0xCF and m not in (0xC4, 0xC8, 0xCC):
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return "image/jpeg", w, h
                i += 2 + n
            return None
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP" and abs(int.from_bytes(data[4:8], "little") + 8 - len(data)) <= 1:
            kind = data[12:16]
            if kind == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
                w, h = struct.unpack("<HH", data[26:30])
                return "image/webp", w & 0x3FFF, h & 0x3FFF
            if kind == b"VP8L" and data[20] == 0x2F:
                b = int.from_bytes(data[21:25], "little")
                return "image/webp", (b & 0x3FFF) + 1, ((b >> 14) & 0x3FFF) + 1
            if kind == b"VP8X":
                return "image/webp", 1 + int.from_bytes(data[24:27], "little"), 1 + int.from_bytes(data[27:30], "little")
    except (IndexError, struct.error):
        return None
    return None


def hhmm(v):
    """'06:30' -> minutes after midnight."""
    if not isinstance(v, str) or not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", v):
        raise ApiError(400, "bad_hours")
    return int(v[:2]) * 60 + int(v[3:])


def valid_latlng(lat, lng):
    ok = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and x == x
    return ok(lat) and ok(lng) and -90 <= lat <= 90 and -180 <= lng <= 180 and not (lat == 0 and lng == 0)


# where a pasted map link may come from (a shared Google Maps link is often a short one that has to be opened to read it)
MAP_HOSTS = {"maps.app.goo.gl", "goo.gl", "g.co", "maps.google.com", "www.google.com", "google.com", "www.google.com.sa", "google.com.sa", "maps.apple.com"}
COORD_PATTERNS = (
    r"!3d(-?\d{1,2}(?:\.\d+)?)!4d(-?\d{1,3}(?:\.\d+)?)",                                              # the pin of a Google Maps place
    r"[?&](?:q|query|ll|sll|destination|daddr|center|coordinate)=\s*(-?\d{1,2}\.\d+)\s*,\s*\+?(-?\d{1,3}\.\d+)",  # ?q=24.46,39.61
    r"@(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+)",                                                             # .../@24.46,39.61,17z
    r"/(?:search|place|dir)/(-?\d{1,2}\.\d+),\s*\+?(-?\d{1,3}\.\d+)",                                         # .../search/24.46,+39.61
    r"^\s*\(?\s*(-?\d{1,2}\.\d+)\s*[,،\s]\s*(-?\d{1,3}\.\d+)\s*\)?\s*$",                                 # 24.46, 39.61
)


def coords_in(text):
    """Latitude and longitude written in a map link or as two numbers; None when there are none."""
    t = urllib.parse.unquote(str(text or "")).replace("٫", ".")
    t = t.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    for pat in COORD_PATTERNS:
        m = re.search(pat, t)
        if m:
            lat, lng = float(m.group(1)), float(m.group(2))
            if valid_latlng(lat, lng):
                return round(lat, 6), round(lng, 6)
    return None


def coords_in_page(html):
    """The place a Google Maps page shows: its preview image is centred on it, and the place data carries it too."""
    for pat in (r"staticmap\?center=(-?\d{1,2}\.\d+)(?:%2C|,)(-?\d{1,3}\.\d+)", r"!3d(-?\d{1,2}\.\d+)!4d(-?\d{1,3}\.\d+)", r"/@(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+),"):
        m = re.search(pat, html or "")
        if m and valid_latlng(float(m.group(1)), float(m.group(2))):
            return round(float(m.group(1)), 6), round(float(m.group(2)), 6)
    return None


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):   # read where a link leads, never go there
        return None


def name_key(s):
    return re.sub(r"\s+", " ", str(s).strip()).casefold()


def valid_pin(p):
    return isinstance(p, str) and re.fullmatch(r"\d{6,10}", p) is not None


def valid_phone(p):
    return isinstance(p, str) and re.fullmatch(r"5\d{8}", p) is not None


def valid_email(e):
    return isinstance(e, str) and len(e) <= 120 and re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]{2,}", e) is not None


def valid_birth(b):
    """YYYY-MM-DD, a real date, not before 1920 and not in the future (a day of slack for time zones)."""
    if not (isinstance(b, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", b)):
        return False
    try:
        d = datetime.date.fromisoformat(b)
    except ValueError:
        return False
    return datetime.date(1920, 1, 1) <= d <= datetime.date.today() + datetime.timedelta(days=1)


def profile_extra(body):
    """The optional sign-up details a customer sends along: only the valid ones, in the form they are stored."""
    out = {}
    e = clean(body.get("email"), 120).lower()
    if valid_email(e):
        out["email"] = e
    if valid_birth(body.get("birth")):
        out["birth"] = body["birth"]
    if body.get("gender") in ("m", "f"):
        out["gender"] = body["gender"]
    inv = clean(body.get("invite"), 20).upper()
    if re.fullmatch(r"[A-Z0-9]{3,20}", inv):
        out["invite"] = inv
    if isinstance(body.get("mk"), bool):
        out["mk"] = 1 if body["mk"] else 0
    return out


def zatca_qr(name, vat, ts_ms, total_c, vat_c):
    """The QR text of a simplified tax invoice (ZATCA phase 1): seller, VAT number, time, total with VAT and the VAT,
    each as tag, length, value; then base64."""
    when = datetime.datetime.fromtimestamp(ts_ms / 1000, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    out = b""
    for tag, v in enumerate((name, vat, when, "%.2f" % (total_c / 100), "%.2f" % (vat_c / 100)), 1):
        b = v.encode("utf-8")
        out += bytes([tag, len(b)]) + b
    return base64.b64encode(out).decode("ascii")


# ---- Web Push (0.7). The push carries no data: the phone's service worker asks /api/push/inbox for the message, so
# nothing has to be encrypted here. The server signs a short token (VAPID, ES256 = ECDSA on P-256 with SHA-256)
# so the push services know the pushes come from this server. Plain Python: no outside package.
P256_P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
P256_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
P256_G = (0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296, 0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5)


def _ec_double(P):
    X, Y, Z = P
    if not Z or not Y:
        return (0, 1, 0)
    p = P256_P
    YY = Y * Y % p
    S = 4 * X * YY % p
    ZZ = Z * Z % p
    M = 3 * (X - ZZ) * (X + ZZ) % p   # a = -3
    X3 = (M * M - 2 * S) % p
    return (X3, (M * (S - X3) - 8 * YY * YY) % p, 2 * Y * Z % p)


def _ec_add(P, Q):
    if not P[2]:
        return Q
    if not Q[2]:
        return P
    p = P256_P
    X1, Y1, Z1 = P
    X2, Y2, Z2 = Q
    Z1Z1, Z2Z2 = Z1 * Z1 % p, Z2 * Z2 % p
    U1, U2 = X1 * Z2Z2 % p, X2 * Z1Z1 % p
    S1, S2 = Y1 * Z2 * Z2Z2 % p, Y2 * Z1 * Z1Z1 % p
    if U1 == U2:
        return _ec_double(P) if S1 == S2 else (0, 1, 0)
    H, R = (U2 - U1) % p, (S2 - S1) % p
    HH = H * H % p
    HHH, V = H * HH % p, U1 * HH % p
    X3 = (R * R - HHH - 2 * V) % p
    return (X3, (R * (V - X3) - S1 * HHH) % p, H * Z1 * Z2 % p)


def ec_mul(k, point=P256_G):
    """k times a point of P-256, in affine coordinates."""
    R, Q = (0, 1, 0), (point[0], point[1], 1)
    for b in bin(k)[2:]:
        R = _ec_double(R)
        if b == "1":
            R = _ec_add(R, Q)
    zi = pow(R[2], -1, P256_P)
    return (R[0] * zi * zi % P256_P, R[1] * zi * zi * zi % P256_P)


def b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def es256_sign(d, msg):
    """ECDSA P-256 with SHA-256: r and s, 32 bytes each (the form JWT uses)."""
    z = int.from_bytes(hashlib.sha256(msg).digest(), "big")
    while True:
        k = secrets.randbelow(P256_N - 1) + 1
        r = ec_mul(k)[0] % P256_N
        s = pow(k, -1, P256_N) * (z + r * d) % P256_N
        if r and s:
            return r.to_bytes(32, "big") + s.to_bytes(32, "big")


# the road route (free key, 2000 a day). HeiGIT moved openrouteservice to api.heigit.org in 2026 and switched the old
# address api.openrouteservice.org off in November 2026; the same keys work here.
ROUTE_URL = "https://api.heigit.org/openrouteservice/v2/directions/driving-car/geojson"
# The road is asked for once per delivery: as the driver goes, the line is cut where he is. A new road is asked for only
# when he leaves it (a turn the road did not take), never twice within ROUTE_GAP_MS, and ROUTE_WAIT_MS after an ask that
# failed (a wrong key, the day's 2000 used up, no road near the address), so a failure is not repeated with every sync.
ROUTE_OFF_KM, ROUTE_SHOW_KM = 0.15, 0.4   # farther than this from the road: ask for a new one / stop drawing the old one
ROUTE_GAP_MS, ROUTE_WAIT_MS = 20_000, 120_000
PUSH_HOSTS = ("fcm.googleapis.com", "push.services.mozilla.com", "notify.windows.com", "push.apple.com")   # the browsers' push services


def fmt_sar(v):
    """12, 12.5, 12.25: no needless zeros (a push message)."""
    return ("%.2f" % v).rstrip("0").rstrip(".")


def valid_vat(v):
    """A Saudi VAT number: 15 digits, starting and ending with 3."""
    return isinstance(v, str) and re.fullmatch(r"3\d{13}3", v) is not None


def sha(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


# ---- membership tiers (0.5.1). Each tier: the points of the last TIER_DAYS days that open it (min), and the points a
# customer earns for every 10 SAR he pays (per10). The admin changes both from the management page.
TIER_IDS = ("basic", "silver", "gold")
TIER_DAYS = 30
WELCOME_PTS = 100        # the app gives these at sign-up (WELCOME_PTS in core.js); they count toward the tier for 30 days
WELCOME_LABEL = {"ar": "تم التسجيل للمرة الأولى", "en": "First registration"}
BONUS_LABEL = {"ar": "نقاط هدية من واي", "en": "Bonus points from Why"}
OTP_TEST = "12345"       # the sign-in code until the WhatsApp codes are switched on (before launch)
# 0.7.6: the sign-in code by WhatsApp (Meta's Cloud API, an authentication template with a copy-code button). Set with
# the command  why_server.py wakey  (the token typed hidden); until then, or while the test code is kept on, 12345 works.
WA_URL = "https://graph.facebook.com/v25.0/%s/messages"
OTP_TTL_MS, OTP_TRIES, OTP_GAP_MS = 10 * 60_000, 5, 30_000   # a code lives 10 minutes, 5 tries, a new one every 30 s
# 0.7.7: the daily copy, encrypted, by e-mail (Brevo's e-mail API: DigitalOcean blocks the mail ports 25/465/587).
# Set with the command  why_server.py mailkey ; the key and the password are typed hidden and never leave this server
# except the password-locked copy itself.
MAIL_URL = "https://api.brevo.com/v3/smtp/email"
MAIL_MAX_BYTES = 12 * 1024 * 1024         # Brevo takes up to 25 MB a mail; kept lower so the service stays within its 96 MB
MAIL_TRIES_A_DAY = 3
PBKDF2_ITER = 600_000                     # openssl enc -pbkdf2 -iter (the same number is in the mail, to open the file)
SECRET_KV = ("route_key", "wa_token", "mail_key", "mail_pw")   # left out of every copy that leaves the server
GIFT_MIN, GIFT_MAX = 10, 1000   # a gift card or a wallet top-up, whole riyals (GIFT_MIN and GIFT_MAX in core.js)
DEFAULT_TIERS = [{"id": "basic", "min": 0, "per10": 8}, {"id": "silver", "min": 500, "per10": 9}, {"id": "gold", "min": 1000, "per10": 10}]


def clean_tiers(v):
    """basic, silver, gold in that order: basic opens at 0, every higher tier needs more points than the one under it and
    gives at least as many. None when the list is not like that."""
    if not isinstance(v, list) or len(v) != len(TIER_IDS):
        return None
    out = []
    for tid, t in zip(TIER_IDS, v):
        if not isinstance(t, dict) or t.get("id") != tid:
            return None
        mn, per = t.get("min"), t.get("per10")
        if any(isinstance(x, bool) or not isinstance(x, int) for x in (mn, per)) or not 1 <= per <= 100 or not 0 <= mn <= 1_000_000:
            return None
        if (not out and mn != 0) or (out and (mn <= out[-1]["min"] or per < out[-1]["per10"])):
            return None
        out.append({"id": tid, "min": mn, "per10": per})
    return out


def tier_for(pts, tiers):
    cur = tiers[0]
    for t in tiers:
        if pts >= t["min"]:
            cur = t
    return cur


def tier_earn(pay_c, tier):
    """Points for a payment in halalas: per10 points for every 10 SAR, whole points only."""
    return pay_c * tier["per10"] // 1000


def mask_email(e):
    """a***@gmail.com: enough to recognise the address, not to read it out."""
    user, _, dom = e.partition("@")
    return (user[:1] + "***@" + dom) if dom else "***"


def lock_file(src, dest, password):
    """AES-256 with a key from the password (PBKDF2, salted), by openssl: the same file opens on any computer with
    openssl, and with  why_server.py unlock FILE  on the server."""
    env = dict(os.environ, WHY_LOCK_PW=password)
    r = subprocess.run(["openssl", "enc", "-aes-256-cbc", "-salt", "-pbkdf2", "-iter", str(PBKDF2_ITER), "-md", "sha256",
                        "-in", str(src), "-out", str(dest), "-pass", "env:WHY_LOCK_PW"], env=env, capture_output=True, timeout=300)
    if r.returncode != 0:
        raise RuntimeError("openssl: " + r.stderr.decode("utf-8", "replace")[:200])


def unlock_file(src, dest, password):
    env = dict(os.environ, WHY_LOCK_PW=password)
    r = subprocess.run(["openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-iter", str(PBKDF2_ITER), "-md", "sha256",
                        "-in", str(src), "-out", str(dest), "-pass", "env:WHY_LOCK_PW"], env=env, capture_output=True, timeout=300)
    return r.returncode == 0 and zipfile.is_zipfile(dest)


def backup_readme(when):
    return ("نسخة احتياطية من بيانات واي! أُخذت %s (بتوقيت المتجر)، النسخة %s.\n\n"
            "why.db: قاعدة البيانات كاملة (العملاء والطلبات والنقاط والمحفظة والهدايا والمنتجات والفروع، والرموز السرية مشفّرة).\n"
            "هذا الملف للاسترجاع عند الحاجة، لا للقراءة.\n"
            "مفاتيح الخادم (الطريق، واتساب، الإيميل) غير موجودة فيها: بعد الاسترجاع تُكتب من جديد بأوامرها.\n\n"
            "الاسترجاع على سيرفر (الخدمة متوقفة): ضع why.db مكان /var/lib/why/why.db بمالك why وصلاحية 600، "
            "واحذف why.db-wal و why.db-shm إن وُجدا، ثم شغّل الخدمة why-server.\n") % (when, VERSION)


def mail_text(day, name, size_mb, big):
    if big:
        return ("نسخة اليوم %s كبيرة على الإيميل (%s ميجا)، فلم تُرفق.\n"
                "النسخة محفوظة على الخادم كالعادة. نزّل نسخة من تطبيق الإدارة (الإعدادات ← النسخ الاحتياطي) واحفظها في مكان آمن.\n") % (day, size_mb)
    return ("مرفق نسخة اليوم %s من بيانات المتجر (%s ميجا)، مقفلة بكلمة سر النسخ الاحتياطي.\n\n"
            "احتفظ بهذا الإيميل ولا تعيد إرساله: الملف لا يُفتح إلا بكلمة السر، فاحفظها في مكان آمن غير هذا الإيميل.\n\n"
            "لفتحه عند الحاجة:\n"
            "• على الخادم:  python3 /opt/why-server/why_server.py unlock %s\n"
            "• أو على أي كمبيوتر فيه openssl:\n"
            "  openssl enc -d -aes-256-cbc -pbkdf2 -iter %d -md sha256 -in %s -out why-backup.zip\n\n"
            "يخرج ملف zip فيه قاعدة البيانات وورقة تشرح الاسترجاع.\n") % (day, size_mb, name, PBKDF2_ITER, name)


class ApiError(Exception):
    def __init__(self, status, code, **extra):
        super().__init__(code)
        self.status, self.code, self.extra = status, code, extra


REASONS = {
    "out": ("نفد أحد الأصناف", "An item is sold out"),
    "busy": ("الفرع مزدحم حاليًا", "The branch is too busy right now"),
    "close": ("الفرع على وشك الإغلاق", "The branch is about to close"),
    "reach": ("تعذّر التواصل مع العميل", "We could not reach the customer"),
    "other": ("سبب آخر", "Another reason"),
}
ROLES = ("recv", "admin", "driver")
DESK_PREFIX = "desk:"   # the account name of a branch's own order desk (0.7): desk:b1
KINDS = ("drink", "food", "retail")        # drink and food are made at a branch; retail (beans, tools) can also be shipped
KIND_ART = {"drink": "hot", "food": "cake", "retail": "bag"}   # the drawing a product shows until it has a photo
MAX_PRODUCTS, MAX_CATS, MAX_BRANCHES = 400, 40, 30
MAX_REWARDS, MAX_BANNERS, MAX_NEWS = 30, 12, 40
BANNER_ACTIONS = ("menu", "points", "gift")   # where a banner takes the customer, besides a product
ARRIVE_GAP_MS = 60_000                       # a driver can tell the customer "I am here" again after this
LOC_FRESH_MS = 3 * 60_000                     # a driver position older than this is not shown to the customer
IMG_FULL_MAX, IMG_THUMB_MAX = 1_600_000, 320_000                # bytes of a product photo and of its small copy
IMG_BODY_MAX = 2_700_000
IMG_GRACE_MS = 6 * 3600_000                                     # an uploaded photo no product uses is swept after this
SESSION_DAYS = {"recv": 30, "admin": 7, "driver": 14}
PAY_METHODS = {"card", "apple", "stc", "mada", "wallet", "points"}
REPORT_DAYS = 366       # the longest period one report covers
REPORT_LIST = 20000     # orders listed one by one in the Excel file (the totals always count every order)
REPORT_TOP = 50         # products the report screen gets; the Excel file lists them all
XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

# ---------------------------------------------------------------- Excel files (the reports)


class Fx:
    """A formula in a cell, with the value it gives: phones that only preview the file show that value,
    Excel and the others work it out again when the file opens."""
    __slots__ = ("f", "v")

    def __init__(self, f, v):
        self.f, self.v = f, v


def xml_text(s):
    s = re.sub("[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]", "", str(s))   # characters an XML file cannot hold
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def col_name(i):
    """0 -> A, 25 -> Z, 26 -> AA"""
    s, i = "", i + 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


class Xlsx:
    """A small Excel writer (Office Open XML): text, numbers, dates, formulas and a few styles, enough for the reports.
    The standard library only, like the rest of the server."""
    # the cell styles, in the order of <cellXfs> below
    TEXT, TITLE, HEAD, MONEY, MONEY_T, INT, INT_T, DATE, STAMP, PCT, PCT_T, NOTE, BOLD, TOTAL, ORDER_NO = range(15)
    EPOCH = datetime.datetime(1899, 12, 30)

    def __init__(self, rtl, title):
        self.rtl, self.title = rtl, title
        self.sheets, self.strings, self.sidx, self.names = [], [], {}, []

    def _s(self, text):
        i = self.sidx.get(text)
        if i is None:
            i = self.sidx[text] = len(self.strings)
            self.strings.append(text)
        return i

    def _cell(self, ref, c):
        style = None
        if isinstance(c, tuple):
            c, style = c
        if c is None or c == "":
            return '<c r="%s" s="%d"/>' % (ref, style) if style else ""
        s = ' s="%d"' % style if style else ""
        if isinstance(c, Fx):
            v = c.v
            if isinstance(v, str):
                return '<c r="%s"%s t="str"><f>%s</f><v>%s</v></c>' % (ref, s, xml_text(c.f), xml_text(v))
            return '<c r="%s"%s><f>%s</f><v>%s</v></c>' % (ref, s, xml_text(c.f), self._num(v))
        if isinstance(c, bool):
            c = int(c)
        if isinstance(c, datetime.datetime):
            d = c.replace(microsecond=0) - self.EPOCH
            return '<c r="%s"%s><v>%s</v></c>' % (ref, s, repr(round(d.days + d.seconds / 86400, 10)))
        if isinstance(c, datetime.date):
            return '<c r="%s"%s><v>%d</v></c>' % (ref, s, (c - self.EPOCH.date()).days)
        if isinstance(c, (int, float)):
            return '<c r="%s"%s><v>%s</v></c>' % (ref, s, self._num(c))
        return '<c r="%s"%s t="s"><v>%d</v></c>' % (ref, s, self._s(xml_text(str(c)[:32000])))

    @staticmethod
    def _num(v):
        if isinstance(v, float):
            if not math.isfinite(v):
                return "0"
            return repr(round(v, 6))
        return str(int(v))

    def sheet(self, name, rows, widths, freeze=0, filt=None, landscape=False):
        """rows: lists of cells. A cell is None, a value (text, number, date) or (value, style); a value can be an Fx.
        freeze: how many rows stay on top. filt: (first row, last row, columns) that get the filter buttons."""
        out, w = [], max([len(r) for r in rows] + [1])
        for i, r in enumerate(rows, 1):
            cells = "".join(self._cell("%s%d" % (col_name(j), i), c) for j, c in enumerate(r))
            out.append('<row r="%d">%s</row>' % (i, cells) if cells else '<row r="%d"/>' % i)
        view = '<sheetView workbookViewId="0"%s%s>' % (' rightToLeft="1"' if self.rtl else "", ' tabSelected="1"' if not self.sheets else "")
        if freeze:
            cell = "A%d" % (freeze + 1)
            view += '<pane ySplit="%d" topLeftCell="%s" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="%s" sqref="%s"/>' % (freeze, cell, cell, cell)
        view += "</sheetView>"
        cols = "".join('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (j + 1, j + 1, wd) for j, wd in enumerate(widths))
        af = ""
        if filt:
            a, b, n = filt
            af = '<autoFilter ref="A%d:%s%d"/>' % (a, col_name(n - 1), b)
            self.names.append((len(self.sheets), "'%s'!$A$%d:$%s$%d" % (name.replace("'", "''"), a, col_name(n - 1), b)))
        xml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
               '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
               '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:%s%d"/><sheetViews>%s</sheetViews><sheetFormatPr defaultRowHeight="15"/>'
               '%s<sheetData>%s</sheetData>%s<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
               '<pageSetup paperSize="9" orientation="%s" fitToWidth="1" fitToHeight="0"/></worksheet>') % (
            col_name(w - 1), max(1, len(rows)), view, "<cols>%s</cols>" % cols if cols else "", "".join(out), af, "landscape" if landscape else "portrait")
        self.sheets.append((name, xml))

    STYLES = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<numFmts count="6"><numFmt numFmtId="164" formatCode="#,##0.00;-#,##0.00;&quot;-&quot;"/><numFmt numFmtId="165" formatCode="#,##0;-#,##0;&quot;-&quot;"/>'
        '<numFmt numFmtId="166" formatCode="yyyy-mm-dd"/><numFmt numFmtId="167" formatCode="yyyy-mm-dd hh:mm"/><numFmt numFmtId="168" formatCode="0.0%"/>'
        '<numFmt numFmtId="169" formatCode="&quot;#&quot;0"/></numFmts>'
        '<fonts count="4"><font><sz val="11"/><name val="Arial"/><family val="2"/></font><font><b/><sz val="15"/><name val="Arial"/><family val="2"/></font>'
        '<font><b/><sz val="11"/><name val="Arial"/><family val="2"/></font><font><i/><sz val="10"/><color rgb="FF6B6B6B"/><name val="Arial"/><family val="2"/></font></fonts>'
        '<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFFDF3DB"/><bgColor indexed="64"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFF4F4F4"/><bgColor indexed="64"/></patternFill></fill></fills>'
        '<borders count="3"><border><left/><right/><top/><bottom/><diagonal/></border>'
        '<border><left/><right/><top/><bottom style="medium"><color rgb="FFECB444"/></bottom><diagonal/></border>'
        '<border><left/><right/><top style="thin"><color rgb="FF0F0F0F"/></top><bottom/><diagonal/></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="15">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'                                                       # TEXT
        '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'                                         # TITLE
        '<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'                               # MONEY
        '<xf numFmtId="164" fontId="2" fillId="3" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>'
        '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'                               # INT
        '<xf numFmtId="165" fontId="2" fillId="3" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>'
        '<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'                               # DATE
        '<xf numFmtId="167" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'                               # STAMP
        '<xf numFmtId="168" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'                               # PCT
        '<xf numFmtId="168" fontId="2" fillId="3" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>'
        '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>'                                         # NOTE
        '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'                                         # BOLD
        '<xf numFmtId="0" fontId="2" fillId="3" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>'           # TOTAL
        '<xf numFmtId="169" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'                               # ORDER_NO
        '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        '<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>')

    def save(self, when):
        """The file, as bytes. when: the local time the report was made (it goes in the file's properties)."""
        n = len(self.sheets)
        ns = 'xmlns="http://schemas.openxmlformats.org/package/2006/relationships"'
        head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        types = (head + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                 '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                 + "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(n))
                 + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                 '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
                 '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                 '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>')
        rels = (head + '<Relationships %s><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>') % ns
        wrels = (head + '<Relationships %s>' % ns
                 + "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n))
                 + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' % (n + 1)
                 + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>' % (n + 2))
        names = "".join('<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">%s</definedName>' % (i, xml_text(ref)) for i, ref in self.names)
        book = (head + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                '<workbookPr/><bookViews><workbookView activeTab="0"/></bookViews><sheets>'
                + "".join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (xml_text(nm), i + 1, i + 1) for i, (nm, _) in enumerate(self.sheets))
                + "</sheets>" + ("<definedNames>%s</definedNames>" % names if names else "") + '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
        sst = (head + '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="%d" uniqueCount="%d">' % (len(self.strings), len(self.strings))
               + "".join('<si><t xml:space="preserve">%s</t></si>' % s for s in self.strings) + "</sst>")
        stamp = when.strftime("%Y-%m-%dT%H:%M:%SZ")
        core = (head + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" '
                'xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
                '<dc:title>%s</dc:title><dc:creator>Why!</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created>'
                '<dcterms:modified xsi:type="dcterms:W3CDTF">%s</dcterms:modified></cp:coreProperties>') % (xml_text(self.title), stamp, stamp)
        app = (head + '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
               'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Why!</Application></Properties>')
        buf = io.BytesIO()
        stamp_t = (max(1980, when.year), when.month, when.day, when.hour, when.minute, when.second)
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            def put(name, text):
                info = zipfile.ZipInfo(name, date_time=stamp_t)
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, text.encode("utf-8"))
            put("[Content_Types].xml", types)
            put("_rels/.rels", rels)
            put("docProps/core.xml", core)
            put("docProps/app.xml", app)
            put("xl/workbook.xml", book)
            put("xl/_rels/workbook.xml.rels", wrels)
            put("xl/styles.xml", self.STYLES)
            put("xl/sharedStrings.xml", sst)
            for i, (_, xml) in enumerate(self.sheets):
                put("xl/worksheets/sheet%d.xml" % (i + 1), xml)
        return buf.getvalue()


REPORT_WORDS = {
    "ar": {
        "title": "تقرير مبيعات واي!", "from": "من تاريخ", "to": "إلى تاريخ", "made": "تاريخ التقرير",
        "note": "المبالغ بالريال السعودي وشاملة ضريبة القيمة المضافة (15%)، ولا تشمل الطلبات المرفوضة.",
        "item": "البند", "value": "القيمة", "n": "عدد الطلبات", "sales": "المبيعات (شامل الضريبة)", "avg": "متوسط قيمة الطلب",
        "vat": "ضريبة القيمة المضافة", "net": "المبيعات بدون الضريبة", "disc": "الخصومات (أكواد الخصم)", "fees": "رسوم التوصيل والشحن",
        "bal": "مدفوع من رصيد المحفظة", "items": "الأصناف المباعة", "free": "منها مجانية (مكافآت وهدايا)", "cust": "عدد العملاء",
        "rej": "الطلبات المرفوضة (غير محسوبة)", "mode": "طريقة الطلب", "orders": "الطلبات", "amount": "المبلغ", "total": "المجموع",
        "pay": "طريقة الدفع", "pay_note": "مبلغ رصيد المحفظة يشمل ما دُفع من الرصيد في كل الطلبات.",
        "s_sum": "الملخص", "s_days": "الأيام", "s_br": "الفروع", "s_prod": "المنتجات", "s_ord": "الطلبات",
        "d_head": ["التاريخ", "اليوم", "الطلبات", "المبيعات", "الضريبة", "بدون الضريبة", "الخصومات", "رسوم التوصيل والشحن", "متوسط الطلب"],
        "b_head": ["الفرع", "الطلبات", "المبيعات", "متوسط الطلب", "النسبة من المبيعات"],
        "p_head": ["المنتج", "القسم", "الكمية", "منها مجانية", "قيمة المبيعات", "النسبة"],
        "p_note": "قيمة المنتجات قبل خصم أكواد الخصم وبدون رسوم التوصيل والشحن، لذلك يختلف مجموعها عن المبيعات.",
        "o_head": ["رقم الطلب", "التاريخ والوقت", "الفرع", "طريقة الطلب", "العميل", "الأصناف", "عدد الأصناف", "قيمة الأصناف", "رسوم التوصيل والشحن",
                   "الخصم", "الإجمالي", "الضريبة", "من رصيد المحفظة", "المدفوع", "طريقة الدفع", "كود الخصم", "الحالة"],
        "done": "مكتمل", "open": "مفتوح", "rw": "مكافأة", "gift": "هدية", "sep": "، ",
        "cut": "يعرض الملف أول %d طلب فقط. المجاميع في الملخص تشمل كل الطلبات، واختر فترة أقصر لرؤية الباقي.",
        "modes": {"pickup": "استلام من الفرع", "delivery": "توصيل", "ship": "شحن"},
        "pays": {"card": "بطاقة الدفع", "apple": "Apple Pay", "mada": "مدى", "stc": "STC Pay", "wallet": "رصيد المحفظة", "points": "النقاط"},
        "week": ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"],
    },
    "en": {
        "title": "Why! sales report", "from": "From", "to": "To", "made": "Report made",
        "note": "Amounts are in Saudi riyals and include 15% VAT. Rejected orders are not included.",
        "item": "Item", "value": "Value", "n": "Orders", "sales": "Sales (incl. VAT)", "avg": "Average order",
        "vat": "VAT", "net": "Sales without VAT", "disc": "Discounts (discount codes)", "fees": "Delivery and shipping fees",
        "bal": "Paid from wallet credit", "items": "Items sold", "free": "Of which free (rewards and gifts)", "cust": "Customers",
        "rej": "Rejected orders (not counted)", "mode": "How it was ordered", "orders": "Orders", "amount": "Amount", "total": "Total",
        "pay": "Payment", "pay_note": "The wallet amount covers what was paid from wallet credit in every order.",
        "s_sum": "Summary", "s_days": "Days", "s_br": "Branches", "s_prod": "Products", "s_ord": "Orders",
        "d_head": ["Date", "Day", "Orders", "Sales", "VAT", "Without VAT", "Discounts", "Delivery and shipping fees", "Average order"],
        "b_head": ["Branch", "Orders", "Sales", "Average order", "Share of sales"],
        "p_head": ["Product", "Category", "Quantity", "Of which free", "Sales value", "Share"],
        "p_note": "Product values are before discount codes and without delivery and shipping fees, so their total differs from sales.",
        "o_head": ["Order", "Date and time", "Branch", "How it was ordered", "Customer", "Items", "Item count", "Items value", "Delivery and shipping fee",
                   "Discount", "Total", "VAT", "From wallet credit", "Paid", "Payment", "Discount code", "Status"],
        "done": "Done", "open": "Open", "rw": "reward", "gift": "gift", "sep": ", ",
        "cut": "The file lists the first %d orders only. The summary totals count every order; choose a shorter period to see the rest.",
        "modes": {"pickup": "Pickup", "delivery": "Delivery", "ship": "Shipping"},
        "pays": {"card": "Payment card", "apple": "Apple Pay", "mada": "mada", "stc": "STC Pay", "wallet": "Wallet credit", "points": "Points"},
        "week": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    },
}


def report_book(R, lang, made, local_dt):
    """The Excel file of one report (R from App.report_data). The totals are formulas, so a figure edited in Excel
    carries through; each formula also holds its value, for phones that only preview the file."""
    W, X = REPORT_WORDS[lang], Xlsx
    nm = lambda d: d.get(lang) or d.get("ar") or ""
    money = lambda c: c / 100.0
    S = R["sum"]
    book = Xlsx(lang == "ar", W["title"])
    q = lambda name: "'%s'" % name.replace("'", "''")

    def total(col, a, b, v, style):   # a column total; an empty table adds up to nothing
        return (Fx("SUM(%s%d:%s%d)" % (col, a, col, b), v) if b >= a else 0, style)

    # ---- the days, with a total row (the summary reads its totals from here)
    days = R["days"]
    rows = [[(h, X.HEAD) for h in W["d_head"]]]
    for i, x in enumerate(days, 2):
        avg = money(x["sales"]) / x["n"] if x["n"] else 0
        rows.append([(x["date"], X.DATE), W["week"][x["date"].weekday()], (x["n"], X.INT), (money(x["sales"]), X.MONEY), (money(x["vat"]), X.MONEY),
                     (Fx("D%d-E%d" % (i, i), money(x["sales"] - x["vat"])), X.MONEY), (money(x["disc"]), X.MONEY), (money(x["fees"]), X.MONEY),
                     (Fx("IF(C%d=0,0,D%d/C%d)" % (i, i, i), avg), X.MONEY)])
    dt, last = len(days) + 2, len(days) + 1
    rows.append([(W["total"], X.TOTAL), ("", X.TOTAL), total("C", 2, last, S["n"], X.INT_T), total("D", 2, last, money(S["sales"]), X.MONEY_T),
                 total("E", 2, last, money(S["vat"]), X.MONEY_T), total("F", 2, last, money(S["sales"] - S["vat"]), X.MONEY_T),
                 total("G", 2, last, money(S["disc"]), X.MONEY_T), total("H", 2, last, money(S["fees"]), X.MONEY_T),
                 (Fx("IF(C%d=0,0,D%d/C%d)" % (dt, dt, dt), money(S["sales"]) / S["n"] if S["n"] else 0), X.MONEY_T)])
    days_rows = rows

    # ---- the products, best sellers first
    prods = R["products"]
    pt, plast, psum = len(prods) + 2, len(prods) + 1, sum(x["sales"] for x in prods)
    rows = [[(h, X.HEAD) for h in W["p_head"]]]
    for i, x in enumerate(prods, 2):
        rows.append([nm(x["name"]), nm(x["cat"]), (x["qty"], X.INT), (x["free"], X.INT), (money(x["sales"]), X.MONEY),
                     (Fx("IF(E$%d=0,0,E%d/E$%d)" % (pt, i, pt), x["sales"] / psum if psum else 0), X.PCT)])
    rows.append([(W["total"], X.TOTAL), ("", X.TOTAL), total("C", 2, plast, S["items"], X.INT_T), total("D", 2, plast, S["free"], X.INT_T),
                 total("E", 2, plast, money(psum), X.MONEY_T), total("F", 2, plast, 1 if psum else 0, X.PCT_T)])
    rows += [[], [(W["p_note"], X.NOTE)]]
    prod_rows = rows

    # ---- the summary
    dq, pq = q(W["s_days"]), q(W["s_prod"])
    # the period as real dates: they read the same way round in any language and sort like dates
    rows = [[(W["title"], X.TITLE)], [(W["from"], X.BOLD), (days[0]["date"], X.DATE)], [(W["to"], X.BOLD), (days[-1]["date"], X.DATE)],
            [(W["made"], X.BOLD), (made.replace(microsecond=0), X.STAMP)], [(W["note"], X.NOTE)], [], [(W["item"], X.HEAD), (W["value"], X.HEAD)]]
    r0 = len(rows) + 1   # the row of "orders"; the rows below follow it
    avg = money(S["sales"]) / S["n"] if S["n"] else 0
    rows += [
        [W["n"], (Fx("%s!C%d" % (dq, dt), S["n"]), X.INT)],
        [W["sales"], (Fx("%s!D%d" % (dq, dt), money(S["sales"])), X.MONEY)],
        [W["avg"], (Fx("IF(B%d=0,0,B%d/B%d)" % (r0, r0 + 1, r0), avg), X.MONEY)],
        [W["vat"], (Fx("%s!E%d" % (dq, dt), money(S["vat"])), X.MONEY)],
        [W["net"], (Fx("B%d-B%d" % (r0 + 1, r0 + 3), money(S["sales"] - S["vat"])), X.MONEY)],
        [W["disc"], (Fx("%s!G%d" % (dq, dt), money(S["disc"])), X.MONEY)],
        [W["fees"], (Fx("%s!H%d" % (dq, dt), money(S["fees"])), X.MONEY)],
        [W["bal"], (money(S["bal"]), X.MONEY)],
        [W["items"], (Fx("%s!C%d" % (pq, pt), S["items"]), X.INT)],
        [W["free"], (Fx("%s!D%d" % (pq, pt), S["free"]), X.INT)],
        [W["cust"], (R["cust"], X.INT)],
        [W["rej"], (S["rej"], X.INT)],
        [],
    ]
    for head, items, key, labels in ((W["mode"], R["modes"], "sales", W["modes"]), (W["pay"], R["pays"], "amount", W["pays"])):
        rows.append([(head, X.HEAD), (W["orders"], X.HEAD), (W["amount"] if key == "amount" else W["d_head"][3], X.HEAD)])
        a = len(rows) + 1
        for x in items:
            rows.append([labels.get(x["id"], x["id"]), (x["n"], X.INT), (money(x[key]), X.MONEY)])
        b = len(rows)
        rows.append([(W["total"], X.TOTAL), total("B", a, b, sum(x["n"] for x in items), X.INT_T), total("C", a, b, money(sum(x[key] for x in items)), X.MONEY_T)])
        if key == "amount" and any(x["id"] == "wallet" for x in items):
            rows.append([(W["pay_note"], X.NOTE)])
        rows.append([])
    book.sheet(W["s_sum"], rows, [36, 20, 16])
    book.sheet(W["s_days"], days_rows, [13, 12, 10, 14, 13, 14, 12, 18, 14], freeze=1)

    # ---- the branches
    brs = R["branches"]
    bt, blast = len(brs) + 2, len(brs) + 1
    rows = [[(h, X.HEAD) for h in W["b_head"]]]
    for i, x in enumerate(brs, 2):
        rows.append([nm(x["name"]), (x["n"], X.INT), (money(x["sales"]), X.MONEY), (Fx("IF(B%d=0,0,C%d/B%d)" % (i, i, i), money(x["sales"]) / x["n"] if x["n"] else 0), X.MONEY),
                     (Fx("IF(C$%d=0,0,C%d/C$%d)" % (bt, i, bt), x["sales"] / S["sales"] if S["sales"] else 0), X.PCT)])
    rows.append([(W["total"], X.TOTAL), total("B", 2, blast, S["n"], X.INT_T), total("C", 2, blast, money(S["sales"]), X.MONEY_T),
                 (Fx("IF(B%d=0,0,C%d/B%d)" % (bt, bt, bt), avg), X.MONEY_T), total("E", 2, blast, 1 if S["sales"] else 0, X.PCT_T)])
    book.sheet(W["s_br"], rows, [32, 10, 14, 14, 18], freeze=1)
    book.sheet(W["s_prod"], prod_rows, [34, 24, 10, 13, 15, 10], freeze=1)

    # ---- every order, one row each
    ords = R["orders"]
    rows = [[(h, X.HEAD) for h in W["o_head"]]]
    for x in ords:
        items = W["sep"].join("%s × %d%s" % (nm(n), k, " (%s)" % W[tag] if tag else "") for n, k, tag in x["items"])
        rows.append([(x["seq"], X.ORDER_NO), (local_dt(x["ts"]).replace(second=0, microsecond=0), X.STAMP), nm(R["bnames"].get(x["branch"]) or {"ar": x["branch"]}),
                     W["modes"].get(x["mode"], x["mode"]), x["cust"], items, (x["nq"], X.INT), (money(x["sub"]), X.MONEY), (money(x["fee"]), X.MONEY),
                     (money(x["disc"]), X.MONEY), (money(x["total"]), X.MONEY), (money(x["vat"]), X.MONEY), (money(x["bal"]), X.MONEY), (money(x["pay"]), X.MONEY),
                     W["pays"].get(x["payM"], x["payM"]), x["code"], W["done"] if x["fin"] else W["open"]])
    olast = len(ords) + 1
    tot = [(W["total"], X.TOTAL)] + [("", X.TOTAL)] * 5 + [total("G", 2, olast, sum(x["nq"] for x in ords), X.INT_T)]
    for col, key in zip("HIJKLMN", ("sub", "fee", "disc", "total", "vat", "bal", "pay")):
        tot.append(total(col, 2, olast, money(sum(x[key] for x in ords)), X.MONEY_T))
    rows.append(tot + [("", X.TOTAL)] * 3)
    if len(ords) < S["n"]:
        rows += [[], [(W["cut"] % len(ords), X.NOTE)]]
    book.sheet(W["s_ord"], rows, [10, 17, 26, 16, 20, 50, 11, 13, 16, 11, 13, 12, 15, 13, 15, 13, 10], freeze=1,
               filt=(1, olast, len(W["o_head"])) if ords else None, landscape=True)
    return book.save(made)

# ---------------------------------------------------------------- limits kept in memory


class Limiter:
    """Sliding-window counters and lock-outs. Lives in memory: a restart clears it, which is fine for abuse limits."""

    def __init__(self):
        self.lock = threading.Lock()
        self.hits = {}
        self.fails = {}

    def allow(self, key, limit, window):
        t = time.time()
        with self.lock:
            if len(self.hits) > 20000:
                self.hits = {k: v for k, v in self.hits.items() if v and v[-1] > t - 3600}
            q = [x for x in self.hits.get(key, []) if x > t - window]
            if len(q) >= limit:
                self.hits[key] = q
                return False, int(q[0] + window - t) + 1
            q.append(t)
            self.hits[key] = q
            return True, 0

    def locked(self, key):
        with self.lock:
            f = self.fails.get(key)
            if f and f[1] > time.time():
                return int(f[1] - time.time()) + 1
            return 0

    def fail(self, key, free=5):
        with self.lock:
            if len(self.fails) > 20000:
                t = time.time()
                self.fails = {k: v for k, v in self.fails.items() if v[1] > t - 3600}
            n, until = self.fails.get(key, (0, 0))
            n += 1
            if n >= free:
                until = time.time() + min(900, 30 * 2 ** (n - free))
            self.fails[key] = (n, until)

    def ok(self, key):
        with self.lock:
            self.fails.pop(key, None)


# ---------------------------------------------------------------- the database

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS staff(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL,
  name TEXT NOT NULL,
  name_key TEXT NOT NULL,
  salt BLOB NOT NULL,
  hash BLOB NOT NULL,
  iters INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS staff_key ON staff(role, name_key);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  staff_id INTEGER NOT NULL,
  role TEXT NOT NULL,
  created INTEGER NOT NULL,
  expires INTEGER NOT NULL,
  seen INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_staff ON sessions(staff_id);
CREATE TABLE IF NOT EXISTS customers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  dev_hash TEXT,
  pts INTEGER NOT NULL DEFAULT 0,
  created INTEGER NOT NULL,
  seen INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS customers_dev ON customers(dev_hash);
CREATE TABLE IF NOT EXISTS bonus(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cust_id INTEGER NOT NULL,
  pts INTEGER NOT NULL,
  ts INTEGER NOT NULL,
  by_name TEXT,
  claimed INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS bonus_cust ON bonus(cust_id, claimed);
CREATE TABLE IF NOT EXISTS orders(
  id TEXT PRIMARY KEY,
  seq INTEGER NOT NULL UNIQUE,
  ts INTEGER NOT NULL,
  day TEXT NOT NULL,
  mode TEXT NOT NULL,
  branch TEXT NOT NULL,
  st INTEGER NOT NULL DEFAULT 0,
  rej INTEGER NOT NULL DEFAULT 0,
  fin INTEGER NOT NULL DEFAULT 0,
  total REAL NOT NULL,
  dev_hash TEXT NOT NULL,
  cid TEXT,
  cust_id INTEGER,
  driver_id INTEGER,
  rev INTEGER NOT NULL,
  data TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS orders_cid ON orders(dev_hash, cid) WHERE cid IS NOT NULL;
CREATE INDEX IF NOT EXISTS orders_day ON orders(day);
CREATE INDEX IF NOT EXISTS orders_dev ON orders(dev_hash, rev);
CREATE INDEX IF NOT EXISTS orders_open ON orders(fin, rej, st);
CREATE INDEX IF NOT EXISTS orders_ts ON orders(ts);
CREATE TABLE IF NOT EXISTS cats(
  id TEXT PRIMARY KEY,
  sort INTEGER NOT NULL,
  gone INTEGER NOT NULL DEFAULT 0,
  data TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products(
  id TEXT PRIMARY KEY,
  sort INTEGER NOT NULL,
  gone INTEGER NOT NULL DEFAULT 0,
  data TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS branches(
  id TEXT PRIMARY KEY,
  sort INTEGER NOT NULL,
  gone INTEGER NOT NULL DEFAULT 0,
  data TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS images(
  id TEXT PRIMARY KEY,
  mime TEXT NOT NULL,
  w INTEGER NOT NULL,
  h INTEGER NOT NULL,
  bg TEXT,
  f TEXT NOT NULL,
  created INTEGER NOT NULL,
  data BLOB NOT NULL,
  tmime TEXT NOT NULL,
  thumb BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cust_id INTEGER NOT NULL,
  ts INTEGER NOT NULL,
  pts INTEGER NOT NULL,
  kind TEXT NOT NULL,
  ref TEXT,
  label TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_cust ON ledger(cust_id, id);
CREATE TABLE IF NOT EXISTS wallet(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cust_id INTEGER NOT NULL,
  ts INTEGER NOT NULL,
  amt INTEGER NOT NULL,
  kind TEXT NOT NULL,
  ref TEXT,
  label TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS wallet_cust ON wallet(cust_id, id);
CREATE TABLE IF NOT EXISTS gifts(
  id TEXT PRIMARY KEY,
  ts INTEGER NOT NULL,
  from_cust INTEGER,
  to_phone TEXT NOT NULL,
  kind TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'new',
  data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS gifts_to ON gifts(to_phone, ts);
CREATE INDEX IF NOT EXISTS gifts_from ON gifts(from_cust, ts);
CREATE TABLE IF NOT EXISTS devices(
  dev_hash TEXT PRIMARY KEY,
  cust_id INTEGER NOT NULL,
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS devices_cust ON devices(cust_id);
CREATE TABLE IF NOT EXISTS push(
  ep TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  who TEXT NOT NULL,
  ref TEXT NOT NULL DEFAULT '',
  lang TEXT NOT NULL DEFAULT 'ar',
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS push_who ON push(who, ref);
CREATE TABLE IF NOT EXISTS push_inbox(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ep TEXT NOT NULL,
  ts INTEGER NOT NULL,
  data TEXT NOT NULL,
  seen INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS push_inbox_ep ON push_inbox(ep, id);
"""


# what a customer tells us when signing up (added after the first version of the table, so they are added on open when missing)
CUSTOMER_COLS = (
    ("email", "TEXT NOT NULL DEFAULT ''"),
    ("birth", "TEXT NOT NULL DEFAULT ''"),
    ("gender", "TEXT NOT NULL DEFAULT ''"),
    ("invite", "TEXT NOT NULL DEFAULT ''"),
    ("mk", "INTEGER NOT NULL DEFAULT 0"),
    ("arev", "INTEGER NOT NULL DEFAULT 0"),     # 0.7: grows with every change of the account (points, wallet, gifts)
    ("opened", "INTEGER NOT NULL DEFAULT 0"),   # 0.7: 1 once the account lives on the server (new, or the phone's balances taken over)
)


# 0.7: an order desk account can belong to one branch ('' = every branch, as before)
STAFF_COLS = (("branch", "TEXT NOT NULL DEFAULT ''"), ("phone", "TEXT NOT NULL DEFAULT ''"))   # phone: a driver's mobile (0.7.5)


def km_between(a_lat, a_lng, b_lat, b_lng):
    """Distance on the ground (haversine), in kilometres."""
    p1, p2 = math.radians(a_lat), math.radians(b_lat)
    dp, dl = p2 - p1, math.radians(b_lng - a_lng)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0 * 2 * math.asin(min(1.0, math.sqrt(h)))


def road_km(pts):
    """Length of a road given as [lat, lng] points, in kilometres."""
    return sum(km_between(pts[j][0], pts[j][1], pts[j + 1][0], pts[j + 1][1]) for j in range(len(pts) - 1))


def on_road(pts, p, start=0):
    """Where the point p is on the road pts: (index of the piece of road he is on, km from the road).
    Only from piece `start` on, so a road that comes back near itself does not make him jump ahead.
    Flat sums over a town are close enough here."""
    kx, ky = 111.32 * math.cos(math.radians(p[0])), 110.57
    px, py, best = p[1] * kx, p[0] * ky, None
    for i in range(max(0, start), len(pts) - 1):
        ax, ay, bx, by = pts[i][1] * kx, pts[i][0] * ky, pts[i + 1][1] * kx, pts[i + 1][0] * ky
        dx, dy = bx - ax, by - ay
        ln = dx * dx + dy * dy
        u = 0.0 if ln == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / ln))
        d = math.hypot(px - ax - u * dx, py - ay - u * dy)
        if best is None or d <= best[1]:
            best = (i, d)
    return best


class DB:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA busy_timeout=8000")
            self.conn.executescript(SCHEMA)
            have = {r["name"] for r in self.conn.execute("PRAGMA table_info(customers)")}
            for col, ddl in CUSTOMER_COLS:
                if col not in have:
                    self.conn.execute("ALTER TABLE customers ADD COLUMN %s %s" % (col, ddl))
            have = {r["name"] for r in self.conn.execute("PRAGMA table_info(staff)")}
            for col, ddl in STAFF_COLS:
                if col not in have:
                    self.conn.execute("ALTER TABLE staff ADD COLUMN %s %s" % (col, ddl))
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def q(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    @contextmanager
    def tx(self):
        with self.lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield self.conn
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise
            else:
                self.conn.execute("COMMIT")

    def backup_to(self, dest):
        with self.lock:
            out = sqlite3.connect(str(dest))
            try:
                self.conn.backup(out)
            finally:
                out.close()


class Catalog:
    """The menu as every page sees it, in the order it is shown. Deleted categories and products stay in it, marked
    gone, so an old order can still name what it held. Never changed in place: a change builds a new one."""

    def __init__(self, crev, cats, prods, branches=()):
        self.crev, self.cats, self.prods, self.branches = crev, cats, prods, list(branches)
        self.C = {c["id"]: c for c in cats}
        self.P = {p["id"]: p for p in prods}
        self.B = {b["id"]: b for b in self.branches}

    def payload(self):
        return {"crev": self.crev, "cats": self.cats, "products": self.prods, "branches": self.branches}

    def live_branches(self):
        return [b for b in self.branches if not b.get("gone")]

    def kind(self, p):
        c = self.C.get(p["cat"])
        return c["kind"] if c else "drink"

    def live_cats(self):
        return [c for c in self.cats if not c.get("gone")]

    def live_prods(self):
        return [p for p in self.prods if not p.get("gone")]


class Hub:
    """The revision counter staff screens wait on."""

    def __init__(self, rev=0):
        self.cond = threading.Condition()
        self.rev = rev

    def publish(self, rev):
        with self.cond:
            self.rev = rev
            self.cond.notify_all()

    def wait(self, since, timeout):
        with self.cond:
            self.cond.wait_for(lambda: self.rev != since, timeout)
            return self.rev


# ---------------------------------------------------------------- the application


class App:
    def __init__(self, db_path, catalog_path=None, iters=200_000, tz_min=180, static=None, backups=True, keep_backups=14, quiet=False, push_test=False):
        self.db = DB(db_path)
        self.cat = json.loads(Path(catalog_path or HERE / "catalog.json").read_text(encoding="utf-8"))
        self.iters = iters
        self.tz_min = tz_min
        self.static = Path(static).resolve() if static else None
        self.limit = Limiter()
        self.pollers = threading.BoundedSemaphore(48)
        self.keep_backups = keep_backups
        self.quiet = quiet
        self.backup_dir = Path(db_path).resolve().parent / "backups"
        self.stop = threading.Event()
        self.locs = {}   # driver id -> where his phone was last, only in memory: (lat, lng, accuracy m, time ms)
        self.push_test = push_test   # tests send pushes to a pretend push service on this machine (http://127.0.0.1)
        self.push_q = queue.Queue(maxsize=2000)
        self.jwts = {}               # push service origin -> (token, valid until)
        self.mail_post = self._mail_post   # 0.7.7: tests put a pretend mail service here
        self.otps, self.otp_lock, self.wa_send = {}, threading.Lock(), self._wa_send   # 0.7.6: phone -> the code sent to it
        self.routes, self.route_busy, self.route_url = {}, set(), ROUTE_URL   # order id -> the road from the driver to the door
        self.route_next = {}   # order id -> not before this time may the road be asked for again
        with self.db.tx() as c:
            rev = int(self._kv(c, "rev", "0")) + 1
            self._set_kv(c, "rev", str(rev))
            self.srev = int(self._kv(c, "srev", "1"))
            raw = self._kv(c, "settings", "")
            self.settings = self.default_settings()
            if raw:
                saved = json.loads(raw)
                self.settings.update({k: v for k, v in saved.items() if k != "delivery"})
                self.settings["delivery"].update(saved.get("delivery", {}))
                if not clean_tiers(self.settings.get("tiers")):   # a database from before 0.5.1, or a damaged value
                    self.settings["tiers"] = [dict(t) for t in DEFAULT_TIERS]
                if not isinstance(self.settings.get("rewards"), list):   # before 0.6: the rewards of catalog.json
                    self.settings["rewards"] = [dict(r, on=True) for r in self.cat["rewards"]]
                if not isinstance(self.settings.get("banners"), list):
                    self.settings["banners"] = [{"id": b} for b in self.cat["banners"]]
                if not isinstance(self.settings.get("news"), list):   # before 0.6.4: the news written in the app
                    self.settings["news"] = [{"id": n} for n in self.cat.get("news", [])]
            else:
                self._set_kv(c, "settings", json.dumps(self.settings, ensure_ascii=False))
            if self._kv(c, "seq", "") == "":
                self._set_kv(c, "seq", "1000")
            vk = self._kv(c, "vapid", "")   # the server's own push key, made once
            if not vk:
                vk = "%064x" % (secrets.randbelow(P256_N - 1) + 1)
                self._set_kv(c, "vapid", vk)
            self.vapid_d = int(vk, 16)
            self.crev = int(self._kv(c, "crev", "0"))
            if self._kv(c, "catalog", "") != "1":
                self._seed_catalog(c)
            if self._kv(c, "branches", "") != "1":   # 0.4.0 had the menu in the database but not yet the branches
                self._seed_branches(c)
            self._gc_images(c)
            self.catalog = self._read_catalog(c, self.crev)
        # what the first menu said, to tell pages built before 0.4 how the menu differs from theirs (see compat_menu)
        self.seed_ref = {p["id"]: (p["price"], p.get("stock", True) is not False) for p in (self.cat.get("seed") or {}).get("products", [])}
        (self.cat.get("seed") or {}).pop("images", None)   # copied into the database once; no need to keep them in memory
        self.rev = rev
        self.hub = Hub(rev)
        if backups:
            threading.Thread(target=self._backup_loop, daemon=True, name="backup").start()
        x, y = ec_mul(self.vapid_d)
        self.vapid_pub = b64u(b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big"))
        # tests reach the pretend push service directly; on the server the usual network settings apply
        self.push_open = urllib.request.build_opener(urllib.request.ProxyHandler({})).open if push_test else urllib.request.urlopen
        threading.Thread(target=self._push_loop, daemon=True, name="push").start()

    # ---- the menu in the database
    def _seed_catalog(self, c):
        """The first start: copy the menu of catalog.json into the database. A database from before 0.4 kept the admin's
        price and availability changes as overrides in the settings; they are applied here, then the overrides go."""
        seed = self.cat.get("seed") or {}
        for i, x in enumerate(seed.get("cats") or []):
            c.execute("INSERT OR IGNORE INTO cats(id,sort,gone,data) VALUES(?,?,0,?)", (x["id"], i, json.dumps({"ar": x["ar"], "en": x.get("en") or "", "kind": x["kind"]}, ensure_ascii=False)))
        imgs, t = {}, now_ms()
        for pid, im in (seed.get("images") or {}).items():
            full, thumb = base64.b64decode(im["full"]), base64.b64decode(im["thumb"])
            fi, ti = image_info(full), image_info(thumb)
            if not fi or not ti:
                continue
            iid = hashlib.sha256(full).hexdigest()[:32]
            c.execute("INSERT OR IGNORE INTO images(id,mime,w,h,bg,f,created,data,tmime,thumb) VALUES(?,?,?,?,?,?,?,?,?,?)", (iid, fi[0], fi[1], fi[2], im.get("bg"), im.get("f") or "c", t, full, ti[0], thumb))
            imgs[pid] = {"id": iid, "bg": im.get("bg"), "f": im.get("f") or "c", "r": round(fi[1] / fi[2], 4)}
        menu = self.settings.get("menu") or {}
        for i, p in enumerate(seed.get("products") or []):
            q = {
                "cat": p["cats"][0], "cats": list(p["cats"]), "ar": p["ar"], "en": p.get("en") or "", "price": p["price"], "cal": int(p.get("cal") or 0),
                "art": p.get("art") or "hot", "tone": p.get("tone") or "#C8965A", "opts": list(p.get("opts") or []),
                "desc": or_none(p.get("desc")), "sub": or_none(p.get("sub")), "d": p.get("d") or None, "badge": or_none(p.get("badge")),
                "stock": p.get("stock", True) is not False, "fship": bool(p.get("fship")), "img": imgs.get(p["id"]),
            }
            o = menu.get(p["id"]) or {}
            if isinstance(o.get("price"), (int, float)) and not isinstance(o.get("price"), bool):
                q["price"] = o["price"]
            if isinstance(o.get("stock"), bool):
                q["stock"] = o["stock"]
            q["id"] = p["id"]
            c.execute("INSERT OR IGNORE INTO products(id,sort,gone,data) VALUES(?,?,0,?)", (p["id"], i, json.dumps(q, ensure_ascii=False)))
        self.settings["menu"] = {}
        self._set_kv(c, "settings", json.dumps(self.settings, ensure_ascii=False))
        self.crev += 1
        self._set_kv(c, "crev", str(self.crev))
        self._set_kv(c, "catalog", "1")

    def _seed_branches(self, c):
        seed = (self.cat.get("seed") or {}).get("branches") or [{"id": i, "ar": i, "en": i, "addr": {"ar": i, "en": ""}, "h": "24"} for i in self.cat.get("branches", ["b1"])]
        for i, b in enumerate(seed):
            q = {"ar": b["ar"], "en": b.get("en") or "", "addr": pair(b.get("addr"), 160), "h": b.get("h") or "24", "lat": b.get("lat"), "lng": b.get("lng")}
            c.execute("INSERT OR IGNORE INTO branches(id,sort,gone,data) VALUES(?,?,0,?)", (b["id"], i, json.dumps(q, ensure_ascii=False)))
        self.crev += 1
        self._set_kv(c, "crev", str(self.crev))
        self._set_kv(c, "branches", "1")

    @staticmethod
    def _read_catalog(c, crev):
        cats, prods = [], []
        for r in c.execute("SELECT id, gone, data FROM cats ORDER BY sort, id"):
            x = json.loads(r["data"])
            x["id"] = r["id"]
            if r["gone"]:
                x["gone"] = 1
            cats.append(x)
        for r in c.execute("SELECT id, gone, data FROM products ORDER BY sort, id"):
            x = json.loads(r["data"])
            x["id"] = r["id"]
            if r["gone"]:
                x["gone"] = 1
            prods.append(x)
        brs = []
        for r in c.execute("SELECT id, gone, data FROM branches ORDER BY sort, id"):
            x = json.loads(r["data"])
            x["id"] = r["id"]
            if r["gone"]:
                x["gone"] = 1
            brs.append(x)
        return Catalog(crev, cats, prods, brs)

    def _gc_images(self, c):
        """Photos no product uses any more (replaced, removed, or uploaded and never saved) go after a grace period."""
        used = set()
        for r in c.execute("SELECT data FROM products"):
            im = json.loads(r["data"]).get("img")
            if im:
                used.add(im["id"])
        st = getattr(self, "settings", None) or {}
        for b in (st.get("banners") or []) + (st.get("news") or []):
            if isinstance(b, dict) and isinstance(b.get("img"), dict):
                used.add(b["img"].get("id"))
        for r in c.execute("SELECT id FROM images WHERE created<?", (now_ms() - IMG_GRACE_MS,)).fetchall():
            if r["id"] not in used:
                c.execute("DELETE FROM images WHERE id=?", (r["id"],))

    def close(self):
        self.stop.set()
        try:
            self.push_q.put_nowait(None)
        except queue.Full:
            pass
        with self.db.lock:
            self.db.conn.close()

    # ---- key/value and counters
    @staticmethod
    def _kv(c, k, default=""):
        r = c.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return r[0] if r else default

    @staticmethod
    def _set_kv(c, k, v):
        c.execute("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))

    def default_settings(self):
        return {
            "menu": {},
            "br": {},
            "bn": {},
            "codes": {"WHY10": {"on": True, "pct": 10}},
            "ship": self.cat["ship_fee"],
            "delivery": {"on": True, "fee": self.cat["delivery_fee"], "km": 0, "min": 0},   # km, min: 0 = no limit (0.7)
            "tiers": [dict(t) for t in DEFAULT_TIERS],
            "rewards": [dict(r, on=True) for r in self.cat["rewards"]],
            "banners": [{"id": b} for b in self.cat["banners"]],   # a banner of the first set shows the page's own picture and words
            "news": [{"id": n} for n in self.cat.get("news", [])],   # the same for the first news
        }

    def _bump(self, c, settings=False, catalog=False):
        """Called inside a transaction: new revision, saved with the change itself.
        A menu change is also a public change: pages from before 0.4 read the menu from the public settings."""
        self.rev += 1
        self._set_kv(c, "rev", str(self.rev))
        if settings or catalog:
            self.srev += 1
            self._set_kv(c, "srev", str(self.srev))
        if settings:
            self._set_kv(c, "settings", json.dumps(self.settings, ensure_ascii=False))
        if catalog:
            self.crev += 1
            self._set_kv(c, "crev", str(self.crev))
        return self.rev

    def mutate(self, fn, settings=False, catalog=False):
        with self.db.lock:   # the new menu is put in place before anyone else can change it again
            with self.db.tx() as c:
                snap = json.dumps(self.settings) if settings else None
                try:
                    res = fn(c)
                except BaseException:
                    if snap is not None:
                        self.settings = json.loads(snap)
                    raise
                rev = self._bump(c, settings, catalog)
                new = self._read_catalog(c, self.crev) if catalog else None
            if new:
                self.catalog = new
        self.hub.publish(rev)
        return res

    def day_of(self, ts):
        t = time.gmtime(ts / 1000 + self.tz_min * 60)
        return "%04d-%02d-%02d" % (t.tm_year, t.tm_mon, t.tm_mday)

    def today(self):
        return self.day_of(now_ms())

    def snap(self):
        with self.db.lock:
            return json.loads(json.dumps(self.settings))

    # ---- backups
    def _backup_loop(self):
        while not self.stop.wait(1800):
            try:
                self.backup()
            except Exception as e:  # never let a backup problem stop the server
                print("backup failed:", e, file=sys.stderr, flush=True)
            try:
                self.mail_backup()
            except Exception as e:
                print("backup mail failed:", e, file=sys.stderr, flush=True)

    def backup(self, force=False):
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        dest = self.backup_dir / ("why-%s.db" % self.today())
        if dest.exists() and not force:
            return None
        tmp = dest.with_suffix(".tmp")
        self.db.backup_to(tmp)
        os.chmod(tmp, 0o600)
        tmp.replace(dest)
        old = sorted(self.backup_dir.glob("why-*.db"))
        for f in old[: max(0, len(old) - self.keep_backups)]:
            f.unlink()
        return dest

    # ---------------------------------------------------------------- push notifications (0.7)
    def _push_url_ok(self, url):
        if not isinstance(url, str) or len(url) > 1000:
            return False
        u = urllib.parse.urlsplit(url)
        if self.push_test and u.scheme == "http" and u.hostname == "127.0.0.1":
            return True
        host = (u.hostname or "").lower()
        return u.scheme == "https" and any(host == h or host.endswith("." + h) for h in PUSH_HOSTS)

    def push_sub(self, who, ref, body):
        """This phone or tablet wants the notifications of who/ref (a customer, a desk, a driver)."""
        url = body.get("endpoint")
        if not self._push_url_ok(url):
            raise ApiError(400, "bad_push")
        lang = "en" if body.get("lang") == "en" else "ar"
        with self.db.tx() as c:
            c.execute("INSERT INTO push(ep,url,who,ref,lang,ts) VALUES(?,?,?,?,?,?) ON CONFLICT(ep) DO UPDATE SET who=excluded.who, ref=excluded.ref, lang=excluded.lang, ts=excluded.ts",
                      (sha(url), url, who, str(ref), lang, now_ms()))
        return {}

    def push_off(self, body):
        url = body.get("endpoint")
        if isinstance(url, str) and len(url) <= 1000:
            ep = sha(url)
            with self.db.tx() as c:
                c.execute("DELETE FROM push WHERE ep=?", (ep,))
                c.execute("DELETE FROM push_inbox WHERE ep=?", (ep,))
        return {}

    def push_inbox(self, body):
        """What a push says: the service worker of the phone that got it asks, with the address of its subscription."""
        url = body.get("endpoint")
        if not isinstance(url, str) or len(url) > 1000:
            raise ApiError(400, "bad_push")
        ep = sha(url)
        with self.db.tx() as c:
            rows = c.execute("SELECT id, data FROM push_inbox WHERE ep=? AND seen=0 ORDER BY id LIMIT 5", (ep,)).fetchall()
            if rows:
                c.execute("UPDATE push_inbox SET seen=1 WHERE ep=? AND id<=?", (ep, rows[-1]["id"]))
            else:   # its message went with an earlier push: the last one again (same tag, so it replaces quietly)
                rows = c.execute("SELECT id, data FROM push_inbox WHERE ep=? ORDER BY id DESC LIMIT 1", (ep,)).fetchall()
        return {"items": [json.loads(r["data"]) for r in rows]}

    def push(self, who, refs, title, body, url, tag):
        """A message for every phone of these people (title and body in Arabic and English): kept in the inbox, then
        pushed in the background. refs: the customers / desks / drivers it is for; None = everyone of that kind."""
        if refs is not None:
            refs = [str(r) for r in refs if r is not None and r != ""]
            if not refs:
                return
        rows = self.db.q("SELECT ep, url, lang FROM push WHERE who=?" + ("" if refs is None else " AND ref IN (%s)" % ",".join("?" * len(refs))), [who] + (refs or []))
        if not rows:
            return
        t = now_ms()
        with self.db.tx() as c:
            c.execute("DELETE FROM push_inbox WHERE ts<?", (t - 2 * 86400_000,))
            for r in rows:
                data = {"t": title[r["lang"]], "b": body[r["lang"]], "url": url, "tag": tag, "lang": r["lang"]}
                c.execute("INSERT INTO push_inbox(ep,ts,data) VALUES(?,?,?)", (r["ep"], t, json.dumps(data, ensure_ascii=False)))
        for r in rows:
            try:
                self.push_q.put_nowait((r["ep"], r["url"]))
            except queue.Full:
                break

    def _vapid(self, url):
        """The signed token that tells the push service the push comes from this server (VAPID)."""
        u = urllib.parse.urlsplit(url)
        aud, t = "%s://%s" % (u.scheme, u.netloc), int(time.time())
        tok = self.jwts.get(aud)
        if not tok or tok[1] < t + 600:
            js = lambda d: b64u(json.dumps(d, separators=(",", ":")).encode())
            head = js({"typ": "JWT", "alg": "ES256"}) + "." + js({"aud": aud, "exp": t + 12 * 3600, "sub": "https://whyroasteryco.com"})
            tok = (head + "." + b64u(es256_sign(self.vapid_d, head.encode())), t + 12 * 3600)
            self.jwts[aud] = tok
        return "vapid t=%s, k=%s" % (tok[0], self.vapid_pub)

    def _push_loop(self):
        while True:
            item = self.push_q.get()
            if item is None or self.stop.is_set():
                return
            ep, url = item
            try:
                req = urllib.request.Request(url, data=b"", method="POST", headers={"TTL": "86400", "Urgency": "high", "Authorization": self._vapid(url)})
                with self.push_open(req, timeout=15) as r:
                    r.read()
            except urllib.error.HTTPError as e:
                if e.code in (404, 410):   # the phone unsubscribed, or the subscription ran out
                    try:
                        with self.db.tx() as c:
                            c.execute("DELETE FROM push WHERE ep=?", (ep,))
                    except Exception:
                        pass
                elif not self.quiet:
                    print("push failed:", e.code, file=sys.stderr, flush=True)
            except Exception as e:  # a push problem never stops the server
                if not self.quiet:
                    print("push failed:", e, file=sys.stderr, flush=True)

    # what each person hears, and when
    def _order_cust(self, oid):
        r = self.db.one("SELECT cust_id FROM orders WHERE id=?", (oid,))
        return r["cust_id"] if r else None

    def push_new_order(self, o):
        no, b = o["no"].replace("\u200e", ""), self.catalog.B.get(o["branch"], {})
        kind = {"pickup": ("استلام", "Pickup"), "delivery": ("توصيل", "Delivery"), "ship": ("شحن", "Shipping")}[o["mode"]]
        when = ""
        if o.get("pick"):
            hm = time.gmtime(o["pick"] / 1000 + self.tz_min * 60)
            when = " · %d:%02d" % (hm.tm_hour, hm.tm_min)
        self.push("recv", ["*", o["branch"]], {"ar": "طلب جديد %s" % no, "en": "New order %s" % no},
                  {"ar": "%s%s · %s · %s ر.س" % (kind[0], when, b.get("ar", ""), fmt_sar(o["total"])), "en": "%s%s · %s · %s SAR" % (kind[1], when, b.get("en") or b.get("ar", ""), fmt_sar(o["total"]))},
                  "/reception/", "o-" + o["id"])

    def push_for_drivers(self, o):
        no, b = o["no"].replace("\u200e", ""), self.catalog.B.get(o["branch"], {})
        a = o.get("addr") or {}
        self.push("driver", None, {"ar": "طلب توصيل %s" % no, "en": "Delivery %s" % no},
                  {"ar": "من %s إلى %s" % (b.get("ar", ""), a.get("street") or a.get("city") or ""), "en": "From %s to %s" % (b.get("en") or b.get("ar", ""), a.get("street") or a.get("city") or "")},
                  "/driver/", "o-" + o["id"])

    def push_order_event(self, o, op, role):
        """After the desk or a driver moved an order."""
        no, cid, tag = o["no"].replace("\u200e", ""), self._order_cust(o["id"]), "o-" + o["id"]
        mode, st = o["mode"], o["st"]
        to_cust = lambda t, b: self.push("cust", [cid], t, b, "/#o=" + o["id"], tag) if cid else None   # a tap opens this order
        if op == "reject":
            w = o["rej"]["why"]
            to_cust({"ar": "تعذّر تنفيذ طلبك %s" % no, "en": "Order %s could not be prepared" % no},
                    {"ar": "%s. سيُرد المبلغ المدفوع، وتعود نقاطك ورصيدك." % w["ar"], "en": "%s. Your payment will be refunded and your points and balance are back." % w["en"]})
        elif op == "accept":
            to_cust({"ar": "طلبك %s قيد %s" % (no, "التجهيز" if mode == "ship" else "التحضير"), "en": "Order %s is being %s" % (no, "packed" if mode == "ship" else "prepared")},
                    {"ar": "بدأ الفرع العمل على طلبك.", "en": "The branch started on your order."})
            if mode == "delivery" and not o.get("driver"):
                self.push_for_drivers(o)
        elif op == "ready":
            if mode == "pickup":
                to_cust({"ar": "طلبك %s جاهز للاستلام" % no, "en": "Order %s is ready" % no}, {"ar": "أظهر رمز الاستلام للموظف.", "en": "Show your pickup code to the staff."})
            elif mode == "ship":
                to_cust({"ar": "تم شحن طلبك %s" % no, "en": "Order %s has shipped" % no}, {"ar": "مع %s · رقم الشحنة %s" % (o["carrier"], o["code"]), "en": "With %s · tracking %s" % (o["carrier"], o["code"])})
            elif o.get("driver"):
                to_cust({"ar": "طلبك %s في الطريق إليك" % no, "en": "Order %s is on its way" % no}, {"ar": "المندوب %s في الطريق. جهّز رمز الاستلام." % o["driver"]["name"], "en": "%s is bringing it. Have your code ready." % o["driver"]["name"]})
            else:
                self.push_for_drivers(o)
        elif op == "take" and st == 2:
            to_cust({"ar": "طلبك %s في الطريق إليك" % no, "en": "Order %s is on its way" % no}, {"ar": "المندوب %s في الطريق. جهّز رمز الاستلام." % o["driver"]["name"], "en": "%s is bringing it. Have your code ready." % o["driver"]["name"]})
        elif op in ("release", "unassign"):
            self.push_for_drivers(o)
        elif op == "arrive":
            d = o["driver"]["name"]
            to_cust({"ar": "المندوب وصل بطلبك %s" % no, "en": "Your driver is here with order %s" % no},
                    {"ar": "%s عند موقعك الآن. جهّز رمز الاستلام." % d, "en": "%s is at your place now. Have your code ready." % d})
        elif op == "deliver" and o["fin"] and mode != "pickup":
            to_cust({"ar": "تم توصيل طلبك %s" % no, "en": "Order %s was delivered" % no}, {"ar": "بالعافية! قيّم طلبك من التطبيق.", "en": "Enjoy! Rate your order in the app."})

    # ---------------------------------------------------------------- staff accounts and sessions
    def hash_pin(self, pin, salt, iters):
        return hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt, iters)

    def set_staff(self, role, name, pin, staff_id=None):
        """Create or update an account. A changed PIN signs that account out everywhere."""
        if not valid_pin(pin):
            raise ApiError(400, "bad_pin")
        salt = secrets.token_bytes(16)
        h = self.hash_pin(pin, salt, self.iters)
        key = name_key(name)

        def go(c):
            row = c.execute("SELECT id FROM staff WHERE id=?", (staff_id,)).fetchone() if staff_id else c.execute("SELECT id FROM staff WHERE role=? AND name_key=?", (role, key)).fetchone()
            if row:
                c.execute("UPDATE staff SET hash=?, salt=?, iters=? WHERE id=?", (h, salt, self.iters, row["id"]))
                c.execute("DELETE FROM sessions WHERE staff_id=?", (row["id"],))
                return row["id"]
            cur = c.execute("INSERT INTO staff(role,name,name_key,salt,hash,iters,active,created) VALUES(?,?,?,?,?,?,1,?)", (role, name, key, salt, h, self.iters, now_ms()))
            return cur.lastrowid

        return self.mutate(go)

    def login(self, role, name, pin, ip, branch=None):
        if role not in ROLES:
            raise ApiError(404, "not_found")
        if role == "driver":
            name = clean(name, 40)
            if not name or not isinstance(pin, str):
                raise ApiError(400, "bad_request")
        elif role == "recv" and branch:   # 0.7: the order desk of one branch
            if not isinstance(branch, str) or branch not in self.catalog.B:
                raise ApiError(400, "bad_request")
            name = DESK_PREFIX + branch
        else:
            name = role
        k_ip, k_acc = ("login", role, ip), ("login-acc", role, name_key(name))
        for k in (k_ip, k_acc):
            wait = self.limit.locked(k)
            if wait:
                raise ApiError(429, "locked", retry=wait)
        row = self.db.one("SELECT * FROM staff WHERE role=? AND name_key=? AND active=1", (role, name_key(name)))
        salt, iters, good = (row["salt"], row["iters"], row["hash"]) if row else (b"\0" * 16, self.iters, b"\0" * 32)
        h = self.hash_pin(pin if isinstance(pin, str) else "", salt, iters)
        if not (row and isinstance(pin, str) and hmac.compare_digest(h, good)):
            self.limit.fail(k_ip)
            self.limit.fail(k_acc, free=8)
            raise ApiError(401, "bad_login")
        self.limit.ok(k_ip)
        self.limit.ok(k_acc)
        token = secrets.token_urlsafe(32)
        t = now_ms()
        ttl = SESSION_DAYS[role] * 86400 * 1000
        with self.db.tx() as c:
            c.execute("DELETE FROM sessions WHERE expires<?", (t,))
            c.execute("INSERT INTO sessions(token_hash,staff_id,role,created,expires,seen) VALUES(?,?,?,?,?,?)", (sha(token), row["id"], role, t, t + ttl, t))
        return token, {"id": row["id"], "role": role, "name": row["name"], "branch": row["branch"]}, ttl // 1000

    def session(self, role, token):
        if not token or len(token) > 100:
            return None
        t = now_ms()
        r = self.db.one(
            "SELECT s.staff_id, s.expires, s.seen, f.name, f.role, f.branch, f.phone FROM sessions s JOIN staff f ON f.id=s.staff_id WHERE s.token_hash=? AND s.role=? AND f.active=1",
            (sha(token), role),
        )
        if not r or r["expires"] < t:
            return None
        if t - r["seen"] > 3600_000:
            with self.db.tx() as c:
                c.execute("UPDATE sessions SET seen=?, expires=? WHERE token_hash=?", (t, t + SESSION_DAYS[role] * 86400_000, sha(token)))
        return {"id": r["staff_id"], "role": role, "name": r["name"], "branch": r["branch"], "phone": r["phone"]}

    def logout(self, token):
        if token:
            with self.db.tx() as c:
                c.execute("DELETE FROM sessions WHERE token_hash=?", (sha(token),))

    def verify_admin_pin(self, staff, pin, ip):
        k = ("verify", staff["id"])
        wait = self.limit.locked(k)
        if wait:
            raise ApiError(429, "locked", retry=wait)
        row = self.db.one("SELECT * FROM staff WHERE id=?", (staff["id"],))
        h = self.hash_pin(pin if isinstance(pin, str) else "", row["salt"], row["iters"])
        if not (isinstance(pin, str) and hmac.compare_digest(h, row["hash"])):
            self.limit.fail(k, free=4)
            raise ApiError(403, "bad_pin_confirm")
        self.limit.ok(k)

    # ---------------------------------------------------------------- the menu, as the server prices it
    def sel_clean(self, p, sel):
        """The options of one product: a valid choice for every group, nothing unknown."""
        sel = sel if isinstance(sel, dict) else {}
        out, delta = {}, 0
        for g in p["opts"]:
            G = self.cat["opts"].get(g)
            if not G:
                continue
            ids = {i["id"]: i["d"] for i in G["items"]}
            x = sel.get(g)
            if G["type"] == "check":
                picked = []
                for v in (x if isinstance(x, list) else []):
                    if isinstance(v, str) and v in ids and v not in picked:
                        picked.append(v)
                out[g] = picked
                delta += sum(ids[v] for v in picked)
            else:
                if not (isinstance(x, str) and x in ids):
                    x = G["items"][0]["id"]
                out[g] = x
                delta += ids[x]
        return out, half_up(delta * 100)

    def compat_menu(self):
        """Pages built before 0.4 carry the first menu and expect only the changes to it: price and availability.
        A deleted product reads as unavailable to them; products added later they cannot show at all."""
        out, P = {}, self.catalog.P
        for pid, (price, stock) in self.seed_ref.items():
            p = P.get(pid)
            if not p:
                continue
            if p.get("gone"):
                out[pid] = {"stock": False}
                continue
            m = {}
            if p["price"] != price:
                m["price"] = p["price"]
            if p["stock"] != stock:
                m["stock"] = p["stock"]
            if m:
                out[pid] = m
        return out

    def public_cfg(self):
        st = self.snap()
        return {
            "srev": self.srev,
            "menu": self.compat_menu(),
            "br": st["br"],
            "bn": st["bn"],
            "codes": {k: {"on": True, "pct": v["pct"]} for k, v in st["codes"].items() if v.get("on")},
            "ship": st["ship"],
            "delivery": st["delivery"],
            "tiers": st["tiers"],
            "tdays": TIER_DAYS,
            "rewards": [r for r in st["rewards"] if r.get("on", True) is not False],
            "banners": st["banners"],
            "news": [n for n in st["news"] if n.get("on", True) is not False],
        }

    # ---- membership tiers
    def tier_points(self, ex, cust_id, t):
        """The points of the last TIER_DAYS days that decide a customer's tier: points of his orders the café did not turn
        down, the bonus points the admin sent him, and the welcome points while the account is new.
        ex(sql, args) gives the first column of the first row (inside or outside a transaction)."""
        since = t - TIER_DAYS * 86400_000
        pts = ex("SELECT COALESCE(SUM(CAST(json_extract(data,'$.earn') AS INTEGER)),0) FROM orders WHERE cust_id=? AND rej=0 AND ts>=?", (cust_id, since))
        pts += ex("SELECT COALESCE(SUM(pts),0) FROM bonus WHERE cust_id=? AND ts>=?", (cust_id, since))
        pts += ex("SELECT COALESCE(SUM(CAST(json_extract(data,'$.earn') AS INTEGER)),0) FROM gifts WHERE from_cust=? AND kind IN ('card','item') AND state IN ('new','used') AND ts>=?", (cust_id, since))
        if ex("SELECT COUNT(*) FROM customers WHERE id=? AND created>=?", (cust_id, since)):
            pts += WELCOME_PTS
        return int(pts)

    def _db_ex(self, sql, args):
        r = self.db.one(sql, args)
        return r[0] if r else 0

    def tier_of_customer(self, cust_id, t=None):
        t = t or now_ms()
        pts = self.tier_points(self._db_ex, cust_id, t) if cust_id else 0
        return {"id": tier_for(pts, self.snap()["tiers"])["id"], "pts": pts}

    # ---- rewards the customer buys with points
    def admin_reward(self, b):
        op = b.get("op")
        if op == "del":
            rid = b.get("id")

            def go(c):
                l = self.settings["rewards"]
                if not any(r["id"] == rid for r in l):
                    raise ApiError(404, "not_found")
                self.settings["rewards"] = [r for r in l if r["id"] != rid]
            self.mutate(go, settings=True)
            return {}
        if op != "save" or not isinstance(b.get("r"), dict):
            raise ApiError(400, "bad_request")
        r = b["r"]
        pts, pid, credit, on = r.get("pts"), r.get("pid"), r.get("credit"), r.get("on", True)
        if isinstance(pts, bool) or not isinstance(pts, int) or not 1 <= pts <= 100_000 or not isinstance(on, bool):
            raise ApiError(400, "bad_reward")
        q = {"pts": pts, "on": on}
        if pid is not None:
            p = self.catalog.P.get(pid) if isinstance(pid, str) else None
            if not p or p.get("gone") or credit is not None:
                raise ApiError(400, "bad_reward")
            q["pid"], dar, den = pid, p["ar"], p["en"] or p["ar"]
        else:
            if isinstance(credit, bool) or not isinstance(credit, (int, float)) or not 1 <= credit <= 1000:
                raise ApiError(400, "bad_reward")
            q["credit"] = half_up(credit * 100) / 100
            amt = ("%g" % q["credit"])
            dar, den = "رصيد %s ريال في المحفظة" % amt, "%s SAR wallet credit" % amt
        q["ar"], q["en"] = clean(r.get("ar"), 40) or dar, clean(r.get("en"), 40) or den
        rid = r.get("id")

        def go(c):
            l = self.settings["rewards"]
            if rid is None:
                if len(l) >= MAX_REWARDS:
                    raise ApiError(409, "too_many")
                q["id"] = "r" + secrets.token_hex(4)
                l.append(q)
            else:
                i = next((k for k, x in enumerate(l) if x["id"] == rid), None)
                if i is None:
                    raise ApiError(404, "not_found")
                q["id"] = rid
                l[i] = q
            return q
        return {"reward": self.mutate(go, settings=True)}

    # ---- home page banners: the first five show the page's own pictures until the admin changes them
    def _image_ref(self, v):
        if v is None:
            return None
        iid = v.get("id") if isinstance(v, dict) else None
        if not isinstance(iid, str) or not re.fullmatch(r"[0-9a-f]{32}", iid):
            raise ApiError(400, "bad_img")
        r = self.db.one("SELECT w,h FROM images WHERE id=?", (iid,))
        if not r:
            raise ApiError(400, "bad_img")
        return {"id": iid, "r": round(r["w"] / r["h"], 4)}

    def admin_banner(self, b):
        op, bid = b.get("op"), b.get("id")
        if op in ("del", "up", "down"):
            def go(c):
                l = self.settings["banners"]
                i = next((k for k, x in enumerate(l) if x["id"] == bid), None)
                if i is None:
                    raise ApiError(404, "not_found")
                if op == "del":
                    if not any(self.settings["bn"].get(x["id"]) is not False for k, x in enumerate(l) if k != i):
                        raise ApiError(409, "last_banner")
                    l.pop(i)
                    self.settings["bn"].pop(bid, None)
                else:
                    j = i - 1 if op == "up" else i + 1
                    if 0 <= j < len(l):
                        l[i], l[j] = l[j], l[i]
            self.mutate(go, settings=True)
            return {}
        if op != "save" or not isinstance(b.get("b"), dict):
            raise ApiError(400, "bad_request")
        v = b["b"]
        builtin = bid in self.cat["banners"]
        t, s = pair(v.get("t"), 60), pair(v.get("s"), 90)
        a = v.get("a")
        if not (a in BANNER_ACTIONS or (isinstance(a, str) and a in self.catalog.P and not self.catalog.P[a].get("gone"))):
            raise ApiError(400, "bad_banner")
        img = self._image_ref(v.get("img"))
        if not builtin and not t["ar"] and not img:
            raise ApiError(400, "bad_banner")   # a new banner needs a picture or at least a title
        q = {"t": t, "s": s, "a": a, "img": img}

        def go(c):
            l = self.settings["banners"]
            if bid is None:
                if len(l) >= MAX_BANNERS:
                    raise ApiError(409, "too_many")
                q["id"] = "b" + secrets.token_hex(4)
                l.append(q)
            else:
                i = next((k for k, x in enumerate(l) if x["id"] == bid), None)
                if i is None:
                    raise ApiError(404, "not_found")
                q["id"] = bid
                l[i] = q
            return q
        return {"banner": self.mutate(go, settings=True)}

    # ---- news (0.6.4): the admin writes them, with a photo; the first ones keep the app's own words and pictures until edited
    def admin_news(self, b):
        op, nid = b.get("op"), b.get("id")
        if op in ("del", "up", "down", "on"):
            on = b.get("on")
            if op == "on" and not isinstance(on, bool):
                raise ApiError(400, "bad_request")

            def go(c):
                l = self.settings["news"]
                i = next((k for k, x in enumerate(l) if x["id"] == nid), None)
                if i is None:
                    raise ApiError(404, "not_found")
                if op == "del":
                    l.pop(i)
                elif op == "on":
                    l[i]["on"] = on
                else:
                    j = i - 1 if op == "up" else i + 1
                    if 0 <= j < len(l):
                        l[i], l[j] = l[j], l[i]
            self.mutate(go, settings=True)
            return {}
        if op != "save" or not isinstance(b.get("n"), dict):
            raise ApiError(400, "bad_request")
        v = b["n"]
        builtin = nid in self.cat.get("news", [])
        t = pair(v.get("t"), 90)
        body = v.get("b") if isinstance(v.get("b"), dict) else {}
        body = {"ar": clean_text(body.get("ar"), 3000, 40), "en": clean_text(body.get("en"), 3000, 40)}
        img = self._image_ref(v.get("img"))
        if not builtin and len(t["ar"]) < 2:
            raise ApiError(400, "bad_news")   # a new item needs its title at least

        def go(c):
            l = self.settings["news"]
            if nid is None:
                if len(l) >= MAX_NEWS:
                    raise ApiError(409, "too_many")
                q = {"id": "n" + secrets.token_hex(4), "t": t, "b": body, "img": img, "ts": now_ms(), "on": True}
                l.insert(0, q)   # the newest on top
                return q
            i = next((k for k, x in enumerate(l) if x["id"] == nid), None)
            if i is None:
                raise ApiError(404, "not_found")
            q = dict(l[i], t=t, b=body, img=img)   # its date and on/off stay
            l[i] = q
            return q
        return {"news": self.mutate(go, settings=True)}

    # ---- where the driver is, for the customer's map
    def driver_loc(self, staff, b):
        lat, lng, acc = b.get("lat"), b.get("lng"), b.get("acc")
        if not valid_latlng(lat, lng):
            raise ApiError(400, "bad_location")
        acc = acc if isinstance(acc, (int, float)) and not isinstance(acc, bool) and 0 <= acc <= 100_000 else None
        busy = self.db.one("SELECT 1 FROM orders WHERE driver_id=? AND fin=0 AND rej=0 AND mode='delivery'", (staff["id"],))
        if not busy:
            self.locs.pop(staff["id"], None)
            return {"shared": False}
        self.locs[staff["id"]] = (round(float(lat), 5), round(float(lng), 5), round(acc) if acc is not None else None, now_ms())
        return {"shared": True}

    def tracking(self, cid, dh, t):
        """For the customer's own deliveries on their way: where the driver was a moment ago, and the way to the door
        with how long it takes (by road once the route key is set, otherwise an estimate from the distance)."""
        out = {}
        who, arg = ("cust_id=?", cid) if cid else ("dev_hash=?", dh)
        for r in self.db.q("SELECT id, driver_id, data FROM orders WHERE %s AND fin=0 AND rej=0 AND mode='delivery' AND st=2 AND driver_id IS NOT NULL" % who, (arg,)):
            loc = self.locs.get(r["driver_id"])
            if loc and t - loc[3] <= LOC_FRESH_MS:
                v = {"lat": loc[0], "lng": loc[1], "acc": loc[2], "ts": loc[3]}
                a = json.loads(r["data"]).get("addr") or {}
                if a.get("lat") is not None:
                    v["way"] = self.way_for(r["id"], (loc[0], loc[1]), (a["lat"], a["lng"]), t)
                out[r["id"]] = v
        return out

    def way_for(self, oid, src, dst, t):
        rt = self.routes.get(oid)
        if rt and (len(rt["pts"]) < 2 or km_between(rt["to"][0], rt["to"][1], dst[0], dst[1]) >= 0.05):
            rt = None                                          # no road, or a road to another door
        at = on_road(rt["pts"], src, rt["k"] - 1) if rt else None
        if (not at or at[1] > ROUTE_OFF_KM) and oid not in self.route_busy and t >= self.route_next.get(oid, 0) and self.route_key():
            self.route_busy.add(oid)
            self.route_next[oid] = t + ROUTE_GAP_MS
            threading.Thread(target=self._route_fetch, args=(oid, src, dst), daemon=True).start()
        if at and at[1] <= ROUTE_SHOW_KM:                      # the road from where the driver is now
            if at[1] <= ROUTE_OFF_KM:
                rt["k"] = at[0]
            rest = [[round(src[0], 5), round(src[1], 5)]] + rt["pts"][at[0] + 1:]
            f = min(1.0, road_km(rest) / rt["len"]) if rt["len"] > 0 else 1.0
            return {"pts": rest, "km": round(rt["km"] * f, 1), "min": max(1, round(rt["min"] * f))}
        km = km_between(src[0], src[1], dst[0], dst[1]) * 1.3   # no road yet: the straight line, a little longer, at town speed
        return {"km": round(km, 1), "min": max(1, round(km / 25 * 60)), "est": True}

    def route_key(self):
        r = self.db.one("SELECT v FROM kv WHERE k='route_key'")
        return r["v"] if r else ""

    def _route_fetch(self, oid, src, dst):
        try:
            body = json.dumps({"coordinates": [[src[1], src[0]], [dst[1], dst[0]]], "radiuses": [1000, 1000]}).encode()
            req = urllib.request.Request(self.route_url, data=body, method="POST", headers={"Authorization": self.route_key(), "Content-Type": "application/json", "Accept": "application/geo+json"})
            with self.push_open(req, timeout=10) as r:
                f = json.loads(r.read())["features"][0]
            cs, sm = f["geometry"]["coordinates"], f["properties"].get("summary") or {}
            pick = cs[::max(1, len(cs) // 150)]   # enough points for a phone map, and always the door
            if pick[-1] != cs[-1]:
                pick.append(cs[-1])
            pts = [[round(c[1], 5), round(c[0], 5)] for c in pick]
            if len(self.routes) > 300:
                old = now_ms() - 3600_000
                self.routes = {k: v for k, v in self.routes.items() if v["ts"] > old}
                self.route_next = {k: v for k, v in self.route_next.items() if v > old}
            self.routes[oid] = {"from": src, "to": dst, "ts": now_ms(), "pts": pts, "k": 0, "len": road_km(pts),
                                "km": round(sm.get("distance", 0) / 1000, 1), "min": max(1, round(sm.get("duration", 0) / 60))}
        except Exception as e:  # no road this time: the estimate stays, and the next ask waits
            self.route_next[oid] = now_ms() + ROUTE_WAIT_MS
            if not self.quiet:
                print("route failed:", e, file=sys.stderr, flush=True)
        finally:
            self.route_busy.discard(oid)

    def set_tiers(self, tiers):
        ok = clean_tiers(tiers)
        if not ok:
            raise ApiError(400, "bad_tiers")

        def go(c):
            self.settings["tiers"] = ok

        self.mutate(go, settings=True)

    # ---------------------------------------------------------------- orders: create
    def price_order(self, body, st):
        cat, menu = self.cat, self.catalog
        mode = body.get("mode")
        if mode not in ("pickup", "delivery", "ship"):
            raise ApiError(400, "bad_mode")
        branch = body.get("branch")
        if not (isinstance(branch, str) and branch in menu.B and not menu.B[branch].get("gone")):
            raise ApiError(400, "bad_branch")
        if mode != "ship" and st["br"].get(branch, {}).get("pause"):
            raise ApiError(409, "paused")
        if mode == "delivery" and not st["delivery"].get("on"):
            raise ApiError(409, "delivery_off")
        raw = body.get("items")
        if not isinstance(raw, list) or not 1 <= len(raw) <= 30:
            raise ApiError(400, "bad_items")
        lines, spent, free_n, sub_c = [], 0, 0, 0
        for it in raw:
            if not isinstance(it, dict):
                raise ApiError(400, "bad_items")
            pid = it.get("pid")
            p = menu.P.get(pid) if isinstance(pid, str) else None
            if not p:
                raise ApiError(400, "bad_item", pid=str(pid)[:30])
            qty = it.get("qty")
            if not isinstance(qty, int) or isinstance(qty, bool) or not 1 <= qty <= 20:
                raise ApiError(400, "bad_qty")
            if p.get("gone") or not p["stock"]:   # a deleted product reads as sold out: the phone refreshes its menu
                raise ApiError(409, "stock", pid=pid)
            if mode != "ship" and branch in (p.get("off") or ()):   # 0.7: not available at this branch
                raise ApiError(409, "not_here", pid=pid)
            sel, delta_c = self.sel_clean(p, it.get("sel"))
            rw = it.get("rw") or None
            gift = it.get("gift") or None
            if rw:
                r = next((x for x in st["rewards"] if x["id"] == rw and x.get("on", True) is not False), None)
                if not r or r.get("pid") != pid:
                    raise ApiError(400, "bad_reward")
                spent += r["pts"] * qty
            if gift:
                gift = clean(gift, 40)
            free = bool(rw or gift)
            if free:
                free_n += 1
                if free_n > 6:
                    raise ApiError(400, "too_many_free")
            unit_c = 0 if free else half_up(p["price"] * 100) + delta_c
            sub_c += unit_c * qty
            lines.append({"pid": pid, "sel": sel, "qty": qty, "unit_c": unit_c, "rw": rw, "gift": gift, "kind": menu.kind(p),
                          "n": {"ar": p["ar"], "en": p["en"]}, "fship": bool(p.get("fship"))})
        if mode == "ship":
            if not all(l["kind"] == "retail" for l in lines):
                raise ApiError(400, "ship_retail_only")
            if body.get("carrier") not in cat["carriers"]:
                raise ApiError(400, "bad_carrier")
        free_ship = any(l["fship"] for l in lines)
        if mode == "ship":
            fee_c = 0 if free_ship else half_up(st["ship"] * 100)
        elif mode == "delivery":
            fee_c = half_up(st["delivery"]["fee"] * 100)
        else:
            fee_c = 0
        disc_c, code = 0, ""
        want = clean(body.get("code") or "", 20).upper()
        if want:
            cd = st["codes"].get(want)
            if not cd or not cd.get("on"):
                raise ApiError(409, "bad_code")
            code = want
            disc_c = half_up(sub_c * cd["pct"] / 100)
        total_c = max(0, sub_c + fee_c - disc_c)
        try:
            bal_c = half_up(max(0.0, float(body.get("bal") or 0)) * 100)
        except (TypeError, ValueError):
            bal_c = 0
        bal_c = min(bal_c, total_c)
        pay_c = total_c - bal_c
        # the VAT line absorbs cent rounding, like the order summary in the app
        ex = lambda cents: half_up(cents / 1.15)
        vat_c = total_c - (sum(ex(l["unit_c"] * l["qty"]) for l in lines) + ex(fee_c) - ex(disc_c))
        pm = body.get("payM")
        pay_m = pm if pm in PAY_METHODS else "card"
        if pay_c == 0:
            pay_m = "wallet" if bal_c > 0 else "points"
        return {
            "mode": mode, "branch": branch, "lines": lines, "sub_c": sub_c, "fee_c": fee_c, "disc_c": disc_c, "code": code,
            "total_c": total_c, "bal_c": bal_c, "pay_c": pay_c, "vat_c": vat_c, "pay_m": pay_m, "spent": spent,
        }

    def create_order(self, dev, ip, body):
        st = self.snap()
        pr = self.price_order(body, st)
        mode = pr["mode"]
        cu = body.get("cust") if isinstance(body.get("cust"), dict) else {}
        name, phone = clean(cu.get("name"), 40), cu.get("phone")
        if len(name) < 2 or not valid_phone(phone):
            raise ApiError(400, "bad_customer")
        addr = None
        if mode in ("ship", "delivery"):
            a = body.get("addr") if isinstance(body.get("addr"), dict) else {}
            addr = {"city": clean(a.get("city"), 60), "street": clean(a.get("street"), 120), "note": clean(a.get("note"), 160)}
            if not addr["city"] or not addr["street"]:
                raise ApiError(400, "bad_address")
            try:
                lat, lng = float(a.get("lat")), float(a.get("lng"))
                if -90 <= lat <= 90 and -180 <= lng <= 180 and not (lat == 0 and lng == 0):
                    addr["lat"], addr["lng"] = round(lat, 5), round(lng, 5)
            except (TypeError, ValueError):
                pass
        if mode == "delivery":   # 0.7: the smallest order, and how far from the branch the drivers go
            dl = self.snap()["delivery"]
            if dl.get("min") and pr["sub_c"] < half_up(dl["min"] * 100):
                raise ApiError(409, "below_min", min=dl["min"])
            b = self.catalog.B[pr["branch"]]
            if dl.get("km") and b.get("lat") is not None and b.get("lng") is not None:
                if addr.get("lat") is None:
                    raise ApiError(400, "need_pin")
                d = km_between(b["lat"], b["lng"], addr["lat"], addr["lng"])
                if d > dl["km"]:
                    raise ApiError(409, "too_far", km=dl["km"], d=round(d, 1))
        gift = None   # a gift brought to someone else (0.6.3): the sender pays and keeps the order, the driver hands it to the recipient
        g = body.get("gift")
        if isinstance(g, dict) and (g.get("phone") or g.get("name")):
            if mode != "delivery" or not valid_phone(g.get("phone")):
                raise ApiError(400, "bad_gift")
            gift = {"name": clean(g.get("name"), 30), "phone": g["phone"], "tail": g["phone"][-4:], "msg": clean(g.get("msg"), 140)}
        exp = body.get("total")
        if isinstance(exp, (int, float)) and not isinstance(exp, bool) and abs(half_up(exp * 100) - pr["total_c"]) > 1:
            raise ApiError(409, "price_changed", total=sar(pr["total_c"]))
        cid = clean(body.get("cid"), 40) or None
        ts = now_ms()
        pick = body.get("pick")   # 0.7: a pickup time later today instead of "as soon as possible"
        if pick is not None:
            if mode != "pickup" or not self.pick_ok(self.catalog.B[pr["branch"]], pick, ts):
                raise ApiError(400, "bad_pick")
        dh = sha(dev)
        if cid:  # the same attempt sent twice (a lost reply): hand back the order that already exists
            old = self.db.one("SELECT data FROM orders WHERE dev_hash=? AND cid=?", (dh, cid))
            if old:
                return self.own_view(json.loads(old["data"]))

        def go(c):
            if cid and c.execute("SELECT 1 FROM orders WHERE dev_hash=? AND cid=?", (dh, cid)).fetchone():
                raise ApiError(409, "duplicate")
            open_n = c.execute("SELECT COUNT(*) FROM orders WHERE dev_hash=? AND fin=0 AND rej=0", (dh,)).fetchone()[0]
            if open_n >= 12:
                raise ApiError(429, "too_many_open")
            seq = int(self._kv(c, "seq", "1000")) + 1
            self._set_kv(c, "seq", str(seq))
            cur = c.execute("SELECT id FROM customers WHERE phone=?", (phone,)).fetchone()
            if cur:
                cust_id = cur["id"]
                c.execute("UPDATE customers SET name=? WHERE id=?", (name, cust_id))
            else:   # a page from before 0.7 that never synced: the account opens when the new page speaks for it
                cust_id = c.execute("INSERT INTO customers(phone,name,dev_hash,pts,created,seen) VALUES(?,?,?,0,?,?)", (phone, name, dh, ts, ts)).lastrowid
            self._bind(c, dh, cust_id, ts)
            if isinstance(body.get("legacy"), dict):
                self._open_account(c, cust_id, body["legacy"])
            opened = c.execute("SELECT opened FROM customers WHERE id=?", (cust_id,)).fetchone()["opened"]
            # a product gift the customer received, used in this order: it must be his, unused, and this product
            used = []
            for l in pr["lines"]:
                if l["gift"]:
                    g = c.execute("SELECT * FROM gifts WHERE id=?", (l["gift"],)).fetchone()
                    if not g or g["to_phone"] != phone or g["kind"] != "item" or json.loads(g["data"]).get("pid") != l["pid"] or l["qty"] != 1 or l["gift"] in used:
                        raise ApiError(409, "gift_used")
                    if g["state"] != "new":
                        raise ApiError(409, "gift_used")
                    used.append(l["gift"])
            if opened:   # the account lives here: the points and the wallet must cover what the order uses
                if pr["spent"] > self._sum_pts(c, cust_id):
                    raise ApiError(409, "no_points")
                if pr["bal_c"] > self._sum_bal(c, cust_id):
                    raise ApiError(409, "no_balance")
            # the tier of the customer before this order decides how many points it earns
            tier = tier_for(self.tier_points(lambda s, a: c.execute(s, a).fetchone()[0], cust_id, ts), clean_tiers(st.get("tiers")) or DEFAULT_TIERS)
            o = {
                "id": secrets.token_urlsafe(8), "no": "‎#%d" % seq, "seq": seq, "ts": ts, "day": self.day_of(ts), "mode": mode, "branch": pr["branch"],
                "serve": (body.get("serve") if body.get("serve") in ("in", "take") else "in") if mode == "pickup" else "",
                "carrier": body.get("carrier") if mode == "ship" else "",
                "addr": addr,
                # each item keeps the name it had when it was ordered: a product renamed or deleted later does not change old orders
                "items": [{"pid": l["pid"], "n": l["n"], "sel": l["sel"], "qty": l["qty"], "unit": sar(l["unit_c"]), "rw": l["rw"], "gift": l["gift"]} for l in pr["lines"]],
                "sub": sar(pr["sub_c"]), "ship": sar(pr["fee_c"]), "disc": sar(pr["disc_c"]), "total": sar(pr["total_c"]), "bal": sar(pr["bal_c"]), "pay": sar(pr["pay_c"]),
                "payM": pr["pay_m"], "vat": sar(pr["vat_c"]), "earn": tier_earn(pr["pay_c"], tier), "tier": tier["id"], "spent": pr["spent"], "dcode": pr["code"],
                "code": ("WH%d" % (1000000 + secrets.randbelow(9000000))) if mode == "ship" else "%04d" % (1000 + secrets.randbelow(9000)),
                "st": 0, "done": False, "fin": False, "at": [ts], "rej": None, "driver": None,
                "cust": {"name": name, "tail": phone[-4:], "phone": phone}, "gift": gift, "pick": pick,
            }
            tax = st.get("tax")
            if tax and tax.get("vat"):   # 0.7: a simplified tax invoice, from the day the admin enters the VAT number
                o["inv"] = {"name": tax["name"], "vat": tax["vat"], "cr": tax.get("cr") or "", "addr": tax.get("addr") or "",
                            "qr": zatca_qr(tax["name"], tax["vat"], ts, pr["total_c"], pr["vat_c"])}
            if gift:   # it shows among the gifts the customer sent, with the order to follow
                o["gid"] = "g" + secrets.token_hex(6)
                gd = {"from_name": name, "to_name": gift["name"], "msg": gift["msg"], "pid": pr["lines"][0]["pid"], "amt_c": 0, "price_c": pr["total_c"], "earn": o["earn"], "oid": o["id"]}
                c.execute("INSERT INTO gifts(id,ts,from_cust,to_phone,kind,state,data) VALUES(?,?,?,?,'item','del',?)", (o["gid"], ts, cust_id, gift["phone"], json.dumps(gd, ensure_ascii=False)))
                self._bump_acct(c, cust_id)
            c.execute(
                "INSERT INTO orders(id,seq,ts,day,mode,branch,st,rej,fin,total,dev_hash,cid,cust_id,driver_id,rev,data) VALUES(?,?,?,?,?,?,0,0,0,?,?,?,?,NULL,?,?)",
                (o["id"], seq, ts, o["day"], mode, o["branch"], o["total"], dh, cid, cust_id, self.rev + 1, json.dumps(o, ensure_ascii=False)),
            )
            for gid in used:
                g = c.execute("SELECT from_cust FROM gifts WHERE id=?", (gid,)).fetchone()
                c.execute("UPDATE gifts SET state='used' WHERE id=?", (gid,))
                self._bump_acct(c, g["from_cust"], phone)
            if opened:
                no = o["no"].replace("\u200e", "")
                self._add_pts(c, cust_id, -pr["spent"], "spend", {"ar": "إستبدال مكافأة (%s)" % no, "en": "Reward redeemed (%s)" % no}, o["id"])
                self._add_pts(c, cust_id, o["earn"], "earn", {"ar": "هدية %s" % no, "en": "Gift %s" % no} if gift else {"ar": "طلب %s" % no, "en": "Order %s" % no}, o["id"])
                self._add_bal(c, cust_id, -pr["bal_c"], "pay", {"ar": "الدفع للطلب %s" % no, "en": "Paid for order %s" % no}, o["id"])
            return o

        o = self.mutate(go)
        self.push_new_order(o)
        return self.own_view(o)

    def pick_ok(self, b, pick, t):
        """A pickup time the customer chose: 10 minutes to 12 hours ahead, while the branch is open."""
        if not isinstance(pick, int) or isinstance(pick, bool) or not t + 9 * 60_000 <= pick <= t + 12 * 3600_000:
            return False
        h = b.get("h") or "24"
        if h == "24":
            return True
        m = (pick // 60_000 + self.tz_min) % 1440
        return h[0] <= m < h[1] or h[0] <= m + 1440 < h[1]

    # ---------------------------------------------------------------- orders: views
    @staticmethod
    def own_view(o):
        """What the customer's own phone gets back: everything, including the pickup code."""
        v = dict(o)
        v["cust"] = {"name": o["cust"]["name"], "tail": o["cust"]["tail"]}
        v["driver"] = ({"name": o["driver"]["name"]} if o.get("driver") else None)
        v["dphone"] = App.driver_phone_for_cust(o)
        v.pop("tries", None)
        v.pop("seq", None)
        return v

    @staticmethod
    def driver_phone_for_cust(o):
        """The driver's mobile, for the customer, only while his order is on its way to him."""
        d = o.get("driver")
        return (d.get("phone") or None) if d and o["st"] == 2 and not o["fin"] and not o["rej"] else None

    @staticmethod
    def status_view(o):
        return {"id": o["id"], "st": o["st"], "at": o["at"], "rej": o["rej"], "fin": o["fin"], "done": o["done"], "driver": (o["driver"]["name"] if o.get("driver") else None),
                "rate": o.get("rate"), "dphone": App.driver_phone_for_cust(o), "arr": o.get("arr")}

    @staticmethod
    def staff_view(o, phone=False, full_addr=True):
        """An order as the café side sees it. The pickup and delivery code never leaves the server (only the customer holds it)."""
        v = {k: o[k] for k in ("id", "no", "ts", "day", "mode", "branch", "serve", "carrier", "items", "sub", "ship", "disc", "total", "bal", "pay", "payM", "vat", "earn", "st", "done", "fin", "at", "rej")}
        v["cust"] = {"name": o["cust"]["name"], "tail": o["cust"]["tail"]}
        if phone:
            v["cust"]["phone"] = o["cust"]["phone"]
        if o["mode"] == "ship":
            v["code"] = o["code"]
        a = o.get("addr")
        if a:
            v["addr"] = dict(a) if full_addr else {"city": a["city"], "street": a["street"]}
        else:
            v["addr"] = None
        v["driver"] = ({"id": o["driver"]["id"], "name": o["driver"]["name"], "ts": o["driver"]["ts"]} if o.get("driver") else None)
        v["pick"], v["rate"], v["inv"], v["arr"] = o.get("pick"), o.get("rate"), o.get("inv"), o.get("arr")
        gf = o.get("gift")   # the recipient's number only for the driver who carries it (like the customer's)
        v["gift"] = dict({"name": gf["name"], "tail": gf["tail"], "msg": gf["msg"]}, **({"phone": gf["phone"]} if phone else {})) if gf else None
        return v

    def _orders_rows(self, where, args=(), limit=500):
        return [json.loads(r["data"]) for r in self.db.q("SELECT data FROM orders WHERE %s ORDER BY seq DESC LIMIT %d" % (where, limit), args)]

    # ---------------------------------------------------------------- orders: customer side
    def _profile(self, dh, name, phone, pts, t, extra=None):
        """Keep the customer list in step with the phone. Only a change the admin can see wakes the café screens.
        pts: the points a page from before 0.7 counted (not taken once the account lives on the server)."""
        extra = extra or {}
        row = self.db.one("SELECT id,name,pts,dev_hash,seen,email,birth,gender,invite,mk,opened FROM customers WHERE phone=?", (phone,))
        if row and row["opened"]:
            pts = None
        bound = bool(row) and bool(self.db.one("SELECT 1 FROM devices WHERE dev_hash=? AND cust_id=?", (dh, row["id"])))
        new = {k: v for k, v in extra.items() if not row or row[k] != v}
        if row and not new and row["name"] == name and (pts is None or pts == row["pts"]) and bound and t - row["seen"] < 600_000:
            return
        visible = (not row) or row["name"] != name or (pts is not None and pts != row["pts"]) or bool(new)

        def up(c):
            if row:
                sets, args = ["name=?", "pts=?"], [name, row["pts"] if pts is None else pts]
                for k, v in new.items():  # the keys come from profile_extra, never from the request itself
                    sets.append(k + "=?")
                    args.append(v)
                c.execute("UPDATE customers SET %s WHERE id=?" % ",".join(sets), args + [row["id"]])
                cid = row["id"]
            else:   # a page from before 0.7 signed up on the phone alone: the account opens when the new page speaks for it
                cols = ["phone", "name", "dev_hash", "pts", "created", "seen"] + list(new)
                cid = c.execute("INSERT INTO customers(%s) VALUES(%s)" % (",".join(cols), ",".join("?" * len(cols))), [phone, name, dh, pts or 0, t, t] + list(new.values())).lastrowid
            self._bind(c, dh, cid, t)   # as before 0.7, the number alone signs the phone in; the WhatsApp code will make it strict

        if visible:
            self.mutate(up)
        else:
            with self.db.tx() as c:
                up(c)

    def my_sync(self, dev, body):
        rev0 = self.rev  # read first: anything that changes after this has a higher revision and comes with the next call
        dh = sha(dev)
        t = now_ms()
        since = body.get("since") if isinstance(body.get("since"), int) and not isinstance(body.get("since"), bool) else 0
        name, phone, pts = clean(body.get("name"), 40), body.get("phone"), body.get("pts")
        gone = False
        if valid_phone(phone) and len(name) >= 2:
            pts = pts if isinstance(pts, int) and not isinstance(pts, bool) and 0 <= pts <= 10_000_000 else None
            if body.get("arev") is not None and not self.db.one("SELECT 1 FROM customers WHERE phone=?", (phone,)):
                gone = True   # the account was deleted (from another phone): this one signs out instead of making it again
            else:
                self._profile(dh, name, phone, pts, t, profile_extra(body))
        cust = None if gone else self._cust_of(dh)   # a phone that signed out (or never signed in) is no one
        ack = body.get("ack")
        if cust and isinstance(ack, list):   # bonus points the phone has told the customer about (first, so the opening counts them once)
            ids = [i for i in ack if isinstance(i, int) and not isinstance(i, bool)][:50]
            if ids:
                with self.db.tx() as c:
                    c.execute("UPDATE bonus SET claimed=1 WHERE cust_id=? AND id IN (%s)" % ",".join("?" * len(ids)), [cust["id"]] + ids)
        if cust and not cust["opened"] and isinstance(body.get("legacy"), dict):   # the new page hands over what the phone counted
            self.mutate(lambda c: self._open_account(c, cust["id"], dict(body["legacy"], since=since)))
            cust = self._cust_of(dh)
        cid = cust["id"] if cust else None
        who, arg = ("cust_id=?", cid) if cid else ("dev_hash=?", dh)
        orders = [self.status_view(json.loads(r["data"])) for r in self.db.q("SELECT data FROM orders WHERE %s AND rev>? ORDER BY ts DESC LIMIT 60" % who, (arg, since))]
        bonus = [{"id": r["id"], "pts": r["pts"]} for r in self.db.q("SELECT id,pts FROM bonus WHERE cust_id=? AND claimed=0 ORDER BY id LIMIT 20", (cid,))] if cid else []
        out = {"rev": rev0, "orders": orders, "bonus": bonus, "now": t, "tier": self.tier_of_customer(cid, t)}
        if gone:
            out["gone"] = True
        if cust and cust["opened"]:
            arev = self.db.one("SELECT arev FROM customers WHERE id=?", (cid,))["arev"]
            if body.get("arev") != arev:
                out["acct"] = self.account(cid)
            if body.get("full"):   # a phone that has just signed in on a page that lost its orders
                out["history"] = self.history(cid)
        trk = self.tracking(cid, dh, t)
        if trk:
            out["track"] = trk
        if body.get("srev") != self.srev:
            out["pub"] = self.public_cfg()
        menu = self.catalog
        if "crev" in body and body.get("crev") != menu.crev:   # pages from before 0.4 do not ask for the menu
            out["cat"] = menu.payload()
        return out

    def my_collect(self, dev, body):
        oid = body.get("id")
        if not isinstance(oid, str):
            raise ApiError(400, "bad_request")
        dh = sha(dev)
        me = self._cust_of(dh)

        def go(c):
            r = c.execute("SELECT data FROM orders WHERE id=? AND (dev_hash=? OR cust_id=?)", (oid, dh, me["id"] if me else -1)).fetchone()
            if not r:
                raise ApiError(404, "not_found")
            o = json.loads(r["data"])
            if o["mode"] != "pickup" or o["rej"] or o["fin"] or o["st"] != 2:
                raise ApiError(409, "bad_state")
            self._advance(o, 3)
            self._save_order(c, o)
            return o

        o = self.mutate(go)
        return self.status_view(o)

    def _my_order(self, c, dev, oid):
        """One of the customer's orders, placed from any of his phones."""
        if not isinstance(oid, str):
            raise ApiError(400, "bad_request")
        dh = sha(dev)
        me = self._cust_of(dh, c)
        r = c.execute("SELECT data FROM orders WHERE id=? AND (dev_hash=? OR cust_id=?)", (oid, dh, me["id"] if me else -1)).fetchone()
        if not r:
            raise ApiError(404, "not_found")
        return json.loads(r["data"])

    def my_cancel(self, dev, body):
        """The customer cancels an order the branch has not accepted yet: what it used comes back."""
        def go(c):
            o = self._my_order(c, dev, body.get("id"))
            if o["rej"] or o["fin"] or o["st"] != 0:
                raise ApiError(409, "bad_state")
            o["rej"] = {"ts": now_ms(), "id": "cust", "by": "cust", "why": {"ar": "ألغاه العميل", "en": "Cancelled by the customer"}}
            self._undo(c, o)
            self._save_order(c, o)
            return o
        o = self.mutate(go)
        no = o["no"].replace("\u200e", "")
        self.push("recv", ["*", o["branch"]], {"ar": "ألغى العميل الطلب %s" % no, "en": "Order %s was cancelled" % no},
                  {"ar": "ألغاه قبل أن يقبله الفرع.", "en": "The customer cancelled it before it was accepted."}, "/reception/", "o-" + o["id"])
        return self.status_view(o)

    def my_rate(self, dev, body):
        """Stars (1 to 5) and a few words for a completed order, once. The management sees them."""
        stars = body.get("stars")
        if not isinstance(stars, int) or isinstance(stars, bool) or not 1 <= stars <= 5:
            raise ApiError(400, "bad_rate")
        words = clean_text(body.get("note"), 300, 4)

        def go(c):
            o = self._my_order(c, dev, body.get("id"))
            if not o["fin"] or o["rej"]:
                raise ApiError(409, "bad_state")
            if o.get("rate"):
                raise ApiError(409, "rated")
            o["rate"] = {"s": stars, "c": words, "ts": now_ms()}
            self._save_order(c, o)
            return o
        return self.status_view(self.mutate(go))

    def acct_of(self, dev):
        me = self._cust_of(sha(dev))
        return self.account(me["id"]) if me and me["opened"] else None

    # ---------------------------------------------------------------- the customer's account (0.7): points, wallet and gifts live here
    # A phone signs in with the code (a test code until the WhatsApp codes come, before launch) and is bound to the customer
    # in devices; one customer may use several phones. Every point and every halala is a row of ledger or wallet: the balance
    # is their sum and the history is the rows. A customer from before 0.7 is "not opened": his phone counted, so the first
    # time a phone on the new page speaks for him, its balances become his opening balance (_open_account) and from then
    # on only the server counts.
    @staticmethod
    def _sum_pts(c, cid):
        return c.execute("SELECT COALESCE(SUM(pts),0) FROM ledger WHERE cust_id=?", (cid,)).fetchone()[0]

    @staticmethod
    def _sum_bal(c, cid):
        """The wallet, in halalas."""
        return c.execute("SELECT COALESCE(SUM(amt),0) FROM wallet WHERE cust_id=?", (cid,)).fetchone()[0]

    @staticmethod
    def _bump_acct(c, cid=None, phone=None):
        """The phones of this customer fetch the account again at their next sync."""
        if cid:
            c.execute("UPDATE customers SET arev=arev+1 WHERE id=?", (cid,))
        if phone:
            c.execute("UPDATE customers SET arev=arev+1 WHERE phone=?", (phone,))

    def _add_pts(self, c, cid, pts, kind, label, ref=None):
        if pts:
            c.execute("INSERT INTO ledger(cust_id,ts,pts,kind,ref,label) VALUES(?,?,?,?,?,?)", (cid, now_ms(), int(pts), kind, ref, json.dumps(label, ensure_ascii=False)))
            self._bump_acct(c, cid)

    def _add_bal(self, c, cid, amt_c, kind, label, ref=None):
        if amt_c:
            c.execute("INSERT INTO wallet(cust_id,ts,amt,kind,ref,label) VALUES(?,?,?,?,?,?)", (cid, now_ms(), int(amt_c), kind, ref, json.dumps(label, ensure_ascii=False)))
            self._bump_acct(c, cid)

    @staticmethod
    def _bind(c, dh, cid, t):
        """This phone is now signed in as this customer."""
        c.execute("INSERT INTO devices(dev_hash,cust_id,ts) VALUES(?,?,?) ON CONFLICT(dev_hash) DO UPDATE SET cust_id=excluded.cust_id, ts=excluded.ts", (dh, cid, t))
        c.execute("UPDATE customers SET dev_hash=?, seen=? WHERE id=?", (dh, t, cid))

    def _cust_of(self, dh, c=None):
        """The customer a phone is signed in as, or None (a guest). A phone bound before 0.7 is found by the old column."""
        one = (lambda s, a: c.execute(s, a).fetchone()) if c is not None else self.db.one
        return (one("SELECT c.id, c.phone, c.name, c.opened FROM devices d JOIN customers c ON c.id=d.cust_id WHERE d.dev_hash=?", (dh,))
                or one("SELECT id, phone, name, opened FROM customers WHERE dev_hash=? ORDER BY seen DESC", (dh,)))

    def _new_customer(self, c, phone, name, dh, t, extra=None):
        """A customer whose account starts on the server: the welcome points are its first row."""
        extra = extra or {}
        cols = ["phone", "name", "dev_hash", "pts", "created", "seen", "opened"] + list(extra)
        cid = c.execute("INSERT INTO customers(%s) VALUES(%s)" % (",".join(cols), ",".join("?" * len(cols))),
                        [phone, name, dh, 0, t, t, 1] + list(extra.values())).lastrowid
        self._add_pts(c, cid, WELCOME_PTS, "welcome", WELCOME_LABEL)
        return cid

    def _open_account(self, c, cid, legacy):
        """Once, for a customer from before 0.7: what his phone held (legacy = {pts, bal, since}) becomes the opening balance,
        with the admin's bonus points the phone had not taken yet, and an order turned down after the phone last looked (since)
        given back here, since that phone never saw it. Without legacy (another phone) the points the phone last reported are
        used. Capped, since a phone said them."""
        row = c.execute("SELECT opened, pts FROM customers WHERE id=?", (cid,)).fetchone()
        if not row or row["opened"]:
            return
        legacy = legacy if isinstance(legacy, dict) else {}
        pts, bal, since = legacy.get("pts", row["pts"]), legacy.get("bal", 0), legacy.get("since")
        pts = pts if isinstance(pts, int) and not isinstance(pts, bool) and 0 <= pts <= 1_000_000 else 0
        bal_c = half_up(bal * 100) if isinstance(bal, (int, float)) and not isinstance(bal, bool) and 0 <= bal <= 100_000 else 0
        self._add_pts(c, cid, pts, "open", {"ar": "رصيد النقاط السابق", "en": "Points carried over"})
        for b in c.execute("SELECT pts FROM bonus WHERE cust_id=? AND claimed=0", (cid,)).fetchall():
            self._add_pts(c, cid, b["pts"], "bonus", BONUS_LABEL)
        self._add_bal(c, cid, bal_c, "open", {"ar": "رصيد المحفظة السابق", "en": "Wallet balance carried over"})
        c.execute("UPDATE customers SET opened=1, arev=arev+1 WHERE id=?", (cid,))
        if isinstance(since, int) and not isinstance(since, bool):
            for r in c.execute("SELECT data FROM orders WHERE cust_id=? AND rej=1 AND rev>?", (cid, since)).fetchall():
                self._undo(c, json.loads(r["data"]))

    @staticmethod
    def gift_view(r, sent):
        d = json.loads(r["data"])
        v = {"id": r["id"], "ts": r["ts"], "kind": r["kind"], "state": r["state"], "pid": d.get("pid"), "amt": sar(d.get("amt_c", 0)), "msg": d.get("msg", "")}
        if sent:
            v.update({"to": r["to_phone"], "toName": d.get("to_name", ""), "price": sar(d.get("price_c", 0)), "earn": d.get("earn", 0), "oid": d.get("oid")})
        else:
            v["from"] = d.get("from_name", "")
        return v

    def account(self, cid):
        """What the customer's phones show of the account: points and their history, the wallet, gifts received and sent."""
        row = self.db.one("SELECT phone, arev FROM customers WHERE id=? AND opened=1", (cid,)) if cid else None
        if not row:
            return None
        pts = self.db.one("SELECT COALESCE(SUM(pts),0) n FROM ledger WHERE cust_id=?", (cid,))["n"]
        bal = self.db.one("SELECT COALESCE(SUM(amt),0) n FROM wallet WHERE cust_id=?", (cid,))["n"]
        led = [{"id": r["id"], "ts": r["ts"], "pts": r["pts"], "label": json.loads(r["label"])}
               for r in self.db.q("SELECT id,ts,pts,label FROM ledger WHERE cust_id=? ORDER BY id DESC LIMIT 100", (cid,))]
        wal = [{"id": r["id"], "ts": r["ts"], "amt": sar(r["amt"]), "label": json.loads(r["label"])}
               for r in self.db.q("SELECT id,ts,amt,label FROM wallet WHERE cust_id=? ORDER BY id DESC LIMIT 50", (cid,))]
        recv = [self.gift_view(r, False) for r in self.db.q("SELECT * FROM gifts WHERE to_phone=? AND state IN ('new','used') ORDER BY ts DESC LIMIT 60", (row["phone"],))]
        sent = [self.gift_view(r, True) for r in self.db.q("SELECT * FROM gifts WHERE from_cust=? ORDER BY ts DESC LIMIT 60", (cid,))]
        return {"arev": row["arev"], "pts": pts, "bal": sar(bal), "ledger": led, "wallet": wal, "gifts": recv, "sent": sent}

    def history(self, cid):
        """The customer's recent orders, whole, for a phone that does not have them (a new phone, after signing in)."""
        return [self.own_view(json.loads(r["data"])) for r in self.db.q("SELECT data FROM orders WHERE cust_id=? ORDER BY ts DESC LIMIT 40", (cid,))]

    def _me(self, dev, open_it=True):
        """The customer this phone is signed in as; his account opened if it was not yet."""
        dh = sha(dev)
        me = self._cust_of(dh)
        if not me:
            raise ApiError(401, "bad_customer")
        if open_it and not me["opened"]:
            self.mutate(lambda c: self._open_account(c, me["id"], None))
            me = self._cust_of(dh)
        return me

    # ---------------------------------------------------------------- the sign-in code by WhatsApp (0.7.6)
    def wa_conf(self):
        """The WhatsApp settings (token, phone number ID, template, language), or None while they are not set."""
        get = lambda k: (self.db.one("SELECT v FROM kv WHERE k=?", ("wa_" + k,)) or {"v": ""})["v"]
        conf = {k: get(k) for k in ("token", "phone", "tpl", "lang")}
        if not (conf["token"] and conf["phone"]):
            return None
        conf["tpl"], conf["lang"] = conf["tpl"] or "why_code", conf["lang"] or "ar"
        return conf

    def otp_test_on(self):
        """12345 still signs in: always until WhatsApp is set, and after that until the test code is switched off."""
        r = self.db.one("SELECT v FROM kv WHERE k='otp_test'")
        return not self.wa_conf() or not r or r["v"] != "off"

    @staticmethod
    def _wa_send(conf, phone, code):
        body = {"messaging_product": "whatsapp", "to": "966" + phone, "type": "template", "template": {
            "name": conf["tpl"], "language": {"code": conf["lang"]},
            "components": [{"type": "body", "parameters": [{"type": "text", "text": code}]},
                           {"type": "button", "sub_type": "url", "index": "0", "parameters": [{"type": "text", "text": code}]}]}}
        req = urllib.request.Request(WA_URL % conf["phone"], data=json.dumps(body).encode(), method="POST",
                                     headers={"Authorization": "Bearer " + conf["token"], "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            json.loads(r.read() or b"{}")

    def send_code(self, phone):
        """A new sign-in code to this number by WhatsApp. {via: 'wa'} when it went; {via: 'test'} while WhatsApp is not
        set, or when it could not go and the test code still works (Meta's test number reaches only the numbers added to it)."""
        if not valid_phone(phone):
            raise ApiError(400, "bad_phone")
        conf = self.wa_conf()
        if not conf:
            return {"via": "test"}
        t = now_ms()
        with self.otp_lock:
            old = self.otps.get(phone)
            if old and t - old["sent"] < OTP_GAP_MS:
                raise ApiError(429, "slow_down", retry=max(1, (OTP_GAP_MS - (t - old["sent"])) // 1000))
            if len(self.otps) > 5000:
                self.otps = {k: v for k, v in self.otps.items() if v["exp"] > t}
            self.otps[phone] = {"sent": t, "exp": 0, "tries": 0, "h": ""}   # holds the 30 s gap while it is being sent
        code = "%05d" % secrets.randbelow(100000)
        try:
            self.wa_send(conf, phone, code)
        except Exception as e:
            detail = e.read().decode("utf-8", "replace")[:300] if isinstance(e, urllib.error.HTTPError) else str(e)
            print("whatsapp code failed:", getattr(e, "code", ""), detail, file=sys.stderr, flush=True)
            if self.otp_test_on():
                return {"via": "test"}
            raise ApiError(502, "wa_failed")
        with self.otp_lock:
            self.otps[phone] = {"sent": t, "exp": t + OTP_TTL_MS, "tries": 0, "h": sha(phone + ":" + code)}
        return {"via": "wa"}

    def check_code(self, phone, code):
        """Is this the code sent to this number (not expired, not tried too often), or the test code while it is on."""
        if not isinstance(code, str) or not re.fullmatch(r"\d{5}", code):
            return False
        with self.otp_lock:
            o = self.otps.get(phone)
            if o and o["h"] and now_ms() < o["exp"] and o["tries"] < OTP_TRIES:
                o["tries"] += 1
                if hmac.compare_digest(o["h"], sha(phone + ":" + code)):
                    return True
        return self.otp_test_on() and hmac.compare_digest(code.encode(), OTP_TEST.encode())

    def used_code(self, phone):
        with self.otp_lock:
            self.otps.pop(phone, None)

    def my_login(self, dev, body):
        """Signing in on a phone, or signing up. {need: 'signup'} for a number we do not know yet."""
        phone = body.get("phone")
        if not valid_phone(phone):
            raise ApiError(400, "bad_phone")
        if not self.check_code(phone, body.get("code")):
            raise ApiError(403, "bad_otp")
        dh, t, name, extra = sha(dev), now_ms(), clean(body.get("name"), 40), profile_extra(body)

        def go(c):
            row = c.execute("SELECT id FROM customers WHERE phone=?", (phone,)).fetchone()
            if row:
                self._bind(c, dh, row["id"], t)
                self._open_account(c, row["id"], body.get("legacy"))
                return row["id"], False
            if body.get("signup") is not True:
                return None, False
            if len(name) < 2:
                raise ApiError(400, "bad_customer")
            cid = self._new_customer(c, phone, name, dh, t, extra)
            self._bind(c, dh, cid, t)
            return cid, True

        cid, created = self.mutate(go)
        if not cid:
            return {"need": "signup"}   # the code stays good for the sign-up that follows
        self.used_code(phone)
        r = self.db.one("SELECT name,phone,email,birth,gender,invite,mk FROM customers WHERE id=?", (cid,))
        user = {"name": r["name"], "phone": r["phone"], "email": r["email"], "birth": r["birth"], "gender": r["gender"], "invite": r["invite"], "mk": bool(r["mk"])}
        return {"user": user, "new": created, "acct": self.account(cid), "history": self.history(cid), "rev": self.rev}

    def my_logout(self, dev):
        """This phone is no longer signed in (the account stays as it is)."""
        dh = sha(dev)

        def go(c):
            c.execute("DELETE FROM devices WHERE dev_hash=?", (dh,))
            c.execute("UPDATE customers SET dev_hash=NULL WHERE dev_hash=?", (dh,))
        with self.db.tx() as c:
            go(c)
        return {}

    def my_gift(self, dev, body):
        """op send: a gift card or a product to another number (paid by card; a trial until the payment gateway comes).
        op claim: a gift card received goes into the wallet."""
        me, op, t = self._me(dev), body.get("op"), now_ms()
        if op == "claim":
            gid = body.get("id")

            def claim(c):
                r = c.execute("SELECT * FROM gifts WHERE id=? AND to_phone=? AND kind='card'", (gid, me["phone"])).fetchone() if isinstance(gid, str) else None
                if not r:
                    raise ApiError(404, "not_found")
                if r["state"] != "new":
                    raise ApiError(409, "gift_used")
                d = json.loads(r["data"])
                fr = d.get("from_name") or ""
                c.execute("UPDATE gifts SET state='used' WHERE id=?", (gid,))
                self._add_bal(c, me["id"], d["amt_c"], "gift", {"ar": "بطاقة هدية من %s" % (fr or "صديق"), "en": "Gift card from %s" % (fr or "a friend")}, gid)
                self._bump_acct(c, r["from_cust"])   # the sender sees it used
                return d["amt_c"]
            amt_c = self.mutate(claim)
            return {"amt": sar(amt_c), "acct": self.account(me["id"])}
        if op != "send":
            raise ApiError(400, "bad_op")
        to, kind = body.get("to"), body.get("kind")
        if not valid_phone(to):
            raise ApiError(400, "bad_gift")
        if kind == "card":
            amt = body.get("amt")
            if not isinstance(amt, int) or isinstance(amt, bool) or not GIFT_MIN <= amt <= GIFT_MAX:
                raise ApiError(400, "bad_amount")
            pid, amt_c, price_c = None, amt * 100, amt * 100
        elif kind == "item":
            pid = body.get("pid")
            p = self.catalog.P.get(pid) if isinstance(pid, str) else None
            if not p or p.get("gone") or not p["stock"]:
                raise ApiError(409, "stock", pid=str(pid)[:30])
            amt_c, price_c = 0, half_up(p["price"] * 100) + self.sel_clean(p, None)[1]
        else:
            raise ApiError(400, "bad_gift")
        exp = body.get("total")
        if isinstance(exp, (int, float)) and not isinstance(exp, bool) and abs(half_up(exp * 100) - price_c) > 1:
            raise ApiError(409, "price_changed", total=sar(price_c))
        cid = clean(body.get("cid"), 40) or None   # the same attempt sent twice (a lost reply) sends one gift
        if cid:
            old = self.db.one("SELECT * FROM gifts WHERE from_cust=? AND json_extract(data,'$.cid')=?", (me["id"], cid))
            if old:
                return {"gift": self.gift_view(old, True), "acct": self.account(me["id"])}
        gid = "g" + secrets.token_hex(6)
        st = self.snap()

        def send(c):
            n = c.execute("SELECT COUNT(*) FROM gifts WHERE from_cust=? AND ts>?", (me["id"], t - 86400_000)).fetchone()[0]
            if n >= 30:
                raise ApiError(429, "slow_down")
            tier = tier_for(self.tier_points(lambda s, a: c.execute(s, a).fetchone()[0], me["id"], t), clean_tiers(st.get("tiers")) or DEFAULT_TIERS)
            earn = tier_earn(price_c, tier)
            data = {"from_name": me["name"], "to_name": clean(body.get("name"), 30), "msg": clean(body.get("msg"), 140), "pid": pid, "amt_c": amt_c,
                    "price_c": price_c, "earn": earn, "payM": body.get("payM") if body.get("payM") in ("card", "apple") else "card", "cid": cid}
            c.execute("INSERT INTO gifts(id,ts,from_cust,to_phone,kind,state,data) VALUES(?,?,?,?,?,'new',?)", (gid, t, me["id"], to, kind, json.dumps(data, ensure_ascii=False)))
            self._add_pts(c, me["id"], earn, "gift", {"ar": "هدية مرسلة", "en": "Gift sent"}, gid)
            self._bump_acct(c, me["id"], to)
        self.mutate(send)
        rc = self.db.one("SELECT id FROM customers WHERE phone=?", (to,))
        if rc:
            self.push("cust", [rc["id"]], {"ar": "وصلتك هدية من %s" % me["name"], "en": "%s sent you a gift" % me["name"]},
                      {"ar": "تجدها في تبويب «الهدايا».", "en": "You will find it in the Gifts tab."}, "/#g=recv." + kind, "g-" + gid)
        return {"gift": self.gift_view(self.db.one("SELECT * FROM gifts WHERE id=?", (gid,)), True), "acct": self.account(me["id"])}

    def my_redeem(self, dev, body):
        """Points into wallet credit (a reward that is an amount; a product reward goes through an order)."""
        me, st = self._me(dev), self.snap()
        r = next((x for x in st["rewards"] if x["id"] == body.get("id") and x.get("on", True) is not False and x.get("credit")), None)
        if not r:
            raise ApiError(400, "bad_reward")

        def go(c):
            if self._sum_pts(c, me["id"]) < r["pts"]:
                raise ApiError(409, "no_points")
            self._add_pts(c, me["id"], -r["pts"], "credit", {"ar": "إستبدال: رصيد في المحفظة", "en": "Redeemed: wallet credit"}, r["id"])
            self._add_bal(c, me["id"], half_up(r["credit"] * 100), "reward", {"ar": "مكافأة نقاط", "en": "Points reward"}, r["id"])
        self.mutate(go)
        return {"credit": r["credit"], "acct": self.account(me["id"])}

    def my_topup(self, dev, body):
        """Topping up the wallet. The payment is a trial until a payment gateway is connected (before launch)."""
        me, amt = self._me(dev), body.get("amt")
        if not isinstance(amt, int) or isinstance(amt, bool) or not GIFT_MIN <= amt <= GIFT_MAX:
            raise ApiError(400, "bad_amount")
        cid = clean(body.get("cid"), 40) or None
        if cid and self.db.one("SELECT 1 FROM wallet WHERE cust_id=? AND kind='topup' AND ref=?", (me["id"], cid)):
            return {"acct": self.account(me["id"])}
        self.mutate(lambda c: self._add_bal(c, me["id"], amt * 100, "topup", {"ar": "شحن المحفظة", "en": "Wallet top-up"}, cid))
        return {"acct": self.account(me["id"])}

    def my_delete(self, dev):
        """The account goes for good: points, wallet, gifts received, the customer and his phones. His orders stay in the
        café's books without his name, number or address. Not while one of them is still open."""
        me = self._me(dev, open_it=False)

        def go(c):
            if c.execute("SELECT 1 FROM orders WHERE cust_id=? AND fin=0 AND rej=0", (me["id"],)).fetchone():
                raise ApiError(409, "open_orders")
            for r in c.execute("SELECT id, data FROM orders WHERE cust_id=?", (me["id"],)).fetchall():
                o = json.loads(r["data"])
                o["cust"] = {"name": "عميل محذوف", "tail": "", "phone": ""}
                o["addr"] = None
                o.pop("gift", None)
                o.pop("rate", None)
                c.execute("UPDATE orders SET data=?, cust_id=NULL, dev_hash='gone', cid=NULL WHERE id=?", (json.dumps(o, ensure_ascii=False), r["id"]))
            for tbl in ("ledger", "wallet", "bonus", "devices"):
                c.execute("DELETE FROM %s WHERE cust_id=?" % tbl, (me["id"],))
            c.execute("DELETE FROM push WHERE who='cust' AND ref=?", (str(me["id"]),))
            c.execute("DELETE FROM gifts WHERE to_phone=?", (me["phone"],))
            c.execute("UPDATE gifts SET from_cust=NULL WHERE from_cust=?", (me["id"],))   # what he sent stays with the people who got it
            c.execute("DELETE FROM customers WHERE id=?", (me["id"],))
        self.mutate(go)
        return {}

    def _undo(self, c, o):
        """An order turned down or cancelled: what it used comes back and the points it gave go."""
        r = c.execute("SELECT cust_id FROM orders WHERE id=?", (o["id"],)).fetchone()
        cid = r["cust_id"] if r else None
        for it in o["items"]:
            if it.get("gift"):
                g = c.execute("SELECT to_phone, from_cust FROM gifts WHERE id=? AND state='used'", (it["gift"],)).fetchone()
                if g:
                    c.execute("UPDATE gifts SET state='new' WHERE id=?", (it["gift"],))
                    self._bump_acct(c, g["from_cust"], g["to_phone"])
        if o.get("gid"):   # a gift brought to someone: it did not go
            g = c.execute("SELECT from_cust FROM gifts WHERE id=?", (o["gid"],)).fetchone()
            c.execute("UPDATE gifts SET state='void' WHERE id=?", (o["gid"],))
            if g:
                self._bump_acct(c, g["from_cust"])
        op = c.execute("SELECT opened FROM customers WHERE id=?", (cid,)).fetchone() if cid else None
        if not op or not op["opened"]:   # the account still lives on the phone, which gives it back itself
            return
        no = o["no"].replace("\u200e", "")
        if o.get("spent"):
            self._add_pts(c, cid, int(o["spent"]), "back", {"ar": "إرجاع نقاط الطلب %s" % no, "en": "Points returned for order %s" % no}, o["id"])
        take = min(int(o.get("earn") or 0), max(0, self._sum_pts(c, cid)))
        if take:
            self._add_pts(c, cid, -take, "unearn", {"ar": "إلغاء نقاط الطلب %s" % no, "en": "Points reversed for order %s" % no}, o["id"])
        bal_c = half_up((o.get("bal") or 0) * 100)
        if bal_c:
            self._add_bal(c, cid, bal_c, "refund", {"ar": "إرجاع رصيد الطلب %s" % no, "en": "Refund for order %s" % no}, o["id"])

    # ---------------------------------------------------------------- orders: staff operations
    def _advance(self, o, k):
        t = now_ms()
        while len(o["at"]) <= k:
            o["at"].append(t)
        o["at"][k] = t
        o["st"] = k
        if k == 3:
            o["fin"] = True
            o["done"] = True

    def _save_order(self, c, o):
        c.execute(
            "UPDATE orders SET st=?, rej=?, fin=?, driver_id=?, rev=?, data=? WHERE id=?",
            (o["st"], 1 if o["rej"] else 0, 1 if o["fin"] else 0, o["driver"]["id"] if o.get("driver") else None, self.rev + 1, json.dumps(o, ensure_ascii=False), o["id"]),
        )

    def _load(self, c, oid):
        r = c.execute("SELECT data FROM orders WHERE id=?", (oid,)).fetchone() if isinstance(oid, str) else None
        if not r:
            raise ApiError(404, "not_found")
        return json.loads(r["data"])

    def _check_code(self, o, code):
        """The 4-digit code the customer shows. Five wrong tries lock the order for three minutes."""
        t = now_ms()
        tr = o.get("tries") or {"n": 0, "until": 0}
        if tr["until"] > t:
            raise ApiError(429, "locked", retry=int((tr["until"] - t) / 1000) + 1)
        good = isinstance(code, str) and hmac.compare_digest(code.strip().encode(), o["code"].encode())
        if good:
            o.pop("tries", None)
            return True
        tr["n"] += 1
        if tr["n"] >= 5:
            tr = {"n": 0, "until": t + 180_000}
        o["tries"] = tr
        return False

    def staff_order(self, staff, body):
        role, oid, op = staff["role"], body.get("id"), body.get("op")
        if not isinstance(op, str):
            raise ApiError(400, "bad_request")
        wrong, quiet = [], []

        def go(c):
            o = self._load(c, oid)
            if staff.get("branch") and role == "recv" and o["branch"] != staff["branch"]:   # another branch's order
                raise ApiError(404, "not_found")
            if o["rej"] or o["fin"]:
                raise ApiError(409, "bad_state")
            mode, st = o["mode"], o["st"]
            if role == "driver":
                if mode != "delivery":
                    raise ApiError(409, "bad_state")
                if op == "take":   # from "being prepared" on, so the driver can get ready (0.6)
                    if st not in (1, 2) or o.get("driver"):
                        raise ApiError(409, "taken" if o.get("driver") else "bad_state")
                    n = c.execute("SELECT COUNT(*) FROM orders WHERE driver_id=? AND fin=0 AND rej=0", (staff["id"],)).fetchone()[0]
                    if n >= 5:
                        raise ApiError(409, "too_many")
                    o["driver"] = {"id": staff["id"], "name": staff["name"], "ts": now_ms(), "phone": staff.get("phone") or ""}
                elif op == "release":
                    if st not in (1, 2) or not o.get("driver") or o["driver"]["id"] != staff["id"]:
                        raise ApiError(409, "bad_state")
                    o["driver"] = None
                elif op == "deliver":
                    if st != 2 or not o.get("driver") or o["driver"]["id"] != staff["id"]:
                        raise ApiError(409, "bad_state")
                    if not self._check_code(o, body.get("code")):
                        wrong.append(True)
                        self._save_order_quiet(c, o)
                        return o
                    self._advance(o, 3)
                elif op == "arrive":   # 0.7.5: at the customer's door: he hears it (again at most once a minute)
                    if st != 2 or not o.get("driver") or o["driver"]["id"] != staff["id"]:
                        raise ApiError(409, "bad_state")
                    t = now_ms()
                    if o.get("arr") and t - o["arr"] < ARRIVE_GAP_MS:
                        quiet.append(True)
                        return o
                    o["arr"] = t
                else:
                    raise ApiError(400, "bad_op")
            else:
                if op == "accept":
                    if st != 0:
                        raise ApiError(409, "bad_state")
                    self._advance(o, 1)
                elif op == "ready":
                    if st != 1:
                        raise ApiError(409, "bad_state")
                    self._advance(o, 2)
                elif op == "deliver":
                    if st != 2:
                        raise ApiError(409, "bad_state")
                    if mode != "ship" and not body.get("skip"):
                        if not self._check_code(o, body.get("code")):
                            wrong.append(True)
                            self._save_order_quiet(c, o)
                            return o
                    self._advance(o, 3)
                elif op == "reject":
                    if st != 0:
                        raise ApiError(409, "bad_state")
                    why = REASONS.get(body.get("reason"))
                    if not why:
                        raise ApiError(400, "bad_reason")
                    o["rej"] = {"ts": now_ms(), "id": body.get("reason"), "why": {"ar": why[0], "en": why[1]}}
                    self._undo(c, o)
                elif op == "unassign":
                    if mode != "delivery" or st not in (1, 2) or not o.get("driver"):
                        raise ApiError(409, "bad_state")
                    o["driver"] = None
                else:
                    raise ApiError(400, "bad_op")
            self._save_order(c, o)
            return o

        o = self.mutate(go)
        if wrong:
            raise ApiError(403, "wrong_code", left=max(0, 5 - (o.get("tries") or {"n": 0})["n"]), retry=max(0, int(((o.get("tries") or {"until": 0})["until"] - now_ms()) / 1000)))
        if not quiet:
            self.push_order_event(o, op, role)
        return self.staff_view(o, phone=(role in ("driver", "admin")), full_addr=True)

    def _save_order_quiet(self, c, o):
        """Remember the wrong-code counter without waking every screen."""
        c.execute("UPDATE orders SET data=? WHERE id=?", (json.dumps(o, ensure_ascii=False), o["id"]))

    # ---------------------------------------------------------------- settings (reception and admin)
    def set_branch(self, bid, pause, staff=None):
        b = self.catalog.B.get(bid) if isinstance(bid, str) else None
        if not b or b.get("gone") or not isinstance(pause, bool):
            raise ApiError(400, "bad_request")
        if staff and staff.get("branch") and staff["branch"] != bid:   # a branch desk pauses its own branch only
            raise ApiError(403, "not_yours")

        def go(c):
            self.settings["br"].setdefault(bid, {})["pause"] = pause

        self.mutate(go, settings=True)

    def set_menu_api(self, b):
        """Price and availability of one product (the admin page of 0.3 and the availability switch).
        price absent = leave, null = back to the first menu's price; stock absent = leave."""
        pid = b.get("id")
        p = self.catalog.P.get(pid) if isinstance(pid, str) else None
        if not p or p.get("gone"):
            raise ApiError(400, "bad_item")
        has_price, has_stock = "price" in b, "stock" in b
        price, stock = b.get("price"), b.get("stock")
        if not (has_price or has_stock):
            raise ApiError(400, "bad_request")
        if has_price and price is not None:
            if isinstance(price, bool) or not isinstance(price, (int, float)) or not 0.5 <= price <= 50000:
                raise ApiError(400, "bad_price")
            price = half_up(price * 100) / 100
        if has_price and price is None:
            price = self.seed_ref.get(pid, (p["price"],))[0]
        if has_stock and not isinstance(stock, bool):
            raise ApiError(400, "bad_request")

        def go(c):
            q = dict(self._live_product(pid))
            if has_price:
                q["price"] = price
            if has_stock:
                q["stock"] = stock
            c.execute("UPDATE products SET data=? WHERE id=?", (json.dumps(q, ensure_ascii=False), pid))
            return q

        return self.mutate(go, catalog=True)

    # ---------------------------------------------------------------- admin: the menu (products, categories, photos)
    def _live_product(self, pid):
        p = self.catalog.P.get(pid) if isinstance(pid, str) else None
        if not p or p.get("gone"):
            raise ApiError(404, "not_found")
        return p

    def _live_cat(self, cid):
        x = self.catalog.C.get(cid) if isinstance(cid, str) else None
        if not x or x.get("gone"):
            raise ApiError(404, "not_found")
        return x

    @staticmethod
    def _new_id(c, table, prefix):
        while True:
            i = prefix + secrets.token_hex(4)
            if not c.execute("SELECT 1 FROM %s WHERE id=?" % table, (i,)).fetchone():
                return i

    def _default_art(self, cid, kind):
        """A new product draws like the first product of its category until it gets a photo."""
        first = next((p for p in self.catalog.live_prods() if cid in p["cats"]), None)
        return (first["art"], first["tone"]) if first else (KIND_ART.get(kind, "hot"), "#C8965A")

    def _clean_product(self, raw, old):
        """What the admin typed, checked and in the form every page reads. Called inside the transaction."""
        if not isinstance(raw, dict):
            raise ApiError(400, "bad_request")
        menu = self.catalog
        ar, en = clean(raw.get("ar"), 60), clean(raw.get("en"), 60)
        if len(ar) < 2:
            raise ApiError(400, "bad_name")
        price = raw.get("price")
        if isinstance(price, bool) or not isinstance(price, (int, float)) or not 0.5 <= price <= 50000:
            raise ApiError(400, "bad_price")
        cats = raw.get("cats")
        if not isinstance(cats, list) or not 1 <= len(cats) <= 6:
            raise ApiError(400, "bad_cat")
        picked = []
        for cid in cats:
            x = menu.C.get(cid) if isinstance(cid, str) else None
            if not x or x.get("gone"):
                raise ApiError(400, "bad_cat")
            if cid not in picked:
                picked.append(cid)
        if len({menu.C[x]["kind"] for x in picked}) > 1:   # a product is either made at the branch or shipped, not both
            raise ApiError(400, "mixed_kinds")
        kind = menu.C[picked[0]]["kind"]
        opts = raw.get("opts", [])
        if not isinstance(opts, list) or len(opts) > 8:
            raise ApiError(400, "bad_opts")
        groups = []
        for g in opts:
            if not isinstance(g, str) or g not in self.cat["opts"]:
                raise ApiError(400, "bad_opts")
            if g not in groups:
                groups.append(g)
        cal = raw.get("cal", 0)
        cal = 0 if cal in (None, "") else cal
        if isinstance(cal, bool) or not isinstance(cal, int) or not 0 <= cal <= 9999:
            raise ApiError(400, "bad_request")
        rows = raw.get("d") or []
        if not isinstance(rows, list) or len(rows) > 10:
            raise ApiError(400, "bad_request")
        d = []
        for r in rows:
            if not isinstance(r, dict):
                raise ApiError(400, "bad_request")
            k, v = pair(r.get("k"), 30), pair(r.get("v"), 160)
            if (k["ar"] or k["en"]) and (v["ar"] or v["en"]):
                d.append({"k": k, "v": v})
        stock, fship = raw.get("stock", True), raw.get("fship", False)
        if not isinstance(stock, bool) or not isinstance(fship, bool):
            raise ApiError(400, "bad_request")
        im = None
        if raw.get("img") is not None:
            iid = raw.get("img")
            row = self.db.one("SELECT w,h,bg,f FROM images WHERE id=?", (iid,)) if isinstance(iid, str) and re.fullmatch(r"[0-9a-f]{32}", iid) else None
            if not row:
                raise ApiError(400, "bad_img")
            im = {"id": iid, "bg": row["bg"], "f": row["f"], "r": round(row["w"] / row["h"], 4)}
        art, tone = (old["art"], old["tone"]) if old else self._default_art(picked[0], kind)
        off = raw.get("off") or []   # 0.7: the branches it is not available at
        if not isinstance(off, list) or len(off) > MAX_BRANCHES or any(not isinstance(x, str) or x not in menu.B for x in off):
            raise ApiError(400, "bad_branch")
        off = [x for i, x in enumerate(off) if x not in off[:i]]
        return {
            "cat": picked[0], "cats": picked, "ar": ar, "en": en, "price": half_up(price * 100) / 100, "cal": cal, "art": art, "tone": tone,
            "opts": groups, "desc": or_none(pair(raw.get("desc"), 600, text=True)), "sub": or_none(pair(raw.get("sub"), 40)), "d": d or None,
            "badge": or_none(pair(raw.get("badge"), 24)), "stock": stock, "fship": fship and kind == "retail", "img": im, "off": off or None,
        }

    def admin_product(self, b):
        op, pid = b.get("op"), b.get("id")
        if op == "save":
            def go(c):
                old = self._live_product(pid) if pid is not None else None
                q = self._clean_product(b.get("p"), old)
                if old:
                    q["id"] = pid
                    c.execute("UPDATE products SET data=? WHERE id=?", (json.dumps(q, ensure_ascii=False), pid))
                else:
                    if c.execute("SELECT COUNT(*) FROM products WHERE gone=0").fetchone()[0] >= MAX_PRODUCTS:
                        raise ApiError(409, "too_many")
                    q["id"] = self._new_id(c, "products", "p")
                    sort = c.execute("SELECT COALESCE(MAX(sort), -1) + 1 FROM products").fetchone()[0]
                    c.execute("INSERT INTO products(id,sort,gone,data) VALUES(?,?,0,?)", (q["id"], sort, json.dumps(q, ensure_ascii=False)))
                self._gc_images(c)
                return q

            q = self.mutate(go, catalog=True)
            return {"id": q["id"], "product": q}
        if op == "stock":
            if not isinstance(b.get("stock"), bool):
                raise ApiError(400, "bad_request")
            self._live_product(pid)
            return {"product": self.set_menu_api({"id": pid, "stock": b["stock"]})}
        if op == "here":   # available at one branch or not (the admin; a branch desk for its own branch)
            return {"product": self.set_here(pid, b.get("branch"), b.get("on"))}
        if op == "delete":
            def go(c):
                q = dict(self._live_product(pid))
                q["img"], q["stock"] = None, False   # the name and price stay for the old orders; the photo goes
                c.execute("UPDATE products SET gone=1, data=? WHERE id=?", (json.dumps(q, ensure_ascii=False), pid))
                self._gc_images(c)

            self.mutate(go, catalog=True)
            return {}
        raise ApiError(400, "bad_op")

    def set_here(self, pid, bid, on, staff=None):
        if not isinstance(bid, str) or bid not in self.catalog.B or self.catalog.B[bid].get("gone") or not isinstance(on, bool):
            raise ApiError(400, "bad_request")
        if staff and staff.get("branch") and staff["branch"] != bid:
            raise ApiError(403, "not_yours")

        def go(c):
            q = dict(self._live_product(pid))
            off = [x for x in (q.get("off") or []) if x != bid] + ([] if on else [bid])
            q["off"] = off or None
            c.execute("UPDATE products SET data=? WHERE id=?", (json.dumps(q, ensure_ascii=False), pid))
            return q
        return self.mutate(go, catalog=True)

    def _cat_used(self, cid):
        return any(cid in p["cats"] for p in self.catalog.live_prods())

    def admin_cat(self, b):
        op, cid = b.get("op"), b.get("id")
        if op == "save":
            raw = b.get("c") if isinstance(b.get("c"), dict) else {}
            ar, en, kind = clean(raw.get("ar"), 40), clean(raw.get("en"), 40), raw.get("kind")
            if len(ar) < 2:
                raise ApiError(400, "bad_name")
            if kind is not None and kind not in KINDS:
                raise ApiError(400, "bad_kind")

            def go(c):
                if cid is None:
                    if kind is None:
                        raise ApiError(400, "bad_kind")
                    if len(self.catalog.live_cats()) >= MAX_CATS:
                        raise ApiError(409, "too_many")
                    i = self._new_id(c, "cats", "c")
                    sort = c.execute("SELECT COALESCE(MAX(sort), -1) + 1 FROM cats").fetchone()[0]
                    c.execute("INSERT INTO cats(id,sort,gone,data) VALUES(?,?,0,?)", (i, sort, json.dumps({"ar": ar, "en": en, "kind": kind}, ensure_ascii=False)))
                    return i
                x = self._live_cat(cid)
                k2 = kind or x["kind"]
                if k2 != x["kind"] and self._cat_used(cid):   # its products would change from made-at-the-branch to shipped
                    raise ApiError(409, "cat_not_empty")
                c.execute("UPDATE cats SET data=? WHERE id=?", (json.dumps({"ar": ar, "en": en, "kind": k2}, ensure_ascii=False), cid))
                return cid

            return {"id": self.mutate(go, catalog=True)}
        if op == "delete":
            def go(c):
                self._live_cat(cid)
                if self._cat_used(cid):
                    raise ApiError(409, "cat_not_empty")
                if len(self.catalog.live_cats()) <= 1:
                    raise ApiError(409, "last_cat")
                c.execute("UPDATE cats SET gone=1 WHERE id=?", (cid,))

            self.mutate(go, catalog=True)
            return {}
        if op == "move":
            step = b.get("d")
            if step not in (-1, 1) or isinstance(step, bool):
                raise ApiError(400, "bad_request")

            def go(c):
                self._live_cat(cid)
                live = [x["id"] for x in self.catalog.live_cats()]
                i = live.index(cid)
                j = i + step
                if 0 <= j < len(live):
                    live[i], live[j] = live[j], live[i]
                order = live + [x["id"] for x in self.catalog.cats if x.get("gone")]
                for n, x in enumerate(order):
                    c.execute("UPDATE cats SET sort=? WHERE id=?", (n, x))

            self.mutate(go, catalog=True)
            return {}
        raise ApiError(400, "bad_op")

    # ---------------------------------------------------------------- admin: branches
    def _live_branch(self, bid):
        b = self.catalog.B.get(bid) if isinstance(bid, str) else None
        if not b or b.get("gone"):
            raise ApiError(404, "not_found")
        return b

    @staticmethod
    def _clean_branch(raw):
        if not isinstance(raw, dict):
            raise ApiError(400, "bad_request")
        ar, en = clean(raw.get("ar"), 60), clean(raw.get("en"), 60)
        if len(ar) < 2:
            raise ApiError(400, "bad_name")
        addr = pair(raw.get("addr"), 160)
        if len(addr["ar"]) < 3:
            raise ApiError(400, "bad_address")
        if raw.get("all_day") is True:
            h = "24"
        elif raw.get("all_day") in (False, None):
            o, c = hhmm(raw.get("open")), hhmm(raw.get("close"))
            if o == c:
                raise ApiError(400, "bad_hours")
            h = [o, c if c > o else c + 1440]   # closing after midnight: 06:00 to 02:00 is [360, 1560]
        else:
            raise ApiError(400, "bad_request")
        lat, lng = raw.get("lat"), raw.get("lng")
        if lat is None and lng is None:
            loc = (None, None)
        elif valid_latlng(lat, lng):
            loc = (round(lat, 6), round(lng, 6))
        else:
            raise ApiError(400, "bad_location")
        return {"ar": ar, "en": en, "addr": addr, "h": h, "lat": loc[0], "lng": loc[1]}

    def admin_branch(self, b):
        op, bid = b.get("op"), b.get("id")
        if op == "save":
            q = self._clean_branch(b.get("b"))

            def go(c):
                if bid is None:
                    if len(self.catalog.live_branches()) >= MAX_BRANCHES:
                        raise ApiError(409, "too_many")
                    i = self._new_id(c, "branches", "b")
                    sort = c.execute("SELECT COALESCE(MAX(sort), -1) + 1 FROM branches").fetchone()[0]
                    c.execute("INSERT INTO branches(id,sort,gone,data) VALUES(?,?,0,?)", (i, sort, json.dumps(q, ensure_ascii=False)))
                    return i
                self._live_branch(bid)
                c.execute("UPDATE branches SET data=? WHERE id=?", (json.dumps(q, ensure_ascii=False), bid))
                return bid

            return {"id": self.mutate(go, catalog=True)}
        if op == "delete":
            def go(c):
                self._live_branch(bid)
                if len(self.catalog.live_branches()) <= 1:
                    raise ApiError(409, "last_branch")
                if c.execute("SELECT 1 FROM orders WHERE branch=? AND fin=0 AND rej=0 LIMIT 1", (bid,)).fetchone():
                    raise ApiError(409, "branch_busy")   # its open orders are finished first (or rejected)
                c.execute("UPDATE branches SET gone=1 WHERE id=?", (bid,))
                self.settings["br"].pop(bid, None)

            self.mutate(go, settings=True, catalog=True)
            return {}
        raise ApiError(400, "bad_op")

    def open_link(self, url):
        """One request to a map site: (status, where it redirects to, the start of the page). Never follows a redirect."""
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
                                                   "Accept-Language": "en", "Cookie": "CONSENT=YES+; SOCS=CAI"})
        try:
            with urllib.request.build_opener(_NoRedirect).open(req, timeout=6) as r:
                return r.status, None, r.read(400_000).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.headers.get("Location"), ""
        except (urllib.error.URLError, OSError, ValueError):
            raise ApiError(502, "link_unreachable")

    def where_link_goes(self, url):
        """Where a (short) map link leads: the address it redirects to, or, for a page, an address with the place it shows."""
        status, loc, body = self.open_link(url)
        if 300 <= status < 400 and loc:
            return loc
        c = coords_in_page(body) if status == 200 else None
        return "https://www.google.com/maps/@%s,%s,17z" % c if c else None

    def map_link(self, text):
        """A pasted location: coordinates, or a Google (or Apple) Maps link, short ones included."""
        url = clean(text, 800)
        loc = coords_in(url)
        if loc:
            return {"lat": loc[0], "lng": loc[1]}
        u = urllib.parse.urlsplit(url)
        if u.scheme not in ("https", "http") or (u.hostname or "").lower() not in MAP_HOSTS:
            raise ApiError(400, "bad_link")
        for _ in range(5):   # a short link can take a few steps; only map sites are asked, and only for where they lead
            nxt = self.where_link_goes(url)
            if not nxt:
                break
            url = urllib.parse.urljoin(url, nxt)
            loc = coords_in(url)
            if loc:
                return {"lat": loc[0], "lng": loc[1]}
            n = urllib.parse.urlsplit(url)
            if n.scheme not in ("https", "http") or (n.hostname or "").lower() not in MAP_HOSTS:
                break   # e.g. a cookie-consent page
        raise ApiError(422, "no_location")

    def upload_image(self, body):
        """A product photo from the admin page. The page makes it small first (a large copy and a small one); the server
        only checks that both really are photos of a sensible size, and keeps them. A product uses it once it is saved."""
        def decode(v, limit):
            if not isinstance(v, str) or not v:
                raise ApiError(400, "bad_img")
            if len(v) > limit * 4 // 3 + 8:
                raise ApiError(413, "too_big")
            try:
                return base64.b64decode(v, validate=True)
            except (ValueError, binascii.Error):
                raise ApiError(400, "bad_img")

        full, thumb = decode(body.get("full"), IMG_FULL_MAX), decode(body.get("thumb"), IMG_THUMB_MAX)
        fi, ti = image_info(full), image_info(thumb)
        if not fi or not ti or not (48 <= fi[1] <= 4096 and 48 <= fi[2] <= 4096) or not (16 <= ti[1] <= 800 and 16 <= ti[2] <= 800):
            raise ApiError(400, "bad_img")
        bg = body.get("bg")
        if bg is not None and not (isinstance(bg, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", bg)):
            raise ApiError(400, "bad_img")
        f = body.get("f") if body.get("f") in ("c", "v") else "v"
        iid, t = hashlib.sha256(full).hexdigest()[:32], now_ms()
        with self.db.tx() as c:
            c.execute("INSERT OR IGNORE INTO images(id,mime,w,h,bg,f,created,data,tmime,thumb) VALUES(?,?,?,?,?,?,?,?,?,?)", (iid, fi[0], fi[1], fi[2], bg.lower() if bg else None, f, t, full, ti[0], thumb))
            c.execute("UPDATE images SET created=? WHERE id=?", (t, iid))   # the same photo again: a fresh grace period
        r = self.db.one("SELECT w,h,bg,f FROM images WHERE id=?", (iid,))
        return {"id": iid, "bg": r["bg"], "f": r["f"], "r": round(r["w"] / r["h"], 4)}

    def image(self, iid, small):
        r = self.db.one("SELECT %s FROM images WHERE id=?" % ("tmime AS m, thumb AS d" if small else "mime AS m, data AS d"), (iid,))
        return (r["m"], bytes(r["d"])) if r else None

    def set_code(self, code, on, pct):
        code = clean(code, 20).upper()
        if not re.fullmatch(r"[A-Z0-9]{3,20}", code):
            raise ApiError(400, "bad_code")
        if pct is not None and (isinstance(pct, bool) or not isinstance(pct, int) or not 1 <= pct <= 90):
            raise ApiError(400, "bad_pct")
        if on is not None and not isinstance(on, bool):
            raise ApiError(400, "bad_request")

        def go(c):
            cd = self.settings["codes"].setdefault(code, {"on": True, "pct": 10})
            if on is not None:
                cd["on"] = on
            if pct is not None:
                cd["pct"] = pct

        self.mutate(go, settings=True)

    def set_banner(self, bid, on):
        if not isinstance(on, bool) or not any(b["id"] == bid for b in self.settings["banners"]):
            raise ApiError(400, "bad_request")

        def go(c):
            bn = self.settings["bn"]
            bn[bid] = on
            if not any(bn.get(b["id"]) is not False for b in self.settings["banners"]):
                raise ApiError(409, "last_banner")
            if on:
                bn.pop(bid, None)

        self.mutate(go, settings=True)

    def set_fees(self, body):
        ship, dfee, don = body.get("ship"), body.get("delivery_fee"), body.get("delivery_on")
        km, mn = body.get("delivery_km"), body.get("delivery_min")
        for v in (ship, dfee):
            if v is not None and (isinstance(v, bool) or not isinstance(v, (int, float)) or not 0 <= v <= 200):
                raise ApiError(400, "bad_fee")
        if km is not None and (isinstance(km, bool) or not isinstance(km, (int, float)) or not 0 <= km <= 100):
            raise ApiError(400, "bad_km")
        if mn is not None and (isinstance(mn, bool) or not isinstance(mn, (int, float)) or not 0 <= mn <= 1000):
            raise ApiError(400, "bad_fee")
        if don is not None and not isinstance(don, bool):
            raise ApiError(400, "bad_request")

        def go(c):
            if km is not None:
                self.settings["delivery"]["km"] = round(km, 1)
            if mn is not None:
                self.settings["delivery"]["min"] = half_up(mn * 100) / 100
            if ship is not None:
                self.settings["ship"] = half_up(ship * 100) / 100
            if dfee is not None:
                self.settings["delivery"]["fee"] = half_up(dfee * 100) / 100
            if don is not None:
                self.settings["delivery"]["on"] = don

        self.mutate(go, settings=True)

    # ---------------------------------------------------------------- admin: the order desk of each branch (0.7)
    def desks(self):
        """The branches that have an order desk of their own (the desk that sees every branch is the PIN in the settings)."""
        return [{"branch": r["branch"], "active": bool(r["active"])} for r in self.db.q("SELECT branch, active FROM staff WHERE role='recv' AND branch!='' ORDER BY id")]

    def admin_desk(self, b):
        op, bid = b.get("op"), b.get("branch")
        br = self.catalog.B.get(bid) if isinstance(bid, str) else None
        if not br or br.get("gone"):
            raise ApiError(400, "bad_branch")
        name = DESK_PREFIX + bid
        row = self.db.one("SELECT id FROM staff WHERE role='recv' AND name_key=?", (name_key(name),))
        if op in ("add", "pin"):
            if not valid_pin(b.get("pin")):
                raise ApiError(400, "bad_pin")
            if op == "add" and row:
                raise ApiError(409, "exists")
            if op == "pin" and not row:
                raise ApiError(404, "not_found")
            sid = self.set_staff("recv", name, b["pin"], row["id"] if row else None)
            self.mutate(lambda c: c.execute("UPDATE staff SET branch=? WHERE id=?", (bid, sid)))
            return {}
        if not row:
            raise ApiError(404, "not_found")
        if op == "on":
            if not isinstance(b.get("on"), bool):
                raise ApiError(400, "bad_request")

            def go(c):
                c.execute("UPDATE staff SET active=? WHERE id=?", (1 if b["on"] else 0, row["id"]))
                if not b["on"]:
                    c.execute("DELETE FROM sessions WHERE staff_id=?", (row["id"],))
            self.mutate(go)
            return {}
        if op == "del":
            def go(c):
                c.execute("DELETE FROM sessions WHERE staff_id=?", (row["id"],))
                c.execute("DELETE FROM staff WHERE id=?", (row["id"],))
            self.mutate(go)
            return {}
        raise ApiError(400, "bad_op")

    # ---------------------------------------------------------------- admin: drivers, customers, PINs
    @staticmethod
    def driver_phone(phone):
        """A driver's mobile as kept: 5XXXXXXXX (from 05…, 5… or +966 5…), or empty."""
        phone = re.sub(r"\D", "", str(phone or ""))
        if phone.startswith("966"):
            phone = phone[3:]
        if phone.startswith("0"):
            phone = phone[1:]
        if phone and not valid_phone(phone):
            raise ApiError(400, "bad_phone")
        return phone

    def set_driver_phone(self, sid, phone):
        """A driver's mobile (or empty to remove it). The orders he carries now get it as well."""
        phone = self.driver_phone(phone)

        def go(c):
            c.execute("UPDATE staff SET phone=? WHERE id=? AND role='driver'", (phone, sid))
            for r in c.execute("SELECT data FROM orders WHERE driver_id=? AND fin=0 AND rej=0", (sid,)).fetchall():
                o = json.loads(r["data"])
                o["driver"]["phone"] = phone
                self._save_order(c, o)

        self.mutate(go)
        return {"phone": phone}

    def drivers(self):
        rows = self.db.q("SELECT id,name,active,phone FROM staff WHERE role='driver' ORDER BY id")
        busy = {r["driver_id"]: r["n"] for r in self.db.q("SELECT driver_id, COUNT(*) n FROM orders WHERE fin=0 AND rej=0 AND driver_id IS NOT NULL GROUP BY driver_id")}
        return [{"id": r["id"], "name": r["name"], "active": bool(r["active"]), "busy": busy.get(r["id"], 0), "phone": r["phone"]} for r in rows]

    def admin_driver(self, body):
        op = body.get("op")
        if op == "add":
            name = clean(body.get("name"), 40)
            if len(name) < 2 or not valid_pin(body.get("pin")):
                raise ApiError(400, "bad_request")
            if self.db.one("SELECT 1 FROM staff WHERE role='driver' AND name_key=?", (name_key(name),)):
                raise ApiError(409, "exists")
            if self.db.one("SELECT COUNT(*) n FROM staff WHERE role='driver'")["n"] >= 30:
                raise ApiError(409, "too_many")
            self.driver_phone(body.get("phone"))   # a wrong number stops here, before the driver is made
            sid = self.set_staff("driver", name, body["pin"])
            if body.get("phone"):
                self.set_driver_phone(sid, body["phone"])
            return {"id": sid}
        sid = body.get("id")
        row = self.db.one("SELECT id FROM staff WHERE id=? AND role='driver'", (sid,)) if isinstance(sid, int) else None
        if not row:
            raise ApiError(404, "not_found")
        if op == "phone":
            return self.set_driver_phone(sid, body.get("phone"))
        if op == "pin":
            if not valid_pin(body.get("pin")):
                raise ApiError(400, "bad_pin")
            r = self.db.one("SELECT name FROM staff WHERE id=?", (sid,))
            self.set_staff("driver", r["name"], body["pin"], staff_id=sid)
        elif op in ("on", "off"):
            def go(c):
                c.execute("UPDATE staff SET active=? WHERE id=?", (1 if op == "on" else 0, sid))
                if op == "off":
                    c.execute("DELETE FROM sessions WHERE staff_id=?", (sid,))
            self.mutate(go)
        elif op == "remove":
            def go(c):
                if c.execute("SELECT 1 FROM orders WHERE driver_id=? AND fin=0 AND rej=0", (sid,)).fetchone():
                    raise ApiError(409, "busy")
                c.execute("DELETE FROM sessions WHERE staff_id=?", (sid,))
                c.execute("DELETE FROM staff WHERE id=?", (sid,))
            self.mutate(go)
        else:
            raise ApiError(400, "bad_op")
        return {}

    def set_tax(self, body):
        """The seller on the tax invoice. An empty VAT number switches the invoice off (orders made since keep theirs)."""
        vat = clean(body.get("vat"), 20)
        if not vat:
            self.mutate(lambda c: self.settings.update(tax=None), settings=True)
            return
        name, cr, addr = clean(body.get("name"), 80), clean(body.get("cr"), 20), clean(body.get("addr"), 160)
        if not valid_vat(vat):
            raise ApiError(400, "bad_vat")
        if len(name) < 2:
            raise ApiError(400, "bad_name")
        if cr and not re.fullmatch(r"\d{10}", cr):
            raise ApiError(400, "bad_cr")
        self.mutate(lambda c: self.settings.update(tax={"name": name, "vat": vat, "cr": cr, "addr": addr}), settings=True)

    # ---- a copy of the database for the admin to keep somewhere else (0.7)
    def db_copy(self, staff, body, ip):
        """A copy of the whole database right now, in a zip with a note on what it is (a phone then keeps it as a file
        instead of showing the database as text). It holds the customers' details: only for the admin, with his code."""
        self.verify_admin_pin(staff, body.get("pin"), ip)
        base = Path(self.db.path).parent / ("download-%s" % secrets.token_hex(6))
        db, zp = base.with_suffix(".db.tmp"), base.with_suffix(".zip.tmp")
        try:
            self.copy_for_outside(db)   # 0.7.7: without this server's keys
            when = self.local_dt(now_ms()).strftime("%Y-%m-%d %H:%M")
            note = (
                "نسخة احتياطية من بيانات واي! أُخذت %s (بتوقيت المتجر)، النسخة %s.\n\n"
                "why.db: قاعدة البيانات كاملة (العملاء والطلبات والنقاط والمحفظة والهدايا والمنتجات والفروع والرموز السرية مشفّرة).\n"
                "هذا الملف للاسترجاع عند الحاجة، لا للقراءة: لو فتحته يظهر كرموز غير مفهومة، وهذا طبيعي.\n"
                "فيه بيانات العملاء: احفظه في مكان آمن (جهازك أو Google Drive)، ولا ترفعه على مستودع عام ولا ترسله لأحد.\n\n"
                "الاسترجاع على سيرفر (الخدمة متوقفة): ضع why.db مكان /var/lib/why/why.db بمالك why وصلاحية 600، "
                "واحذف why.db-wal و why.db-shm إن وُجدا، ثم شغّل الخدمة why-server.\n"
                "مفاتيح الخادم (الطريق، واتساب، الإيميل) غير موجودة في هذه النسخة: بعد الاسترجاع تُكتب من جديد بأوامرها.\n"
            ) % (when, VERSION)
            with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
                z.write(db, "why.db")
                z.writestr("README.txt", note.encode("utf-8"))
            os.chmod(zp, 0o600)
        finally:
            db.unlink(missing_ok=True)
        return zp, "why-backup-%s.zip" % self.today()

    def backups_info(self):
        """The copies the server keeps by itself every day (on the same server), and the e-mailed copy (0.7.7)."""
        files = sorted(self.backup_dir.glob("why-*.db")) if self.backup_dir.exists() else []
        info = {"n": len(files), "last": files[-1].name[4:14] if files else "", "keep": self.keep_backups}
        conf = self.mail_conf()
        if conf:
            st = self._mail_state()
            info["mail"] = {"to": [mask_email(t) for t in conf["to"]], "hour": conf["hour"],
                            "ok": st.get("ok_day", ""), "err": st.get("err", "")}
        return info

    def copy_for_outside(self, dest):
        """A copy of the database to take off this server: the keys this server uses (road, WhatsApp, e-mail) are left
        out, so whoever holds the file cannot use them. A restored copy needs them typed again (routekey, wakey, mailkey)."""
        self.db.backup_to(dest)
        c = sqlite3.connect(str(dest))
        try:
            c.execute("DELETE FROM kv WHERE k IN (%s)" % ",".join("?" * len(SECRET_KV)), SECRET_KV)
            c.commit()
            c.execute("VACUUM")   # the deleted rows must not stay readable in the free pages of the file
        finally:
            c.close()

    # ---------------------------------------------------------------- the daily copy by e-mail (0.7.7)
    def mail_conf(self):
        get = lambda k: (self.db.one("SELECT v FROM kv WHERE k=?", (k,)) or {"v": ""})["v"]
        key, pw = get("mail_key"), get("mail_pw")
        to = [t for t in get("mail_to").split(",") if t]
        if not (key and pw and to and get("mail_from")):
            return None
        hour = get("mail_hour")
        return {"key": key, "pw": pw, "to": to, "from": get("mail_from"), "name": get("mail_name") or "Why! backup",
                "hour": int(hour) if hour.isdigit() else 3}

    def _mail_state(self):
        r = self.db.one("SELECT v FROM kv WHERE k='mail_state'")
        try:
            return json.loads(r["v"]) if r else {}
        except ValueError:
            return {}

    def _set_mail_state(self, st):
        with self.db.tx() as c:
            self._set_kv(c, "mail_state", json.dumps(st))

    @staticmethod
    def _mail_post(key, body):
        att = body.get("attachment")
        if att:   # the file's base64 is put into the request as bytes, not copied through json, to keep memory low
            b64 = att[0]["content"]
            head = json.dumps(dict(body, attachment=[{"name": att[0]["name"], "content": ""}]))
            cut = head.rindex('"content": ""') + len('"content": "')
            data = head[:cut].encode() + (b64 if isinstance(b64, bytes) else b64.encode()) + head[cut:].encode()
        else:
            data = json.dumps(body).encode()
        req = urllib.request.Request(MAIL_URL, data=data, method="POST",
                                     headers={"api-key": key, "Content-Type": "application/json", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read() or b"{}")

    def mail_backup(self, force=False):
        """Once a day, from the chosen hour (shop time): the copy, zipped and locked with the password (AES-256, openssl),
        to the chosen addresses. At most MAIL_TRIES_A_DAY tries a day. Returns 'sent', 'big', or None (nothing to do)."""
        conf = self.mail_conf()
        if not conf:
            return None
        day, st = self.today(), self._mail_state()
        if not force:
            if st.get("ok_day") == day or self.local_dt(now_ms()).hour < conf["hour"]:
                return None
            if st.get("try_day") == day and st.get("tries", 0) >= MAIL_TRIES_A_DAY:
                return None
        st["tries"] = (st.get("tries", 0) + 1) if st.get("try_day") == day else 1
        st["try_day"] = day
        self._set_mail_state(st)
        base = self.backup_dir.parent / ("mail-%s" % secrets.token_hex(6))
        db, zp, enc = base.with_suffix(".db.tmp"), base.with_suffix(".zip.tmp"), base.with_suffix(".enc.tmp")
        name = "why-backup-%s.zip.enc" % day
        try:
            self.copy_for_outside(db)
            with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
                z.write(db, "why.db")
                z.writestr("README.txt", backup_readme(self.local_dt(now_ms()).strftime("%Y-%m-%d %H:%M")).encode("utf-8"))
            lock_file(zp, enc, conf["pw"])
            big = enc.stat().st_size > MAIL_MAX_BYTES
            size_mb = "%.1f" % (enc.stat().st_size / 1048576)
            body = {"sender": {"name": conf["name"], "email": conf["from"]}, "to": [{"email": t} for t in conf["to"]],
                    "subject": "نسخة احتياطية مشفّرة %s" % day, "textContent": mail_text(day, name, size_mb, big)}
            if not big:
                body["attachment"] = [{"name": name, "content": base64.b64encode(enc.read_bytes())}]   # bytes: see _mail_post
            self.mail_post(conf["key"], body)
        except Exception as e:
            detail = e.read().decode("utf-8", "replace")[:300] if isinstance(e, urllib.error.HTTPError) else str(e)[:300]
            print("backup mail failed:", getattr(e, "code", ""), detail, file=sys.stderr, flush=True)
            st.update(err="send_failed" if isinstance(e, (urllib.error.URLError, OSError)) else "failed", err_day=day, err_detail=detail)
            self._set_mail_state(st)
            raise
        finally:
            for f in (db, zp, enc):
                f.unlink(missing_ok=True)
        st.update(ok_day=day, err="big" if big else "", err_day=day if big else "", err_detail="")
        self._set_mail_state(st)
        return "big" if big else "sent"

    def admin_pin(self, staff, body, ip):
        self.verify_admin_pin(staff, body.get("current"), ip)
        target = body.get("target")
        if target not in ("admin", "recv") or not valid_pin(body.get("pin")):
            raise ApiError(400, "bad_pin")
        self.set_staff(target, target, body["pin"])

    def add_points(self, cid, pts):
        if not isinstance(cid, int) or isinstance(cid, bool) or not isinstance(pts, int) or isinstance(pts, bool) or not 1 <= pts <= 5000:
            raise ApiError(400, "bad_request")

        def go(c):
            row = c.execute("SELECT opened FROM customers WHERE id=?", (cid,)).fetchone()
            if not row:
                raise ApiError(404, "not_found")
            # the bonus row tells the phone (a note to the customer) and counts toward the tier; the ledger holds the points
            c.execute("INSERT INTO bonus(cust_id,pts,ts,by_name,claimed) VALUES(?,?,?,?,0)", (cid, pts, now_ms(), "admin"))
            if row["opened"]:
                self._add_pts(c, cid, pts, "bonus", BONUS_LABEL)

        self.mutate(go)
        self.push("cust", [cid], {"ar": "وصلتك %d نقطة هدية" % pts, "en": "You received %d bonus points" % pts},
                  {"ar": "من واي، تجدها في نقاطك.", "en": "From Why! You will find them in your points."}, "/#p=points", "bonus")

    def wipe(self, staff, body, ip):
        self.verify_admin_pin(staff, body.get("pin"), ip)

        def go(c):
            for tbl in ("orders", "bonus", "ledger", "wallet", "gifts", "devices", "customers", "push_inbox"):
                c.execute("DELETE FROM %s" % tbl)
            c.execute("DELETE FROM push WHERE who='cust'")
            self._set_kv(c, "seq", "1000")

        self.mutate(go)

    def customers(self):
        since = now_ms() - TIER_DAYS * 86400_000
        tiers = self.snap()["tiers"]
        rows = self.db.q(
            "SELECT c.id,c.name,c.phone,c.pts,c.seen,c.created,c.email,c.birth,c.gender,c.invite,c.mk,c.opened,"
            " (SELECT COUNT(*) FROM orders o WHERE o.cust_id=c.id AND o.rej=0) n,"
            " (SELECT COALESCE(SUM(o.total),0) FROM orders o WHERE o.cust_id=c.id AND o.rej=0) spent,"
            " (SELECT COALESCE(SUM(CAST(json_extract(o.data,'$.earn') AS INTEGER)),0) FROM orders o WHERE o.cust_id=c.id AND o.rej=0 AND o.ts>=?) tpo,"
            " (SELECT COALESCE(SUM(b.pts),0) FROM bonus b WHERE b.cust_id=c.id AND b.ts>=?) tpb,"
            " (SELECT COALESCE(SUM(CAST(json_extract(g.data,'$.earn') AS INTEGER)),0) FROM gifts g WHERE g.from_cust=c.id AND g.kind IN ('card','item') AND g.state IN ('new','used') AND g.ts>=?) tpg,"
            " (SELECT COALESCE(SUM(l.pts),0) FROM ledger l WHERE l.cust_id=c.id) lpts,"
            " (SELECT COALESCE(SUM(w.amt),0) FROM wallet w WHERE w.cust_id=c.id) wal"
            " FROM customers c ORDER BY c.seen DESC LIMIT 300", (since, since, since)
        )
        out = []
        for r in rows:
            tp = int(r["tpo"]) + int(r["tpb"]) + int(r["tpg"]) + (WELCOME_PTS if r["created"] >= since else 0)
            out.append({"id": r["id"], "name": r["name"], "tail": r["phone"][-4:], "pts": r["lpts"] if r["opened"] else r["pts"], "bal": sar(r["wal"]), "orders": r["n"], "spent": round(r["spent"], 2),
                        "email": r["email"], "birth": r["birth"], "gender": r["gender"], "invite": r["invite"], "mk": bool(r["mk"]),
                        "tier": tier_for(tp, tiers)["id"], "tpts": tp})
        return out

    def week(self):
        t = now_ms()
        days = [self.day_of(t - k * 86400_000) for k in range(6, -1, -1)]
        got = {r["day"]: (r["n"], r["s"]) for r in self.db.q("SELECT day, COUNT(*) n, SUM(total) s FROM orders WHERE rej=0 AND day>=? GROUP BY day", (days[0],))}
        return [{"day": d, "n": got.get(d, (0, 0))[0], "sales": round(got.get(d, (0, 0))[1] or 0, 2)} for d in days]

    # ---------------------------------------------------------------- reports (read only: nothing here changes the database)
    def local_dt(self, ms):
        return datetime.datetime(1970, 1, 1) + datetime.timedelta(milliseconds=ms + self.tz_min * 60_000)

    @staticmethod
    def report_range(b):
        def day(s):
            if not isinstance(s, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
                raise ApiError(400, "bad_range")
            try:
                return datetime.date.fromisoformat(s)
            except ValueError:
                raise ApiError(400, "bad_range")
        d0, d1 = day(b.get("from")), day(b.get("to"))
        if d1 < d0 or (d1 - d0).days >= REPORT_DAYS:
            raise ApiError(400, "bad_range")
        return d0, d1

    def report_data(self, b, listing=False):
        """Everything one period holds, added up in halalas (no rounding drift). Rejected orders are counted apart and add
        nothing. It reads one day at a time, so a long period neither holds the database for long nor fills the memory.
        listing: also keep each order (at most REPORT_LIST) for the Excel file."""
        d0, d1 = self.report_range(b)
        cat = self.catalog

        def cents(v):
            return half_up(float(v) * 100) if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0 else 0

        S = {"n": 0, "sales": 0, "vat": 0, "disc": 0, "fees": 0, "bal": 0, "sub": 0, "items": 0, "free": 0, "rej": 0, "rejv": 0}
        days, br, md, pm, pr, custs, rows = [], {}, {}, {}, {}, set(), []
        d = d0
        while d <= d1:
            k = d.isoformat()
            D = {"day": k, "date": d, "n": 0, "sales": 0, "vat": 0, "disc": 0, "fees": 0}
            for r in self.db.q("SELECT seq, cust_id, rej, data FROM orders WHERE day=? ORDER BY seq", (k,)):
                try:
                    o = json.loads(r["data"])
                except ValueError:
                    continue
                total = cents(o.get("total"))
                if r["rej"]:
                    S["rej"] += 1
                    S["rejv"] += total
                    continue
                vat, disc, fee, bal = cents(o.get("vat")), cents(o.get("disc")), cents(o.get("ship")), cents(o.get("bal"))
                pay = cents(o["pay"]) if "pay" in o else max(0, total - bal)
                m = o.get("payM") if o.get("payM") in PAY_METHODS else ("card" if pay else ("wallet" if bal else "points"))
                nq, sub, txt = 0, 0, []
                for it in o.get("items") or []:
                    if not isinstance(it, dict):
                        continue
                    q = it.get("qty")
                    q = q if isinstance(q, int) and not isinstance(q, bool) and q > 0 else 0
                    pid, free, line = str(it.get("pid") or ""), bool(it.get("rw") or it.get("gift")), cents(it.get("unit")) * q
                    P = pr.get(pid)
                    if P is None:
                        P = pr[pid] = {"pid": pid, "qty": 0, "free": 0, "sales": 0, "snap": None}
                    P["qty"] += q
                    P["sales"] += line
                    nm = it.get("n")
                    nm = nm if isinstance(nm, dict) and nm.get("ar") else ({"ar": nm, "en": nm} if isinstance(nm, str) and nm else None)
                    if nm:
                        P["snap"] = nm   # the newest name it was ordered under (orders come oldest first)
                    if free:
                        P["free"] += q
                        S["free"] += q
                    nq += q
                    sub += line
                    if listing:
                        txt.append((nm or self.product_name(pid), q, "rw" if it.get("rw") else ("gift" if it.get("gift") else "")))
                sub = cents(o["sub"]) if "sub" in o else sub
                for key, v in (("n", 1), ("sales", total), ("vat", vat), ("disc", disc), ("fees", fee)):
                    S[key] += v
                    D[key] += v
                S["bal"] += bal
                S["sub"] += sub
                S["items"] += nq
                bid = str(o.get("branch") or "")
                for bag, key in ((br, bid), (md, o.get("mode") or "pickup")):
                    x = bag.setdefault(key, {"id": key, "n": 0, "sales": 0})
                    x["n"] += 1
                    x["sales"] += total
                x = pm.setdefault(m, {"id": m, "n": 0, "amount": 0})
                x["n"] += 1
                x["amount"] += pay
                if bal:   # paid from the wallet credit, whatever paid the rest: the method column still adds up to the sales
                    pm.setdefault("wallet", {"id": "wallet", "n": 0, "amount": 0})["amount"] += bal
                if r["cust_id"]:
                    custs.add(r["cust_id"])
                if listing and len(rows) < REPORT_LIST:
                    rows.append({"seq": r["seq"], "ts": o.get("ts") or 0, "branch": bid, "mode": o.get("mode") or "pickup",
                                 "cust": clean((o.get("cust") or {}).get("name"), 60), "items": txt, "nq": nq, "sub": sub, "fee": fee,
                                 "disc": disc, "total": total, "vat": vat, "bal": bal, "pay": pay, "payM": m,
                                 "code": clean(o.get("dcode"), 20), "fin": bool(o.get("fin"))})
            days.append(D)
            d += datetime.timedelta(days=1)
        for x in cat.live_branches():   # every branch shows, even without orders; a deleted one only when it sold something
            br.setdefault(x["id"], {"id": x["id"], "n": 0, "sales": 0})
        border = {x["id"]: i for i, x in enumerate(cat.branches)}
        for x in br.values():
            x["name"] = self.branch_name(x["id"])
        for P in pr.values():
            p = cat.P.get(P["pid"])
            P["name"] = self.product_name(P["pid"]) if p else (P["snap"] or self.product_name(P["pid"]))
            cid = (p.get("cat") or (p.get("cats") or [None])[0]) if p else None
            c = cat.C.get(cid) if cid else None
            P["cat"] = {"ar": c.get("ar") or "", "en": c.get("en") or c.get("ar") or ""} if c else {"ar": "", "en": ""}
        return {
            "from": d0.isoformat(), "to": d1.isoformat(), "sum": S, "cust": len(custs), "days": days,
            "branches": sorted(br.values(), key=lambda x: (-x["sales"], -x["n"], border.get(x["id"], 999))),
            "modes": [md[k] for k in ("pickup", "delivery", "ship") if k in md] + [v for k, v in md.items() if k not in ("pickup", "delivery", "ship")],
            "pays": [pm[k] for k in ("card", "apple", "mada", "stc", "wallet", "points") if k in pm],
            "products": sorted(pr.values(), key=lambda x: (-x["qty"], -x["sales"], x["name"]["ar"])),
            "orders": rows, "bnames": {x["id"]: x["name"] for x in br.values()},
        }

    def branch_name(self, bid):
        x = self.catalog.B.get(bid)
        return {"ar": x["ar"], "en": x.get("en") or x["ar"]} if x else {"ar": bid or "—", "en": bid or "—"}

    def product_name(self, pid):
        p = self.catalog.P.get(pid)
        return {"ar": p["ar"], "en": p.get("en") or p["ar"]} if p else {"ar": "منتج محذوف", "en": "Deleted product"}

    def report(self, b):
        """What the report screen shows: the totals of the period, its days, branches, ways of ordering and paying, top products."""
        R = self.report_data(b)
        S, n = R["sum"], R["sum"]["n"]
        return {
            "from": R["from"], "to": R["to"],
            "sum": {"n": n, "sales": sar(S["sales"]), "avg": sar(half_up(S["sales"] / n)) if n else 0, "vat": sar(S["vat"]), "net": sar(S["sales"] - S["vat"]),
                    "disc": sar(S["disc"]), "fees": sar(S["fees"]), "bal": sar(S["bal"]), "items": S["items"], "free": S["free"], "cust": R["cust"],
                    "rej": S["rej"], "rejv": sar(S["rejv"])},
            "days": [{"day": x["day"], "n": x["n"], "sales": sar(x["sales"])} for x in R["days"]],
            "branches": [{"id": x["id"], "name": x["name"], "n": x["n"], "sales": sar(x["sales"])} for x in R["branches"]],
            "modes": [{"id": x["id"], "n": x["n"], "sales": sar(x["sales"])} for x in R["modes"]],
            "pays": [{"id": x["id"], "n": x["n"], "amount": sar(x["amount"])} for x in R["pays"]],
            "top": [{"pid": x["pid"], "name": x["name"], "qty": x["qty"], "free": x["free"], "sales": sar(x["sales"])} for x in R["products"][:REPORT_TOP]],
            "np": len(R["products"]),
        }

    def report_xlsx(self, b):
        """The same period as an Excel file: (file name, bytes)."""
        lang = "en" if b.get("lang") == "en" else "ar"
        R = self.report_data(b, listing=True)
        f, t = R["from"], R["to"]
        if f == t:
            span = f
        elif f[8:] == "01" and f[:7] == t[:7] and (datetime.date.fromisoformat(t) + datetime.timedelta(days=1)).day == 1:
            span = f[:7]
        else:
            span = "%s_%s" % (f, t)
        return "Why-report-%s.xlsx" % span, report_book(R, lang, self.local_dt(now_ms()), self.local_dt)

    # ---------------------------------------------------------------- the state each staff screen shows
    def state(self, staff, crev=None):
        role = staff["role"]
        st = self.snap()
        t = now_ms()
        menu = self.catalog
        base = {"rev": self.rev, "now": t, "today": self.today(), "me": staff, "br": st["br"], "ship": st["ship"], "delivery": st["delivery"], "crev": menu.crev}
        if crev is not None and crev != menu.crev:   # the menu only when the page does not have this one yet
            base["cat"] = menu.payload()
        if role == "recv":
            if staff.get("branch"):   # the desk of one branch sees that branch only
                rows = self._orders_rows("branch=? AND ((fin=0 AND rej=0) OR ts>=?)", (staff["branch"], t - 2 * 86400_000), 400)
            else:
                rows = self._orders_rows("(fin=0 AND rej=0) OR ts>=?", (t - 2 * 86400_000,), 400)
            base["orders"] = [self.staff_view(o) for o in rows]
        elif role == "admin":
            rows = self._orders_rows("(fin=0 AND rej=0) OR ts>=?", (t - 14 * 86400_000,), 700)
            base["orders"] = [self.staff_view(o, phone=False) for o in rows]
            base.update({"menu": self.compat_menu(), "bn": st["bn"], "codes": st["codes"], "tiers": st["tiers"], "tdays": TIER_DAYS,
                         "rewards": st["rewards"], "banners": st["banners"], "news": st["news"], "tax": st.get("tax"), "backups": self.backups_info(),
                         "drivers": self.drivers(), "cust": self.customers(), "week": self.week(), "desks": self.desks()})
        else:
            avail = self._orders_rows("mode='delivery' AND st IN (1,2) AND fin=0 AND rej=0 AND driver_id IS NULL", (), 60)
            mine = self._orders_rows("fin=1 AND rej=0 AND driver_id=? AND day=?", (staff["id"], self.today()), 40)
            act = self._orders_rows("fin=0 AND rej=0 AND driver_id=?", (staff["id"],), 20)
            base["avail"] = [self.driver_view(o, False) for o in avail]
            base["mine"] = [self.driver_view(o, True) for o in act]
            base["done"] = [self.driver_view(o, True) for o in mine]
        return base

    def driver_view(self, o, assigned):
        v = self.staff_view(o, phone=assigned, full_addr=assigned)
        if not assigned:
            v["driver"] = None
        return v


# ---------------------------------------------------------------- HTTP


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "WhyServer/" + VERSION
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 45

    app = None  # set by make_server

    # ---- plumbing
    def log_message(self, fmt, *args):
        pass

    def log(self, status, t0):
        path = urllib.parse.urlsplit(self.path).path
        if path == "/api/health" or self.app.quiet:
            return
        sys.stderr.write("%s %s %s %d %dms\n" % (time.strftime("%H:%M:%S"), self.command, path, status, (time.time() - t0) * 1000))
        sys.stderr.flush()

    def ip(self):
        xf = self.headers.get("X-Forwarded-For")
        if xf and self.client_address[0] in ("127.0.0.1", "::1"):
            return xf.split(",")[-1].strip()[:64] or self.client_address[0]
        return self.client_address[0]

    def secure(self):
        return self.headers.get("X-Forwarded-Proto") == "https"

    def send_json(self, status, obj, headers=None):
        raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Connection", "close")
        for k, v in (headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(raw)
        self.close_connection = True
        self._status = status

    def send_file(self, data, mime, name):
        """A file to save (the Excel reports): never kept by the browser or a proxy, always saved under its name."""
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Disposition", 'attachment; filename="%s"' % re.sub(r'[^A-Za-z0-9._-]', "_", name))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)
        self.close_connection = True
        self._status = 200

    def send_path(self, path, mime, name):
        """A large file to save, sent in pieces (the database copy)."""
        size = path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition", 'attachment; filename="%s"' % re.sub(r'[^A-Za-z0-9._-]', "_", name))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Connection", "close")
        self.end_headers()
        with open(path, "rb") as f:
            while True:
                chunk = f.read(256 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
        self.close_connection = True
        self._status = 200

    def body(self, limit=32768):
        if self.headers.get("Content-Type", "").split(";")[0].strip().lower() != "application/json":
            raise ApiError(415, "json_only")
        try:
            n = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            n = -1
        if n < 0:
            raise ApiError(411, "length_required")
        if n > limit:
            raise ApiError(413, "too_big")
        raw = self.rfile.read(n) if n else b"{}"
        try:
            obj = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, "bad_json")
        if not isinstance(obj, dict):
            raise ApiError(400, "bad_json")
        return obj

    def check_origin(self):
        o = self.headers.get("Origin")
        if o and o != "null":
            host = self.headers.get("X-Forwarded-Host") or self.headers.get("Host") or ""
            if urllib.parse.urlsplit(o).netloc != host:
                raise ApiError(403, "bad_origin")
        elif o == "null":
            raise ApiError(403, "bad_origin")

    def cookie(self, name):
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == name:
                return v
        return ""

    def dev(self):
        d = self.headers.get("X-Dev") or ""
        if not re.fullmatch(r"[0-9a-f]{32,64}", d):
            raise ApiError(401, "no_device")
        return d

    def staff(self, role):
        s = self.app.session(role, self.cookie("why_" + role))
        if not s:
            raise ApiError(401, "auth")
        return s

    # ---- routing
    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.send_json(405, {"error": "method"})

    do_DELETE = do_PATCH = do_PUT

    def dispatch(self, method):
        t0 = time.time()
        self._status = 0
        try:
            u = urllib.parse.urlsplit(self.path)
            path, q = u.path, dict(urllib.parse.parse_qsl(u.query))
            if path.startswith("/api/"):
                if method == "POST":
                    self.check_origin()
                self.route(method, path[4:], q)
            elif self.app.static and method == "GET":
                self.serve_static(path)
            else:
                self.send_json(404, {"error": "not_found"})
        except ApiError as e:
            self.send_json(e.status, dict({"error": e.code}, **e.extra))
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            self.close_connection = True
        except Exception as e:  # a bug must not take the server down
            import traceback
            traceback.print_exc()
            try:
                self.send_json(500, {"error": "server"})
            except Exception:
                pass
        finally:
            self.log(self._status, t0)

    def route(self, method, p, q):
        a = self.app
        ip = self.ip()
        if p == "/health" and method == "GET":
            return self.send_json(200, {"ok": True, "v": VERSION, "rev": a.rev})
        if p == "/public" and method == "GET":
            return self.send_json(200, a.public_cfg())
        if p == "/catalog" and method == "GET":
            return self.send_json(200, a.catalog.payload())
        m = re.fullmatch(r"/img/([0-9a-f]{32})(/t)?", p)
        if m and method == "GET":
            return self.send_image(m.group(1), bool(m.group(2)))
        if p == "/orders" and method == "POST":
            dev = self.dev()
            ok, wait = a.limit.allow(("order-dev", dev), 30, 3600)
            ok2, _ = a.limit.allow(("order-ip", ip), 200, 3600)
            if not (ok and ok2):
                raise ApiError(429, "slow_down", retry=wait)
            o = a.create_order(dev, ip, self.body())
            return self.send_json(200, {"ok": True, "order": o, "acct": a.acct_of(dev)})
        if p == "/my/sync" and method == "POST":
            dev = self.dev()
            ok, wait = a.limit.allow(("sync", dev), 90, 60)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            return self.send_json(200, a.my_sync(dev, self.body(8192)))
        if p == "/my/collect" and method == "POST":
            return self.send_json(200, {"ok": True, "order": a.my_collect(self.dev(), self.body(2048))})
        if p == "/push/key" and method == "GET":   # the server's public push key (for the browser's subscription)
            return self.send_json(200, {"ok": True, "key": a.vapid_pub})
        if p in ("/push/inbox", "/push/off") and method == "POST":   # the service worker; knowing the subscription is the proof
            ok, wait = a.limit.allow(("push-ip", ip), 600, 600)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            b = self.body(4096)
            return self.send_json(200, dict({"ok": True}, **(a.push_inbox(b) if p == "/push/inbox" else a.push_off(b))))
        if p == "/my/push" and method == "POST":   # this phone wants its customer's notifications
            dev = self.dev()
            ok, wait = a.limit.allow(("my-push", dev), 30, 600)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            me = a._cust_of(sha(dev))
            if not me:
                raise ApiError(401, "bad_customer")
            return self.send_json(200, dict({"ok": True}, **a.push_sub("cust", me["id"], self.body(4096))))
        if p == "/my/code" and method == "POST":   # 0.7.6: send a sign-in code to this number by WhatsApp
            dev = self.dev()
            b = self.body(1024)
            ph = b.get("phone") if isinstance(b.get("phone"), str) else ""
            for key, n, sec in ((("code-dev", dev), 8, 3600), (("code-ip", ip), 30, 3600), (("code-ph", ph), 6, 3600)):
                ok, wait = a.limit.allow(key, n, sec)
                if not ok:
                    raise ApiError(429, "slow_down", retry=wait)
            return self.send_json(200, dict({"ok": True}, **a.send_code(ph)))
        m = re.fullmatch(r"/my/(login|logout|gift|redeem|topup|delete|cancel|rate)", p)
        if m and method == "POST":   # 0.7: the customer's account on the server
            what, dev = m.group(1), self.dev()
            per = {"login": (20, 600), "gift": (60, 3600), "redeem": (60, 3600), "topup": (30, 3600), "delete": (10, 3600)}.get(what, (60, 600))
            ok, wait = a.limit.allow(("my-" + what, dev), *per)
            ok2, _ = a.limit.allow(("my-ip", ip), 600, 600)
            if not (ok and ok2):
                raise ApiError(429, "slow_down", retry=wait)
            b = self.body(4096)
            if what == "login":
                return self.send_json(200, dict({"ok": True}, **a.my_login(dev, b)))
            if what == "logout":
                return self.send_json(200, dict({"ok": True}, **a.my_logout(dev)))
            if what == "gift":
                return self.send_json(200, dict({"ok": True}, **a.my_gift(dev, b)))
            if what == "redeem":
                return self.send_json(200, dict({"ok": True}, **a.my_redeem(dev, b)))
            if what == "topup":
                return self.send_json(200, dict({"ok": True}, **a.my_topup(dev, b)))
            if what == "delete":
                return self.send_json(200, dict({"ok": True}, **a.my_delete(dev)))
            if what == "cancel":
                return self.send_json(200, {"ok": True, "order": a.my_cancel(dev, b), "acct": a.acct_of(dev)})
            return self.send_json(200, {"ok": True, "order": a.my_rate(dev, b)})
        m = re.fullmatch(r"/(recv|admin|driver)/([a-z]+)", p)
        if not m:
            raise ApiError(404, "not_found")
        role, what = m.groups()
        if what == "login" and method == "POST":
            b = self.body(2048)
            ok, wait = a.limit.allow(("login-rate", ip), 40, 600)
            if not ok:
                raise ApiError(429, "locked", retry=wait)
            token, me, ttl = a.login(role, b.get("name"), b.get("pin"), ip, b.get("branch") if role == "recv" else None)
            ck = "why_%s=%s; Path=/api/%s; HttpOnly; SameSite=Strict; Max-Age=%d%s" % (role, token, role, ttl, "; Secure" if self.secure() else "")
            return self.send_json(200, {"ok": True, "me": me}, [("Set-Cookie", ck)])
        if what == "logout" and method == "POST":
            a.logout(self.cookie("why_" + role))
            ck = "why_%s=; Path=/api/%s; HttpOnly; SameSite=Strict; Max-Age=0%s" % (role, role, "; Secure" if self.secure() else "")
            return self.send_json(200, {"ok": True}, [("Set-Cookie", ck)])
        if role == "recv" and what == "desks" and method == "GET":   # for the sign-in page: the branches with a desk of their own
            return self.send_json(200, {"ok": True, "desks": [d["branch"] for d in a.desks() if d["active"]]})
        staff = self.staff(role)
        if what == "state" and method == "GET":
            return self.send_state(role, staff, q)
        if method != "POST":
            raise ApiError(405, "method")
        if role == "admin" and what == "img":   # a photo: a larger body than anything else
            ok, wait = a.limit.allow(("img", staff["id"]), 120, 3600)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            return self.send_json(200, {"ok": True, "img": a.upload_image(self.body(IMG_BODY_MAX))})
        b = self.body()
        if what == "order":
            return self.send_json(200, {"ok": True, "order": a.staff_order(staff, b), "rev": a.rev})
        if what == "phone" and role == "driver":   # 0.7.5: the driver's own mobile, for the customer to call him
            ok, wait = a.limit.allow(("drv-phone", staff["id"]), 20, 600)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            return self.send_json(200, dict({"ok": True, "rev": a.rev}, **a.set_driver_phone(staff["id"], b.get("phone"))))
        if what == "loc" and role == "driver":
            ok, wait = a.limit.allow(("loc", staff["id"]), 200, 600)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            return self.send_json(200, dict({"ok": True}, **a.driver_loc(staff, b)))
        if what == "branch" and role in ("recv", "admin"):
            a.set_branch(b.get("id"), b.get("pause"), staff)
            return self.send_json(200, {"ok": True, "rev": a.rev})
        if what == "push" and role in ("recv", "driver"):   # 0.7: this tablet or phone wants the new orders even with the page closed
            ok, wait = a.limit.allow(("staff-push", staff["id"]), 30, 600)
            if not ok:
                raise ApiError(429, "slow_down", retry=wait)
            return self.send_json(200, dict({"ok": True}, **a.push_sub(role, (staff.get("branch") or "*") if role == "recv" else staff["id"], b)))
        if what == "here" and role == "recv":   # 0.7: the desk marks a product as not available at its branch
            return self.send_json(200, {"ok": True, "rev": a.rev, "crev": a.catalog.crev, "product": a.set_here(b.get("id"), b.get("branch"), b.get("on"), staff)})
        if role == "admin":
            if what == "menu":
                a.set_menu_api(b)
            elif what == "product":
                return self.send_json(200, dict({"ok": True, "rev": a.rev, "crev": a.catalog.crev}, **a.admin_product(b)))
            elif what == "branches":   # adding, editing, deleting (pausing is /branch, for reception too)
                return self.send_json(200, dict({"ok": True, "rev": a.rev, "crev": a.catalog.crev}, **a.admin_branch(b)))
            elif what == "maplink":
                ok, wait = a.limit.allow(("maplink", staff["id"]), 40, 600)
                if not ok:
                    raise ApiError(429, "slow_down", retry=wait)
                return self.send_json(200, dict({"ok": True}, **a.map_link(b.get("url"))))
            elif what == "cat":
                return self.send_json(200, dict({"ok": True, "rev": a.rev, "crev": a.catalog.crev}, **a.admin_cat(b)))
            elif what == "code":
                a.set_code(b.get("code"), b.get("on"), b.get("pct"))
            elif what == "banner":
                a.set_banner(b.get("id"), b.get("on"))
            elif what == "fees":
                a.set_fees(b)
            elif what == "driver":
                return self.send_json(200, dict({"ok": True}, **a.admin_driver(b)))
            elif what == "desk":
                return self.send_json(200, dict({"ok": True, "rev": a.rev}, **a.admin_desk(b)))
            elif what == "tax":
                a.set_tax(b)
            elif what == "dbcopy":   # the whole database, to keep off the server
                ok, wait = a.limit.allow(("dbcopy", staff["id"]), 10, 3600)
                if not ok:
                    raise ApiError(429, "slow_down", retry=wait)
                tmp, name = a.db_copy(staff, b, ip)
                try:
                    return self.send_path(tmp, "application/zip", name)
                finally:
                    tmp.unlink(missing_ok=True)
            elif what == "pin":
                a.admin_pin(staff, b, ip)
            elif what == "points":
                a.add_points(b.get("id"), b.get("pts"))
            elif what == "tiers":
                a.set_tiers(b.get("tiers"))
            elif what == "reward":
                return self.send_json(200, dict({"ok": True, "rev": a.rev}, **a.admin_reward(b)))
            elif what == "banners":
                return self.send_json(200, dict({"ok": True, "rev": a.rev}, **a.admin_banner(b)))
            elif what == "news":
                return self.send_json(200, dict({"ok": True, "rev": a.rev}, **a.admin_news(b)))
            elif what == "report":   # reading only: the totals of a period
                ok, wait = a.limit.allow(("report", staff["id"]), 120, 600)
                if not ok:
                    raise ApiError(429, "slow_down", retry=wait)
                return self.send_json(200, dict({"ok": True}, **a.report(b)))
            elif what == "xlsx":     # the same period as an Excel file
                ok, wait = a.limit.allow(("xlsx", staff["id"]), 40, 600)
                if not ok:
                    raise ApiError(429, "slow_down", retry=wait)
                name, data = a.report_xlsx(b)
                return self.send_file(data, XLSX_MIME, name)
            elif what == "wipe":
                a.wipe(staff, b, ip)
            else:
                raise ApiError(404, "not_found")
            return self.send_json(200, {"ok": True, "rev": a.rev})
        raise ApiError(404, "not_found")

    def send_state(self, role, staff, q):
        a = self.app
        try:
            since = int(q.get("rev", "-1"))
            wait = max(0, min(25, int(q.get("wait", "0"))))
            crev = int(q["crev"]) if "crev" in q else None   # pages from before 0.4 do not ask for the menu
        except ValueError:
            raise ApiError(400, "bad_request")
        same = lambda: since == a.hub.rev and (crev is None or crev == a.catalog.crev)
        if wait and same() and a.pollers.acquire(blocking=False):
            try:
                a.hub.wait(since, wait)
            finally:
                a.pollers.release()
            staff = self.staff(role)  # signed out while waiting?
        if same():
            return self.send_json(200, {"rev": a.hub.rev, "same": True})
        return self.send_json(200, a.state(staff, crev))

    def send_image(self, iid, small):
        """A product photo. Its name is its content, so it never changes: the phone may keep it for a year."""
        tag = '"%s%s"' % (iid, "-t" if small else "")
        if self.headers.get("If-None-Match") == tag:
            self.send_response(304)
            self.send_header("ETag", tag)
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            self._status = 304
            return
        r = self.app.image(iid, small)
        if not r:
            raise ApiError(404, "not_found")
        mime, data = r
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        self.send_header("ETag", tag)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; sandbox")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)
        self.close_connection = True
        self._status = 200

    # ---- static files (tests only: on the server Caddy serves the pages)
    CSP = ("default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
           "img-src 'self' data: https://tile.openstreetmap.org; connect-src 'self'; manifest-src 'self'; worker-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")

    def serve_static(self, path):
        root = self.app.static
        rel = urllib.parse.unquote(path).lstrip("/")
        f = (root / rel).resolve()
        if not str(f).startswith(str(root)):
            return self.send_json(404, {"error": "not_found"})
        if f.is_dir():
            if not path.endswith("/"):
                self.send_response(301)
                self.send_header("Location", path + "/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                self._status = 301
                return
            f = f / "index.html"
        if not f.is_file():
            return self.send_json(404, {"error": "not_found"})
        data = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", (mimetypes.guess_type(str(f))[0] or "application/octet-stream") + ("; charset=utf-8" if f.suffix in (".html", ".js", ".css") else ""))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Security-Policy", self.CSP)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)
        self.close_connection = True
        self._status = 200


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64


def make_server(app, host="127.0.0.1", port=0):
    H = type("BoundHandler", (Handler,), {"app": app})
    return Server((host, port), H)


# ---------------------------------------------------------------- command line


def ask_pin(label):
    for _ in range(3):
        a = getpass.getpass("%s (6 to 10 digits, typing is hidden): " % label)
        if not valid_pin(a):
            print("The PIN must be 6 to 10 digits.")
            continue
        if getpass.getpass("Type it again: ") != a:
            print("The two do not match.")
            continue
        return a
    sys.exit("No PIN was set.")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="why_server.py")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("serve", "setpin", "check", "backup", "routekey", "wakey", "mailkey"):
        s = sub.add_parser(name)
        s.add_argument("--db", default="/var/lib/why/why.db")
        s.add_argument("--catalog", default=None)
        s.add_argument("--iters", type=int, default=int(os.environ.get("WHY_PBKDF2_ITERS", "200000")))
        s.add_argument("--tz", type=int, default=180, help="café time zone as minutes from UTC (Riyadh = 180)")
    s = sub.choices["serve"]
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8787)
    s.add_argument("--static", default=None, help="serve the app pages too (for tests; on the server Caddy does this)")
    s = sub.add_parser("unlock", help="open a password-locked copy (why-backup-....zip.enc) into a .zip")
    s.add_argument("file")
    s = sub.choices["setpin"]
    s.add_argument("--role", choices=("admin", "recv"), required=True)
    s.add_argument("--pin-stdin", action="store_true", help="read the PIN from stdin (automated tests only)")
    a = ap.parse_args(argv)
    if a.cmd == "unlock":   # 0.7.7: no database needed
        src = Path(a.file)
        if not src.is_file():
            sys.exit("No such file: %s" % src)
        dest = src.with_name(src.name[:-4] if src.name.endswith(".enc") else src.name + ".zip")
        if dest.exists():
            sys.exit("%s already exists: move it away first." % dest)
        pw = getpass.getpass("Backup password (typing is hidden): ") if sys.stdin.isatty() else sys.stdin.readline().rstrip("\n")
        if unlock_file(src, dest, pw):
            os.chmod(dest, 0o600)
            print("opened:", dest)
            return 0
        Path(dest).unlink(missing_ok=True)
        sys.exit("Wrong password, or not a Why! backup.")

    app = App(a.db, a.catalog, iters=a.iters, tz_min=a.tz, static=getattr(a, "static", None), backups=(a.cmd == "serve"))
    if a.cmd == "setpin":
        pin = sys.stdin.readline().strip() if a.pin_stdin else ask_pin("PIN for " + ("the admin" if a.role == "admin" else "reception"))
        if not valid_pin(pin):
            sys.exit("The PIN must be 6 to 10 digits.")
        app.set_staff(a.role, a.role, pin)
        print("PIN saved for", a.role)
        return 0
    if a.cmd == "routekey":   # the OpenRouteService key for the road route on the delivery map, typed hidden (empty = remove)
        k = sys.stdin.readline().strip() if not sys.stdin.isatty() else getpass.getpass("OpenRouteService key (empty = remove): ").strip()
        if k and not re.fullmatch(r"[A-Za-z0-9=_\-]{20,200}", k):
            sys.exit("That does not look like a key.")
        with app.db.tx() as c:
            app._set_kv(c, "route_key", k)
        print("route key saved" if k else "route key removed")
        return 0
    if a.cmd == "wakey":   # 0.7.6: the WhatsApp sign-in codes (Meta Cloud API); the token typed hidden. Empty token = off.
        tty = sys.stdin.isatty()
        ask = (lambda q, hide=False: (getpass.getpass(q) if hide else input(q)).strip()) if tty else (lambda q, hide=False: sys.stdin.readline().strip())
        tok = ask("WhatsApp access token (typing is hidden; empty = switch WhatsApp codes off): ", True)
        with app.db.tx() as c:
            if not tok:
                for k in ("wa_token", "wa_phone"):
                    app._set_kv(c, k, "")
                print("WhatsApp codes off: the test code 12345 signs in")
                return 0
            if not re.fullmatch(r"[A-Za-z0-9_\-|.]{20,600}", tok):
                sys.exit("That does not look like an access token.")
            pid = ask("Phone number ID (digits): ")
            if not re.fullmatch(r"\d{6,25}", pid):
                sys.exit("The phone number ID is digits only (Meta shows it under WhatsApp > API Setup).")
            tpl = ask("Template name [why_code]: ") or "why_code"
            if not re.fullmatch(r"[a-z0-9_]{1,512}", tpl):
                sys.exit("A template name is small letters, digits and _ only.")
            lang = ask("Template language [ar]: ") or "ar"
            if not re.fullmatch(r"[a-z]{2,3}(_[A-Z]{2})?", lang):
                sys.exit("The language looks like ar or en_US.")
            keep = (ask("Keep the test code 12345 working too? (y/n) [y]: ") or "y").lower().startswith("y")
            for k, v in (("wa_token", tok), ("wa_phone", pid), ("wa_tpl", tpl), ("wa_lang", lang), ("otp_test", "on" if keep else "off")):
                app._set_kv(c, k, v)
        print("WhatsApp codes on (template %s, %s). Test code 12345: %s" % (tpl, lang, "still works" if keep else "off"))
        to = ask("Send a test code now? Type a mobile like 05xxxxxxxx, or press Enter to skip: ") if tty else ""
        to = re.sub(r"\D", "", to or "")
        to = to[3:] if to.startswith("966") else to[1:] if to.startswith("0") else to
        if to:
            app.otp_lock, app.otps = threading.Lock(), {}
            with app.db.tx() as c:   # the test code must not hide a failure here
                app._set_kv(c, "otp_test_was", app._kv(c, "otp_test", "on"))
                app._set_kv(c, "otp_test", "off")
            try:
                print("sent by WhatsApp: check that phone" if app.send_code(to)["via"] == "wa" else "not sent")
            except ApiError as e:
                print("not sent (%s): see the reason above" % e.code)
            finally:
                with app.db.tx() as c:
                    app._set_kv(c, "otp_test", app._kv(c, "otp_test_was", "on"))
        return 0
    if a.cmd == "mailkey":   # 0.7.7: the daily copy by e-mail (Brevo). Key and password typed hidden. Empty key = off.
        tty = sys.stdin.isatty()
        ask = (lambda q, hide=False: (getpass.getpass(q) if hide else input(q)).strip()) if tty else (lambda q, hide=False: sys.stdin.readline().strip())
        key = ask("Brevo API key (typing is hidden; empty = stop the e-mailed copies): ", True)
        if not key:
            with app.db.tx() as c:
                for k in ("mail_key", "mail_pw"):
                    app._set_kv(c, k, "")
            print("E-mailed copies off (the daily copy on this server goes on as before)")
            return 0
        if not re.fullmatch(r"[A-Za-z0-9_\-]{20,200}", key):
            sys.exit("That does not look like a Brevo API key (it starts with xkeysib-).")
        frm = ask("Sender e-mail (the e-mail of the Brevo account): ").lower()
        if not valid_email(frm):
            sys.exit("Not an e-mail address.")
        to = [t.strip().lower() for t in ask("Send the copy to (one e-mail, or up to 3 separated by commas): ").split(",") if t.strip()]
        if not to or len(to) > 3 or not all(valid_email(t) for t in to):
            sys.exit("Give one to three e-mail addresses.")
        name = ask("Sender name [Why! backup]: ") or "Why! backup"
        hour = ask("Send every day at (hour 0-23, shop time) [3]: ") or "3"
        if not hour.isdigit() or not 0 <= int(hour) <= 23:
            sys.exit("The hour is 0 to 23.")
        old_pw = app._kv(app.db.conn, "mail_pw", "")
        pw = ask("Backup password (at least 10 characters; typing is hidden%s): " % ("; empty = keep the current one" if old_pw else ""), True)
        if not pw and old_pw:
            pw = old_pw
        else:
            if len(pw) < 10:
                sys.exit("The password must be at least 10 characters.")
            if tty and ask("Type it again: ", True) != pw:
                sys.exit("The two do not match.")
        with app.db.tx() as c:
            for k, v in (("mail_key", key), ("mail_from", frm), ("mail_to", ",".join(to)), ("mail_name", clean(name, 40)),
                         ("mail_hour", str(int(hour))), ("mail_pw", pw)):
                app._set_kv(c, k, v)
        print("E-mailed copies on: every day from %s:00 to %s" % (int(hour), ", ".join(to)))
        print("Keep the password somewhere safe (not in the same e-mail): without it the copies cannot be opened.")
        if (ask("Send one now to check? (y/n) [y]: ") if tty else "n").lower() in ("", "y", "yes"):
            try:
                r = app.mail_backup(force=True)
                print("sent: check the inbox (and the spam folder)" if r == "sent" else "the copy is too big for e-mail; a note was sent instead")
            except Exception:
                print("not sent: see the reason above")
        return 0
    if a.cmd == "backup":   # a copy of the database right now (the installer takes one before every update)
        dest = app.backup(force=True)
        print("backup saved:", dest)
        return 0
    if a.cmd == "check":
        d = app.db
        print("orders:", d.one("SELECT COUNT(*) n FROM orders")["n"], " customers:", d.one("SELECT COUNT(*) n FROM customers")["n"])
        print("products:", len(app.catalog.live_prods()), " deleted:", len(app.catalog.prods) - len(app.catalog.live_prods()),
              " categories:", len(app.catalog.live_cats()), " photos:", d.one("SELECT COUNT(*) n FROM images")["n"], " branches:", len(app.catalog.live_branches()))
        for r in d.q("SELECT role, name, active FROM staff ORDER BY role, id"):
            print("staff:", r["role"], r["name"], "active" if r["active"] else "off")
        return 0
    srv = make_server(app, a.host, a.port)
    if not app.db.one("SELECT 1 FROM staff WHERE role='admin'"):
        print("note: no admin PIN yet. Run:  python3 why_server.py setpin --role admin --db %s" % a.db, file=sys.stderr)
    print("Why! server %s listening on %s:%d (db %s)" % (VERSION, a.host, srv.server_address[1], a.db), file=sys.stderr, flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        app.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
