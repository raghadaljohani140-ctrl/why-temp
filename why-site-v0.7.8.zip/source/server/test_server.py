#!/usr/bin/env python3
"""Tests for why_server.py. They start the real server on a free port with a temporary database.

    python3 -I test_server.py
"""
import base64
import datetime
import http.client
import http.server
import io
import json
import os
import re
import secrets
import sqlite3
import struct
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import xml.etree.ElementTree as ET
import zipfile
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import why_server as W  # noqa: E402

PINS = {"admin": "482916", "recv": "735019"}


def png(w, h, rgb=(200, 120, 40)):
    """A real (tiny) PNG file of w x h pixels."""
    rows = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))
    chunk = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b"")


def jpeg_head(w, h):
    """The start of a JPEG file: enough for the server to read its size."""
    return (b"\xff\xd8\xff\xe0" + struct.pack(">H", 16) + b"JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"
            + b"\xff\xc0" + struct.pack(">HBHHB", 17, 8, h, w, 3) + b"\x01\x22\x00\x02\x11\x01\x03\x11\x01" + b"\xff\xd9")


def webp_head(w, h):
    """A lossless WebP header (VP8L) for w x h."""
    body = b"VP8L" + struct.pack("<I", 5) + b"\x2f" + struct.pack("<I", (w - 1) | ((h - 1) << 14)) + b"\x00"
    return b"RIFF" + struct.pack("<I", 4 + len(body)) + b"WEBP" + body


b64 = lambda b: base64.b64encode(b).decode("ascii")


class Http:
    """A tiny client: keeps cookies per path prefix like a browser would."""

    def __init__(self, port, dev=None, origin=True):
        self.port, self.dev, self.cookies, self.origin = port, dev, {}, origin

    def call(self, method, path, body=None, headers=None, raw=None, ctype="application/json"):
        h = {"Host": "127.0.0.1:%d" % self.port}
        if self.origin and method == "POST":
            h["Origin"] = "http://127.0.0.1:%d" % self.port
        if self.dev:
            h["X-Dev"] = self.dev
        for prefix, v in self.cookies.items():
            if path.startswith(prefix):
                h["Cookie"] = v
        if body is not None or raw is not None:
            h["Content-Type"] = ctype
        h.update(headers or {})
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=40)
        try:
            c.request(method, path, body=data, headers=h)
        except OSError:
            c.close()
            raise
        r = c.getresponse()
        txt = r.read().decode("utf-8")
        for k, v in r.getheaders():
            if k.lower() == "set-cookie":
                name, _, rest = v.partition("=")
                val = rest.split(";")[0]
                role = name.replace("why_", "")
                self.cookies["/api/" + role] = (name + "=" + val) if val else ""
        c.close()
        try:
            j = json.loads(txt)
        except ValueError:
            j = {"_raw": txt}
        return r.status, j, dict(r.getheaders())

    def get(self, p, **k):
        return self.call("GET", p, **k)

    def bytes(self, p, headers=None):
        """GET, keeping the body as bytes (a photo)."""
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=40)
        c.request("GET", p, headers=dict({"Host": "127.0.0.1:%d" % self.port}, **(headers or {})))
        r = c.getresponse()
        data = r.read()
        c.close()
        return r.status, data, dict(r.getheaders())

    def post(self, p, body=None, **k):
        return self.call("POST", p, body if body is not None else {}, **k)

    def post_bytes(self, p, body):
        """POST, keeping the answer as bytes (an Excel file)."""
        h = {"Host": "127.0.0.1:%d" % self.port, "Content-Type": "application/json"}
        if self.origin:
            h["Origin"] = "http://127.0.0.1:%d" % self.port
        for prefix, v in self.cookies.items():
            if p.startswith(prefix):
                h["Cookie"] = v
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=40)
        c.request("POST", p, body=json.dumps(body).encode(), headers=h)
        r = c.getresponse()
        data = r.read()
        c.close()
        return r.status, data, dict(r.getheaders())


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = os.path.join(cls.tmp.name, "why.db")
        cls.start()

    @classmethod
    def start(cls):
        cls.app = W.App(cls.db, iters=1000, backups=False, quiet=True, push_test=True)
        for role, pin in PINS.items():
            if not cls.app.db.one("SELECT 1 FROM staff WHERE role=?", (role,)):
                cls.app.set_staff(role, role, pin)
        cls.srv = W.make_server(cls.app, "127.0.0.1", 0)
        cls.port = cls.srv.server_address[1]
        cls.thread = threading.Thread(target=cls.srv.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def stop(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        cls.app.close()

    @classmethod
    def tearDownClass(cls):
        cls.stop()
        cls.tmp.cleanup()

    # helpers
    def customer(self):
        return Http(self.port, dev=secrets.token_hex(16))

    def staff(self, role, name=None, pin=None):
        h = Http(self.port)
        body = {"pin": pin or PINS.get(role)}
        if name:
            body["name"] = name
        st, j, _ = h.post("/api/%s/login" % role, body)
        self.assertEqual(st, 200, j)
        return h

    def order_body(self, **kw):
        b = {"cid": secrets.token_hex(6), "mode": "pickup", "branch": "b1", "serve": "in",
             "items": [{"pid": "latte", "sel": {"size": "m", "milk": "oat", "extras": ["shot"]}, "qty": 2}],
             "cust": {"name": "ريم", "phone": "501234567"}, "payM": "card"}
        b.update(kw)
        return b

    def place(self, c, **kw):
        st, j, _ = c.post("/api/orders", self.order_body(**kw))
        self.assertEqual(st, 200, j)
        return j["order"]

    @staticmethod
    def fresh_cust(name="ريم"):
        """A customer of his own: the points of an order depend on the customer's tier (0.5.1)."""
        return {"name": name, "phone": "5" + "".join(secrets.choice("0123456789") for _ in range(8))}


class TestBasics(Base):
    def test_health_and_public(self):
        c = Http(self.port)
        st, j, h = c.get("/api/health")
        self.assertEqual((st, j["ok"]), (200, True))
        self.assertEqual(h["Cache-Control"], "no-store")
        st, j, _ = c.get("/api/public")
        self.assertEqual(st, 200)
        self.assertEqual(j["codes"]["WHY10"], {"on": True, "pct": 10})
        self.assertEqual(j["delivery"], {"on": True, "fee": 12, "km": 0, "min": 0})   # 0.7: no distance limit, no smallest order
        self.assertEqual(j["ship"], 25)

    def test_unknown_and_methods(self):
        c = Http(self.port)
        self.assertEqual(c.get("/api/nothing")[0], 404)
        self.assertEqual(c.call("PUT", "/api/public")[0], 405)
        self.assertEqual(c.get("/")[0], 404)  # the server serves no pages unless started with --static

    def test_body_rules(self):
        c = self.customer()
        self.assertEqual(c.call("POST", "/api/orders", raw=b"x" * 40000)[0], 413)
        self.assertEqual(c.call("POST", "/api/orders", raw=b"{bad", ctype="application/json")[0], 400)
        self.assertEqual(c.call("POST", "/api/orders", raw=b"[]", ctype="application/json")[0], 400)
        self.assertEqual(c.call("POST", "/api/orders", raw=b"{}", ctype="text/plain")[0], 415)

    def test_origin_must_match(self):
        c = self.customer()
        st, j, _ = c.post("/api/orders", self.order_body(), headers={"Origin": "https://evil.example"})
        self.assertEqual((st, j["error"]), (403, "bad_origin"))
        st, j, _ = c.post("/api/orders", self.order_body(), headers={"Origin": "null"})
        self.assertEqual(st, 403)

    def test_device_key_is_required_and_checked(self):
        c = Http(self.port)
        self.assertEqual(c.post("/api/orders", self.order_body())[1]["error"], "no_device")
        c.dev = "short"
        self.assertEqual(c.post("/api/my/sync", {})[0], 401)
        c.dev = "G" * 32
        self.assertEqual(c.post("/api/my/sync", {})[0], 401)


class TestStaffAuth(Base):
    def test_login_logout_and_cookie_flags(self):
        h = Http(self.port)
        self.assertEqual(h.get("/api/recv/state")[0], 401)
        st, j, hd = h.post("/api/recv/login", {"pin": PINS["recv"]})
        self.assertEqual(st, 200)
        self.assertEqual(j["me"]["role"], "recv")
        ck = hd["Set-Cookie"]
        self.assertIn("HttpOnly", ck)
        self.assertIn("SameSite=Strict", ck)
        self.assertIn("Path=/api/recv", ck)
        self.assertNotIn("Secure", ck)  # plain http in the test
        st, j, hd = h.post("/api/recv/login", {"pin": PINS["recv"]}, headers={"X-Forwarded-Proto": "https"})
        self.assertIn("Secure", hd["Set-Cookie"])
        self.assertEqual(h.get("/api/recv/state")[0], 200)
        self.assertEqual(h.post("/api/recv/logout")[0], 200)
        self.assertEqual(h.get("/api/recv/state")[0], 401)

    def test_a_role_cookie_opens_only_that_role(self):
        h = self.staff("recv")
        self.assertEqual(h.get("/api/admin/state")[0], 401)
        self.assertEqual(h.get("/api/driver/state")[0], 401)
        self.assertEqual(h.post("/api/admin/fees", {"ship": 1})[0], 401)

    def test_wrong_pin_locks_the_door(self):
        h = Http(self.port)
        for i in range(5):
            self.assertEqual(h.post("/api/admin/login", {"pin": "000000"})[1]["error"], "bad_login")
        st, j, _ = h.post("/api/admin/login", {"pin": PINS["admin"]})
        self.assertEqual((st, j["error"]), (429, "locked"))
        self.assertGreater(j["retry"], 0)
        W_limit = self.app.limit
        W_limit.fails.clear()  # let the other tests in

    def test_pin_shape(self):
        h = Http(self.port)
        self.assertEqual(h.post("/api/recv/login", {"pin": 735019})[0], 401)
        self.assertEqual(h.post("/api/recv/login", {})[0], 401)
        with self.assertRaises(W.ApiError):
            self.app.set_staff("recv", "recv", "1234")
        self.app.limit.fails.clear()

    def test_driver_needs_name_and_pin(self):
        self.app.set_staff("driver", "سعد", "246810")
        h = Http(self.port)
        self.assertEqual(h.post("/api/driver/login", {"pin": "246810"})[0], 400)
        self.assertEqual(h.post("/api/driver/login", {"name": "خالد", "pin": "246810"})[0], 401)
        self.assertEqual(h.post("/api/driver/login", {"name": "  سعد ", "pin": "246810"})[0], 200)
        self.app.limit.fails.clear()


class TestOrders(Base):
    def test_server_prices_the_order(self):
        c = self.customer()
        o = self.place(c, cust=self.fresh_cust())
        # latte 17 + medium 3 + oat 3 + extra shot 4 = 27 each, two of them
        self.assertEqual(o["items"][0]["unit"], 27)
        self.assertEqual(o["sub"], 54)
        self.assertEqual((o["ship"], o["disc"], o["total"], o["pay"], o["bal"]), (0, 0, 54, 54, 0))
        self.assertEqual(o["vat"], 7.04)
        self.assertEqual((o["tier"], o["earn"]), ("basic", 43))   # 54 SAR, basic: 8 points for every 10 SAR
        self.assertRegex(o["code"], r"^\d{4}$")
        self.assertTrue(o["no"].startswith("‎#"))
        self.assertEqual((o["st"], o["fin"]), (0, False))
        self.assertNotIn("phone", o["cust"])

    def test_vat_line_balances(self):
        c = self.customer()
        o = self.place(c, items=[{"pid": "espresso", "qty": 3, "sel": {"shots": "2"}}, {"pid": "cookie", "qty": 1}])
        ex = sum(round(l["unit"] * l["qty"] / 1.15, 2) for l in o["items"])
        self.assertAlmostEqual(o["total"] - o["vat"], ex, delta=0.02)

    def test_client_cannot_set_prices_or_options(self):
        c = self.customer()
        o = self.place(c, items=[{"pid": "latte", "qty": 1, "unit": 0.01, "price": 0, "sel": {"size": "xxl", "milk": "gold", "extras": ["shot", "shot", "nope"]}}])
        self.assertEqual(o["items"][0]["unit"], 21)  # small (default) + whole milk + one shot
        self.assertEqual(o["items"][0]["sel"], {"size": "s", "milk": "whole", "extras": ["shot"]})

    def test_bad_orders(self):
        c = self.customer()
        self.app.limit.hits.clear()
        bad = lambda **k: c.post("/api/orders", self.order_body(**k))
        self.assertEqual(bad(mode="fly")[1]["error"], "bad_mode")
        self.assertEqual(bad(branch="zz")[1]["error"], "bad_branch")
        self.assertEqual(bad(items=[])[1]["error"], "bad_items")
        self.assertEqual(bad(items=[{"pid": "nothing", "qty": 1}])[1]["error"], "bad_item")
        self.assertEqual(bad(items=[{"pid": "latte", "qty": 0}])[1]["error"], "bad_qty")
        self.assertEqual(bad(items=[{"pid": "latte", "qty": 21}])[1]["error"], "bad_qty")
        self.assertEqual(bad(items=[{"pid": "latte", "qty": True}])[1]["error"], "bad_qty")
        self.assertEqual(bad(items=[{"pid": "pineapple", "qty": 1}])[1]["error"], "stock")
        self.assertEqual(bad(cust={"name": "ر", "phone": "501234567"})[1]["error"], "bad_customer")
        self.assertEqual(bad(cust={"name": "ريم", "phone": "0501234567"})[1]["error"], "bad_customer")
        self.assertEqual(bad(code="NOPE")[1]["error"], "bad_code")
        self.assertEqual(bad(items=[{"pid": "latte", "qty": 1, "rw": "r1"}])[1]["error"], "bad_reward")  # r1 is a different product
        self.assertEqual(bad(mode="ship", carrier="Redbox")[1]["error"], "ship_retail_only")  # a latte cannot be posted
        self.assertEqual(bad(mode="ship", carrier="Pigeon", items=[{"pid": "cup16", "qty": 1}], addr={"city": "x", "street": "y"})[1]["error"], "bad_carrier")

    def test_price_changed_is_refused_not_charged(self):
        c = self.customer()
        st, j, _ = c.post("/api/orders", self.order_body(total=10))
        self.assertEqual((st, j["error"], j["total"]), (409, "price_changed", 54))
        self.assertEqual(c.post("/api/orders", self.order_body(total=54))[0], 200)

    def test_same_attempt_twice_makes_one_order(self):
        c = self.customer()
        b = self.order_body()
        a = c.post("/api/orders", b)[1]["order"]
        again = c.post("/api/orders", b)[1]["order"]
        self.assertEqual(a["id"], again["id"])
        self.assertEqual(self.app.db.one("SELECT COUNT(*) n FROM orders WHERE cid=?", (b["cid"],))["n"], 1)

    def test_discount_code(self):
        c = self.customer()
        o = self.place(c, code="why10")
        self.assertEqual((o["disc"], o["total"], o["dcode"]), (5.4, 48.6, "WHY10"))

    def test_wallet_balance_is_capped_at_the_total(self):
        c, cu = self.customer(), self.fresh_cust()
        o = self.place(c, bal=1000, cust=cu)
        self.assertEqual((o["bal"], o["pay"], o["payM"], o["earn"]), (54, 0, "wallet", 0))
        o = self.place(c, bal=4.5, cust=cu)
        self.assertEqual((o["bal"], o["pay"], o["earn"]), (4.5, 49.5, 39))   # points only on what was paid: 49.5 SAR -> 39

    def test_rewards_are_priced_free_and_cost_points(self):
        c = self.customer()
        o = self.place(c, items=[{"pid": "latte", "qty": 1, "rw": "r2"}, {"pid": "cookie", "qty": 1}])
        self.assertEqual((o["items"][0]["unit"], o["spent"], o["total"]), (0, 200, 10))

    def test_ship_order_free_shipping_collection(self):
        c = self.customer()
        addr = {"city": "الرياض", "street": "حي النرجس", "note": ""}
        o = self.place(c, mode="ship", carrier="Aramex", addr=addr, items=[{"pid": "yirg", "qty": 1}])
        self.assertEqual((o["ship"], o["total"]), (25, 84))
        self.assertTrue(o["code"].startswith("WH"))
        o = self.place(c, mode="ship", carrier="Aramex", addr=addr, items=[{"pid": "collection", "qty": 1}])
        self.assertEqual((o["ship"], o["total"]), (0, 109))
        self.assertEqual(c.post("/api/orders", self.order_body(mode="ship", carrier="Aramex", items=[{"pid": "yirg", "qty": 1}]))[1]["error"], "bad_address")

    def test_delivery_order(self):
        c = self.customer()
        addr = {"city": "المدينة", "street": "شارع قباء", "note": "الباب الأزرق", "lat": 24.4672, "lng": 39.6111}
        o = self.place(c, mode="delivery", addr=addr)
        self.assertEqual((o["mode"], o["ship"], o["total"], o["serve"]), ("delivery", 12, 66, ""))
        self.assertEqual(o["addr"]["lat"], 24.4672)
        self.assertEqual(c.post("/api/orders", self.order_body(mode="delivery"))[1]["error"], "bad_address")
        junk = dict(addr, lat="north", lng=200)
        self.assertNotIn("lat", self.place(c, mode="delivery", addr=junk)["addr"])

    def test_paused_branch_refuses_pickup_and_delivery_but_not_a_parcel(self):
        a = self.staff("admin")
        c = self.customer()
        a.post("/api/admin/branch", {"id": "b2", "pause": True})
        try:
            self.assertEqual(c.post("/api/orders", self.order_body(branch="b2"))[1]["error"], "paused")
            self.assertEqual(c.post("/api/orders", self.order_body(branch="b2", mode="delivery", addr={"city": "a", "street": "b"}))[1]["error"], "paused")
            self.assertEqual(c.post("/api/orders", self.order_body(branch="b2", mode="ship", carrier="SMSA", items=[{"pid": "cup8", "qty": 1}], addr={"city": "a", "street": "b"}))[0], 200)
        finally:
            a.post("/api/admin/branch", {"id": "b2", "pause": False})

    def test_delivery_can_be_switched_off(self):
        a = self.staff("admin")
        c = self.customer()
        a.post("/api/admin/fees", {"delivery_on": False})
        try:
            self.assertEqual(c.post("/api/orders", self.order_body(mode="delivery", addr={"city": "a", "street": "b"}))[1]["error"], "delivery_off")
            self.assertFalse(c.post("/api/my/sync", {})[1]["pub"]["delivery"]["on"])
        finally:
            a.post("/api/admin/fees", {"delivery_on": True})

    def test_a_device_cannot_pile_up_orders(self):
        c = self.customer()
        self.app.limit.hits.clear()
        for i in range(12):
            self.assertEqual(c.post("/api/orders", self.order_body())[0], 200)
        st, j, _ = c.post("/api/orders", self.order_body())
        self.assertIn(j["error"], ("too_many_open", "slow_down"))
        self.app.limit.hits.clear()


class TestPickupLifecycle(Base):
    def test_whole_pickup_flow_with_code(self):
        r, c = self.staff("recv"), self.customer()
        # a customer of its own (0.7: a phone hears about every order of its customer, from any phone)
        o = self.place(c, cust={"name": "ريم", "phone": "5" + "".join(secrets.choice("0123456789") for _ in range(4)) + "4567"})
        # the reception sees it but never the code
        st = r.get("/api/recv/state")[1]
        mine = next(x for x in st["orders"] if x["id"] == o["id"])
        self.assertNotIn("code", mine)
        self.assertNotIn("phone", mine["cust"])
        self.assertEqual(mine["cust"]["tail"], "4567")
        self.assertNotIn("tries", mine)
        self.assertNotIn('"%s"' % o["code"], json.dumps(st))
        # cannot skip a step
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "ready"})[1]["error"], "bad_state")
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "accept"})[0], 200)
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "accept"})[1]["error"], "bad_state")
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "ready"})[0], 200)
        # the customer's next sync shows where it is
        s = c.post("/api/my/sync", {"since": 0})[1]
        self.assertEqual([(x["id"], x["st"]) for x in s["orders"]], [(o["id"], 2)])
        self.assertEqual(len(s["orders"][0]["at"]), 3)
        # wrong code, then the right one
        st, j, _ = r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "code": "0000" if o["code"] != "0000" else "1111"})
        self.assertEqual((st, j["error"], j["left"]), (403, "wrong_code", 4))
        st, j, _ = r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "code": o["code"]})
        self.assertEqual((st, j["order"]["st"], j["order"]["fin"]), (200, 3, True))
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "out"})[1]["error"], "bad_state")

    def test_five_wrong_codes_lock_the_order_but_reception_can_hand_over(self):
        r, c = self.staff("recv"), self.customer()
        o = self.place(c)
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        wrong = "0000" if o["code"] != "0000" else "1111"
        for i in range(5):
            r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "code": wrong})
        st, j, _ = r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "code": o["code"]})
        self.assertEqual((st, j["error"]), (429, "locked"))
        st, j, _ = r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "skip": True})
        self.assertEqual((st, j["order"]["st"]), (200, 3))

    def test_customer_can_confirm_pickup_only_when_ready(self):
        r, c, other = self.staff("recv"), self.customer(), self.customer()
        o = self.place(c)
        self.assertEqual(c.post("/api/my/collect", {"id": o["id"]})[1]["error"], "bad_state")
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        self.assertEqual(other.post("/api/my/collect", {"id": o["id"]})[0], 404)  # somebody else's order
        st, j, _ = c.post("/api/my/collect", {"id": o["id"]})
        self.assertEqual((st, j["order"]["st"], j["order"]["fin"]), (200, 3, True))

    def test_reject_keeps_a_reason_the_customer_can_read(self):
        r, c = self.staff("recv"), self.customer()
        o = self.place(c)
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "nonsense"})[1]["error"], "bad_reason")
        st, j, _ = r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})
        self.assertEqual(st, 200)
        s = c.post("/api/my/sync", {"since": 0})[1]["orders"][0]
        self.assertEqual(s["rej"]["why"]["ar"], "الفرع مزدحم حاليًا")
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "accept"})[1]["error"], "bad_state")

    def test_ship_order_needs_no_code(self):
        r, c = self.staff("recv"), self.customer()
        o = self.place(c, mode="ship", carrier="SMSA", addr={"city": "جدة", "street": "الروضة"}, items=[{"pid": "cup12", "qty": 2}])
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        mine = next(x for x in r.get("/api/recv/state")[1]["orders"] if x["id"] == o["id"])
        self.assertEqual(mine["code"], o["code"])  # the tracking number is for staff too
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "deliver"})[1]["order"]["st"], 3)

    def test_unknown_order_and_op(self):
        r = self.staff("recv")
        self.assertEqual(r.post("/api/recv/order", {"id": "nope", "op": "accept"})[0], 404)
        self.assertEqual(r.post("/api/recv/order", {"id": 5, "op": "accept"})[0], 404)
        self.assertEqual(r.post("/api/recv/order", {"id": "x"})[0], 400)


class TestDelivery(Base):
    def setUp(self):
        for n in ("سعد", "خالد"):
            if not self.app.db.one("SELECT 1 FROM staff WHERE role='driver' AND name_key=?", (W.name_key(n),)):
                self.app.set_staff("driver", n, "246810" if n == "سعد" else "135790")
        self.app.limit.fails.clear()

    def ready_delivery(self, c, r):
        o = self.place(c, mode="delivery", addr={"city": "المدينة", "street": "شارع قباء", "note": "الباب الأزرق", "lat": 24.4672, "lng": 39.6111})
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        return o

    def test_a_gift_brought_to_someone_else(self):
        """0.6.3: the sender pays a delivery order for a recipient; the desk sees who it is for, the driver who carries it gets the number."""
        r, c = self.staff("recv"), self.customer()
        saad = self.staff("driver", "سعد", "246810")
        addr = {"city": "المدينة", "street": "حي العزيزية", "lat": 24.47, "lng": 39.61}
        gift = {"name": "سارة", "phone": "551234567", "msg": "كل عام وأنتِ بخير"}
        for bad, why in ((dict(gift, phone="12"), "bad phone"), (gift, "only with delivery")):
            mode = "pickup" if why == "only with delivery" else "delivery"
            st, j, _ = c.post("/api/orders", self.order_body(mode=mode, addr=addr if mode == "delivery" else None, gift=bad))
            self.assertEqual((st, j.get("error")), (400, "bad_gift"), why)
        o = self.place(c, mode="delivery", addr=addr, gift=gift, cust=self.fresh_cust("أحمد"))
        self.assertEqual(o["gift"], {"name": "سارة", "phone": "551234567", "tail": "4567", "msg": "كل عام وأنتِ بخير"})   # the sender sees it all
        self.assertEqual(o["cust"]["name"], "أحمد")   # the order and its points are the sender's
        desk = next(x for x in r.get("/api/recv/state")[1]["orders"] if x["id"] == o["id"])
        self.assertEqual(desk["gift"], {"name": "سارة", "tail": "4567", "msg": "كل عام وأنتِ بخير"})   # no full number at the desk
        r.post("/api/recv/order", {"id": o["id"], "op": "accept"})
        av = next(x for x in saad.get("/api/driver/state")[1]["avail"] if x["id"] == o["id"])
        self.assertNotIn("phone", av["gift"])
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "take"})[0], 200)
        mine = next(x for x in saad.get("/api/driver/state")[1]["mine"] if x["id"] == o["id"])
        self.assertEqual(mine["gift"]["phone"], "551234567")   # the driver who carries it can call the recipient
        plain = self.place(c, mode="delivery", addr=addr)
        self.assertIsNone(plain["gift"])

    def test_a_driver_takes_an_order_while_it_is_prepared_and_the_customer_follows_him(self):
        r, c = self.staff("recv"), self.customer()
        saad, khalid = self.staff("driver", "سعد", "246810"), self.staff("driver", "خالد", "135790")
        o = self.place(c, mode="delivery", addr={"city": "المدينة", "street": "شارع قباء", "lat": 24.4672, "lng": 39.6111})
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "take"})[1]["error"], "bad_state")   # not accepted yet
        r.post("/api/recv/order", {"id": o["id"], "op": "accept"})
        a = next(x for x in saad.get("/api/driver/state")[1]["avail"] if x["id"] == o["id"])
        self.assertEqual(a["st"], 1, "seen from the moment it is being prepared")
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "take"})[0], 200)
        self.assertEqual(khalid.post("/api/driver/order", {"id": o["id"], "op": "take"})[1]["error"], "taken")
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "deliver", "code": o["code"]})[1]["error"], "bad_state", "not before it is ready")
        # his phone sends where it is; the customer sees it only once the order is on its way (ready)
        self.assertEqual(saad.post("/api/driver/loc", {"lat": 24.47, "lng": 39.6, "acc": 12})[1]["shared"], True)
        self.assertNotIn("track", c.post("/api/my/sync", {})[1])
        r.post("/api/recv/order", {"id": o["id"], "op": "ready"})
        t = c.post("/api/my/sync", {})[1]["track"][o["id"]]
        self.assertEqual((t["lat"], t["lng"], t["acc"]), (24.47, 39.6, 12))
        self.assertNotIn("track", self.customer().post("/api/my/sync", {})[1], "only the customer of the order")
        self.assertEqual(saad.post("/api/driver/loc", {"lat": 95, "lng": 39.6})[1]["error"], "bad_location")
        self.assertEqual(khalid.post("/api/driver/loc", {"lat": 24.4, "lng": 39.6})[1]["shared"], False, "no order, nothing kept")
        sid = next(iter(k for k, v in self.app.locs.items() if v[0] == 24.47))
        self.app.locs[sid] = self.app.locs[sid][:3] + (W.now_ms() - W.LOC_FRESH_MS - 1000,)
        self.assertNotIn("track", c.post("/api/my/sync", {})[1], "an old position is not shown")
        saad.post("/api/driver/loc", {"lat": 24.468, "lng": 39.61})
        self.assertEqual(c.post("/api/my/sync", {})[1]["track"][o["id"]]["lat"], 24.468)
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "deliver", "code": o["code"]})[0], 200)
        self.assertNotIn("track", c.post("/api/my/sync", {})[1], "delivered: the map is gone")
        # released while still being prepared, it goes back to everyone
        o2 = self.place(c, mode="delivery", addr={"city": "المدينة", "street": "شارع قباء"})
        r.post("/api/recv/order", {"id": o2["id"], "op": "accept"})
        saad.post("/api/driver/order", {"id": o2["id"], "op": "take"})
        self.assertEqual(saad.post("/api/driver/order", {"id": o2["id"], "op": "release"})[0], 200)
        self.assertIn(o2["id"], [x["id"] for x in khalid.get("/api/driver/state")[1]["avail"]])

    def test_driver_flow_end_to_end(self):
        r, c = self.staff("recv"), self.customer()
        saad, khalid = self.staff("driver", "سعد", "246810"), self.staff("driver", "خالد", "135790")
        o = self.place(c, mode="delivery", addr={"city": "المدينة", "street": "شارع قباء", "note": "الباب الأزرق", "lat": 24.4672, "lng": 39.6111})
        # not ready yet: the drivers see nothing, and cannot take it
        self.assertNotIn(o["id"], [x["id"] for x in saad.get("/api/driver/state")[1]["avail"]])
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "take"})[1]["error"], "bad_state")
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        a = next(x for x in saad.get("/api/driver/state")[1]["avail"] if x["id"] == o["id"])
        # before taking it: the area, not the phone or the exact spot
        self.assertEqual(a["addr"], {"city": "المدينة", "street": "شارع قباء"})
        self.assertNotIn("phone", a["cust"])
        self.assertNotIn("code", a)
        # take it
        st, j, _ = saad.post("/api/driver/order", {"id": o["id"], "op": "take"})
        self.assertEqual((st, j["order"]["driver"]["name"]), (200, "سعد"))
        self.assertEqual(j["order"]["cust"]["phone"], "501234567")
        self.assertEqual(j["order"]["addr"]["lat"], 24.4672)
        self.assertEqual(khalid.post("/api/driver/order", {"id": o["id"], "op": "take"})[1]["error"], "taken")
        self.assertNotIn(o["id"], [x["id"] for x in khalid.get("/api/driver/state")[1]["avail"]])
        self.assertEqual([x["id"] for x in saad.get("/api/driver/state")[1]["mine"]].count(o["id"]), 1)
        # the customer sees the driver
        s = c.post("/api/my/sync", {"since": 0})[1]["orders"][0]
        self.assertEqual((s["st"], s["driver"]), (2, "سعد"))
        # another driver cannot deliver or release it
        self.assertEqual(khalid.post("/api/driver/order", {"id": o["id"], "op": "deliver", "code": o["code"]})[1]["error"], "bad_state")
        self.assertEqual(khalid.post("/api/driver/order", {"id": o["id"], "op": "release"})[1]["error"], "bad_state")
        # wrong code, then the right one from the customer
        wrong = "0000" if o["code"] != "0000" else "1111"
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "deliver", "code": wrong})[1]["error"], "wrong_code")
        st, j, _ = saad.post("/api/driver/order", {"id": o["id"], "op": "deliver", "code": o["code"]})
        self.assertEqual((st, j["order"]["st"], j["order"]["fin"]), (200, 3, True))
        done = saad.get("/api/driver/state")[1]["done"]
        self.assertIn(o["id"], [x["id"] for x in done])
        s = c.post("/api/my/sync", {"since": 0})[1]["orders"][0]
        self.assertEqual((s["st"], s["fin"], s["done"]), (3, True, True))

    def test_two_drivers_racing_for_one_order(self):
        r, c = self.staff("recv"), self.customer()
        saad, khalid = self.staff("driver", "سعد", "246810"), self.staff("driver", "خالد", "135790")
        o = self.ready_delivery(c, r)
        res = []
        ts = [threading.Thread(target=lambda d=d: res.append(d.post("/api/driver/order", {"id": o["id"], "op": "take"})[0])) for d in (saad, khalid)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sorted(res), [200, 409])

    def test_release_and_unassign_put_it_back(self):
        r, c = self.staff("recv"), self.customer()
        saad, khalid = self.staff("driver", "سعد", "246810"), self.staff("driver", "خالد", "135790")
        o = self.ready_delivery(c, r)
        saad.post("/api/driver/order", {"id": o["id"], "op": "take"})
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "release"})[0], 200)
        self.assertEqual(khalid.post("/api/driver/order", {"id": o["id"], "op": "take"})[0], 200)
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "unassign"})[0], 200)
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "take"})[0], 200)

    def test_reception_can_hand_over_a_delivery_without_the_driver(self):
        r, c = self.staff("recv"), self.customer()
        o = self.ready_delivery(c, r)
        st, j, _ = r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "skip": True})
        self.assertEqual((st, j["order"]["st"]), (200, 3))

    def test_driver_cannot_touch_pickup_orders_or_use_café_operations(self):
        saad = self.staff("driver", "سعد", "246810")
        c, r = self.customer(), self.staff("recv")
        o = self.place(c)
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "take"})[1]["error"], "bad_state")
        self.assertEqual(saad.post("/api/driver/order", {"id": o["id"], "op": "accept"})[1]["error"], "bad_state")
        self.assertEqual(saad.post("/api/driver/branch", {"id": "b1", "pause": True})[0], 404)
        self.assertEqual(saad.post("/api/driver/menu", {"id": "latte", "stock": False})[0], 404)

    def test_a_driver_holds_at_most_five(self):
        r, c = self.staff("recv"), self.customer()
        khalid = self.staff("driver", "خالد", "135790")
        self.app.limit.hits.clear()
        orders = [self.ready_delivery(c, r) for _ in range(6)]
        res = [khalid.post("/api/driver/order", {"id": o["id"], "op": "take"})[1].get("error", "ok") for o in orders]
        self.assertEqual(res.count("ok"), 5)
        self.assertEqual(res[-1], "too_many")
        for o in orders:  # leave the board clean for the other tests
            r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "skip": True})
        self.app.limit.hits.clear()


class TestAdmin(Base):
    def test_menu_price_and_stock_reach_customers_and_pricing(self):
        a, c = self.staff("admin"), self.customer()
        srev = c.post("/api/my/sync", {})[1]["pub"]["srev"]
        self.assertEqual(a.post("/api/admin/menu", {"id": "latte", "price": 20.5})[0], 200)
        pub = c.post("/api/my/sync", {"srev": srev})[1]["pub"]
        self.assertEqual(pub["menu"]["latte"], {"price": 20.5})
        self.assertNotIn("pub", c.post("/api/my/sync", {"srev": pub["srev"]})[1])
        o = self.place(c, items=[{"pid": "latte", "qty": 1}])
        self.assertEqual(o["items"][0]["unit"], 20.5)
        # back to the original price removes the override
        a.post("/api/admin/menu", {"id": "latte", "price": None})
        self.assertNotIn("latte", c.get("/api/public")[1]["menu"])
        # stock
        a.post("/api/admin/menu", {"id": "cookie", "stock": False})
        self.assertEqual(c.post("/api/orders", self.order_body(items=[{"pid": "cookie", "qty": 1}]))[1]["error"], "stock")
        a.post("/api/admin/menu", {"id": "pineapple", "stock": True})
        self.assertEqual(c.post("/api/orders", self.order_body(items=[{"pid": "pineapple", "qty": 1}], mode="ship", carrier="Redbox", addr={"city": "a", "street": "b"}))[0], 200)
        a.post("/api/admin/menu", {"id": "cookie", "stock": True})
        a.post("/api/admin/menu", {"id": "pineapple", "stock": False})
        self.assertEqual(c.get("/api/public")[1]["menu"], {})

    def test_menu_validation(self):
        a = self.staff("admin")
        self.assertEqual(a.post("/api/admin/menu", {"id": "nope", "price": 5})[0], 400)
        self.assertEqual(a.post("/api/admin/menu", {"id": "latte", "price": 0})[0], 400)
        self.assertEqual(a.post("/api/admin/menu", {"id": "latte", "price": "5"})[0], 400)
        self.assertEqual(a.post("/api/admin/menu", {"id": "latte", "price": 99999})[0], 400)
        self.assertEqual(a.post("/api/admin/menu", {"id": "latte"})[0], 400)
        self.assertEqual(a.post("/api/admin/menu", {"id": "latte", "stock": "no"})[0], 400)

    def test_discount_code_switch_and_percent(self):
        a, c = self.staff("admin"), self.customer()
        a.post("/api/admin/code", {"code": "WHY10", "pct": 25})
        self.assertEqual(self.place(c, code="WHY10")["disc"], 13.5)
        a.post("/api/admin/code", {"code": "WHY10", "on": False})
        self.assertNotIn("WHY10", c.get("/api/public")[1]["codes"])
        self.assertEqual(c.post("/api/orders", self.order_body(code="WHY10"))[1]["error"], "bad_code")
        a.post("/api/admin/code", {"code": "EID20", "pct": 20})
        self.assertEqual(self.place(c, code="eid20")["disc"], 10.8)
        a.post("/api/admin/code", {"code": "WHY10", "on": True, "pct": 10})
        self.assertEqual(a.post("/api/admin/code", {"code": "W", "pct": 10})[0], 400)
        self.assertEqual(a.post("/api/admin/code", {"code": "WHY10", "pct": 95})[0], 400)

    def test_at_least_one_banner_stays_on(self):
        a, c = self.staff("admin"), self.customer()
        for b in ("bn1", "bn2", "bn3", "bn4"):
            self.assertEqual(a.post("/api/admin/banner", {"id": b, "on": False})[0], 200)
        self.assertEqual(a.post("/api/admin/banner", {"id": "bn5", "on": False})[1]["error"], "last_banner")
        self.assertEqual(sorted(c.get("/api/public")[1]["bn"]), ["bn1", "bn2", "bn3", "bn4"])
        for b in ("bn1", "bn2", "bn3", "bn4"):
            a.post("/api/admin/banner", {"id": b, "on": True})
        self.assertEqual(c.get("/api/public")[1]["bn"], {})

    def test_fees(self):
        a, c = self.staff("admin"), self.customer()
        a.post("/api/admin/fees", {"delivery_fee": 15, "ship": 30})
        try:
            addr = {"city": "a", "street": "b"}
            self.assertEqual(self.place(c, mode="delivery", addr=addr)["ship"], 15)
            self.assertEqual(self.place(c, mode="ship", carrier="Redbox", addr=addr, items=[{"pid": "cup8", "qty": 1}])["ship"], 30)
            self.assertEqual(a.post("/api/admin/fees", {"ship": -1})[0], 400)
            self.assertEqual(a.post("/api/admin/fees", {"delivery_fee": "x"})[0], 400)
        finally:
            a.post("/api/admin/fees", {"delivery_fee": 12, "ship": 25})

    def test_driver_management(self):
        a = self.staff("admin")
        st, j, _ = a.post("/api/admin/driver", {"op": "add", "name": "ماجد", "pin": "112233"})
        self.assertEqual(st, 200)
        did = j["id"]
        self.assertEqual(a.post("/api/admin/driver", {"op": "add", "name": " ماجد ", "pin": "112233"})[1]["error"], "exists")
        self.assertEqual(a.post("/api/admin/driver", {"op": "add", "name": "ماجد2", "pin": "12"})[0], 400)
        d = self.staff("driver", "ماجد", "112233")
        self.assertEqual(d.get("/api/driver/state")[0], 200)
        # a new PIN signs the old session out
        a.post("/api/admin/driver", {"op": "pin", "id": did, "pin": "445566"})
        self.assertEqual(d.get("/api/driver/state")[0], 401)
        self.assertEqual(Http(self.port).post("/api/driver/login", {"name": "ماجد", "pin": "112233"})[0], 401)
        self.app.limit.fails.clear()
        d = self.staff("driver", "ماجد", "445566")
        a.post("/api/admin/driver", {"op": "off", "id": did})
        self.assertEqual(d.get("/api/driver/state")[0], 401)
        self.assertEqual(Http(self.port).post("/api/driver/login", {"name": "ماجد", "pin": "445566"})[0], 401)
        self.app.limit.fails.clear()
        a.post("/api/admin/driver", {"op": "on", "id": did})
        self.staff("driver", "ماجد", "445566")
        self.assertIn("ماجد", [x["name"] for x in a.get("/api/admin/state")[1]["drivers"]])
        self.assertEqual(a.post("/api/admin/driver", {"op": "remove", "id": did})[0], 200)
        self.assertNotIn("ماجد", [x["name"] for x in a.get("/api/admin/state")[1]["drivers"]])
        self.assertEqual(a.post("/api/admin/driver", {"op": "remove", "id": did})[0], 404)

    def test_cannot_remove_a_driver_who_is_on_the_road(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        a.post("/api/admin/driver", {"op": "add", "name": "بدر", "pin": "778899"})
        d = self.staff("driver", "بدر", "778899")
        o = self.place(c, mode="delivery", addr={"city": "a", "street": "b"})
        for op in ("accept", "ready"):
            r.post("/api/recv/order", {"id": o["id"], "op": op})
        d.post("/api/driver/order", {"id": o["id"], "op": "take"})
        did = next(x["id"] for x in a.get("/api/admin/state")[1]["drivers"] if x["name"] == "بدر")
        self.assertEqual(a.post("/api/admin/driver", {"op": "remove", "id": did})[1]["error"], "busy")
        r.post("/api/recv/order", {"id": o["id"], "op": "deliver", "skip": True})
        self.assertEqual(a.post("/api/admin/driver", {"op": "remove", "id": did})[0], 200)

    def test_changing_a_pin_needs_the_current_one_and_signs_out(self):
        a = self.staff("admin")
        r = self.staff("recv")
        self.assertEqual(a.post("/api/admin/pin", {"target": "recv", "pin": "908070", "current": "000000"})[1]["error"], "bad_pin_confirm")
        self.assertEqual(a.post("/api/admin/pin", {"target": "recv", "pin": "123", "current": PINS["admin"]})[0], 400)
        self.assertEqual(a.post("/api/admin/pin", {"target": "recv", "pin": "908070", "current": PINS["admin"]})[0], 200)
        self.assertEqual(r.get("/api/recv/state")[0], 401)
        self.assertEqual(Http(self.port).post("/api/recv/login", {"pin": PINS["recv"]})[0], 401)
        self.app.limit.fails.clear()
        self.staff("recv", pin="908070")
        a.post("/api/admin/pin", {"target": "recv", "pin": PINS["recv"], "current": PINS["admin"]})
        self.app.limit.fails.clear()

    def test_points_reach_the_customer_once(self):
        a, c = self.staff("admin"), self.customer()
        c.post("/api/my/sync", {"name": "نورة", "phone": "559876543", "pts": 120})
        cust = next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == "6543")
        self.assertEqual((cust["name"], cust["pts"]), ("نورة", 120))
        self.assertEqual(a.post("/api/admin/points", {"id": cust["id"], "pts": 50})[0], 200)
        self.assertEqual(a.post("/api/admin/points", {"id": cust["id"], "pts": 0})[0], 400)
        self.assertEqual(a.post("/api/admin/points", {"id": 99999, "pts": 5})[0], 404)
        b = c.post("/api/my/sync", {"name": "نورة", "phone": "559876543"})[1]["bonus"]
        self.assertEqual([x["pts"] for x in b], [50])
        self.assertEqual(len(c.post("/api/my/sync", {})[1]["bonus"]), 1)  # no ack yet: it is offered again
        self.assertEqual(c.post("/api/my/sync", {"ack": [b[0]["id"]]})[1]["bonus"], [])
        self.assertEqual(c.post("/api/my/sync", {})[1]["bonus"], [])
        # another phone does not see it
        other = self.customer()
        self.assertEqual(other.post("/api/my/sync", {"name": "فهد", "phone": "558000111"})[1]["bonus"], [])

    def test_signup_details_are_kept_and_the_admin_sees_them(self):
        a, c = self.staff("admin"), self.customer()
        full = {"name": "سارة", "phone": "541112233", "pts": 100, "email": " Sara@Example.COM ", "birth": "1994-03-09", "gender": "f", "invite": "why-77", "mk": True}
        self.assertEqual(c.post("/api/my/sync", full)[0], 200)
        row = lambda: next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == "2233")
        r = row()
        # the invite code has a dash: not a valid code, so it is left out; the rest is stored in the form we keep it
        self.assertEqual((r["email"], r["birth"], r["gender"], r["invite"], r["mk"]), ("sara@example.com", "1994-03-09", "f", "", True))
        # a later sync with only the basics keeps what we have
        c.post("/api/my/sync", {"name": "سارة", "phone": "541112233", "pts": 100})
        self.assertEqual(row()["email"], "sara@example.com")
        # a valid invite code and a changed e-mail replace the old ones; the marketing choice can be withdrawn
        c.post("/api/my/sync", {"name": "سارة", "phone": "541112233", "invite": "why77", "email": "sara.new@example.com", "mk": False})
        r = row()
        self.assertEqual((r["email"], r["invite"], r["mk"], r["gender"]), ("sara.new@example.com", "WHY77", False, "f"))

    def test_bad_signup_details_are_ignored_not_stored(self):
        a, c = self.staff("admin"), self.customer()
        bad = {"name": "ليلى", "phone": "552223344", "email": "not-an-email", "birth": "2999-01-01", "gender": "x", "invite": "a", "mk": "yes"}
        self.assertEqual(c.post("/api/my/sync", bad)[0], 200)
        r = next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == "3344")
        self.assertEqual((r["email"], r["birth"], r["gender"], r["invite"], r["mk"]), ("", "", "", "", False))
        for b in ("1919-12-31", "1990-02-30", "90-01-01", "1990-1-1", 19900101):
            self.assertEqual(W.valid_birth(b), False, b)
        for b in ("1920-01-01", "2001-12-31"):
            self.assertEqual(W.valid_birth(b), True, b)
        for e in ("a@b.co", "first.last+tag@mail.example.sa"):
            self.assertEqual(W.valid_email(e), True, e)
        for e in ("a@b", "a b@c.com", "@c.com", "a@@c.com", "x" * 130 + "@c.com", None):
            self.assertEqual(W.valid_email(e), False, e)

    def test_an_old_database_gets_the_new_customer_columns(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as d:
            f = os.path.join(d, "old.db")
            con = sqlite3.connect(f)
            con.execute("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL UNIQUE, name TEXT NOT NULL, dev_hash TEXT, pts INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL, seen INTEGER NOT NULL)")
            con.execute("INSERT INTO customers(phone,name,pts,created,seen) VALUES('500000001','قديم',5,1,1)")
            con.commit()
            con.close()
            db = W.DB(f)
            cols = {r["name"] for r in db.q("PRAGMA table_info(customers)")}
            self.assertTrue({"email", "birth", "gender", "invite", "mk"} <= cols)
            self.assertEqual(db.one("SELECT name,email,mk FROM customers")["name"], "قديم")
            db.conn.close()
            W.DB(f).conn.close()  # opening it again changes nothing and does not fail

    def test_wipe_needs_the_pin_and_restarts_numbering(self):
        a, c = self.staff("admin"), self.customer()
        self.place(c)
        self.assertEqual(a.post("/api/admin/wipe", {"pin": "111111"})[1]["error"], "bad_pin_confirm")
        self.assertGreater(self.app.db.one("SELECT COUNT(*) n FROM orders")["n"], 0)
        self.assertEqual(a.post("/api/admin/wipe", {"pin": PINS["admin"]})[0], 200)
        self.assertEqual(self.app.db.one("SELECT COUNT(*) n FROM orders")["n"], 0)
        self.assertEqual(self.app.db.one("SELECT COUNT(*) n FROM customers")["n"], 0)
        self.assertEqual(self.place(c)["no"], "‎#1001")
        self.app.limit.fails.clear()

    def test_stats_and_state(self):
        a, c, r = self.staff("admin"), self.customer(), self.staff("recv")
        a.post("/api/admin/wipe", {"pin": PINS["admin"]})
        self.place(c)
        o = self.place(c, items=[{"pid": "cookie", "qty": 1}])
        r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "out"})
        s = a.get("/api/admin/state")[1]
        self.assertEqual(len(s["week"]), 7)
        self.assertEqual(s["week"][-1], {"day": s["today"], "n": 1, "sales": 54})
        self.assertEqual(len(s["orders"]), 2)
        self.assertEqual(s["cust"][0]["orders"], 1)  # the rejected one is not counted
        self.assertEqual(s["cust"][0]["spent"], 54)
        self.assertIn("menu", s)
        self.assertNotIn("code", s["orders"][0])
        self.assertNotIn("phone", s["orders"][0]["cust"])


class TestLongPoll(Base):
    def test_state_waits_then_answers_at_once_on_change(self):
        r, c = self.staff("recv"), self.customer()
        rev = r.get("/api/recv/state")[1]["rev"]
        t0 = time.time()
        st, j, _ = r.get("/api/recv/state?rev=%d&wait=1" % rev)
        self.assertEqual((st, j.get("same")), (200, True))
        self.assertGreaterEqual(time.time() - t0, 0.9)
        out = {}

        def wait():
            out["t0"] = time.time()
            out["r"] = r.get("/api/recv/state?rev=%d&wait=20" % rev)[1]
            out["t1"] = time.time()

        t = threading.Thread(target=wait)
        t.start()
        time.sleep(0.4)
        o = self.place(c)
        t.join(10)
        self.assertLess(out["t1"] - out["t0"], 3)
        self.assertIn(o["id"], [x["id"] for x in out["r"]["orders"]])
        self.assertGreater(out["r"]["rev"], rev)

    def test_signing_out_ends_a_wait(self):
        a = self.staff("admin")
        rev = a.get("/api/admin/state")[1]["rev"]
        res = {}
        t = threading.Thread(target=lambda: res.update(r=Http.get(a, "/api/admin/state?rev=%d&wait=20" % rev)))
        t.start()
        time.sleep(0.3)
        self.app.mutate(lambda c: None)  # anything that changes
        # the session is deleted by the logout below only after the wait ends: just prove the wait ends on a change
        t.join(10)
        self.assertEqual(res["r"][0], 200)

    def test_customer_sync_only_returns_what_changed(self):
        c, r = self.customer(), self.staff("recv")
        o = self.place(c)
        s = c.post("/api/my/sync", {"since": 0})[1]
        self.assertEqual(len(s["orders"]), 1)
        s2 = c.post("/api/my/sync", {"since": s["rev"]})[1]
        self.assertEqual(s2["orders"], [])
        r.post("/api/recv/order", {"id": o["id"], "op": "accept"})
        s3 = c.post("/api/my/sync", {"since": s2["rev"]})[1]
        self.assertEqual([(x["id"], x["st"]) for x in s3["orders"]], [(o["id"], 1)])
        # nobody else's orders ever show up
        other = self.customer()
        self.assertEqual(other.post("/api/my/sync", {"since": 0})[1]["orders"], [])


class TestCatalog(Base):
    """The menu in the database: what the admin adds, changes and deletes reaches every page and the prices."""

    def menu(self):
        return Http(self.port).get("/api/catalog")[1]

    def prod(self, pid):
        return next((p for p in self.menu()["products"] if p["id"] == pid), None)

    def add(self, a, **kw):
        p = {"ar": "قهوة تجربة", "en": "Test coffee", "price": 25, "cats": ["hot"], "opts": ["size"]}
        p.update(kw)
        st, j, _ = a.post("/api/admin/product", {"op": "save", "p": p})
        self.assertEqual(st, 200, j)
        return j["id"]

    def upload(self, a, w=600, h=400, small=(240, 160), **kw):
        body = {"full": b64(png(w, h)), "thumb": b64(png(*small)), "bg": "#FFFFFF", "f": "c"}
        body.update(kw)
        return a.post("/api/admin/img", body)

    def test_the_first_menu_comes_from_the_seed_with_its_photos(self):
        seed = json.loads((HERE / "catalog.json").read_text(encoding="utf-8"))["seed"]
        m = self.menu()
        seed_ids = [c["id"] for c in seed["cats"]]
        self.assertEqual([c["id"] for c in m["cats"] if c["id"] in seed_ids], seed_ids, "in the order of the first menu")
        self.assertEqual({p["id"] for p in m["products"]} >= {p["id"] for p in seed["products"]}, True)
        latte = self.prod("latte")
        for k in ("ar", "en", "price", "cat", "cats", "opts", "stock", "art", "tone", "cal"):
            self.assertIn(k, latte)
        self.assertEqual(latte["cats"], ["hot"])
        coll = self.prod("collection")
        self.assertTrue(coll["fship"]); self.assertEqual(coll["cats"], ["esp", "fil"])
        for pid in seed["images"]:
            im = self.prod(pid)["img"]
            self.assertRegex(im["id"], r"^[0-9a-f]{32}$")
            self.assertIn(im["f"], ("c", "v")); self.assertGreater(im["r"], 0)
            st, data, h = Http(self.port).bytes("/api/img/" + im["id"])
            self.assertEqual((st, h["Content-Type"]), (200, "image/webp"))
            self.assertEqual(data[:4] + data[8:12], b"RIFFWEBP")
            self.assertIn("immutable", h["Cache-Control"]); self.assertEqual(h["X-Content-Type-Options"], "nosniff")
            st2, small, _ = Http(self.port).bytes("/api/img/%s/t" % im["id"])
            self.assertEqual(st2, 200); self.assertLess(len(small), len(data))
            self.assertEqual(Http(self.port).bytes("/api/img/" + im["id"], {"If-None-Match": h["ETag"]})[0], 304)
        self.assertEqual(Http(self.port).bytes("/api/img/" + "0" * 32)[0], 404)
        self.assertEqual(Http(self.port).bytes("/api/img/../why.db")[0], 404)

    def test_a_new_product_reaches_every_page_and_the_server_prices_it(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        crev = c.post("/api/my/sync", {"crev": -1})[1]["cat"]["crev"]
        self.assertNotIn("cat", c.post("/api/my/sync", {"crev": crev})[1])
        self.assertNotIn("cat", c.post("/api/my/sync", {})[1], "a page from before 0.4 does not ask for the menu")
        pid = self.add(a, desc={"ar": "مزيج خاص\nبنكهة الكراميل", "en": "House blend"})
        got = c.post("/api/my/sync", {"crev": crev})[1]
        self.assertGreater(got["cat"]["crev"], crev)
        p = next(x for x in got["cat"]["products"] if x["id"] == pid)
        self.assertEqual((p["ar"], p["en"], p["price"], p["cats"], p["opts"], p["stock"]), ("قهوة تجربة", "Test coffee", 25, ["hot"], ["size"], True))
        self.assertEqual(p["desc"], {"ar": "مزيج خاص\nبنكهة الكراميل", "en": "House blend"})
        self.assertEqual((p["art"], p["img"]), (self.prod("espresso")["art"], None), "it draws like the first product of its category")
        o1 = self.place(c, items=[{"pid": pid, "sel": {"size": "l"}, "qty": 1}])
        self.assertEqual(o1["items"][0]["unit"], 30)
        self.assertEqual(o1["items"][0]["n"], {"ar": "قهوة تجربة", "en": "Test coffee"})
        # change it: the next order follows, the first one keeps its name
        st, j, _ = a.post("/api/admin/product", {"op": "save", "id": pid, "p": {"ar": "قهوة معدّلة", "en": "", "price": 27, "cats": ["hot"], "opts": []}})
        self.assertEqual(st, 200, j)
        self.assertEqual(j["product"]["ar"], "قهوة معدّلة")
        o2 = self.place(c, items=[{"pid": pid, "sel": {"size": "l"}, "qty": 1}])
        self.assertEqual((o2["items"][0]["unit"], o2["items"][0]["sel"]), (27, {}))
        for who in (a, r):
            st = who.get("/api/%s/state?rev=-1&crev=-1" % ("admin" if who is a else "recv"))[1]
            self.assertEqual(next(x for x in st["cat"]["products"] if x["id"] == pid)["ar"], "قهوة معدّلة")
            old = next(o for o in st["orders"] if o["id"] == o1["id"])
            self.assertEqual(old["items"][0]["n"]["ar"], "قهوة تجربة")
        st = a.get("/api/admin/state?rev=-1&crev=%d" % self.menu()["crev"])[1]
        self.assertNotIn("cat", st)
        self.assertEqual(st["crev"], self.menu()["crev"])
        # a page that waits for news hears about a menu change at once
        rev = st["rev"]
        res = {}
        t = threading.Thread(target=lambda: res.update(r=a.get("/api/admin/state?rev=%d&crev=%d&wait=10" % (rev, st["crev"]))[1]))
        t0 = time.time()
        t.start()
        time.sleep(0.3)
        self.staff("admin").post("/api/admin/product", {"op": "stock", "id": pid, "stock": False})
        t.join(8)
        self.assertLess(time.time() - t0, 5)
        self.assertFalse(next(x for x in res["r"]["cat"]["products"] if x["id"] == pid)["stock"])
        a.post("/api/admin/product", {"op": "stock", "id": pid, "stock": True})

    def test_what_the_admin_types_is_checked(self):
        a = self.staff("admin")
        bad = lambda body: a.post("/api/admin/product", {"op": "save", "p": dict({"ar": "صنف", "price": 5, "cats": ["hot"]}, **body)})
        for body, code in (({"ar": "x"}, "bad_name"), ({"price": 0}, "bad_price"), ({"price": "5"}, "bad_price"), ({"price": 60000}, "bad_price"),
                           ({"price": True}, "bad_price"), ({"cats": []}, "bad_cat"), ({"cats": ["nope"]}, "bad_cat"), ({"cats": "hot"}, "bad_cat"),
                           ({"cats": ["hot", "esp"]}, "mixed_kinds"), ({"opts": ["nope"]}, "bad_opts"), ({"opts": "size"}, "bad_opts"),
                           ({"cal": "a"}, "bad_request"), ({"cal": -1}, "bad_request"), ({"stock": "yes"}, "bad_request"), ({"img": "f" * 32}, "bad_img"), ({"img": 5}, "bad_img")):
            st, j, _ = bad(body)
            self.assertEqual((st, j.get("error")), (400, code), body)
        self.assertEqual(a.post("/api/admin/product", {"op": "save", "id": "nope", "p": {"ar": "صنف", "price": 5, "cats": ["hot"]}})[0], 404)
        self.assertEqual(a.post("/api/admin/product", {"op": "jump", "id": "latte"})[0], 400)
        long = "ق" * 90
        st, j, _ = a.post("/api/admin/product", {"op": "save", "p": {
            "ar": "  " + long + "\x07 ", "price": 12.345, "cats": ["esp", "fil", "esp"], "cal": None, "fship": True, "stock": False,
            "desc": {"ar": "سطر\r\n\r\n\r\n\r\nسطر\x00 ثاني"}, "sub": {"ar": " 250 جرام "}, "badge": {"ar": "", "en": ""},
            "d": [{"k": {"ar": "المنشأ", "en": "Origin"}, "v": {"ar": "إثيوبيا"}}, {"k": {"ar": "فارغ"}, "v": {"ar": "", "en": ""}}]}})
        self.assertEqual(st, 200, j)
        p = j["product"]
        self.assertEqual(len(p["ar"]), 60)
        self.assertEqual((p["price"], p["cats"], p["cat"], p["cal"], p["fship"], p["stock"]), (12.35, ["esp", "fil"], "esp", 0, True, False))
        self.assertEqual(p["desc"], {"ar": "سطر\n\nسطر ثاني", "en": ""})
        self.assertEqual((p["sub"], p["badge"]), ({"ar": "250 جرام", "en": ""}, None))
        self.assertEqual(p["d"], [{"k": {"ar": "المنشأ", "en": "Origin"}, "v": {"ar": "إثيوبيا", "en": ""}}])
        self.assertEqual(p["art"], "bag", "a retail product draws like the beans of its category")
        st, j, _ = a.post("/api/admin/product", {"op": "save", "p": {"ar": "مشروب", "price": 9, "cats": ["cold"], "fship": True}})
        self.assertFalse(j["product"]["fship"], "free shipping only means something for products that can be shipped")
        for role in ("recv", "driver"):
            self.assertEqual(Http(self.port).post("/api/%s/product" % role, {"op": "stock", "id": "latte", "stock": False})[0], 401)
        self.assertEqual(self.staff("recv").post("/api/recv/product", {"op": "stock", "id": "latte", "stock": False})[0], 404)

    def test_stopping_and_deleting_keep_the_old_orders(self):
        a, c = self.staff("admin"), self.customer()
        pid = self.add(a, ar="كرواسون", price=11, cats=["sweet"], opts=[])
        o = self.place(c, items=[{"pid": pid, "qty": 2}])
        self.assertEqual(a.post("/api/admin/product", {"op": "stock", "id": pid, "stock": False})[0], 200)
        self.assertEqual(c.post("/api/orders", self.order_body(items=[{"pid": pid, "qty": 1}]))[1]["error"], "stock")
        self.assertFalse(self.prod(pid)["stock"])
        a.post("/api/admin/product", {"op": "stock", "id": pid, "stock": True})
        self.assertEqual(c.post("/api/orders", self.order_body(items=[{"pid": pid, "qty": 1}]))[0], 200)
        st, j, _ = a.post("/api/admin/product", {"op": "delete", "id": pid})
        self.assertEqual(st, 200, j)
        gone = self.prod(pid)
        self.assertEqual((gone["gone"], gone["stock"], gone["img"], gone["ar"]), (1, False, None, "كرواسون"), "kept, marked gone")
        st, j, _ = c.post("/api/orders", self.order_body(items=[{"pid": pid, "qty": 1}]))
        self.assertEqual((st, j["error"]), (409, "stock"))
        old = next(x for x in a.get("/api/admin/state")[1]["orders"] if x["id"] == o["id"])
        self.assertEqual((old["items"][0]["n"]["ar"], old["total"]), ("كرواسون", 22))
        self.assertEqual(a.post("/api/admin/product", {"op": "delete", "id": pid})[0], 404)
        self.assertEqual(a.post("/api/admin/product", {"op": "save", "id": pid, "p": {"ar": "عودة", "price": 5, "cats": ["sweet"]}})[0], 404)
        self.assertEqual(a.post("/api/admin/product", {"op": "stock", "id": pid, "stock": True})[0], 404)
        # a deleted product of the first menu reads as sold out to pages built before 0.4
        a.post("/api/admin/product", {"op": "delete", "id": "datecake"})
        self.assertEqual(c.get("/api/public")[1]["menu"]["datecake"], {"stock": False})

    def test_photos_upload_replace_and_sweep(self):
        a = self.staff("admin")
        st, j, _ = self.upload(a)
        self.assertEqual(st, 200, j)
        img = j["img"]
        self.assertRegex(img["id"], r"^[0-9a-f]{32}$")
        self.assertEqual((img["bg"], img["f"], img["r"]), ("#ffffff", "c", 1.5))
        self.assertEqual(self.upload(a)[1]["img"]["id"], img["id"], "the same photo twice is one photo")
        pid = self.add(a, img=img["id"])
        self.assertEqual(self.prod(pid)["img"], img)
        st, data, h = Http(self.port).bytes("/api/img/" + img["id"])
        self.assertEqual((st, h["Content-Type"], data), (200, "image/png", png(600, 400)))
        self.assertEqual(Http(self.port).bytes("/api/img/%s/t" % img["id"])[1], png(240, 160))
        # what is not a photo, or not a sensible one
        for kw, code in (({"full": b64(b"GIF89a" + b"\0" * 40)}, "bad_img"), ({"full": b64(b"<svg onload=alert(1)>")}, "bad_img"), ({"full": "@@@"}, "bad_img"),
                         ({"full": ""}, "bad_img"), ({"thumb": None}, "bad_img"), ({"full": b64(png(20, 20))}, "bad_img"), ({"thumb": b64(png(900, 900))}, "bad_img"),
                         ({"bg": "red"}, "bad_img"), ({"full": "A" * 2_200_000}, "too_big")):
            st, j, _ = self.upload(a, **kw)
            self.assertEqual(j.get("error"), code, kw.keys())
            self.assertIn(st, (400, 413))
        try:
            err = a.post("/api/admin/img", {"full": "A" * 3_000_000})[1].get("error")
        except (BrokenPipeError, ConnectionResetError):   # the server refused and closed before the whole body was sent
            err = "too_big"
        self.assertEqual(err, "too_big")
        st, j, _ = self.upload(a, full=b64(jpeg_head(1200, 900)), f="v", bg=None)
        self.assertEqual((st, j["img"]["r"], j["img"]["f"], j["img"]["bg"]), (200, 1.3333, "v", None))
        self.assertEqual(Http(self.port).bytes("/api/img/" + j["img"]["id"])[2]["Content-Type"], "image/jpeg")
        st, j, _ = self.upload(a, full=b64(webp_head(800, 800)))
        self.assertEqual((st, j["img"]["r"]), (200, 1.0))
        self.assertEqual(self.staff("recv").post("/api/recv/img", {"full": b64(png(100, 100)), "thumb": b64(png(50, 50))})[0], 404)
        # replacing the photo: the old one goes once no product uses it (after a grace period, as an unsaved upload does)
        st, j, _ = self.upload(a, w=500, h=500, small=(200, 200))
        new = j["img"]["id"]
        st, j, _ = self.upload(a, w=300, h=300, small=(100, 100))
        stray = j["img"]["id"]
        with self.app.db.tx() as c:
            c.execute("UPDATE images SET created=0 WHERE id IN (?,?)", (img["id"], stray))
        p = self.prod(pid)
        a.post("/api/admin/product", {"op": "save", "id": pid, "p": {"ar": p["ar"], "price": p["price"], "cats": p["cats"], "img": new}})
        self.assertEqual(Http(self.port).bytes("/api/img/" + img["id"])[0], 404)
        self.assertEqual(Http(self.port).bytes("/api/img/" + stray)[0], 404)
        self.assertEqual(Http(self.port).bytes("/api/img/" + new)[0], 200)
        # removing it
        a.post("/api/admin/product", {"op": "save", "id": pid, "p": {"ar": p["ar"], "price": p["price"], "cats": p["cats"], "img": None}})
        self.assertIsNone(self.prod(pid)["img"])

    def test_categories(self):
        a, c = self.staff("admin"), self.customer()
        st, j, _ = a.post("/api/admin/cat", {"op": "save", "c": {"ar": "أدوات القهوة", "en": "Coffee tools", "kind": "retail"}})
        self.assertEqual(st, 200, j)
        cid = j["id"]
        m = self.menu()
        self.assertEqual(m["cats"][len([x for x in m["cats"] if not x.get("gone")]) - 1]["id"], cid, "a new category goes last")
        pid = self.add(a, ar="مطحنة يدوية", price=150, cats=[cid], fship=True)
        o = self.place(c, items=[{"pid": pid, "qty": 1}], mode="ship", carrier="Aramex", addr={"city": "المدينة", "street": "شارع"})
        self.assertEqual((o["ship"], o["total"]), (0, 150), "shipped free")
        self.assertEqual(c.post("/api/orders", self.order_body(items=[{"pid": "latte", "qty": 1}, {"pid": pid, "qty": 1}], mode="ship", carrier="Aramex", addr={"city": "a", "street": "b"}))[1]["error"], "ship_retail_only")
        self.assertEqual(a.post("/api/admin/cat", {"op": "save", "id": cid, "c": {"ar": "الأدوات", "en": "Tools"}})[0], 200)
        self.assertEqual(next(x for x in self.menu()["cats"] if x["id"] == cid)["ar"], "الأدوات")
        self.assertEqual(a.post("/api/admin/cat", {"op": "save", "id": cid, "c": {"ar": "الأدوات", "kind": "drink"}})[1]["error"], "cat_not_empty")
        ids = lambda: [x["id"] for x in self.menu()["cats"] if not x.get("gone")]
        before = ids()
        a.post("/api/admin/cat", {"op": "move", "id": cid, "d": -1})
        self.assertEqual(ids()[-2:], [cid, before[-2]])
        first = ids()[0]
        a.post("/api/admin/cat", {"op": "move", "id": first, "d": -1})
        self.assertEqual(ids()[0], first, "the first one cannot go higher")
        self.assertEqual(a.post("/api/admin/cat", {"op": "move", "id": cid, "d": 2})[0], 400)
        self.assertEqual(a.post("/api/admin/cat", {"op": "delete", "id": cid})[1]["error"], "cat_not_empty")
        a.post("/api/admin/product", {"op": "delete", "id": pid})
        self.assertEqual(a.post("/api/admin/cat", {"op": "delete", "id": cid})[0], 200)
        gone = next(x for x in self.menu()["cats"] if x["id"] == cid)
        self.assertEqual(gone["gone"], 1)
        self.assertNotIn(cid, ids())
        self.assertEqual(a.post("/api/admin/product", {"op": "save", "p": {"ar": "صنف", "price": 5, "cats": [cid]}})[1]["error"], "bad_cat")
        for body, code in (({"c": {"ar": "قسم"}}, "bad_kind"), ({"c": {"ar": "قسم", "kind": "toys"}}, "bad_kind"), ({"c": {"ar": "ق", "kind": "drink"}}, "bad_name")):
            self.assertEqual(a.post("/api/admin/cat", dict({"op": "save"}, **body))[1]["error"], code)
        self.assertEqual(a.post("/api/admin/cat", {"op": "delete", "id": "nope"})[0], 404)
        # the old order of the deleted product still reads well on the café side
        old = next(x for x in a.get("/api/admin/state")[1]["orders"] if x["id"] == o["id"])
        self.assertEqual(old["items"][0]["n"]["ar"], "مطحنة يدوية")


class TestBranches(Base):
    """Branches live in the database too: the admin adds, edits and deletes them; orders and pauses follow."""
    BODY = {"ar": "فرع العوالي", "en": "Al Awali", "addr": {"ar": "حي العوالي، طريق قباء", "en": "Al Awali, Quba Rd"},
            "all_day": False, "open": "07:00", "close": "01:30", "lat": 24.4421, "lng": 39.6168}

    def menu(self):
        return Http(self.port).get("/api/catalog")[1]

    def br(self, bid):
        return next((b for b in self.menu()["branches"] if b["id"] == bid), None)

    def test_the_first_branches_come_from_the_seed(self):
        live = [b["id"] for b in self.menu()["branches"] if not b.get("gone")]
        self.assertEqual(live[:3], ["b1", "b2", "b3"])
        b1, b2 = self.br("b1"), self.br("b2")
        self.assertEqual((b1["h"], b2["h"], b1["lat"], b1["lng"]), ([360, 1560], "24", None, None))
        self.assertTrue(b1["addr"]["ar"] and b1["addr"]["en"])

    def test_a_new_branch_takes_orders_pauses_changes_and_goes(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        crev = c.post("/api/my/sync", {"crev": -1})[1]["cat"]["crev"]
        st, j, _ = a.post("/api/admin/branches", {"op": "save", "b": self.BODY})
        self.assertEqual(st, 200, j)
        bid = j["id"]
        got = c.post("/api/my/sync", {"crev": crev})[1]["cat"]
        b = next(x for x in got["branches"] if x["id"] == bid)
        self.assertEqual((b["ar"], b["en"], b["addr"]["en"], b["h"], b["lat"], b["lng"]), ("فرع العوالي", "Al Awali", "Al Awali, Quba Rd", [420, 1530], 24.4421, 39.6168))
        self.assertEqual(self.menu()["branches"][-1]["id"], bid, "a new branch goes last")
        o = self.place(c, branch=bid)
        self.assertEqual(o["branch"], bid)
        self.assertEqual(r.post("/api/recv/branch", {"id": bid, "pause": True})[0], 200)
        self.assertEqual(c.post("/api/orders", self.order_body(branch=bid))[1]["error"], "paused")
        r.post("/api/recv/branch", {"id": bid, "pause": False})
        st, j, _ = a.post("/api/admin/branches", {"op": "save", "id": bid, "b": dict(self.BODY, ar="فرع العوالي الجديد", all_day=True, lat=None, lng=None)})
        self.assertEqual(st, 200, j)
        b = self.br(bid)
        self.assertEqual((b["ar"], b["h"], b["lat"], b["lng"]), ("فرع العوالي الجديد", "24", None, None))
        st, j, _ = a.post("/api/admin/branches", {"op": "save", "id": bid, "b": dict(self.BODY, open="16:00", close="23:00")})
        self.assertEqual(self.br(bid)["h"], [960, 1380])
        # its unfinished order comes first
        self.assertEqual(a.post("/api/admin/branches", {"op": "delete", "id": bid})[1]["error"], "branch_busy")
        r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})
        self.assertEqual(a.post("/api/admin/branches", {"op": "delete", "id": bid})[0], 200)
        self.assertEqual(self.br(bid)["gone"], 1, "kept, marked gone, so old orders still name it")
        self.assertEqual(c.post("/api/orders", self.order_body(branch=bid))[1]["error"], "bad_branch")
        self.assertEqual(r.post("/api/recv/branch", {"id": bid, "pause": True})[0], 400)
        self.assertEqual(a.post("/api/admin/branches", {"op": "save", "id": bid, "b": self.BODY})[0], 404)
        self.assertEqual(a.post("/api/admin/branches", {"op": "delete", "id": bid})[0], 404)
        old = next(x for x in a.get("/api/admin/state")[1]["orders"] if x["id"] == o["id"])
        self.assertEqual(old["branch"], bid)

    def test_what_the_admin_types_for_a_branch_is_checked(self):
        a = self.staff("admin")
        bad = lambda **kw: a.post("/api/admin/branches", {"op": "save", "b": dict(self.BODY, **kw)})
        for kw, code in (({"ar": "x"}, "bad_name"), ({"addr": {"ar": "ح"}}, "bad_address"), ({"addr": None}, "bad_address"),
                         ({"open": "7:00"}, "bad_hours"), ({"open": "24:00"}, "bad_hours"), ({"close": "07:00"}, "bad_hours"), ({"open": None}, "bad_hours"),
                         ({"all_day": "yes"}, "bad_request"), ({"lat": 95}, "bad_location"), ({"lat": None}, "bad_location"),
                         ({"lng": "39.6"}, "bad_location"), ({"lat": 0, "lng": 0}, "bad_location"), ({"lat": True}, "bad_location")):
            st, j, _ = bad(**kw)
            self.assertEqual((st, j.get("error")), (400, code), kw)
        st, j, _ = bad(all_day=True, open=None, close=None, ar="  فرع   الحرم\x07 ", lat=24.123456789, lng=39.987654321)
        self.assertEqual(st, 200, j)
        b = self.br(j["id"])
        self.assertEqual((b["ar"], b["h"], b["lat"], b["lng"]), ("فرع الحرم", "24", 24.123457, 39.987654))
        self.assertEqual(a.post("/api/admin/branches", {"op": "jump", "id": "b1"})[0], 400)
        self.assertEqual(self.staff("recv").post("/api/recv/branch", {"id": "nope", "pause": True})[0], 400)
        for role in ("recv", "driver"):
            self.assertEqual(Http(self.port).post("/api/%s/maplink" % role, {"url": "24.4,39.6"})[0], 401)
        self.assertEqual(self.staff("recv").post("/api/recv/maplink", {"url": "24.4,39.6"})[0], 404)
        self.assertEqual(self.staff("recv").post("/api/recv/branches", {"op": "save", "b": self.BODY})[0], 404, "reception can pause, not edit")

    def test_a_location_from_a_map_link_or_from_numbers(self):
        a = self.staff("admin")
        ask = lambda u: a.post("/api/admin/maplink", {"url": u})
        want = (24.4672, 39.6111)
        for u in ("24.4672, 39.6111", "24.4672 39.6111", "(24.4672,39.6111)", "٢٤٫٤٦٧٢، ٣٩٫٦١١١",
                  "https://www.google.com/maps/place/Why/@24.40,39.50,17z/data=!3m1!4b1!4m6!3m5!1s0x0:0x0!8m2!3d24.4672!4d39.6111",
                  "https://maps.google.com/?q=24.4672,39.6111", "https://www.google.com/maps/search/?api=1&query=24.4672%2C39.6111",
                  "https://www.google.com/maps/@24.4672,39.6111,15z", "https://maps.apple.com/?address=Madinah&ll=24.4672,39.6111&q=Why",
                  "https://www.google.com/maps/dir/?api=1&destination=24.4672,39.6111"):
            st, j, _ = ask(u)
            self.assertEqual((st, j.get("lat"), j.get("lng")), (200,) + want, u)
        # a short link is opened on the server, only to read where it leads (no internet in the test: a stand-in answers)
        seen = []

        def lead(url):
            seen.append(url)
            return {"https://maps.app.goo.gl/AbC123?g_st=ic": "https://www.google.com/maps/place/Why/@24.40,39.50,17z/data=!3d24.4672!4d39.6111",
                    "https://maps.app.goo.gl/Two": "https://goo.gl/maps/Three", "https://goo.gl/maps/Three": "/maps/@24.4672,39.6111,15z"}.get(url)

        self.app.where_link_goes = lead
        try:
            self.assertEqual(ask("https://maps.app.goo.gl/AbC123?g_st=ic")[1], {"ok": True, "lat": 24.4672, "lng": 39.6111})
            self.assertEqual(ask("https://maps.app.goo.gl/Two")[1].get("lat"), 24.4672, "two steps, the second one relative")
            self.assertEqual(ask("https://maps.app.goo.gl/Nowhere")[1]["error"], "no_location")
            self.assertEqual(seen.count("https://maps.app.goo.gl/Nowhere"), 1)

            def down(url):
                raise W.ApiError(502, "link_unreachable")
            self.app.where_link_goes = down
            self.assertEqual(ask("https://maps.app.goo.gl/AbC123")[1]["error"], "link_unreachable")
        finally:
            del self.app.where_link_goes
        for u in ("https://evil.example.com/where", "file:///etc/passwd", "http://127.0.0.1:8787/api/health", "مكان ما", "", None):
            self.assertEqual(ask(u)[1]["error"], "bad_link", u)
        self.assertEqual(ask("https://www.google.com/maps/search/24.4672,+39.6111?entry=tts")[1].get("lat"), 24.4672)

    def test_reading_where_a_short_link_leads(self):
        """One step of a short link: a redirect, a page that shows the place, a page that does not, a step off the map sites."""
        pages = {
            "https://maps.app.goo.gl/A": (302, "https://maps.google.com/?q=Why+Roastery&ftid=0x15:0x9", ""),
            "https://maps.google.com/?q=Why+Roastery&ftid=0x15:0x9": (200, None, '<head><meta content="https://maps.google.com/maps/api/staticmap?center=24.4672%2C39.6111&amp;zoom=17" property="og:image"></head>'),
            "https://maps.app.goo.gl/B": (302, "https://consent.google.com/m?continue=https://www.google.com/maps", ""),
            "https://maps.app.goo.gl/C": (200, None, "<html>nothing here</html>"),
            "https://maps.app.goo.gl/D": (404, None, ""),
        }
        self.app.open_link = lambda url: pages[url]
        try:
            self.assertEqual(self.app.map_link("https://maps.app.goo.gl/A"), {"lat": 24.4672, "lng": 39.6111})
            for u in ("https://maps.app.goo.gl/B", "https://maps.app.goo.gl/C", "https://maps.app.goo.gl/D"):
                with self.assertRaises(W.ApiError) as e:
                    self.app.map_link(u)
                self.assertEqual(e.exception.code, "no_location", u)
        finally:
            del self.app.open_link
        self.assertEqual(W.coords_in_page('"https://www.google.com/maps/place/x/data=!3d24.1!4d39.2"'), (24.1, 39.2))
        self.assertIsNone(W.coords_in_page("staticmap?center=95.1%2C39.2"))


class TestTiers(Base):
    """Membership tiers (0.5.1): the points of the last 30 days open silver and gold; each tier earns its own points."""

    def admin_cust(self, a, phone):
        return next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == phone[-4:])

    def test_the_tiers_are_public(self):
        pub = Http(self.port).get("/api/public")[1]
        self.assertEqual(pub["tiers"], W.DEFAULT_TIERS)
        self.assertEqual(pub["tiers"], [{"id": "basic", "min": 0, "per10": 8}, {"id": "silver", "min": 500, "per10": 9}, {"id": "gold", "min": 1000, "per10": 10}])
        self.assertEqual(pub["tdays"], 30)

    def test_points_follow_the_tier_and_the_tier_follows_the_last_30_days(self):
        a, c, cu = self.staff("admin"), self.customer(), self.fresh_cust("سلمان")
        self.assertEqual(Http(self.port, dev=secrets.token_hex(16)).post("/api/my/sync", {})[1]["tier"], {"id": "basic", "pts": 0})   # a guest
        self.assertEqual(c.post("/api/my/sync", cu)[1]["tier"], {"id": "basic", "pts": 100})   # the welcome points count
        o = self.place(c, cust=cu)
        self.assertEqual((o["tier"], o["earn"]), ("basic", 43))
        cid = self.admin_cust(a, cu["phone"])["id"]
        self.assertEqual(a.post("/api/admin/points", {"id": cid, "pts": 400})[0], 200)   # 100 + 43 + 400 = 543
        self.assertEqual(c.post("/api/my/sync", {})[1]["tier"], {"id": "silver", "pts": 543})
        o = self.place(c, cust=cu)
        self.assertEqual((o["tier"], o["earn"]), ("silver", 48))                            # 54 SAR, 9 for every 10
        a.post("/api/admin/points", {"id": cid, "pts": 500})                                  # 543 + 48 + 500 = 1091
        o = self.place(c, cust=cu)
        self.assertEqual((o["tier"], o["earn"]), ("gold", 54))                              # 10 for every 10
        row = self.admin_cust(a, cu["phone"])
        self.assertEqual((row["tier"], row["tpts"]), ("gold", 1145))
        # an order the café turns down no longer counts
        r = self.staff("recv")
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})[0], 200)
        self.assertEqual(c.post("/api/my/sync", {})[1]["tier"], {"id": "gold", "pts": 1091})
        # 31 days later the old points and the welcome points have run out
        with self.app.db.tx() as x:
            x.execute("UPDATE orders SET ts=ts-? WHERE cust_id=?", (31 * 86400_000, cid))
            x.execute("UPDATE bonus SET ts=ts-? WHERE cust_id=?", (31 * 86400_000, cid))
            x.execute("UPDATE customers SET created=created-? WHERE id=?", (31 * 86400_000, cid))
        self.assertEqual(c.post("/api/my/sync", {})[1]["tier"], {"id": "basic", "pts": 0})
        self.assertEqual((self.place(c, cust=cu)["tier"]), "basic")
        # the balance itself is the phone's and is not touched by any of this
        self.assertEqual(self.admin_cust(a, cu["phone"])["pts"], 0)


class TestRewardsAndBanners(Base):
    """0.6: the admin manages the rewards and the home banners; customers get them with the public settings."""

    def test_rewards(self):
        a, c = self.staff("admin"), self.customer()
        pub = Http(self.port).get("/api/public")[1]
        self.assertEqual([r["id"] for r in pub["rewards"]], ["r1", "r2", "r3", "r4", "r5"])
        self.assertEqual((pub["rewards"][1]["ar"], pub["rewards"][4]["credit"]), ("لاتيه (صغير)", 20))
        st, j, _ = a.post("/api/admin/reward", {"op": "save", "r": {"pid": "cookie", "pts": 90}})
        self.assertEqual(st, 200, j)
        nr = j["reward"]
        self.assertEqual((nr["ar"], nr["pts"], nr["on"]), ("كوكيز شوكولاتة", 90, True))
        self.assertIn(nr["id"], [r["id"] for r in Http(self.port).get("/api/public")[1]["rewards"]])
        o = self.place(c, items=[{"pid": "cookie", "qty": 1, "rw": nr["id"]}], cust=self.fresh_cust())
        self.assertEqual((o["spent"], o["sub"]), (90, 0))
        a.post("/api/admin/reward", {"op": "save", "r": dict(nr, on=False)})
        self.assertNotIn(nr["id"], [r["id"] for r in Http(self.port).get("/api/public")[1]["rewards"]])
        self.assertEqual(c.post("/api/orders", self.order_body(items=[{"pid": "cookie", "qty": 1, "rw": nr["id"]}]))[1]["error"], "bad_reward")
        cr = a.post("/api/admin/reward", {"op": "save", "r": {"credit": 15, "pts": 300, "en": "Fifteen"}})[1]["reward"]
        self.assertEqual((cr["ar"], cr["en"], cr["credit"]), ("رصيد 15 ريال في المحفظة", "Fifteen", 15))
        for bad in ({"pid": "cookie", "pts": 0}, {"pid": "cookie", "credit": 5, "pts": 10}, {"pid": "nope", "pts": 10}, {"credit": 2000, "pts": 10}, {"pts": 10}, {"pid": "cookie", "pts": 1.5}):
            self.assertEqual(a.post("/api/admin/reward", {"op": "save", "r": bad})[1].get("error"), "bad_reward", bad)
        self.assertEqual(a.post("/api/admin/reward", {"op": "del", "id": cr["id"]})[0], 200)
        self.assertEqual(a.post("/api/admin/reward", {"op": "del", "id": cr["id"]})[0], 404)
        self.assertNotIn(cr["id"], [r["id"] for r in a.get("/api/admin/state")[1]["rewards"]])
        self.assertNotEqual(self.staff("recv").post("/api/recv/reward", {"op": "del", "id": "r1"})[0], 200)

    def test_banners(self):
        a = self.staff("admin")
        self.assertEqual([b["id"] for b in Http(self.port).get("/api/public")[1]["banners"]], ["bn1", "bn2", "bn3", "bn4", "bn5"])
        img = a.post("/api/admin/img", {"full": b64(png(900, 450)), "thumb": b64(png(300, 150)), "bg": "#FFFFFF", "f": "v"})[1]["img"]
        st, j, _ = a.post("/api/admin/banners", {"op": "save", "b": {"t": {"ar": "عرض الشتاء", "en": "Winter offer"}, "s": {"ar": "خصم على الحبوب"}, "a": "menu", "img": {"id": img["id"]}}})
        self.assertEqual(st, 200, j)
        nb = j["banner"]
        self.assertEqual((nb["img"]["r"], nb["a"], nb["t"]["ar"]), (2.0, "menu", "عرض الشتاء"))
        self.assertEqual(Http(self.port).get("/api/public")[1]["banners"][-1]["id"], nb["id"])
        # a banner of the first set takes new words and keeps its place
        a.post("/api/admin/banners", {"op": "save", "id": "bn2", "b": {"t": {"ar": "نقاط أكثر"}, "a": "points"}})
        b2 = Http(self.port).get("/api/public")[1]["banners"][1]
        self.assertEqual((b2["id"], b2["t"]["ar"], b2["img"]), ("bn2", "نقاط أكثر", None))
        for bad, err in (({"t": {"ar": "x"}, "a": "nope"}, "bad_banner"), ({"a": "menu"}, "bad_banner"), ({"t": {"ar": "x"}, "a": "menu", "img": {"id": "0" * 32}}, "bad_img")):
            self.assertEqual(a.post("/api/admin/banners", {"op": "save", "b": bad})[1].get("error"), err, bad)
        a.post("/api/admin/banners", {"op": "up", "id": nb["id"]})
        self.assertEqual(Http(self.port).get("/api/public")[1]["banners"][-2]["id"], nb["id"])
        # its photo is never swept while the banner uses it
        with self.app.db.tx() as x:
            x.execute("UPDATE images SET created=0 WHERE id=?", (img["id"],))
            self.app._gc_images(x)
        self.assertIsNotNone(self.app.db.one("SELECT 1 FROM images WHERE id=?", (img["id"],)))
        # the last banner that is on cannot go
        ids = [b["id"] for b in Http(self.port).get("/api/public")[1]["banners"]]
        for i in ids[1:]:
            a.post("/api/admin/banner", {"id": i, "on": False})
        self.assertEqual(a.post("/api/admin/banners", {"op": "del", "id": ids[0]})[1].get("error"), "last_banner")
        self.assertEqual(a.post("/api/admin/banners", {"op": "del", "id": nb["id"]})[0], 200)
        self.assertNotIn(nb["id"], [b["id"] for b in Http(self.port).get("/api/public")[1]["banners"]])


class TestTierSettings(Base):
    def test_the_admin_changes_the_tiers_and_the_next_order_follows(self):
        a, c, cu = self.staff("admin"), self.customer(), self.fresh_cust()
        new = [{"id": "basic", "min": 0, "per10": 10}, {"id": "silver", "min": 300, "per10": 12}, {"id": "gold", "min": 800, "per10": 15}]
        self.assertEqual(a.post("/api/admin/tiers", {"tiers": new})[0], 200)
        self.assertEqual(Http(self.port).get("/api/public")[1]["tiers"], new)
        self.assertEqual(a.get("/api/admin/state")[1]["tiers"], new)
        self.assertEqual(self.place(c, cust=cu)["earn"], 54)                           # basic is now 10 for every 10
        self.assertEqual(c.post("/api/my/sync", {"srev": 0})[1]["pub"]["tiers"], new)  # phones get the new values
        bad = [
            new[:2],                                                                   # all three
            [new[1], new[0], new[2]],                                                  # in order
            [dict(new[0], min=5), new[1], new[2]],                                     # basic opens at 0
            [new[0], dict(new[1], min=900), new[2]],                                   # gold needs more than silver
            [new[0], dict(new[1], per10=9), new[2]],                                   # silver gives at least basic
            [new[0], new[1], dict(new[2], per10=0)],
            [new[0], new[1], dict(new[2], per10=101)],
            [new[0], new[1], dict(new[2], per10=12.5)],
            [new[0], new[1], dict(new[2], min=True)],
            [new[0], new[1], dict(new[2], id="vip")],
            "gold",
        ]
        for b in bad:
            self.assertEqual(a.post("/api/admin/tiers", {"tiers": b})[1].get("error"), "bad_tiers", b)
        self.assertEqual(Http(self.port).get("/api/public")[1]["tiers"], new)          # nothing changed
        self.assertNotEqual(self.staff("recv").post("/api/recv/tiers", {"tiers": new})[0], 200)
        self.assertEqual(Http(self.port).post("/api/admin/tiers", {"tiers": new})[0], 401)
        # kept across a restart
        type(self).stop(); type(self).start()
        self.assertEqual(Http(self.port).get("/api/public")[1]["tiers"], new)


class TestNews(Base):
    """News (0.6.4): written in the admin page, read by every customer; the first ones are the app's own until edited."""

    def test_news_from_the_admin_to_the_customers(self):
        ad, pub = self.staff("admin"), lambda: Http(self.port).get("/api/public")[1]["news"]
        self.assertEqual([n["id"] for n in pub()], ["n1", "n2", "n3"])
        self.assertEqual(ad.post("/api/admin/news", {"op": "save", "n": {"t": {"ar": "x"}}})[1]["error"], "bad_news")
        self.assertEqual(ad.post("/api/admin/news", {"op": "save", "n": {"t": {"ar": "خبر"}, "img": {"id": "0" * 32}}})[1]["error"], "bad_img")
        st, j, _ = ad.post("/api/admin/news", {"op": "save", "n": {"t": {"ar": "افتتاح فرع", "en": "New branch"}, "b": {"ar": "سطر أول\n\nسطر ثانٍ"}}})
        self.assertEqual(st, 200, j)
        n = j["news"]
        self.assertEqual((n["t"]["ar"], n["b"]["ar"], n["on"], n["img"]), ("افتتاح فرع", "سطر أول\n\nسطر ثانٍ", True, None))
        self.assertGreater(n["ts"], 0)
        self.assertEqual(pub()[0]["id"], n["id"], "the newest on top")
        ad.post("/api/admin/news", {"op": "on", "id": n["id"], "on": False})
        self.assertNotIn(n["id"], [x["id"] for x in pub()])
        self.assertIn(n["id"], [x["id"] for x in ad.get("/api/admin/state")[1]["news"]], "the admin still sees it")
        ad.post("/api/admin/news", {"op": "on", "id": n["id"], "on": True})
        ad.post("/api/admin/news", {"op": "down", "id": n["id"]})
        self.assertEqual([x["id"] for x in pub()][:2], ["n1", n["id"]])
        st, j, _ = ad.post("/api/admin/news", {"op": "save", "id": n["id"], "n": {"t": {"ar": "افتتاح فرع العزيزية"}, "b": {"ar": "نص"}}})
        self.assertEqual((j["news"]["ts"], j["news"]["t"]["ar"]), (n["ts"], "افتتاح فرع العزيزية"), "an edit keeps the date")
        st, j, _ = ad.post("/api/admin/news", {"op": "save", "id": "n3", "n": {"t": {"ar": ""}}})   # a first one may keep its own words
        self.assertEqual(st, 200, j)
        self.assertEqual(ad.post("/api/admin/news", {"op": "del", "id": n["id"]})[0], 200)
        self.assertEqual([x["id"] for x in pub()], ["n1", "n2", "n3"])
        self.assertEqual(ad.post("/api/admin/news", {"op": "del", "id": "nope"})[0], 404)
        self.assertEqual(self.staff("recv").post("/api/recv/news", {"op": "del", "id": "n1"})[0], 404)


NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def read_xlsx(data):
    """An Excel file as the tests need it: sheet names, and each sheet as {cell: (value, formula)} with text resolved."""
    z = zipfile.ZipFile(io.BytesIO(data))
    assert z.testzip() is None
    sst = [si.find("m:t", NS).text or "" for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS)]
    book = ET.fromstring(z.read("xl/workbook.xml"))
    names = [s.get("name") for s in book.find("m:sheets", NS)]
    sheets = {}
    for i, nm in enumerate(names, 1):
        root = ET.fromstring(z.read("xl/worksheets/sheet%d.xml" % i))
        cells = {}
        for c in root.iter("{%s}c" % NS["m"]):
            v, f = c.find("m:v", NS), c.find("m:f", NS)
            val = v.text if v is not None else None
            if c.get("t") == "s":
                val = sst[int(val)]
            elif val is not None and c.get("t") != "str":
                val = float(val)
            cells[c.get("r")] = (val, f.text if f is not None else None)
        view = root.find("m:sheetViews/m:sheetView", NS)
        sheets[nm] = {"cells": cells, "rtl": view.get("rightToLeft") == "1", "rows": len(root.find("m:sheetData", NS)),
                      "filter": (root.find("m:autoFilter", NS).get("ref") if root.find("m:autoFilter", NS) is not None else None)}
    return names, sheets, z


class TestReports(Base):
    """Reports (0.6.1): any period, added up on the server, and the same period as an Excel file. Reading only."""

    def move(self, oid, day, hour=10):
        """Test only: an order as if it had been made on another day (the column and the copy inside the order)."""
        d = datetime.datetime.fromisoformat("%sT%02d:30:00" % (day, hour))
        ts = int((d - datetime.timedelta(minutes=self.app.tz_min) - datetime.datetime(1970, 1, 1)).total_seconds() * 1000)
        with self.app.db.tx() as c:
            o = json.loads(c.execute("SELECT data FROM orders WHERE id=?", (oid,)).fetchone()["data"])
            o["day"], o["ts"] = day, ts
            c.execute("UPDATE orders SET day=?, ts=?, data=? WHERE id=?", (day, ts, json.dumps(o, ensure_ascii=False), oid))

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.today = cls.app.today()
        d0 = datetime.date.fromisoformat(cls.today)
        cls.yday = (d0 - datetime.timedelta(days=1)).isoformat()
        cls.old = (d0 - datetime.timedelta(days=40)).isoformat()

    def setUp(self):
        if getattr(type(self), "made", None):
            return
        type(self).made = True
        c = self.customer()
        o = {}
        o["A"] = self.place(c, items=[{"pid": "latte", "sel": {"size": "m", "milk": "oat", "extras": []}, "qty": 2}])
        o["B"] = self.place(c, mode="delivery", branch="b2", addr={"city": "المدينة", "street": "شارع 1"}, code="WHY10",
                            items=[{"pid": "cap", "sel": {}, "qty": 1}, {"pid": "espresso", "sel": {}, "qty": 3}])
        o["C"] = self.place(self.customer(), cust=self.fresh_cust("سارة"), payM="apple", items=[{"pid": "espresso", "sel": {}, "qty": 1}])
        o["D"] = self.place(c, branch="b3", items=[{"pid": "latte", "sel": {}, "qty": 1}])
        o["E"] = self.place(c, branch="b2", items=[{"pid": "brownie", "sel": {}, "qty": 1}])
        o["F"] = self.place(c, items=[{"pid": "latte", "sel": {}, "qty": 1}])
        r = self.staff("recv")
        st, j, _ = r.post("/api/recv/order", {"id": o["D"]["id"], "op": "reject", "reason": "busy"})
        self.assertEqual(st, 200, j)
        self.move(o["E"]["id"], self.yday)
        self.move(o["F"]["id"], self.old)
        type(self).o = o

    def test_totals_days_branches_ways_and_products(self):
        o, ad = self.o, self.staff("admin")
        st, j, _ = ad.post("/api/admin/report", {"from": self.yday, "to": self.today})
        self.assertEqual(st, 200, j)
        got = [o[k] for k in "ABCE"]
        cents = lambda v: round(v * 100)
        sales = sum(cents(x["total"]) for x in got)
        s = j["sum"]
        self.assertEqual((s["n"], cents(s["sales"])), (4, sales))
        self.assertEqual(cents(s["vat"]), sum(cents(x["vat"]) for x in got))
        self.assertEqual(cents(s["net"]), sales - sum(cents(x["vat"]) for x in got))
        self.assertEqual(cents(s["disc"]), cents(o["B"]["disc"]))
        self.assertGreater(s["disc"], 0)
        self.assertEqual(s["fees"], 12)
        self.assertEqual(s["avg"], W.half_up(sales / 4) / 100)
        self.assertEqual((s["items"], s["free"], s["cust"]), (2 + 4 + 1 + 1, 0, 2))
        self.assertEqual((s["rej"], cents(s["rejv"])), (1, cents(o["D"]["total"])))   # the rejected order adds nothing, but is counted
        # every day of the period, with nothing missing
        self.assertEqual([d["day"] for d in j["days"]], [self.yday, self.today])
        self.assertEqual([d["n"] for d in j["days"]], [1, 3])
        self.assertEqual(cents(j["days"][0]["sales"]), cents(o["E"]["total"]))
        # branches: best first; a branch without sales still shows
        br = {b["id"]: b for b in j["branches"]}
        self.assertEqual(set(br), {"b1", "b2", "b3"})
        self.assertEqual((br["b1"]["n"], cents(br["b1"]["sales"])), (2, cents(o["A"]["total"]) + cents(o["C"]["total"])))
        self.assertEqual((br["b3"]["n"], br["b3"]["sales"]), (0, 0))
        self.assertEqual([b["sales"] for b in j["branches"]], sorted([b["sales"] for b in j["branches"]], reverse=True))
        self.assertTrue(br["b1"]["name"]["ar"])
        self.assertEqual(sum(cents(b["sales"]) for b in j["branches"]), sales)
        # how they ordered and paid: each adds up to the sales
        self.assertEqual({m["id"]: m["n"] for m in j["modes"]}, {"pickup": 3, "delivery": 1})
        self.assertEqual([(p["id"], p["n"]) for p in j["pays"]], [("card", 3), ("apple", 1)])
        self.assertEqual(sum(cents(p["amount"]) for p in j["pays"]), sales)
        # best sellers: by quantity, the rejected and the out-of-period orders left out
        self.assertEqual([(p["pid"], p["qty"]) for p in j["top"]][:2], [("espresso", 4), ("latte", 2)])
        self.assertEqual(j["np"], 4)
        self.assertEqual(j["top"][0]["name"]["ar"], "إسبريسو")
        # another period holds only its own day
        st, j, _ = ad.post("/api/admin/report", {"from": self.old, "to": self.old})
        self.assertEqual((st, j["sum"]["n"], [p["pid"] for p in j["top"]]), (200, 1, ["latte"]))

    def test_periods_are_checked_and_only_the_admin_sees_them(self):
        ad = self.staff("admin")
        d0 = datetime.date.fromisoformat(self.today)
        for bad in ({"from": self.today, "to": self.yday}, {"from": "2026-02-30", "to": self.today}, {"from": "2026-1-01", "to": self.today},
                    {"from": 20260101, "to": self.today}, {"to": self.today}, {"from": (d0 - datetime.timedelta(days=366)).isoformat(), "to": self.today}):
            st, j, _ = ad.post("/api/admin/report", bad)
            self.assertEqual((st, j.get("error")), (400, "bad_range"), bad)
            self.assertEqual(ad.post_bytes("/api/admin/xlsx", bad)[0], 400)
        st, j, _ = ad.post("/api/admin/report", {"from": (d0 - datetime.timedelta(days=365)).isoformat(), "to": self.today})   # a whole year
        self.assertEqual((st, len(j["days"]), j["sum"]["n"]), (200, 366, 5))
        body = {"from": self.yday, "to": self.today}
        self.assertEqual(Http(self.port).post("/api/admin/report", body)[0], 401)
        self.assertEqual(self.staff("recv").post("/api/recv/report", body)[0], 404)
        self.assertEqual(ad.get("/api/admin/report")[0], 405)
        self.assertEqual(ad.post("/api/admin/report", body, headers={"Origin": "https://evil.example"})[0], 403)
        rev = self.app.rev
        ad.post("/api/admin/report", body)
        ad.post_bytes("/api/admin/xlsx", body)
        self.assertEqual(self.app.rev, rev)   # reading changes nothing

    def test_excel_file(self):
        o, ad = self.o, self.staff("admin")
        body = {"from": self.yday, "to": self.today}
        st, data, h = ad.post_bytes("/api/admin/xlsx", body)
        self.assertEqual(st, 200, data[:200])
        self.assertEqual(h["Content-Type"], W.XLSX_MIME)
        self.assertEqual(h["Content-Disposition"], 'attachment; filename="Why-report-%s_%s.xlsx"' % (self.yday, self.today))
        self.assertEqual(h["Cache-Control"], "no-store")
        names, sh, z = read_xlsx(data)
        self.assertEqual(names, ["الملخص", "الأيام", "الفروع", "المنتجات", "الطلبات"])
        self.assertTrue(all(x["rtl"] for x in sh.values()))
        self.assertIn('fullCalcOnLoad="1"', z.read("xl/workbook.xml").decode())
        self.assertIn('name val="Arial"', z.read("xl/styles.xml").decode())
        sales = round(sum(o[k]["total"] for k in "ABCE"), 2)
        S, D, B, P, O = (sh[n]["cells"] for n in names)
        # the summary reads its totals from the other sheets (formulas), and holds their values for a phone preview
        self.assertEqual(S["A1"][0], "تقرير مبيعات واي!")
        serial = lambda d: float((datetime.date.fromisoformat(d) - datetime.date(1899, 12, 30)).days)
        self.assertEqual((S["A2"][0], S["B2"][0], S["A3"][0], S["B3"][0]), ("من تاريخ", serial(self.yday), "إلى تاريخ", serial(self.today)))
        self.assertEqual(S["A8"][0], "عدد الطلبات")
        self.assertEqual(S["B8"], (4.0, "'الأيام'!C4"))
        self.assertEqual((round(S["B9"][0], 2), S["B9"][1]), (sales, "'الأيام'!D4"))
        self.assertEqual(S["B10"][1], "IF(B8=0,0,B9/B8)")
        self.assertEqual(S["B18"][0], 2.0)                       # customers
        self.assertEqual(S["B19"][0], 1.0)                       # rejected
        # the days: one row each, a total row of sums
        self.assertEqual(D["C2"][0] + D["C3"][0], 4.0)
        self.assertEqual(D["C4"][1], "SUM(C2:C3)")
        self.assertEqual(D["F2"][1], "D2-E2")
        self.assertEqual(D["B2"][0] in ("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"), True)
        # the date is a real date (a number Excel shows as a date), not text
        self.assertEqual(D["A3"][0], serial(self.today))
        # branches and products
        self.assertEqual(B["A1"][0], "الفرع")
        self.assertEqual(sh["الفروع"]["rows"], 1 + 3 + 1)
        self.assertEqual(P["A2"][0], "إسبريسو")
        self.assertEqual(P["C2"][0], 4.0)
        # every order on its own row, with its number, the oldest first; a filter on the heading
        self.assertEqual(sh["الطلبات"]["rows"], 1 + 4 + 1)
        self.assertEqual(sh["الطلبات"]["filter"], "A1:Q5")
        self.assertEqual(O["A2"][0], float(o["E"]["no"].replace("‎#", "")))
        self.assertIn("براونيز × 1", O["F2"][0])
        self.assertEqual(round(O["K6"][0], 2), sales)
        self.assertEqual(O["K6"][1], "SUM(K2:K5)")
        # English
        st, data, _ = ad.post_bytes("/api/admin/xlsx", dict(body, lang="en"))
        names, sh, _ = read_xlsx(data)
        self.assertEqual(names, ["Summary", "Days", "Branches", "Products", "Orders"])
        self.assertFalse(any(x["rtl"] for x in sh.values()))
        self.assertEqual(sh["Summary"]["cells"]["B8"], (4.0, "'Days'!C4"))
        self.assertEqual(sh["Products"]["cells"]["A2"][0], "Espresso")
        # a whole month is named by its month
        d0 = datetime.date.fromisoformat(self.old)
        first, nxt = d0.replace(day=1), (d0.replace(day=28) + datetime.timedelta(days=4)).replace(day=1)
        st, data, h = ad.post_bytes("/api/admin/xlsx", {"from": first.isoformat(), "to": (nxt - datetime.timedelta(days=1)).isoformat()})
        self.assertEqual(h["Content-Disposition"], 'attachment; filename="Why-report-%s.xlsx"' % first.isoformat()[:7])
        st, data, h = ad.post_bytes("/api/admin/xlsx", {"from": self.today, "to": self.today})
        self.assertEqual(h["Content-Disposition"], 'attachment; filename="Why-report-%s.xlsx"' % self.today)

    def test_excel_lists_a_capped_number_of_orders_but_counts_all(self):
        ad = self.staff("admin")
        keep = W.REPORT_LIST
        W.REPORT_LIST = 2
        try:
            st, data, _ = ad.post_bytes("/api/admin/xlsx", {"from": self.yday, "to": self.today})
        finally:
            W.REPORT_LIST = keep
        names, sh, _ = read_xlsx(data)
        O = sh["الطلبات"]["cells"]
        self.assertEqual(sh["الملخص"]["cells"]["B8"][0], 4.0)
        self.assertIn("أول 2 طلب", O["A6"][0])
        self.assertEqual(O["K4"][1], "SUM(K2:K3)")

    def test_old_orders_without_newer_fields_still_count(self):
        """An order kept by an older version may miss fields added later (payM, pay, vat, sub): it is still counted."""
        o, ad = self.o, self.staff("admin")
        st, before, _ = ad.post("/api/admin/report", {"from": self.yday, "to": self.today})
        with self.app.db.tx() as c:
            row = c.execute("SELECT data FROM orders WHERE id=?", (o["E"]["id"],)).fetchone()
            keep = row["data"]
            x = json.loads(keep)
            for k in ("payM", "pay", "vat", "sub", "bal"):
                x.pop(k, None)
            c.execute("UPDATE orders SET data=? WHERE id=?", (json.dumps(x, ensure_ascii=False), o["E"]["id"]))
        try:
            st, j, _ = ad.post("/api/admin/report", {"from": self.yday, "to": self.today})
            self.assertEqual(st, 200, j)
            self.assertEqual((j["sum"]["n"], j["sum"]["sales"]), (before["sum"]["n"], before["sum"]["sales"]))
            self.assertEqual(sum(round(p["amount"] * 100) for p in j["pays"]), round(j["sum"]["sales"] * 100))
            self.assertEqual(ad.post_bytes("/api/admin/xlsx", {"from": self.yday, "to": self.today})[0], 200)
        finally:
            with self.app.db.tx() as c:
                c.execute("UPDATE orders SET data=? WHERE id=?", (keep, o["E"]["id"]))


class TestAccount(Base):
    """0.7: points, wallet and gifts live on the server; a phone signs in with the code and any phone of the customer sees it all."""

    def phone(self):
        return "5" + "".join(secrets.choice("0123456789") for _ in range(8))

    def signup(self, c, name="سارة", phone=None, **kw):
        phone = phone or self.phone()
        st, j, _ = c.post("/api/my/login", dict({"phone": phone, "code": W.OTP_TEST, "signup": True, "name": name}, **kw))
        self.assertEqual(st, 200, j)
        return phone, j

    def acct(self, c, arev=None):
        return c.post("/api/my/sync", {"arev": arev})[1].get("acct")

    def test_signing_up_signing_in_and_a_second_phone(self):
        c, ph = self.customer(), self.phone()
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": "00000"})[1]["error"], "bad_otp")
        self.assertEqual(c.post("/api/my/login", {"phone": "12", "code": W.OTP_TEST})[1]["error"], "bad_phone")
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST})[1], {"ok": True, "need": "signup"})
        _, j = self.signup(c, phone=ph, email="Sara@Example.com", gender="f")
        self.assertTrue(j["new"])
        self.assertEqual((j["user"]["name"], j["user"]["phone"], j["user"]["email"], j["user"]["gender"]), ("سارة", ph, "sara@example.com", "f"))
        self.assertEqual((j["acct"]["pts"], j["acct"]["bal"], j["history"]), (100, 0, []))
        self.assertEqual(j["acct"]["ledger"][0]["label"], W.WELCOME_LABEL)
        st, r, _ = c.post("/api/orders", self.order_body(cust={"name": "سارة", "phone": ph}))
        o = r["order"]
        self.assertEqual(r["acct"]["pts"], 100 + o["earn"])
        self.assertEqual(r["acct"]["ledger"][0], dict(r["acct"]["ledger"][0], pts=o["earn"], label={"ar": "طلب %s" % o["no"].replace("\u200e", ""), "en": "Order %s" % o["no"].replace("\u200e", "")}))
        # another phone signs in with the same number: the same account and the orders, and it hears about them
        d = self.customer()
        st, k, _ = d.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST, "signup": True, "name": "غيرها"})
        self.assertEqual((k["new"], k["user"]["name"], k["acct"]["pts"], [x["id"] for x in k["history"]]), (False, "سارة", 100 + o["earn"], [o["id"]]))
        self.assertIn("code", k["history"][0])
        self.staff("recv").post("/api/recv/order", {"id": o["id"], "op": "accept"})
        self.assertEqual([(x["id"], x["st"]) for x in d.post("/api/my/sync", {"since": k["rev"]})[1]["orders"]], [(o["id"], 1)])
        # the account comes again only when it changed
        self.assertIsNone(self.acct(d, k["acct"]["arev"]))
        self.assertEqual(self.acct(d)["pts"], 100 + o["earn"])
        # signing out: this phone is no one again
        self.assertEqual(d.post("/api/my/logout", {})[0], 200)
        self.assertNotIn("acct", d.post("/api/my/sync", {})[1])
        self.assertEqual(d.post("/api/my/topup", {"amt": 50})[1]["error"], "bad_customer")
        self.assertIn("acct", c.post("/api/my/sync", {})[1])   # the first phone is still in

    def test_points_and_the_wallet_are_counted_here(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        ph, j = self.signup(c, "منى")
        cu = {"name": "منى", "phone": ph}
        reward = [{"pid": "batch", "sel": {"size": "s"}, "qty": 1, "rw": "r1"}]   # 120 points
        self.assertEqual(c.post("/api/orders", self.order_body(cust=cu, items=reward))[1]["error"], "no_points")
        cid = next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == ph[-4:])["id"]
        self.assertEqual(a.post("/api/admin/points", {"id": cid, "pts": 50})[0], 200)
        s = c.post("/api/my/sync", {"arev": j["acct"]["arev"]})[1]
        self.assertEqual((s["acct"]["pts"], [b["pts"] for b in s["bonus"]]), (150, [50]))   # in the ledger; the bonus row only tells the phone
        self.assertEqual(s["acct"]["ledger"][0]["label"], W.BONUS_LABEL)
        st, x, _ = c.post("/api/orders", self.order_body(cust=cu, items=reward))
        self.assertEqual((st, x["order"]["total"], x["acct"]["pts"]), (200, 0, 30))
        self.assertEqual(next(a2 for a2 in a.get("/api/admin/state")[1]["cust"] if a2["id"] == cid)["pts"], 30)
        # the wallet: nothing to pay with yet, then a top-up (a trial payment until the gateway comes)
        self.assertEqual(c.post("/api/orders", self.order_body(cust=cu, bal=5))[1]["error"], "no_balance")
        for bad in (5, 1001, 12.5, "50", True):
            self.assertEqual(c.post("/api/my/topup", {"amt": bad})[1]["error"], "bad_amount")
        t = c.post("/api/my/topup", {"amt": 50, "cid": "tp1"})[1]["acct"]
        self.assertEqual((t["bal"], t["wallet"][0]["amt"], t["wallet"][0]["label"]["ar"]), (50, 50, "شحن المحفظة"))
        self.assertEqual(c.post("/api/my/topup", {"amt": 50, "cid": "tp1"})[1]["acct"]["bal"], 50)   # the same attempt twice: once
        self.assertEqual(c.post("/api/my/redeem", {"id": "r5"})[1]["error"], "no_points")
        self.assertEqual(c.post("/api/my/redeem", {"id": "r1"})[1]["error"], "bad_reward")   # a product reward goes through an order
        st, x, _ = c.post("/api/orders", self.order_body(cust=cu, bal=20))
        o = x["order"]
        self.assertEqual((o["bal"], o["pay"], x["acct"]["bal"], x["acct"]["pts"]), (20, o["total"] - 20, 30, 30 + o["earn"]))
        # the café turns it down: the 20 riyals and the points come back, the points it gave go
        self.assertEqual(r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})[0], 200)
        back = self.acct(c)
        self.assertEqual((back["bal"], back["pts"]), (50, 30))
        self.assertEqual([w["label"]["ar"] for w in back["wallet"][:1]], ["إرجاع رصيد الطلب %s" % o["no"].replace("\u200e", "")])
        # enough points now for wallet credit
        a.post("/api/admin/points", {"id": cid, "pts": 400})
        x = c.post("/api/my/redeem", {"id": "r5"})[1]
        self.assertEqual((x["credit"], x["acct"]["pts"], x["acct"]["bal"]), (20, 30, 70))

    def test_a_gift_card_reaches_another_number(self):
        c, d = self.customer(), self.customer()
        pa, _ = self.signup(c, "أحمد")
        pb = self.phone()
        for bad, err in (({"to": "12", "kind": "card", "amt": 50}, "bad_gift"), ({"to": pb, "kind": "card", "amt": 5}, "bad_amount"),
                         ({"to": pb, "kind": "x"}, "bad_gift"), ({"to": pb, "kind": "card", "amt": 50, "total": 49}, "price_changed")):
            self.assertEqual(c.post("/api/my/gift", dict(bad, op="send"))[1]["error"], err)
        x = c.post("/api/my/gift", {"op": "send", "to": pb, "kind": "card", "amt": 50, "name": "خالد", "msg": "مبروك", "total": 50, "cid": "g1"})[1]
        g = x["gift"]
        self.assertEqual((g["to"], g["toName"], g["amt"], g["price"], g["state"], g["earn"]), (pb, "خالد", 50, 50, "new", 40))
        self.assertEqual(x["acct"]["pts"], 140)   # 100 welcome + 8 for every 10 riyals
        self.assertEqual(c.post("/api/my/gift", {"op": "send", "to": pb, "kind": "card", "amt": 50, "cid": "g1"})[1]["gift"]["id"], g["id"])   # once
        # the recipient has no account yet; when he signs up it is waiting for him
        _, j = self.signup(d, "خالد", phone=pb)
        self.assertEqual([(y["id"], y["from"], y["amt"], y["msg"], y["state"]) for y in j["acct"]["gifts"]], [(g["id"], "أحمد", 50, "مبروك", "new")])
        self.assertNotIn("to", j["acct"]["gifts"][0])
        self.assertEqual(c.post("/api/my/gift", {"op": "claim", "id": g["id"]})[1]["error"], "not_found")   # not the sender's to take
        y = d.post("/api/my/gift", {"op": "claim", "id": g["id"]})[1]
        self.assertEqual((y["amt"], y["acct"]["bal"], y["acct"]["gifts"][0]["state"]), (50, 50, "used"))
        self.assertEqual(y["acct"]["wallet"][0]["label"]["ar"], "بطاقة هدية من أحمد")
        self.assertEqual(d.post("/api/my/gift", {"op": "claim", "id": g["id"]})[1]["error"], "gift_used")
        self.assertEqual(self.acct(c)["sent"][0]["state"], "used")   # the sender sees it was used

    def test_a_product_gift_is_used_once_and_comes_back_if_the_order_is_turned_down(self):
        r, c, d = self.staff("recv"), self.customer(), self.customer()
        self.signup(c, "أحمد")
        pb, _ = self.signup(d, "خالد")
        g = c.post("/api/my/gift", {"op": "send", "to": pb, "kind": "item", "pid": "latte", "total": 17})[1]["gift"]
        self.assertEqual((g["pid"], g["price"], g["earn"]), ("latte", 17, 13))
        cu = {"name": "خالد", "phone": pb}
        wrong = [{"pid": "ilatte", "sel": {}, "qty": 1, "gift": g["id"]}]
        self.assertEqual(d.post("/api/orders", self.order_body(cust=cu, items=wrong))[1]["error"], "gift_used")
        two = [{"pid": "latte", "sel": {}, "qty": 2, "gift": g["id"]}]
        self.assertEqual(d.post("/api/orders", self.order_body(cust=cu, items=two))[1]["error"], "gift_used")
        use = [{"pid": "latte", "sel": {}, "qty": 1, "gift": g["id"]}]
        self.assertEqual(c.post("/api/orders", self.order_body(cust={"name": "أحمد", "phone": "509999999"}, items=use))[1]["error"], "gift_used")   # someone else
        st, x, _ = d.post("/api/orders", self.order_body(cust=cu, items=use))
        self.assertEqual((st, x["order"]["total"], x["acct"]["gifts"][0]["state"]), (200, 0, "used"))
        self.assertEqual(d.post("/api/orders", self.order_body(cust=cu, items=use))[1]["error"], "gift_used")
        r.post("/api/recv/order", {"id": x["order"]["id"], "op": "reject", "reason": "out"})
        self.assertEqual(self.acct(d)["gifts"][0]["state"], "new")

    def test_a_gift_brought_by_a_driver_shows_among_the_sent_gifts(self):
        r, c = self.staff("recv"), self.customer()
        ph, _ = self.signup(c, "أحمد")
        addr = {"city": "المدينة", "street": "حي العزيزية"}
        o = self.place(c, mode="delivery", addr=addr, gift={"name": "سارة", "phone": "551234567", "msg": "هلا"}, cust={"name": "أحمد", "phone": ph},
                       items=[{"pid": "latte", "sel": {}, "qty": 1}])
        sent = self.acct(c)["sent"][0]
        self.assertEqual((sent["id"], sent["oid"], sent["state"], sent["to"], sent["price"]), (o["gid"], o["id"], "del", "551234567", o["total"]))
        self.assertEqual(self.acct(c)["ledger"][0]["label"]["ar"], "هدية %s" % o["no"].replace("\u200e", ""))
        r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})
        self.assertEqual(self.acct(c)["sent"][0]["state"], "void")

    def test_cancelling_before_the_branch_accepts_and_rating(self):
        r, c = self.staff("recv"), self.customer()
        ph, j = self.signup(c, "ريما")
        cu = {"name": "ريما", "phone": ph}
        c.post("/api/my/topup", {"amt": 30})
        x = c.post("/api/orders", self.order_body(cust=cu, bal=10))[1]
        o = x["order"]
        st, y, _ = c.post("/api/my/cancel", {"id": o["id"]})
        self.assertEqual((st, y["order"]["rej"]["by"], y["acct"]["bal"], y["acct"]["pts"]), (200, "cust", 30, 100))
        self.assertEqual(c.post("/api/my/cancel", {"id": o["id"]})[1]["error"], "bad_state")
        desk = next(z for z in r.get("/api/recv/state")[1]["orders"] if z["id"] == o["id"])
        self.assertEqual(desk["rej"]["why"]["ar"], "ألغاه العميل")
        o2 = self.place(c, cust=cu)
        r.post("/api/recv/order", {"id": o2["id"], "op": "accept"})
        self.assertEqual(c.post("/api/my/cancel", {"id": o2["id"]})[1]["error"], "bad_state")   # too late once accepted
        self.assertEqual(self.customer().post("/api/my/cancel", {"id": o2["id"]})[1]["error"], "not_found")   # not someone else's
        self.assertEqual(c.post("/api/my/rate", {"id": o2["id"], "stars": 5})[1]["error"], "bad_state")   # not finished yet
        r.post("/api/recv/order", {"id": o2["id"], "op": "ready"})
        r.post("/api/recv/order", {"id": o2["id"], "op": "deliver", "code": o2["code"]})
        for bad in (0, 6, 4.5, "5", True):
            self.assertEqual(c.post("/api/my/rate", {"id": o2["id"], "stars": bad})[1]["error"], "bad_rate")
        st, z, _ = c.post("/api/my/rate", {"id": o2["id"], "stars": 4, "note": "  القهوة ممتازة\nوالانتظار طويل  "})
        self.assertEqual((st, z["order"]["rate"]["s"], z["order"]["rate"]["c"]), (200, 4, "القهوة ممتازة\nوالانتظار طويل"))
        self.assertEqual(c.post("/api/my/rate", {"id": o2["id"], "stars": 1})[1]["error"], "rated")
        desk = next(z for z in self.staff("admin").get("/api/admin/state")[1]["orders"] if z["id"] == o2["id"])
        self.assertEqual(desk["rate"]["s"], 4)

    def test_a_pickup_time(self):
        r, c = self.staff("recv"), self.customer()
        t = W.now_ms()
        o = self.place(c, branch="b2", pick=t + 45 * 60_000)
        self.assertEqual(o["pick"], t + 45 * 60_000)
        self.assertEqual(next(z for z in r.get("/api/recv/state")[1]["orders"] if z["id"] == o["id"])["pick"], t + 45 * 60_000)
        self.assertIsNone(self.place(c, branch="b2")["pick"])
        for pick, kw in ((t + 5 * 60_000, {}), (t + 13 * 3600_000, {}), ("soon", {}), (t + 45 * 60_000, {"mode": "delivery", "addr": {"city": "م", "street": "ش"}})):
            self.assertEqual(c.post("/api/orders", self.order_body(branch="b2", pick=pick, **kw))[1]["error"], "bad_pick")
        # the branch hours, in the café's time (UTC+3): b3 opens 16:00 to 23:00
        day = (t // 86400_000) * 86400_000 - 3 * 3600_000   # a local midnight
        b3 = self.app.catalog.B["b3"]
        at = lambda hh, mm: day + (hh * 60 + mm) * 60_000
        self.assertTrue(self.app.pick_ok(b3, at(16, 30), at(16, 0)))
        self.assertFalse(self.app.pick_ok(b3, at(23, 15), at(22, 30)))
        self.assertFalse(self.app.pick_ok(b3, at(15, 30), at(15, 0)))
        b1 = self.app.catalog.B["b1"]   # 06:00 to 02:00, past midnight
        self.assertTrue(self.app.pick_ok(b1, at(24, 30), at(23, 30)))
        self.assertFalse(self.app.pick_ok(b1, at(26, 30), at(23, 30)))

    def test_deleting_the_account(self):
        r, c, d = self.staff("recv"), self.customer(), self.customer()
        ph, j0 = self.signup(c, "هند")
        other = self.customer()   # her second phone
        other.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST})
        pd, _ = self.signup(d, "دانة")
        cu = {"name": "هند", "phone": ph}
        g_in = d.post("/api/my/gift", {"op": "send", "to": ph, "kind": "card", "amt": 20})[1]["gift"]
        g_out = c.post("/api/my/gift", {"op": "send", "to": pd, "kind": "card", "amt": 30})[1]["gift"]
        o = self.place(c, cust=cu, mode="delivery", addr={"city": "المدينة", "street": "شارع قباء", "lat": 24.4, "lng": 39.6})
        self.assertEqual(c.post("/api/my/delete", {})[1]["error"], "open_orders")
        r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})
        self.assertEqual(c.post("/api/my/delete", {})[0], 200)
        cid = self.app.db.one("SELECT cust_id FROM orders WHERE id=?", (o["id"],))["cust_id"]
        self.assertIsNone(cid)
        data = json.loads(self.app.db.one("SELECT data FROM orders WHERE id=?", (o["id"],))["data"])
        self.assertEqual((data["cust"]["name"], data["cust"]["phone"], data["addr"]), ("عميل محذوف", "", None))
        self.assertIsNone(self.app.db.one("SELECT 1 FROM customers WHERE phone=?", (ph,)))
        self.assertIsNone(self.app.db.one("SELECT 1 FROM gifts WHERE id=?", (g_in["id"],)))
        self.assertEqual(self.app.db.one("SELECT from_cust FROM gifts WHERE id=?", (g_out["id"],))["from_cust"], None)
        self.assertEqual([y["id"] for y in self.acct(d)["gifts"]], [g_out["id"]])   # what she sent still reaches dana
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST})[1]["need"], "signup")
        self.assertEqual(c.post("/api/my/delete", {})[1]["error"], "bad_customer")
        # her second phone hears it at its next sync (and does not make the account again)
        g = other.post("/api/my/sync", {"name": "هند", "phone": ph, "arev": j0["acct"]["arev"]})[1]
        self.assertTrue(g.get("gone"))
        self.assertIsNone(self.app.db.one("SELECT 1 FROM customers WHERE phone=?", (ph,)))

    def test_a_phone_from_before_hands_over_its_balances_once(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        cu = self.fresh_cust("وليد")
        c.post("/api/my/sync", dict(cu, pts=340))              # the old page: the phone counts
        cid = next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == cu["phone"][-4:])["id"]
        a.post("/api/admin/points", {"id": cid, "pts": 25})       # not taken by the phone yet
        o = self.place(c, cust=cu)                                 # an order of the old page: nothing booked here
        self.assertEqual(self.app.db.one("SELECT COUNT(*) n FROM ledger WHERE cust_id=?", (cid,))["n"], 0)
        s = c.post("/api/my/sync", dict(cu, pts=340 + o["earn"]))[1]
        self.assertNotIn("acct", s)
        since = s["rev"]
        r.post("/api/recv/order", {"id": o["id"], "op": "reject", "reason": "busy"})   # the phone has not seen this yet
        x = c.post("/api/my/sync", dict(cu, since=since, legacy={"pts": 340 + o["earn"], "bal": 12.5}))[1]
        self.assertEqual((x["acct"]["pts"], x["acct"]["bal"]), (340 + 25, 12.5))
        self.assertEqual([e["label"]["ar"] for e in reversed(x["acct"]["ledger"])][:3], ["رصيد النقاط السابق", "نقاط هدية من واي", "إلغاء نقاط الطلب %s" % o["no"].replace("\u200e", "")])
        y = c.post("/api/my/sync", dict(cu, legacy={"pts": 99999, "bal": 999}))[1]   # once only
        self.assertEqual((y["acct"]["pts"], y["acct"]["bal"]), (365, 12.5))
        # from now on the phone's own count is not taken
        c.post("/api/my/sync", dict(cu, pts=5))
        self.assertEqual(next(z for z in a.get("/api/admin/state")[1]["cust"] if z["id"] == cid)["pts"], 365)

    def test_signing_in_on_another_phone_opens_an_old_account_with_the_points_it_reported(self):
        c, d = self.customer(), self.customer()
        cu = self.fresh_cust("سعود")
        c.post("/api/my/sync", dict(cu, pts=210))
        j = d.post("/api/my/login", {"phone": cu["phone"], "code": W.OTP_TEST})[1]
        self.assertEqual((j["new"], j["acct"]["pts"], j["acct"]["bal"]), (False, 210, 0))


class TestBranchesOwnWays(Base):
    """0.7: a desk for each branch, how far the drivers go, the smallest delivery, products a branch does not make."""

    def test_the_order_desk_of_one_branch(self):
        a, c = self.staff("admin"), self.customer()
        self.assertEqual(Http(self.port).get("/api/recv/desks")[1]["desks"], [])
        for bad, err in (({"op": "add", "branch": "zz", "pin": "445566"}, "bad_branch"), ({"op": "add", "branch": "b1", "pin": "12"}, "bad_pin")):
            self.assertEqual(a.post("/api/admin/desk", bad)[1]["error"], err)
        self.assertEqual(a.post("/api/admin/desk", {"op": "add", "branch": "b1", "pin": "445566"})[0], 200)
        self.assertEqual(a.post("/api/admin/desk", {"op": "add", "branch": "b1", "pin": "445566"})[1]["error"], "exists")
        self.assertEqual(Http(self.port).get("/api/recv/desks")[1]["desks"], ["b1"])
        self.assertEqual(a.get("/api/admin/state")[1]["desks"], [{"branch": "b1", "active": True}])
        o1 = self.place(c, branch="b1")
        o2 = self.place(c, branch="b2")
        h = Http(self.port)
        self.assertEqual(h.post("/api/recv/login", {"pin": "445566"})[0], 401)                        # not the desk of every branch
        self.assertEqual(h.post("/api/recv/login", {"pin": "445566", "branch": "b2"})[0], 401)        # nor another branch's
        self.app.limit.fails.clear()
        st, j, _ = h.post("/api/recv/login", {"pin": "445566", "branch": "b1"})
        self.assertEqual((st, j["me"]["branch"]), (200, "b1"))
        ids = {o["id"] for o in h.get("/api/recv/state")[1]["orders"]}
        self.assertIn(o1["id"], ids)
        self.assertNotIn(o2["id"], ids)
        self.assertEqual(h.post("/api/recv/order", {"id": o2["id"], "op": "accept"})[1]["error"], "not_found")
        self.assertEqual(h.post("/api/recv/order", {"id": o1["id"], "op": "accept"})[0], 200)
        self.assertEqual(h.post("/api/recv/branch", {"id": "b2", "pause": True})[1]["error"], "not_yours")
        self.assertEqual(h.post("/api/recv/branch", {"id": "b1", "pause": True})[0], 200)
        h.post("/api/recv/branch", {"id": "b1", "pause": False})
        # the desk of every branch still sees everything
        everyone = {o["id"] for o in self.staff("recv").get("/api/recv/state")[1]["orders"]}
        self.assertTrue({o1["id"], o2["id"]} <= everyone)
        # a new PIN signs the desk out; switched off it cannot sign in; removed it is gone
        self.assertEqual(a.post("/api/admin/desk", {"op": "pin", "branch": "b1", "pin": "778899"})[0], 200)
        self.assertEqual(h.get("/api/recv/state")[0], 401)
        self.assertEqual(Http(self.port).post("/api/recv/login", {"pin": "778899", "branch": "b1"})[0], 200)
        a.post("/api/admin/desk", {"op": "on", "branch": "b1", "on": False})
        self.assertEqual(Http(self.port).post("/api/recv/login", {"pin": "778899", "branch": "b1"})[0], 401)
        self.assertEqual(Http(self.port).get("/api/recv/desks")[1]["desks"], [])
        self.app.limit.fails.clear()
        self.assertEqual(a.post("/api/admin/desk", {"op": "del", "branch": "b1"})[0], 200)
        self.assertEqual(a.get("/api/admin/state")[1]["desks"], [])

    def test_the_smallest_delivery_and_how_far_the_drivers_go(self):
        a, c = self.staff("admin"), self.customer()
        addr = {"city": "المدينة", "street": "شارع قباء"}
        for bad in ({"delivery_km": -1}, {"delivery_km": 101}, {"delivery_min": 1001}, {"delivery_km": True}):
            self.assertEqual(a.post("/api/admin/fees", bad)[0], 400)
        self.assertEqual(a.post("/api/admin/fees", {"delivery_min": 60, "delivery_km": 5})[0], 200)
        self.assertEqual(Http(self.port).get("/api/public")[1]["delivery"], {"on": True, "fee": 12, "km": 5, "min": 60})
        one = [{"pid": "latte", "sel": {}, "qty": 1}]   # 17 riyals
        st, j, _ = c.post("/api/orders", self.order_body(mode="delivery", addr=addr, items=one))
        self.assertEqual((st, j["error"], j["min"]), (409, "below_min", 60))
        four = [{"pid": "latte", "sel": {}, "qty": 4}]
        # the sample branch b1 has no place on the map yet: no distance can be checked
        self.assertEqual(c.post("/api/orders", self.order_body(mode="delivery", addr=addr, items=four))[0], 200)
        a.post("/api/admin/branches", {"op": "save", "id": "b1", "b": {"ar": "فرع الخزامى", "addr": {"ar": "حي الخزامى"}, "all_day": True, "lat": 24.4672, "lng": 39.6024}})
        self.assertEqual(c.post("/api/orders", self.order_body(mode="delivery", addr=addr, items=four))[1]["error"], "need_pin")
        near = dict(addr, lat=24.48, lng=39.61)    # about 1.6 km
        far = dict(addr, lat=24.55, lng=39.70)     # about 13 km
        self.assertEqual(c.post("/api/orders", self.order_body(mode="delivery", addr=near, items=four))[0], 200)
        st, j, _ = c.post("/api/orders", self.order_body(mode="delivery", addr=far, items=four))
        self.assertEqual((st, j["error"], j["km"]), (409, "too_far", 5))
        self.assertGreater(j["d"], 12)
        self.assertEqual(self.place(c, items=one)["mode"], "pickup")   # a pickup has no smallest order
        a.post("/api/admin/fees", {"delivery_min": 0, "delivery_km": 0})
        a.post("/api/admin/branches", {"op": "save", "id": "b1", "b": {"ar": "فرع الخزامى", "addr": {"ar": "حي الخزامى"}, "all_day": True}})

    def test_a_product_a_branch_does_not_make(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        self.assertEqual(a.post("/api/admin/product", {"op": "here", "id": "latte", "branch": "b2", "on": False})[0], 200)
        self.assertEqual(next(p for p in Http(self.port).get("/api/catalog")[1]["products"] if p["id"] == "latte")["off"], ["b2"])
        st, j, _ = c.post("/api/orders", self.order_body(branch="b2"))
        self.assertEqual((st, j["error"], j["pid"]), (409, "not_here", "latte"))
        self.assertEqual(c.post("/api/orders", self.order_body(branch="b1"))[0], 200)
        # a branch desk switches its own branch only; the desk of every branch any branch
        a.post("/api/admin/desk", {"op": "add", "branch": "b2", "pin": "121212"})
        d = Http(self.port)
        d.post("/api/recv/login", {"pin": "121212", "branch": "b2"})
        self.assertEqual(d.post("/api/recv/here", {"id": "latte", "branch": "b1", "on": False})[1]["error"], "not_yours")
        self.assertEqual(d.post("/api/recv/here", {"id": "latte", "branch": "b2", "on": True})[1]["product"]["off"], None)
        self.assertEqual(c.post("/api/orders", self.order_body(branch="b2"))[0], 200)
        self.assertEqual(r.post("/api/recv/here", {"id": "latte", "branch": "b3", "on": False})[1]["product"]["off"], ["b3"])
        self.assertEqual(r.post("/api/recv/here", {"id": "latte", "branch": "b3", "on": True})[1]["product"]["off"], None)
        a.post("/api/admin/desk", {"op": "del", "branch": "b2"})
        # the product form sends the list too
        body = {"ar": "قهوة الفرع", "price": 9, "cats": ["hot"], "off": ["b1", "b1", "b3"]}
        st, j, _ = a.post("/api/admin/product", {"op": "save", "p": body})
        self.assertEqual((st, j["product"]["off"]), (200, ["b1", "b3"]))
        self.assertEqual(a.post("/api/admin/product", {"op": "save", "p": dict(body, off=["zz"])})[1]["error"], "bad_branch")
        self.assertEqual(a.post("/api/admin/product", {"op": "save", "id": j["id"], "p": dict(body, off=[])})[1]["product"]["off"], None)
        a.post("/api/admin/product", {"op": "delete", "id": j["id"]})


class TestTaxInvoiceAndCopy(Base):
    """0.7: the simplified tax invoice once the VAT number is entered; a copy of the database for the admin."""

    def test_the_invoice_comes_with_the_vat_number(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        self.assertIsNone(a.get("/api/admin/state")[1]["tax"])
        self.assertNotIn("inv", self.place(c))   # no number yet: no invoice
        for bad, err in (({"vat": "300000000000003", "name": "و"}, "bad_name"), ({"vat": "123456789012345", "name": "مؤسسة واي"}, "bad_vat"),
                         ({"vat": "30000000000000", "name": "مؤسسة واي"}, "bad_vat"), ({"vat": "300000000000003", "name": "مؤسسة واي", "cr": "12"}, "bad_cr")):
            self.assertEqual(a.post("/api/admin/tax", bad)[1]["error"], err)
        self.assertEqual(a.post("/api/admin/tax", {"vat": "310122393500003", "name": "مؤسسة واي للتحميص", "cr": "4650012345", "addr": "المدينة المنورة"})[0], 200)
        self.assertEqual(a.get("/api/admin/state")[1]["tax"], {"name": "مؤسسة واي للتحميص", "vat": "310122393500003", "cr": "4650012345", "addr": "المدينة المنورة"})
        o = self.place(c)
        inv = o["inv"]
        self.assertEqual((inv["name"], inv["vat"], inv["cr"]), ("مؤسسة واي للتحميص", "310122393500003", "4650012345"))
        raw = base64.b64decode(inv["qr"])
        tags, i = {}, 0
        while i < len(raw):
            t, n = raw[i], raw[i + 1]
            tags[t] = raw[i + 2:i + 2 + n].decode("utf-8")
            i += 2 + n
        self.assertEqual(tags[1], "مؤسسة واي للتحميص")
        self.assertEqual(tags[2], "310122393500003")
        self.assertRegex(tags[3], r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
        self.assertEqual(float(tags[4]), o["total"])
        self.assertEqual(float(tags[5]), o["vat"])
        self.assertEqual(next(x for x in r.get("/api/recv/state")[1]["orders"] if x["id"] == o["id"])["inv"]["qr"], inv["qr"])   # the desk prints it
        # switched off: new orders have none, the ones made meanwhile keep theirs
        self.assertEqual(a.post("/api/admin/tax", {"vat": ""})[0], 200)
        self.assertNotIn("inv", self.place(c))
        self.assertEqual(json.loads(self.app.db.one("SELECT data FROM orders WHERE id=?", (o["id"],))["data"])["inv"]["vat"], "310122393500003")

    def test_a_copy_of_the_database_for_the_admin(self):
        a = self.staff("admin")
        self.assertEqual(a.post("/api/admin/dbcopy", {"pin": "000000"})[1]["error"], "bad_pin_confirm")
        self.app.limit.fails.clear()
        st, data, h = a.post_bytes("/api/admin/dbcopy", {"pin": PINS["admin"]})
        self.assertEqual(st, 200)
        self.assertRegex(h["Content-Disposition"], r'attachment; filename="why-backup-\d{4}-\d{2}-\d{2}\.zip"')
        self.assertEqual(h["Content-Type"], "application/zip")
        z = zipfile.ZipFile(io.BytesIO(data))   # a zip, so a phone keeps it as a file (0.7.1)
        self.assertEqual(sorted(z.namelist()), ["README.txt", "why.db"])
        self.assertIn("للاسترجاع", z.read("README.txt").decode("utf-8"))
        db = z.read("why.db")
        self.assertTrue(db.startswith(b"SQLite format 3\x00"))
        path = os.path.join(self.tmp.name, "copy.db")
        with open(path, "wb") as f:
            f.write(db)
        cx = sqlite3.connect(path)
        self.assertGreater(cx.execute("SELECT COUNT(*) FROM products").fetchone()[0], 10)
        cx.close()
        self.assertEqual(list(Path(self.tmp.name).glob("download-*")), [])   # nothing left behind
        self.assertEqual(Http(self.port).post("/api/admin/dbcopy", {"pin": PINS["admin"]})[0], 401)
        self.assertEqual(self.staff("recv").post("/api/recv/dbcopy", {"pin": PINS["admin"]})[0], 404)
        self.assertIn("backups", a.get("/api/admin/state")[1])


class PretendPush:
    """A push service on this machine: it keeps what it was sent and answers with the status asked for."""

    def __init__(self):
        got, status = [], {}

        class H(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                got.append((self.path, dict(self.headers), self.rfile.read(n)))
                self.send_response(status.get(self.path, 201))
                self.send_header("Content-Length", "0")
                self.end_headers()

            def log_message(self, *a):
                pass

        self.got, self.status = got, status
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]

    def url(self, name):
        return self.base + "/push/" + name

    def wait(self, name, n=1, secs=5):
        t = time.time() + secs
        while time.time() < t:
            if sum(1 for g in self.got if g[0] == "/push/" + name) >= n:
                return True
            time.sleep(0.05)
        return False

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


class TestPush(Base):
    """0.7: notifications on the phone, even with the page closed (Web Push: the push carries nothing, the page asks)."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.ps = PretendPush()

    @classmethod
    def tearDownClass(cls):
        cls.ps.close()
        super().tearDownClass()

    def test_the_signature_is_real_ecdsa_p256(self):
        try:
            from cryptography.hazmat.primitives.asymmetric import ec, utils
            from cryptography.hazmat.primitives import hashes
        except ImportError:
            self.skipTest("cryptography is not here to check against")
        for _ in range(5):
            d = secrets.randbelow(W.P256_N - 1) + 1
            key = ec.derive_private_key(d, ec.SECP256R1())
            pub = key.public_key().public_numbers()
            self.assertEqual(W.ec_mul(d), (pub.x, pub.y))
            msg = secrets.token_bytes(40)
            sig = W.es256_sign(d, msg)
            key.public_key().verify(utils.encode_dss_signature(int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big")), msg, ec.ECDSA(hashes.SHA256()))

    def jwt_ok(self, auth):
        try:
            from cryptography.hazmat.primitives.asymmetric import ec, utils
            from cryptography.hazmat.primitives import hashes
        except ImportError:   # the claims are still checked; the signature where the package is installed
            ec = None
        m = re.fullmatch(r"vapid t=([\w-]+)\.([\w-]+)\.([\w-]+), k=([\w-]+)", auth)
        self.assertTrue(m, auth)
        unb = lambda x: base64.urlsafe_b64decode(x + "=" * (-len(x) % 4))
        claims = json.loads(unb(m.group(2)))
        self.assertEqual(claims["aud"], self.ps.base)
        self.assertGreater(claims["exp"], time.time() + 3600)
        self.assertLessEqual(claims["exp"], time.time() + 24 * 3600)
        self.assertTrue(claims["sub"].startswith(("https://", "mailto:")))
        self.assertEqual(m.group(4), self.app.vapid_pub)
        if ec is None:
            return
        pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), unb(m.group(4)))
        sig = unb(m.group(3))
        pub.verify(utils.encode_dss_signature(int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big")), (m.group(1) + "." + m.group(2)).encode(), ec.ECDSA(hashes.SHA256()))

    def inbox(self, url):
        return Http(self.port).post("/api/push/inbox", {"endpoint": url})[1]["items"]

    def test_who_hears_what(self):
        key = Http(self.port).get("/api/push/key")[1]["key"]
        self.assertEqual(len(base64.urlsafe_b64decode(key + "=")), 65)
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        ph = "5" + "".join(secrets.choice("0123456789") for _ in range(8))
        c.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST, "signup": True, "name": "نوف"})
        self.assertEqual(c.post("/api/my/push", {"endpoint": "https://evil.example.com/push"})[1]["error"], "bad_push")
        self.assertEqual(self.customer().post("/api/my/push", {"endpoint": self.ps.url("x")})[1]["error"], "bad_customer")   # nobody signed in
        self.assertEqual(c.post("/api/my/push", {"endpoint": self.ps.url("c1"), "lang": "ar"})[0], 200)
        self.assertEqual(r.post("/api/recv/push", {"endpoint": self.ps.url("d1")})[0], 200)
        a.post("/api/admin/desk", {"op": "add", "branch": "b2", "pin": "343434"})
        d2 = Http(self.port)
        d2.post("/api/recv/login", {"pin": "343434", "branch": "b2"})
        d2.post("/api/recv/push", {"endpoint": self.ps.url("d2"), "lang": "en"})
        a.post("/api/admin/driver", {"op": "add", "name": "فيصل", "pin": "565657"})
        v = self.staff("driver", "فيصل", "565657")
        v.post("/api/driver/push", {"endpoint": self.ps.url("v1")})
        cu = {"name": "نوف", "phone": ph}
        # a new order at b1: the desk of every branch hears it, the desk of b2 does not
        o = self.place(c, cust=cu, branch="b1")
        self.assertTrue(self.ps.wait("d1"))
        self.jwt_ok(next(g for g in self.ps.got if g[0] == "/push/d1")[1]["Authorization"])
        self.assertEqual(next(g for g in self.ps.got if g[0] == "/push/d1")[2], b"")   # nothing in the push itself
        it = self.inbox(self.ps.url("d1"))
        self.assertEqual((it[0]["t"], it[0]["url"], it[0]["tag"]), ("طلب جديد %s" % o["no"].replace("\u200e", ""), "/reception/", "o-" + o["id"]))
        self.assertIn("ر.س", it[0]["b"])
        self.assertEqual(self.inbox(self.ps.url("d1"))[0]["tag"], "o-" + o["id"])   # asked again: the last one, for the same tag
        self.assertFalse(self.ps.wait("d2", secs=0.6))
        o2 = self.place(c, cust=cu, branch="b2")
        self.assertTrue(self.ps.wait("d2"))
        self.assertEqual(self.inbox(self.ps.url("d2"))[0]["t"], "New order %s" % o2["no"].replace("\u200e", ""))   # in his language
        # the desk accepts: the customer hears it
        r.post("/api/recv/order", {"id": o["id"], "op": "accept"})
        self.assertTrue(self.ps.wait("c1"))
        it = self.inbox(self.ps.url("c1"))
        self.assertIn("قيد التحضير", it[0]["t"])
        self.assertEqual(it[0]["url"], "/#o=" + o["id"])   # a tap opens this order
        r.post("/api/recv/order", {"id": o["id"], "op": "ready"})
        self.assertTrue(self.ps.wait("c1", 2))
        self.assertIn("جاهز للاستلام", self.inbox(self.ps.url("c1"))[0]["t"])
        # a delivery accepted: the drivers hear it
        od = self.place(c, cust=cu, mode="delivery", addr={"city": "المدينة", "street": "شارع قباء"})
        r.post("/api/recv/order", {"id": od["id"], "op": "accept"})
        self.assertTrue(self.ps.wait("v1"))
        self.assertEqual(self.inbox(self.ps.url("v1"))[0]["url"], "/driver/")
        # a gift and bonus points reach the customer
        g = self.customer()
        g.post("/api/my/login", {"phone": "5" + "".join(secrets.choice("0123456789") for _ in range(8)), "code": W.OTP_TEST, "signup": True, "name": "هيا"})
        g.post("/api/my/gift", {"op": "send", "to": ph, "kind": "card", "amt": 20})
        self.assertTrue(self.ps.wait("c1", 4))   # the delivery being prepared, then the gift
        self.assertEqual([(x["t"], x["url"]) for x in self.inbox(self.ps.url("c1"))],
                         [("طلبك %s قيد التحضير" % od["no"].replace("\u200e", ""), "/#o=" + od["id"]), ("وصلتك هدية من هيا", "/#g=recv.card")])
        # the driver takes it and says he is at the door: the customer hears it, and a tap opens the order
        v.post("/api/driver/order", {"id": od["id"], "op": "take"})
        r.post("/api/recv/order", {"id": od["id"], "op": "ready"})
        self.assertEqual(v.post("/api/driver/order", {"id": od["id"], "op": "arrive"})[0], 200)
        t = time.time() + 3
        while time.time() < t and not any("المندوب وصل" in x["t"] for x in self.inbox(self.ps.url("c1"))):
            time.sleep(0.05)
        hit = [x for x in self.inbox(self.ps.url("c1")) if "المندوب وصل" in x["t"]]
        self.assertTrue(hit)
        self.assertEqual(hit[0]["url"], "/#o=" + od["id"])
        # the push service says the phone is gone: the subscription goes
        self.ps.status["/push/c1"] = 410
        cid = next(x for x in a.get("/api/admin/state")[1]["cust"] if x["tail"] == ph[-4:])["id"]
        a.post("/api/admin/points", {"id": cid, "pts": 10})
        self.assertTrue(self.ps.wait("c1", 5))
        t = time.time() + 3
        while time.time() < t and self.app.db.one("SELECT 1 FROM push WHERE ep=?", (W.sha(self.ps.url("c1")),)):
            time.sleep(0.05)
        self.assertIsNone(self.app.db.one("SELECT 1 FROM push WHERE ep=?", (W.sha(self.ps.url("c1")),)))
        # switching off on the phone
        self.assertEqual(Http(self.port).post("/api/push/off", {"endpoint": self.ps.url("v1")})[0], 200)
        self.assertIsNone(self.app.db.one("SELECT 1 FROM push WHERE ep=?", (W.sha(self.ps.url("v1")),)))
        a.post("/api/admin/desk", {"op": "del", "branch": "b2"})


class TestDriverAtTheDoor(Base):
    """0.7.5: the driver says he is at the door, and the customer can call him while his order is on its way."""

    def mine(self, c, oid):
        return next(x for x in c.post("/api/my/sync", {})[1]["orders"] if x["id"] == oid)

    def test_arrive_and_the_drivers_number(self):
        a, r, c = self.staff("admin"), self.staff("recv"), self.customer()
        self.assertEqual(a.post("/api/admin/driver", {"op": "add", "name": "هاني", "pin": "818181", "phone": "12345"})[1]["error"], "bad_phone")
        self.assertEqual(a.post("/api/admin/driver", {"op": "add", "name": "هاني", "pin": "818181", "phone": "+966 55 123 4567"})[0], 200)
        hani = next(x for x in a.get("/api/admin/state")[1]["drivers"] if x["name"] == "هاني")
        self.assertEqual(hani["phone"], "551234567")
        a.post("/api/admin/driver", {"op": "add", "name": "سعد", "pin": "828282"})
        d, s = self.staff("driver", "هاني", "818181"), self.staff("driver", "سعد", "828282")
        o = self.place(c, mode="delivery", addr={"city": "المدينة", "street": "قباء", "lat": 24.48, "lng": 39.61})
        r.post("/api/recv/order", {"id": o["id"], "op": "accept"})
        d.post("/api/driver/order", {"id": o["id"], "op": "take"})
        self.assertEqual(d.post("/api/driver/order", {"id": o["id"], "op": "arrive"})[1]["error"], "bad_state")   # not on its way yet
        self.assertIsNone(self.mine(c, o["id"])["dphone"])                 # being prepared: no number yet
        r.post("/api/recv/order", {"id": o["id"], "op": "ready"})
        m = self.mine(c, o["id"])
        self.assertEqual((m["driver"], m["dphone"], m["arr"]), ("هاني", "551234567", None))
        self.assertEqual(s.post("/api/driver/order", {"id": o["id"], "op": "arrive"})[0], 409)   # not his order
        st, j, _ = d.post("/api/driver/order", {"id": o["id"], "op": "arrive"})
        self.assertEqual(st, 200)
        t1 = j["order"]["arr"]
        self.assertTrue(t1)
        self.assertEqual(self.mine(c, o["id"])["arr"], t1)                  # the customer's phone hears it
        self.assertEqual(d.post("/api/driver/order", {"id": o["id"], "op": "arrive"})[1]["order"]["arr"], t1)   # again at once: nothing new
        with self.app.db.tx() as x:                                          # ... a minute later
            od = json.loads(x.execute("SELECT data FROM orders WHERE id=?", (o["id"],)).fetchone()["data"])
            od["arr"] -= 61_000
            x.execute("UPDATE orders SET data=? WHERE id=?", (json.dumps(od, ensure_ascii=False), o["id"]))
        self.assertGreater(d.post("/api/driver/order", {"id": o["id"], "op": "arrive"})[1]["order"]["arr"], t1 - 61_000)
        # the driver gives his number himself: the order he carries shows the new one at once
        self.assertEqual(d.post("/api/driver/phone", {"phone": "0509"})[1]["error"], "bad_phone")
        self.assertEqual(d.post("/api/driver/phone", {"phone": "0560000001"})[1]["phone"], "560000001")
        self.assertEqual(self.mine(c, o["id"])["dphone"], "560000001")
        self.assertEqual(d.get("/api/driver/state")[1]["me"]["phone"], "560000001")
        # delivered: the number is no longer shown to the customer
        d.post("/api/driver/order", {"id": o["id"], "op": "deliver", "code": o["code"]})
        self.assertEqual(self.mine(c, o["id"])["fin"], True)
        self.assertIsNone(self.mine(c, o["id"])["dphone"])
        # the admin removes it
        self.assertEqual(a.post("/api/admin/driver", {"op": "phone", "id": hani["id"], "phone": ""})[1]["phone"], "")
        self.assertEqual(next(x for x in a.get("/api/admin/state")[1]["drivers"] if x["name"] == "هاني")["phone"], "")


class TestRoute(Base):
    """0.7.1: the customer's delivery map shows the way to the door and how long it takes."""

    def road_server(self, fail=False):
        got = []

        class H(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                got.append((self.headers.get("Authorization"), json.loads(self.rfile.read(int(self.headers["Content-Length"])))))
                if fail:                                  # what a wrong key or a used-up day gets
                    self.send_response(403)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                b = json.dumps({"features": [{"geometry": {"coordinates": [[39.60, 24.47], [39.605, 24.472], [39.61, 24.48]]},
                                              "properties": {"summary": {"distance": 3240.0, "duration": 515.0}}}]}).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def log_message(self, *a):
                pass

        srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.app.route_url = "http://127.0.0.1:%d/route" % srv.server_address[1]

        def stop():
            srv.shutdown()
            srv.server_close()
            with self.app.db.tx() as x:
                self.app._set_kv(x, "route_key", "")
        self.addCleanup(stop)
        return got

    def on_its_way(self):
        r, c, a = self.staff("recv"), self.customer(), self.staff("admin")
        a.post("/api/admin/driver", {"op": "add", "name": "ماجد", "pin": "787878"})
        d = self.staff("driver", "ماجد", "787878")
        o = self.place(c, mode="delivery", addr={"city": "المدينة", "street": "قباء", "lat": 24.48, "lng": 39.61})
        r.post("/api/recv/order", {"id": o["id"], "op": "accept"})
        d.post("/api/driver/order", {"id": o["id"], "op": "take"})
        r.post("/api/recv/order", {"id": o["id"], "op": "ready"})
        d.post("/api/driver/loc", {"lat": 24.47, "lng": 39.60, "acc": 10})
        return c, d, o["id"]

    def way(self, c, oid):
        return c.post("/api/my/sync", {})[1]["track"][oid]["way"]

    def settle(self, oid):
        t = time.time() + 3
        while time.time() < t and oid in self.app.route_busy:
            time.sleep(0.02)

    def test_estimate_then_the_road(self):
        got = self.road_server()
        c, d, oid = self.on_its_way()
        way = self.way(c, oid)
        self.assertTrue(way["est"])                       # no key yet: an estimate, no road call
        self.assertGreater(way["min"], 0)
        self.assertEqual(got, [])
        with self.app.db.tx() as x:
            self.app._set_kv(x, "route_key", "k" * 30)
        self.way(c, oid)
        self.settle(oid)
        way = self.way(c, oid)
        self.assertEqual((way["km"], way["min"], way["pts"][0], way["pts"][-1], "est" in way), (3.2, 9, [24.47, 39.6], [24.48, 39.61], False))
        self.assertEqual(got[0][0], "k" * 30)              # the key goes in the header, not in the address
        self.assertEqual(got[0][1]["coordinates"], [[39.6, 24.47], [39.61, 24.48]])
        self.way(c, oid)
        self.assertEqual(len(got), 1)                      # the driver did not move: no new call
        # he drives along the road: the line starts where he is, the time and distance shrink, and nothing is asked again
        d.post("/api/driver/loc", {"lat": 24.472, "lng": 39.605, "acc": 10})
        way = self.way(c, oid)
        self.assertEqual((way["pts"], "est" in way), ([[24.472, 39.605], [24.48, 39.61]], False))
        self.assertTrue(1.5 < way["km"] < 3.2 and 4 <= way["min"] < 9, way)
        self.settle(oid)
        self.assertEqual(len(got), 1)
        # he turns off the road: a new road is asked for, but not twice within 20 seconds
        d.post("/api/driver/loc", {"lat": 24.476, "lng": 39.598, "acc": 10})
        self.way(c, oid)
        self.settle(oid)
        self.assertEqual(len(got), 1)                      # the last ask was a moment ago
        self.app.route_next[oid] = 0                       # ... 20 seconds later
        self.way(c, oid)
        self.settle(oid)
        self.assertEqual(len(got), 2)
        self.assertEqual(got[1][1]["coordinates"], [[39.598, 24.476], [39.61, 24.48]])

    def test_the_address_is_the_new_one(self):
        # openrouteservice moved to api.heigit.org; the old api.openrouteservice.org was switched off in November 2026
        self.assertEqual(W.ROUTE_URL, "https://api.heigit.org/openrouteservice/v2/directions/driving-car/geojson")

    def test_a_failed_ask_is_not_repeated_with_every_sync(self):
        got = self.road_server(fail=True)
        c, d, oid = self.on_its_way()
        with self.app.db.tx() as x:
            self.app._set_kv(x, "route_key", "k" * 30)
        for _ in range(4):
            way = self.way(c, oid)
            self.settle(oid)
        self.assertTrue(way["est"])                        # the customer still sees how long, as an estimate
        self.assertEqual(len(got), 1)
        self.assertGreater(self.app.route_next[oid], W.now_ms() + 60_000)   # it waits two minutes
        self.app.route_next[oid] = 0                       # ... two minutes later
        self.way(c, oid)
        self.settle(oid)
        self.assertEqual(len(got), 2)


class TestCatalogSeedAndMigration(unittest.TestCase):
    def open(self, db, catalog=None):
        return W.App(db, catalog, iters=1000, backups=False, quiet=True)

    def test_a_database_from_0_3_keeps_its_price_and_availability_changes(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "why.db")
            con = sqlite3.connect(db)   # what 0.3 left: the changes are overrides in the settings, an order without item names
            con.execute("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
            settings = {"menu": {"latte": {"price": 22}, "cookie": {"stock": False}, "pineapple": {"stock": True}}, "br": {}, "bn": {}, "codes": {"WHY10": {"on": True, "pct": 10}}, "ship": 25, "delivery": {"on": True, "fee": 12}}
            con.executemany("INSERT INTO kv VALUES(?,?)", [("settings", json.dumps(settings)), ("rev", "40"), ("srev", "7"), ("seq", "1001")])
            con.commit()
            con.close()
            app = self.open(db)
            P = app.catalog.P
            self.assertEqual((P["latte"]["price"], P["cookie"]["stock"], P["pineapple"]["stock"], P["cap"]["price"]), (22, False, True, 16))
            self.assertEqual(app.settings["menu"], {}, "the overrides were taken into the menu")
            self.assertEqual(app.compat_menu(), {"latte": {"price": 22}, "cookie": {"stock": False}, "pineapple": {"stock": True}})
            self.assertEqual(len(app.catalog.live_prods()), len(app.seed_ref))
            self.assertEqual([b["id"] for b in app.catalog.live_branches()], ["b1", "b2", "b3"], "the branches came along too")
            o = app.create_order("ab" * 16, "1.2.3.4", {"mode": "pickup", "branch": "b1", "items": [{"pid": "latte", "qty": 1}], "cust": {"name": "ريم", "phone": "501234567"}})
            self.assertEqual(o["items"][0]["unit"], 22)
            # an order saved by 0.3 (its items have no names) still shows on the café side
            with app.db.tx() as c:
                old = dict(o, id="old1", no="#1000", items=[{"pid": "cap", "sel": {}, "qty": 1, "unit": 16, "rw": None, "gift": None}])
                c.execute("INSERT INTO orders(id,seq,ts,day,mode,branch,st,rej,fin,total,dev_hash,cid,cust_id,driver_id,rev,data) VALUES('old1',999,?,?,'pickup','b1',0,0,0,16,'x',NULL,NULL,NULL,1,?)", (o["ts"], o["day"], json.dumps(old)))
            st = app.state({"id": 1, "role": "admin", "name": "admin"}, -1)
            self.assertIn("old1", [x["id"] for x in st["orders"]])
            self.assertIn("cap", st["cat"] and [p["id"] for p in st["cat"]["products"]])
            app.admin_product({"op": "save", "id": "latte", "p": {"ar": "لاتيه", "en": "Latte", "price": 30, "cats": ["hot"], "opts": ["size", "milk", "extras"]}})
            app.close()
            app2 = self.open(db)   # started again: the menu is not copied from the seed a second time
            self.assertEqual(app2.catalog.P["latte"]["price"], 30)
            self.assertEqual(app2.compat_menu()["latte"], {"price": 30})
            app2.close()

    def test_settings_from_before_0_5_1_get_the_default_tiers(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "why.db")
            app = self.open(db)
            s = dict(app.settings)
            s.pop("tiers")
            with app.db.tx() as c:
                c.execute("UPDATE kv SET v=? WHERE k='settings'", (json.dumps(s),))
            app.close()
            app = self.open(db)
            self.assertEqual(app.settings["tiers"], W.DEFAULT_TIERS)
            with app.db.tx() as c:
                c.execute("UPDATE kv SET v=? WHERE k='settings'", (json.dumps(dict(s, tiers=[{"id": "gold"}])),))
            app.close()
            app = self.open(db)
            self.assertEqual(app.settings["tiers"], W.DEFAULT_TIERS, "a damaged value falls back to the start values")
            self.assertEqual(app.settings["codes"], s["codes"], "the other settings stay")
            app.close()

    def test_a_database_from_0_4_0_gets_its_branches(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "why.db")
            app = self.open(db)
            with app.db.tx() as c:   # 0.4.0: the menu in the database, the branches not yet
                c.execute("DELETE FROM branches")
                c.execute("DELETE FROM kv WHERE k='branches'")
                c.execute("UPDATE products SET data=json_set(data, '$.price', 33) WHERE id='latte'")
            crev = app.catalog.crev
            app.close()
            app = self.open(db)
            self.assertEqual([b["id"] for b in app.catalog.live_branches()], ["b1", "b2", "b3"])
            self.assertEqual(app.catalog.P["latte"]["price"], 33, "the menu is not copied again")
            self.assertGreater(app.catalog.crev, crev, "the pages are told the menu changed")
            app.close()

    def test_the_last_category_stays(self):
        with tempfile.TemporaryDirectory() as d:
            cat = json.loads((HERE / "catalog.json").read_text(encoding="utf-8"))
            cat["seed"] = {"cats": cat["seed"]["cats"][:1], "products": [p for p in cat["seed"]["products"] if p["cats"] == ["hot"]][:2], "images": {}}
            path = os.path.join(d, "catalog.json")
            Path(path).write_text(json.dumps(cat, ensure_ascii=False), encoding="utf-8")
            app = self.open(os.path.join(d, "why.db"), path)
            self.assertEqual([c["id"] for c in app.catalog.live_cats()], ["hot"])
            for p in app.catalog.live_prods():
                app.admin_product({"op": "delete", "id": p["id"]})
            with self.assertRaises(W.ApiError) as e:
                app.admin_cat({"op": "delete", "id": "hot"})
            self.assertEqual(e.exception.code, "last_cat")
            app.close()

    def test_the_last_branch_stays(self):
        with tempfile.TemporaryDirectory() as d:
            cat = json.loads((HERE / "catalog.json").read_text(encoding="utf-8"))
            cat["seed"]["branches"] = cat["seed"]["branches"][:1]
            path = os.path.join(d, "catalog.json")
            Path(path).write_text(json.dumps(cat, ensure_ascii=False), encoding="utf-8")
            app = self.open(os.path.join(d, "why.db"), path)
            with self.assertRaises(W.ApiError) as e:
                app.admin_branch({"op": "delete", "id": "b1"})
            self.assertEqual(e.exception.code, "last_branch")
            app.close()


class TestPersistence(unittest.TestCase):
    def test_restart_keeps_everything(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "why.db")
            app = W.App(db, iters=1000, backups=False, quiet=True)
            app.set_staff("admin", "admin", "482916")
            srv = W.make_server(app, "127.0.0.1", 0)
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            port = srv.server_address[1]
            c = Http(port, dev=secrets.token_hex(16))
            o = c.post("/api/orders", {"cid": "a1", "mode": "pickup", "branch": "b1", "items": [{"pid": "latte", "qty": 1}], "cust": {"name": "ريم", "phone": "501234567"}})[1]["order"]
            a = Http(port)
            a.post("/api/admin/login", {"pin": "482916"})
            a.post("/api/admin/menu", {"id": "latte", "price": 22})
            rev1 = app.rev
            srv.shutdown()
            srv.server_close()
            app.close()
            app2 = W.App(db, iters=1000, backups=False, quiet=True)
            self.assertGreater(app2.rev, rev1)
            srv2 = W.make_server(app2, "127.0.0.1", 0)
            threading.Thread(target=srv2.serve_forever, daemon=True).start()
            port2 = srv2.server_address[1]
            c2, a2 = Http(port2, dev=c.dev), Http(port2)
            self.assertEqual(c2.get("/api/public")[1]["menu"]["latte"], {"price": 22})
            self.assertEqual(c2.post("/api/my/sync", {"since": 0})[1]["orders"][0]["id"], o["id"])
            self.assertEqual(a2.get("/api/admin/state")[0], 401 if not a2.cookies else 200)
            a2.post("/api/admin/login", {"pin": "482916"})  # the PIN survived
            nxt = c2.post("/api/orders", {"cid": "a2", "mode": "pickup", "branch": "b1", "items": [{"pid": "latte", "qty": 1}], "cust": {"name": "ريم", "phone": "501234567"}})[1]["order"]
            self.assertEqual(nxt["no"], "‎#1002")
            self.assertEqual(nxt["items"][0]["unit"], 22)
            srv2.shutdown()
            srv2.server_close()
            app2.close()

    def test_backup_file_is_a_working_database(self):
        with tempfile.TemporaryDirectory() as d:
            app = W.App(os.path.join(d, "why.db"), iters=1000, backups=False, keep_backups=2, quiet=True)
            app.set_staff("admin", "admin", "482916")
            f = app.backup()
            self.assertTrue(f.exists())
            self.assertIsNone(app.backup())  # one per day
            import sqlite3
            con = sqlite3.connect(str(f))
            self.assertEqual(con.execute("SELECT role FROM staff").fetchone()[0], "admin")
            con.close()
            self.assertEqual(oct(f.stat().st_mode & 0o777), "0o600")
            app.close()


class TestCli(unittest.TestCase):
    def test_setpin_from_stdin_then_check(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "why.db")
            env = dict(os.environ, WHY_PBKDF2_ITERS="1000")
            run = lambda *a, **k: subprocess.run([sys.executable, "-I", str(HERE / "why_server.py"), *a], capture_output=True, text=True, env=env, **k)
            r = run("setpin", "--role", "admin", "--db", db, "--pin-stdin", input="12345\n")
            self.assertNotEqual(r.returncode, 0)
            r = run("setpin", "--role", "admin", "--db", db, "--pin-stdin", input="482916\n")
            self.assertEqual(r.returncode, 0, r.stderr)
            r = run("setpin", "--role", "recv", "--db", db, "--pin-stdin", input="735019\n")
            out = run("check", "--db", db).stdout
            self.assertIn("staff: admin admin active", out)
            self.assertRegex(out, r"products: \d+  deleted: 0  categories: \d+  photos: 2  branches: 3")
            self.assertIn("staff: recv recv active", out)
            self.assertNotIn("482916", out + r.stdout + r.stderr)
            self.assertEqual(oct(os.stat(db).st_mode & 0o777), "0o600")

    def test_backup_command_saves_a_copy_the_installer_can_rely_on(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "why.db")
            env = dict(os.environ, WHY_PBKDF2_ITERS="1000")
            run = lambda *a, **k: subprocess.run([sys.executable, "-I", str(HERE / "why_server.py"), *a], capture_output=True, text=True, env=env, **k)
            self.assertEqual(run("setpin", "--role", "admin", "--db", db, "--pin-stdin", input="482916\n").returncode, 0)
            r1 = run("backup", "--db", db)
            self.assertEqual(r1.returncode, 0, r1.stderr)
            files = list(Path(d, "backups").glob("why-*.db"))
            self.assertEqual(len(files), 1, files)
            self.assertIn("backup saved", r1.stdout)
            r2 = run("backup", "--db", db)      # asked again the same day: it is replaced by the newer copy, not refused
            self.assertEqual(r2.returncode, 0, r2.stderr)
            self.assertEqual(len(list(Path(d, "backups").glob("why-*.db"))), 1)
            self.assertEqual(oct(files[0].stat().st_mode & 0o777), "0o600")
            import sqlite3
            con = sqlite3.connect(str(files[0]))
            self.assertEqual(con.execute("SELECT role FROM staff").fetchone()[0], "admin")
            con.close()


class TestStaticMode(unittest.TestCase):
    def test_pages_and_security_headers(self):
        with tempfile.TemporaryDirectory() as d:
            site = Path(d, "site")
            (site / "admin").mkdir(parents=True)
            (site / "index.html").write_text("<h1>customer</h1>")
            (site / "admin" / "index.html").write_text("<h1>admin</h1>")
            (Path(d, "secret.txt")).write_text("no")
            app = W.App(os.path.join(d, "why.db"), iters=1000, backups=False, static=site, quiet=True)
            srv = W.make_server(app, "127.0.0.1", 0)
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            c = Http(srv.server_address[1])
            st, j, h = c.get("/")
            self.assertEqual((st, j["_raw"]), (200, "<h1>customer</h1>"))
            self.assertIn("frame-ancestors 'none'", h["Content-Security-Policy"])
            self.assertEqual(c.get("/admin")[0], 301)
            self.assertEqual(c.get("/admin/")[1]["_raw"], "<h1>admin</h1>")
            self.assertEqual(c.get("/../secret.txt")[0], 404)
            self.assertEqual(c.get("/%2e%2e/secret.txt")[0], 404)
            self.assertEqual(c.get("/nothing.html")[0], 404)
            srv.shutdown()
            srv.server_close()
            app.close()


class TestWhatsAppCode(Base):
    """0.7.6: the sign-in code by WhatsApp; 12345 only while WhatsApp is not set or the test code is kept on."""

    def setUp(self):
        self.sent = []
        self.fail = False

        def fake(conf, phone, code):
            if self.fail:
                raise OSError("no route")
            self.sent.append((conf["tpl"], conf["lang"], phone, code))
        self.app.wa_send = fake
        self.app.otps.clear()
        self.app.limit = W.Limiter()

    def tearDown(self):
        with self.app.db.tx() as c:
            for k in ("wa_token", "wa_phone", "wa_tpl", "wa_lang", "otp_test"):
                c.execute("DELETE FROM kv WHERE k=?", (k,))

    def wa_on(self, keep_test):
        with self.app.db.tx() as c:
            for k, v in (("wa_token", "T" * 40), ("wa_phone", "1234567890"), ("otp_test", "on" if keep_test else "off")):
                self.app._set_kv(c, k, v)

    def test_not_set_means_test_code(self):
        c, ph = self.customer(), self.fresh_cust()["phone"]
        st, j, _ = c.post("/api/my/code", {"phone": ph})
        self.assertEqual((st, j["via"]), (200, "test"))
        self.assertEqual(self.sent, [])
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST})[1], {"ok": True, "need": "signup"})

    def test_real_code_signs_in_and_test_code_off(self):
        self.wa_on(False)
        c, ph = self.customer(), self.fresh_cust()["phone"]
        self.assertEqual(c.post("/api/my/code", {"phone": ph})[1]["via"], "wa")
        tpl, lang, to, code = self.sent[-1]
        self.assertEqual((tpl, lang, to), ("why_code", "ar", ph))
        self.assertRegex(code, r"^\d{5}$")
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST})[1]["error"], "bad_otp")   # test code off
        # the code proves the number, stays good for the sign-up that follows, then is used up
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": code})[1], {"ok": True, "need": "signup"})
        st, j, _ = c.post("/api/my/login", {"phone": ph, "code": code, "signup": True, "name": "سارة"})
        self.assertEqual((st, j["new"]), (200, True))
        d = self.customer()
        self.assertEqual(d.post("/api/my/login", {"phone": ph, "code": code})[1]["error"], "bad_otp")   # used

    def test_another_number_and_tries(self):
        self.wa_on(False)
        c, ph, other = self.customer(), self.fresh_cust()["phone"], self.fresh_cust()["phone"]
        c.post("/api/my/code", {"phone": ph})
        code = self.sent[-1][3]
        self.assertEqual(c.post("/api/my/login", {"phone": other, "code": code})[1]["error"], "bad_otp")   # not that number's
        wrong = "%05d" % ((int(code) + 1) % 100000)
        for _ in range(W.OTP_TRIES):
            self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": wrong})[1]["error"], "bad_otp")
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": code})[1]["error"], "bad_otp")   # too many tries

    def test_gap_and_expiry(self):
        self.wa_on(False)
        c, ph = self.customer(), self.fresh_cust()["phone"]
        c.post("/api/my/code", {"phone": ph})
        st, j, _ = c.post("/api/my/code", {"phone": ph})
        self.assertEqual((st, j["error"]), (429, "slow_down"))   # a new one only after 30 s
        self.assertEqual(len(self.sent), 1)
        self.app.otps[ph]["exp"] = W.now_ms() - 1
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": self.sent[-1][3]})[1]["error"], "bad_otp")

    def test_send_failure(self):
        self.wa_on(True)   # the test code kept on: a code that cannot go falls back to it
        self.fail = True
        c, ph = self.customer(), self.fresh_cust()["phone"]
        self.assertEqual(c.post("/api/my/code", {"phone": ph})[1]["via"], "test")
        self.assertEqual(c.post("/api/my/login", {"phone": ph, "code": W.OTP_TEST})[1], {"ok": True, "need": "signup"})
        with self.app.db.tx() as k:
            self.app._set_kv(k, "otp_test", "off")
        self.app.otps.clear()
        st, j, _ = c.post("/api/my/code", {"phone": ph})
        self.assertEqual((st, j["error"]), (502, "wa_failed"))
        self.assertEqual(c.post("/api/my/code", {"phone": "12"})[1]["error"], "bad_phone")

    def test_real_sender_body(self):
        seen = {}

        class R:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return b"{}"

        def fake_open(req, timeout=0):
            seen["url"], seen["auth"], seen["body"] = req.full_url, req.get_header("Authorization"), json.loads(req.data)
            return R()
        real = W.urllib.request.urlopen
        W.urllib.request.urlopen = fake_open
        try:
            W.App._wa_send({"token": "TOK", "phone": "777", "tpl": "why_code", "lang": "ar"}, "501234567", "04213")
        finally:
            W.urllib.request.urlopen = real
        self.assertEqual(seen["url"], "https://graph.facebook.com/v25.0/777/messages")
        self.assertEqual(seen["auth"], "Bearer TOK")
        b = seen["body"]
        self.assertEqual((b["to"], b["template"]["name"], b["template"]["language"]["code"]), ("966501234567", "why_code", "ar"))
        comps = b["template"]["components"]
        self.assertEqual(comps[0]["parameters"][0]["text"], "04213")
        self.assertEqual((comps[1]["sub_type"], comps[1]["parameters"][0]["text"]), ("url", "04213"))


class TestBackupMail(Base):
    """0.7.7: the daily copy, locked with a password, by e-mail; the keys of this server never leave in a copy."""

    def setUp(self):
        self.sent, self.fail = [], None

        def fake(key, body):
            if self.fail:
                raise self.fail
            att = body.get("attachment")
            if att:   # as the real sender gets it: bytes; turned into text here like the request would carry it
                body = dict(body, attachment=[{"name": att[0]["name"], "content": att[0]["content"].decode("ascii")}])
            self.sent.append((key, body))
            return {"messageId": "x"}
        self.app.mail_post = fake
        with self.app.db.tx() as c:
            for k, v in (("mail_key", "xkeysib-" + "a" * 40), ("mail_from", "shop@example.com"), ("mail_to", "owner@example.com,me@example.com"),
                         ("mail_name", "Why!"), ("mail_hour", "0"), ("mail_pw", "correct horse battery"), ("mail_state", "{}"),
                         ("wa_token", "WA" * 20), ("route_key", "RK" * 20)):
                self.app._set_kv(c, k, v)

    def tearDown(self):
        with self.app.db.tx() as c:
            for k in ("mail_key", "mail_from", "mail_to", "mail_name", "mail_hour", "mail_pw", "mail_state", "wa_token", "route_key"):
                c.execute("DELETE FROM kv WHERE k=?", (k,))

    def open_copy(self, body, pw):
        att = body["attachment"][0]
        d = tempfile.mkdtemp()
        with zipfile.ZipFile(io.BytesIO(base64.b64decode(att["content"]))) as z:   # the plain zip around the locked file
            inner = [n for n in z.namelist() if n.endswith(".enc")][0]
            self.assertIn("openssl enc -d", z.read("README.txt").decode("utf-8"))
            enc = os.path.join(d, inner)
            Path(enc).write_bytes(z.read(inner))
        out = os.path.join(d, "out.zip")
        ok = W.unlock_file(enc, out, pw)
        return ok, out, d

    def test_sends_once_a_day_locked_and_without_keys(self):
        self.assertEqual(self.app.mail_backup(), "sent")
        self.assertIsNone(self.app.mail_backup())   # once a day
        self.assertEqual(len(self.sent), 1)
        key, body = self.sent[0]
        self.assertTrue(key.startswith("xkeysib-"))
        self.assertEqual([t["email"] for t in body["to"]], ["owner@example.com", "me@example.com"])
        self.assertEqual(body["sender"], {"name": "Why!", "email": "shop@example.com"})
        self.assertRegex(body["attachment"][0]["name"], r"^why-backup-\d{4}-\d\d-\d\d\.zip$")   # a type Brevo takes
        self.assertIn("unlock", body["textContent"])
        raw = base64.b64decode(body["attachment"][0]["content"])
        self.assertTrue(zipfile.is_zipfile(io.BytesIO(raw)))
        self.assertIn(b"Salted__", raw)
        self.assertNotIn(b"SQLite format", raw)
        ok, _, _ = self.open_copy(body, "wrong password!!")
        self.assertFalse(ok)
        ok, out, d = self.open_copy(body, "correct horse battery")
        self.assertTrue(ok)
        with zipfile.ZipFile(out) as z:
            self.assertEqual(sorted(z.namelist()), ["README.txt", "why.db"])
            z.extract("why.db", d)
        dbf = os.path.join(d, "why.db")
        c = sqlite3.connect(dbf)
        keys = {r[0] for r in c.execute("SELECT k FROM kv")}
        c.close()
        for k in W.SECRET_KV:
            self.assertNotIn(k, keys)
        self.assertIn("vapid", keys)
        data = Path(dbf).read_bytes()
        self.assertNotIn(b"correct horse battery", data)
        self.assertNotIn(b"xkeysib-", data)
        self.assertNotIn(b"WAWAWA", data)
        info = self.app.backups_info()["mail"]
        self.assertEqual(info["to"], ["o***@example.com", "m***@example.com"])
        self.assertEqual((info["ok"], info["err"]), (self.app.today(), ""))

    def test_failure_is_retried_three_times_a_day(self):
        self.fail = OSError("no route")
        for _ in range(W.MAIL_TRIES_A_DAY):
            with self.assertRaises(OSError):
                self.app.mail_backup()
        self.assertIsNone(self.app.mail_backup())   # no more today
        self.assertEqual(self.app.backups_info()["mail"]["err"], "send_failed")
        self.fail = None
        self.assertEqual(self.app.mail_backup(force=True), "sent")   # the command sends at once
        self.assertEqual(self.app.backups_info()["mail"]["err"], "")

    def test_too_big_sends_a_note(self):
        old = W.MAIL_MAX_BYTES
        W.MAIL_MAX_BYTES = 10
        try:
            self.assertEqual(self.app.mail_backup(), "big")
        finally:
            W.MAIL_MAX_BYTES = old
        body = self.sent[0][1]
        self.assertNotIn("attachment", body)
        self.assertEqual(self.app.backups_info()["mail"]["err"], "big")

    def test_not_set_does_nothing(self):
        with self.app.db.tx() as c:
            self.app._set_kv(c, "mail_key", "")
        self.assertIsNone(self.app.mail_backup())
        self.assertNotIn("mail", self.app.backups_info())
        self.assertEqual(self.sent, [])

    def test_real_sender_request(self):
        seen = {}

        class R:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return b'{"messageId":"m"}'

        def fake_open(req, timeout=0):
            seen["url"], seen["key"], seen["body"] = req.full_url, req.get_header("Api-key"), json.loads(req.data)
            return R()
        real = W.urllib.request.urlopen
        W.urllib.request.urlopen = fake_open
        try:
            W.App._mail_post("K" * 30, {"sender": {"name": "Why!", "email": "a@b.co"}, "to": [{"email": "c@d.co"}], "subject": "s",
                                        "textContent": "t", "attachment": [{"name": "f.zip.enc", "content": base64.b64encode(b"\x00\x01data")}]})
        finally:
            W.urllib.request.urlopen = real
        self.assertEqual((seen["url"], seen["key"]), ("https://api.brevo.com/v3/smtp/email", "K" * 30))
        self.assertEqual(seen["body"]["attachment"], [{"name": "f.zip.enc", "content": base64.b64encode(b"\x00\x01data").decode()}])
        self.assertEqual(seen["body"]["to"], [{"email": "c@d.co"}])

    def test_admin_download_has_no_keys(self):
        sid = self.app.db.one("SELECT id FROM staff WHERE role='admin'")["id"]
        zp, _ = self.app.db_copy({"id": sid, "role": "admin"}, {"pin": PINS["admin"]}, "127.0.0.1")
        data = Path(zp).read_bytes()
        os.unlink(zp)
        d = tempfile.mkdtemp()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            z.extract("why.db", d)
            self.assertIn("غير موجودة", z.read("README.txt").decode("utf-8"))
        c = sqlite3.connect(os.path.join(d, "why.db"))
        keys = {r[0] for r in c.execute("SELECT k FROM kv")}
        c.close()
        self.assertFalse(keys & set(W.SECRET_KV))

    def test_unlock_command(self):
        self.app.mail_backup()
        body = self.sent[0][1]
        d = tempfile.mkdtemp()
        got = os.path.join(d, body["attachment"][0]["name"])   # the mailed zip, as the owner saves it
        Path(got).write_bytes(base64.b64decode(body["attachment"][0]["content"]))
        r = subprocess.run([sys.executable, W.__file__, "unlock", got], input=b"wrong password\n", capture_output=True)
        self.assertNotEqual(r.returncode, 0)
        r = subprocess.run([sys.executable, W.__file__, "unlock", got], input=b"correct horse battery\n", capture_output=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        opened = got[:-4] + "-opened.zip"
        with zipfile.ZipFile(opened) as z:
            self.assertEqual(sorted(z.namelist()), ["README.txt", "why.db"])
        self.assertEqual([n for n in os.listdir(d) if n.startswith(".unlock")], [])   # no locked copy left behind
        r = subprocess.run([sys.executable, W.__file__, "unlock", got], input=b"correct horse battery\n", capture_output=True)
        self.assertNotEqual(r.returncode, 0)   # the opened zip is there already


if __name__ == "__main__":
    unittest.main(verbosity=1)
