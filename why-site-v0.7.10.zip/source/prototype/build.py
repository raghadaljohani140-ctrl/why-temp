#!/usr/bin/env python3
"""Inline src/styles.css, the JS parts and the brand images from assets/ into one self-contained index.html.

assets/ layout (every folder is optional; a missing image falls back to the drawn art or the text logo):
  assets/brand/brand.json               the identity: colours, font, app names (tools/brand/brand.py makes the logo files below
                                        from it; colours that differ from the ones written in the code are swapped in here)
  assets/brand/lockup-<app>.svg         staff pages: the w with ORDER DESK / MANAGEMENT, the scooter with DELIVERY (sign-in);
  assets/brand/lockup-<app>-compact.svg the same for the top bar
  assets/logo.(png|jpg|webp|svg)        brand logo, shown in the home header
  assets/mark.(png|jpg|webp|svg)        icon-only mark, shown in the tab bar and on the points card
  assets/banners/<banner id>.ext        home banners (bn1 ... bn5)
  assets/news/<news id>.ext             news covers (n1 ... n3)
  assets/products/<product id>.ext      NOT embedded: product photos live on the server (tools/export_catalog.py puts these
                                        into the first menu; after that the admin uploads and changes them)

usage: python3 build.py [--app cust|recv|admin|driver] [--out FILE] [--assets DIR]
  --app     which page to build (default cust, the customer app). recv, admin and driver are the three staff pages.
  --out     where to write it (default: index.html for cust, <app>.html for the others, next to this file)
  --assets  default: the assets folder next to the prototype folder
"""
import base64, io, json, pathlib, re, sys

import numpy as np
from PIL import Image, ImageOps

root = pathlib.Path(__file__).resolve().parent
src = root / "src"
argv = sys.argv[1:]
assets = pathlib.Path(argv[argv.index("--assets") + 1]) if "--assets" in argv else root.parent / "assets"
app = argv[argv.index("--app") + 1] if "--app" in argv else "cust"
# the code each page needs: the shared base (data, core, net, ui), the QR code of the tax invoice where it is shown,
# then its own screens, then the shared events, then its own actions
PARTS = {
    "cust": ["data.js", "core.js", "net.js", "ui.js", "qr.js", "screens.js", "main.js", "cust.js"],
    "recv": ["data.js", "core.js", "net.js", "ui.js", "qr.js", "staff.js", "main.js", "recv.js"],
    "admin": ["data.js", "core.js", "net.js", "ui.js", "qr.js", "staff.js", "main.js", "admin.js"],
    "driver": ["data.js", "core.js", "net.js", "ui.js", "staff.js", "main.js", "driver.js"],
}
TITLES = {"cust": "واي!", "recv": "واي! | الاستقبال", "admin": "واي! | الإدارة", "driver": "واي! | المندوب"}
if app not in PARTS:
    sys.exit(f"unknown --app {app}; use one of {', '.join(PARTS)}")
parts = PARTS[app]
out_path = pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv else root / ("index.html" if app == "cust" else f"{app}.html")
# photos only where they are shown: banners and news on the customer page (product photos come from the server)
KINDS = {"cust": ("b", "n"), "admin": (), "recv": (), "driver": ()}[app]
RASTER = {".png", ".jpg", ".jpeg", ".webp"}


def uri(data, mime):
    return f"data:{mime};base64," + base64.b64encode(data).decode("ascii")


def open_image(path):
    im = Image.open(path)
    im = ImageOps.exif_transpose(im)
    im.load()
    return im


def has_alpha(im):
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        lo, _ = im.convert("RGBA").getchannel("A").getextrema()
        return lo < 250
    return False


def corner_colour(rgb):
    """Average colour of the four corners and how far the corners differ from each other."""
    w, h = rgb.size
    n = max(4, min(w, h) // 40)
    px = [rgb.crop((x, y, x + n, y + n)).resize((1, 1), Image.BOX).getpixel((0, 0))
          for x, y in ((0, 0), (w - n, 0), (0, h - n), (w - n, h - n))]
    avg = tuple(sum(p[i] for p in px) // 4 for i in range(3))
    spread = max(max(abs(p[i] - avg[i]) for i in range(3)) for p in px)
    return avg, spread


def white_to_alpha(rgb):
    """Turn a dark-on-white logo into a transparent one (colour to alpha, white as the key)."""
    a = np.asarray(rgb.convert("RGB")).astype(np.float32) / 255.0
    alpha = 1.0 - a.min(axis=2)
    alpha[alpha < 0.04] = 0.0
    safe = np.where(alpha > 1e-3, alpha, 1.0)
    col = np.clip(1.0 - (1.0 - a) / safe[..., None], 0.0, 1.0)
    out = np.dstack([col, alpha])
    return Image.fromarray((out * 255).round().astype(np.uint8), "RGBA")


def trim(im):
    box = im.getchannel("A").point(lambda v: 255 if v > 14 else 0).getbbox()
    return im.crop(box) if box else im


def webp(im, quality):
    buf = io.BytesIO()
    im.save(buf, "WEBP", quality=quality, method=6)
    return buf.getvalue()


def prep_cover(path, side, quality):
    im = open_image(path)
    im.thumbnail((side, side), Image.LANCZOS)
    return uri(webp(im.convert("RGB"), quality), "image/webp"), round(im.width / im.height, 4)


def prep_logo(path, max_h):
    if path.suffix.lower() == ".svg":
        raw = path.read_bytes()
        text = raw.decode("utf-8", "ignore")
        if "<script" in text.lower():
            sys.exit(f"{path.name}: SVG contains a script tag")
        m = re.search(r'viewBox="[-\d.]+[ ,]+[-\d.]+[ ,]+([\d.]+)[ ,]+([\d.]+)"', text)
        r = float(m.group(1)) / float(m.group(2)) if m else 1.0
        return uri(raw, "image/svg+xml"), {"r": round(r, 4)}
    im = open_image(path)
    if has_alpha(im):
        im = im.convert("RGBA")
    else:
        rgb = im.convert("RGB")
        _, spread = corner_colour(rgb)
        avg, _ = corner_colour(rgb)
        im = white_to_alpha(rgb) if min(avg) > 225 and spread < 20 else rgb.convert("RGBA")
    im = trim(im)
    if im.height > max_h:
        im = im.resize((round(im.width * max_h / im.height), max_h), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    return uri(buf.getvalue(), "image/png"), {"r": round(im.width / im.height, 4)}


def files_in(folder):
    return sorted(p for p in folder.glob("*") if p.is_file() and p.suffix.lower() in RASTER) if folder.is_dir() else []


def first_named(stem):
    for ext in (".svg", ".png", ".webp", ".jpg", ".jpeg"):
        p = assets / f"{stem}{ext}"
        if p.is_file():
            return p
    return None


data_js = (src / "data.js").read_text(encoding="utf-8")
meta = {"p": {}, "b": {}, "n": {}, "logo": None, "mark": None}
rules, count = [], 0

home_file = assets / "home" / "home.json"
home = json.loads(home_file.read_text(encoding="utf-8")) if home_file.is_file() else {}
for kind, folder, side, q in (("b", "banners", 900, 78), ("n", "news", 700, 78)):
    if kind not in KINDS:
        continue
    for f in files_in(assets / folder):
        if kind == "b" and f.stem in (home.get("banners") or {}):
            continue   # the home page shows this banner with its photo and words (assets/home), not as a picture
        if f"'{f.stem}'" not in data_js:
            print(f"warning: {folder}/{f.name} does not match any id in data.js")
            continue
        u, r = prep_cover(f, side, q)
        meta[kind][f.stem] = {"r": r}
        rules.append(f'.im-{kind}-{f.stem}{{background-image:url("{u}")}}')
        count += 1

# 0.7.10: photos on the home page: the two tiles and the text banners (assets/home/home.json). A photo is the name of one
# in assets/menu (its tile colour comes from assets/menu/photos.json) or a path under assets/; bg, ink and pos may be given
if "b" in KINDS and home:
    tones = json.loads((assets / "menu" / "photos.json").read_text(encoding="utf-8")) if (assets / "menu" / "photos.json").is_file() else {}
    meta["ht"], meta["hb"] = {}, {}
    for kind, group in (("ht", "tiles"), ("hb", "banners")):
        for name, x in (home.get(group) or {}).items():
            p = assets / x["photo"] if "/" in x["photo"] else assets / "menu" / f"{x['photo']}.webp"
            if not p.is_file() or not re.fullmatch(r"[a-z0-9]+", name):
                print(f"warning: home photo {group}/{name}: {p} not found")
                continue
            if group == "banners" and f"'{name}'" not in data_js:
                print(f"warning: home photo for banner {name}, which data.js does not have")
                continue
            u, _ = prep_cover(p, 600, 80)
            bg = x.get("bg") or (tones.get(x["photo"]) or {}).get("bg") or "#%02x%02x%02x" % corner_colour(open_image(p).convert("RGB"))[0]
            ink, pos = x.get("ink") or "#0F0F0F", x.get("pos") or ""
            if not all(re.fullmatch(r"#[0-9A-Fa-f]{6}", v) for v in (bg, ink)) or not re.fullmatch(r"(\d{1,3}% \d{1,3}%)?", pos):
                sys.exit(f"assets/home/home.json: {name}: colours look like #A1B2C3, pos like 50% 30%")
            meta[kind][name] = {"bg": bg, "ink": ink, "pos": pos}
            rules.append(f'.im-{kind}-{name}{{background-image:url("{u}")}}')
            count += 1

for key, max_h in (("logo", 200), ("mark", 160)):
    p = first_named(key)
    if p:
        u, m = prep_logo(p, max_h)
        meta[key] = m
        prop = 'background-image' if key == 'logo' else '-webkit-mask-image:url("%s");mask-image' % u
        rules.append(f'.im-{key}{{{prop}:url("{u}")}}')
        if key == 'logo':   # the same wordmark as a mask: the membership cards draw it in their tier's colour
            rules.append(f'.im-logom{{-webkit-mask-image:url("{u}");mask-image:url("{u}")}}')
        count += 1

# the staff page's own logo (drawn in the colour of the text around it)
for key, name in (("lockup", f"lockup-{app}.svg"), ("lockupc", f"lockup-{app}-compact.svg")):
    p = assets / "brand" / name
    if app != "cust" and p.is_file():
        u, m = prep_logo(p, 0)
        meta[key] = m
        rules.append(f'.im-{key}{{-webkit-mask-image:url("{u}");mask-image:url("{u}")}}')
        count += 1

# ---- the identity (assets/brand/brand.json): new colours replace the ones written in the code, the font follows
BASE = {"yellow": "#ECB444", "yellow_deep": "#D49A1C", "yellow_light": "#F3CB6E", "yellow_wash": "#FDF3DB", "black": "#0F0F0F"}
BRAND = {"colors": dict(BASE, gold="#D8AE55", gold_light="#F3DB9B", gold_deep="#A67A27", card="#141414"),
         "font": {"family": "Tajawal", "stylesheet": "https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&display=swap"}}
brand_file = assets / "brand" / "brand.json"
if brand_file.is_file():
    b = json.loads(brand_file.read_text(encoding="utf-8"))
    BRAND["colors"].update(b.get("colors", {}))
    BRAND["font"].update(b.get("font", {}))
meta["name"] = (b.get("apps", {}).get(app, {}).get("name") if brand_file.is_file() else None) or "Why!"
for k, v in BRAND["colors"].items():
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", str(v)):
        sys.exit(f"brand.json: colour {k} must look like #A1B2C3, not {v!r}")
SWAP = {BASE[k].lower(): BRAND["colors"][k].upper() for k in BASE if BRAND["colors"][k].lower() != BASE[k].lower()}
fam = BRAND["font"]["family"]
if not re.fullmatch(r"[A-Za-z0-9 ]{2,40}", fam):
    sys.exit("brand.json: the font family may only have letters, digits and spaces")
c = BRAND["colors"]
rules.insert(0, ":root{" + f"--gold:{c['gold']};--gold-l:{c['gold_light']};--gold-d:{c['gold_deep']};--card:{c['card']};"
             + f"--f:'{fam}','Noto Sans Arabic','SF Arabic','Geeza Pro','Tahoma',system-ui,sans-serif" + "}")

tpl = (root / "template.html").read_text(encoding="utf-8")
css = (src / "styles.css").read_text(encoding="utf-8") + "\n/* embedded brand images */\n" + "\n".join(rules)
js = (f"const APP = '{app}';\nconst IMG = " + json.dumps(meta, ensure_ascii=False, separators=(",", ":")) + ";\n"
      + "\n".join((src / p).read_text(encoding="utf-8") for p in parts) + "\nboot();\n")

if "</script" in js.lower():
    sys.exit("JS contains a closing script tag; escape it")

out = tpl.replace("/*__CSS__*/", css).replace("/*__JS__*/", js).replace("<title>واي!</title>", f"<title>{TITLES[app]}</title>")
sheet = BRAND["font"]["stylesheet"]
if not sheet.startswith("https://fonts.googleapis.com/"):
    sys.exit("brand.json: the font stylesheet must come from https://fonts.googleapis.com/ (the pages allow no other font host)")
out = out.replace('href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&display=swap"', 'href="%s"' % sheet.replace('"', ''))
if SWAP:
    out = re.sub(r"#[0-9A-Fa-f]{6}\b", lambda m: SWAP.get(m.group(0).lower(), m.group(0)), out)
out_path.write_text(out, encoding="utf-8")
print(f"built {out_path.name} ({app}) {len(out)} characters, {count} embedded image(s)")
