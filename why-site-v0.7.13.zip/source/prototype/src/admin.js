/* Admin: the owner's dashboard. Sales, orders, menu, branches, offers and fees, drivers, customers, settings.
   Everything here is read from and written to the server, so it is the same on every phone and computer. */

const ADM = () => [['home', T('نظرة عامة', 'Overview'), 'chart'], ['orders', T('الطلبات', 'Orders'), 'receipt'], ['menu', T('المنتجات', 'Products'), 'cup'], ['branches', T('الفروع', 'Branches'), 'store'],
  ['report', T('التقارير', 'Reports'), 'report'], ['news', T('الأخبار', 'News'), 'book'], ['promo', T('العروض والرسوم', 'Offers and fees'), 'tag'], ['drivers', T('المناديب', 'Drivers'), 'moto'], ['cust', T('العملاء', 'Customers'), 'user'], ['set', T('الإعدادات', 'Settings'), 'gear']];
const DAYS = {ar:['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'], en:['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']};
const live = o => !o.rej && !o.fin;

function dayStats() {
  const list = SRV.orders.filter(o => isToday(o) && !o.rej), top = {};
  let items = 0;
  list.forEach(o => o.items.forEach(i => { items += i.qty; top[i.pid] = (top[i.pid] || 0) + i.qty; }));
  const sales = r2(list.reduce((a, o) => a + o.total, 0));
  return {list, n:list.length, sales, avg:list.length ? r2(sales / list.length) : 0, items, del:list.filter(o => o.mode === 'delivery').length, top:Object.entries(top).sort((a, b) => b[1] - a[1]).slice(0, 5)};
}
function weekData() {
  return (SRV.week || []).map(d => { const dt = new Date(d.day + 'T12:00:00'); return {day:DAYS[S.lang][dt.getDay()], iso:d.day, n:d.n, v:d.sales}; });
}
function chartHTML(wk) {
  const mx = Math.max(1, ...wk.map(d => d.v)), step = [100, 200, 250, 500, 1000, 2000, 5000, 10000, 20000, 50000].find(s => s * 3 >= mx) || 100000, top = step * 3;
  const ticks = [0, 1, 2, 3].map(i => `<span style="bottom:${i * 100 / 3}%">${num(i * step)}</span>`).join('');
  const lines = [0, 1, 2, 3].map(i => `<div class="gl" style="bottom:${i * 100 / 3}%"></div>`).join('');
  const last = wk.length - 1;
  const bars = wk.map((d, i) => {
    const h = d.v > 0 ? Math.max(1.5, d.v / top * 100) : 0, on = UI.ad.bar === i;
    return `<button class="bar ${i === last ? 'now' : ''} ${on ? 'sel' : ''}" data-a="adBar" data-i="${i}" aria-label="${d.day}: ${fmt(d.v)} ${T('ر.س', 'SAR')}"><span class="cm"><i style="height:${h}%"></i><em class="tip" style="bottom:calc(${h}% + 5px)">${fmt(d.v)}</em></span><span class="bd">${d.day}</span></button>`;
  }).join('');
  return `<div class="chart" role="group" aria-label="${T('المبيعات خلال آخر 7 أيام', 'Sales over the last 7 days')}"><div class="yax">${ticks}</div><div class="plot"><div class="gls">${lines}</div><div class="bars">${bars}</div></div></div>`;
}
function tableHTML(wk) {
  const last = wk.length - 1;
  return `<table class="tbl dk"><thead><tr><th>${T('اليوم', 'Day')}</th><th>${T('الطلبات', 'Orders')}</th><th>${T('المبيعات', 'Sales')}</th></tr></thead><tbody>${wk.map((d, i) => `<tr><td>${d.day} <span class="ltr">${d.iso.slice(5)}</span>${i === last ? ` <small>(${T('اليوم', 'today')})</small>` : ''}</td><td>${d.n}</td><td>${money(d.v)}</td></tr>`).join('')}</tbody></table>`;
}
function adHome() {
  const st = dayStats(), wk = weekData(), all = SRV.orders.filter(live);
  const pending = all.filter(o => o.st === 0).length, prep = all.filter(o => o.st === 1).length;
  const ready = all.filter(o => o.st === 2 && !(o.mode === 'delivery')).length;
  const waitD = all.filter(o => o.mode === 'delivery' && o.st === 2 && !o.driver).length, onRoad = all.filter(o => o.mode === 'delivery' && o.st === 2 && o.driver).length;
  const hero = `<section class="hero"><small>${T('مبيعات اليوم', 'Sales today')}</small><b class="hero-v">${money(st.sales)}</b><small>${T(`${st.n} طلب · شامل الضريبة`, `${st.n} orders · incl. VAT`)}</small>
    <div class="ch-h"><span>${T('المبيعات خلال آخر 7 أيام', 'Sales over the last 7 days')}</span><button class="sbb sm" data-a="adTbl">${UI.ad.tbl ? T('الرسم', 'Chart') : T('جدول', 'Table')}</button></div>
    ${UI.ad.tbl ? tableHTML(wk) : chartHTML(wk)}<button class="hlink" data-a="adSec" data-id="report">${ic('report', 16)}${T('الأيام الأقدم في التقارير، مع ملف Excel', 'Older days are in Reports, with an Excel file')}</button></section>`;
  const kpis = `<div class="kpis"><div class="kpi"><small>${T('الطلبات اليوم', 'Orders today')}</small><b>${st.n}</b></div><div class="kpi"><small>${T('متوسط قيمة الطلب', 'Average order')}</small><b>${money(st.avg)}</b></div>
    <button class="kpi ${pending ? 'hot' : ''}" data-a="adGoNew"><small>${T('بانتظار القبول', 'Waiting to be accepted')}</small><b>${pending}</b></button><div class="kpi"><small>${T('الأصناف المباعة', 'Items sold')}</small><b>${st.items}</b></div>
    <div class="kpi"><small>${T('طلبات التوصيل اليوم', 'Deliveries today')}</small><b>${st.del}</b></div><div class="kpi ${waitD ? 'hot' : ''}"><small>${T('بانتظار مندوب', 'Waiting for a driver')}</small><b>${waitD}</b></div></div>
    <p class="flow">${T(`قيد التحضير ${prep} · جاهز للاستلام ${ready} · مع المناديب ${onRoad}`, `Preparing ${prep} · Ready ${ready} · With drivers ${onRoad}`)}</p>`;
  const top = `<section class="ac"><h3>${T('الأكثر طلبًا اليوم', 'Most ordered today')}</h3>${st.top.length ? `<ul class="top">${st.top.map(([pid, q]) => `<li><span class="nm">${esc(PROD[pid] ? L(PROD[pid]) : '—')}</span><b class="ltr">${q}</b><span class="tb"><i style="width:${Math.max(6, q / st.top[0][1] * 100)}%"></i></span></li>`).join('')}</ul>` : `<p class="grey">${T('لا توجد طلبات اليوم بعد', 'No orders yet today')}</p>`}</section>`;
  const brs = `<section class="ac"><h3>${T('الفروع اليوم', 'Branches today')}</h3><table class="tbl"><thead><tr><th>${T('الفرع', 'Branch')}</th><th>${T('الطلبات', 'Orders')}</th><th>${T('المبيعات', 'Sales')}</th><th></th></tr></thead><tbody>${BRANCHES.map(b => { const l = st.list.filter(o => o.branch === b.id); return `<tr><td><b>${esc(brName(b))}</b></td><td>${l.length}</td><td>${money(r2(l.reduce((a, o) => a + o.total, 0)))}</td><td>${bChip(b)}</td></tr>`; }).join('')}</tbody></table></section>`;
  return `<div class="ov"><div class="ov-a">${hero}${brs}</div><div class="ov-b">${kpis}${top}${ratesCard()}</div></div>`;
}
/* what the customers said about their orders (0.7): the average of the last 14 days and the latest words */
function ratesCard() {
  const l = SRV.orders.filter(o => o.rate).sort((a, b) => b.rate.ts - a.rate.ts);
  if (!l.length) return `<section class="ac"><h3>${T('تقييمات العملاء', 'Customer ratings')}</h3><p class="grey">${T('يقيّم العميل طلبه بعد استلامه، وتظهر التقييمات هنا.', 'Customers rate an order once they have it; the ratings show here.')}</p></section>`;
  const avg = l.reduce((a, o) => a + o.rate.s, 0) / l.length, words = l.filter(o => o.rate.c).slice(0, 3);
  return `<section class="ac"><h3>${T('تقييمات العملاء', 'Customer ratings')}</h3><div class="rsum"><b class="ltr">${avg.toFixed(1)}</b>${starsRow(Math.round(avg))}<small class="grey">${T(`من ${l.length} تقييم · آخر 14 يومًا`, `from ${l.length} ratings · last 14 days`)}</small></div>
    ${words.map(o => `<button class="rword" data-a="adOrder" data-id="${o.id}">${starsRow(o.rate.s)}<span>«${esc(o.rate.c)}»</span><small class="grey">${esc(custOf(o).name)} · ${o.no}</small></button>`).join('')}</section>`;
}

const aoRow = o => `<button class="aor" data-a="adOrder" data-id="${o.id}"><span class="no">${o.no}</span><span class="grow"><b>${esc(custOf(o).name)}${o.mode !== 'pickup' ? ` <span class="mi-t">${ic('truck', 14)}</span>` : ''}${o.rate ? ` <span class="mi-r">${ic('star', 13)}${o.rate.s}</span>` : ''}</b><small>${esc(itemsSummary(o))}</small></span><span class="rt">${sChip(o)}<b>${money2(o.total)}</b></span></button>`;
const fOf = o => o.rej ? 'rej' : colOf(o);
function adOrdersBody() {
  const q = (UI.ad.oq || '').trim().toLowerCase(), fl = UI.ad.f;
  let list = SRV.orders.filter(o => fl === 'all' ? true : fOf(o) === fl);
  if (q) list = list.filter(o => (o.no + ' ' + custOf(o).name + ' ' + itemsSummary(o)).toLowerCase().includes(q));
  return list.length ? list.slice(0, 200).map(aoRow).join('') : `<div class="colx">${ic('receipt', 30)}<p>${T('لا توجد طلبات', 'No orders')}</p></div>`;
}
function adOrders() {
  const n = f => SRV.orders.filter(o => f === 'all' ? true : fOf(o) === f).length;
  const fs = [['all', T('الكل', 'All')], ['new', T('جديد', 'New')], ['prep', T('قيد التحضير', 'Preparing')], ['ready', T('جاهز', 'Ready')], ['done', T('مكتمل', 'Done')], ['rej', T('مرفوض', 'Rejected')]];
  return `<div class="srch">${ic('search', 20)}<input type="text" data-bind="ad.oq" data-on="adOrdSearch" value="${esc(UI.ad.oq || '')}" placeholder="${T('بحث برقم الطلب أو اسم العميل', 'Search by order number or customer')}" autocomplete="off" aria-label="${T('البحث', 'Search')}"></div>
    <div class="chips">${fs.map(([id, lb]) => `<button class="chip ${UI.ad.f === id ? 'on' : ''}" data-a="adF" data-id="${id}">${lb} <span class="cn">${n(id)}</span></button>`).join('')}</div>
    <div class="ac flush" id="adords">${adOrdersBody()}</div><p class="note">${T('تظهر هنا طلبات آخر 14 يومًا.', 'Orders from the last 14 days.')}</p>`;
}

/* ---------- products: the menu the customers see (it lives on the server) ---------- */
Object.assign(IC, {
  down:'<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  photo:'<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.7"/><path d="m21 16-5-5-9 8"/>',
  up:'<path d="m6 15 6-6 6 6"/>',
  rows:'<path d="M4 6h16M4 12h16M4 18h11"/>'
});
const inCat = (p, id) => (p.cats || [p.cat]).includes(id);
const catCount = id => PRODUCTS.filter(p => inCat(p, id)).length;
const kindName = k => k === 'retail' ? T('منتجات المحمصة', 'Roastery products') : T('طلبات الفرع', 'Branch orders');
const apr = p => {
  const out = p.stock === false, offs = (p.off || []).filter(id => BR[id]);
  const sub = (p.sub && L(p.sub) ? L(p.sub) : L(CAT[p.cat])) + (offs.length ? T(` · غير متوفر في ${offs.map(id => brName(BR[id])).join('، ')}`, ` · not at ${offs.map(id => brName(BR[id])).join(', ')}`) : '');
  return `<div class="apr ${out ? 'out' : ''}"><button class="apr-b" data-a="pEdit" data-id="${p.id}" aria-label="${esc(T(`تعديل ${L(p)}`, `Edit ${L(p)}`))}"><span class="th" style="background:${tileBg(p)}">${pic(p)}</span><span class="grow"><b>${esc(L(p))}</b><small>${esc(sub)}</small></span><span class="apr-p">${money(p.price)}${ic('pencil', 14)}</span></button>${sw(!out, 'adStock', `data-id="${p.id}"`, `${L(p)}: ${T('متوفر', 'Available')}`)}</div>`;
};
function adMenuBody() {
  const q = (UI.ad.q || '').trim().toLowerCase();
  const list = q ? PRODUCTS.filter(p => (p.ar + ' ' + p.en).toLowerCase().includes(q)) : PRODUCTS.filter(p => inCat(p, UI.ad.cat));
  if (list.length) return list.map(apr).join('');
  return q ? `<div class="colx"><p>${T('لا توجد نتائج', 'No results')}</p></div>`
    : `<div class="colx">${ic('cup', 30)}<p>${T('لا توجد منتجات في هذا القسم بعد', 'No products in this category yet')}</p><button class="btn sm" data-a="pNew">${ic('plus', 18)}${T('إضافة منتج', 'Add a product')}</button></div>`;
}
function adMenu() {
  UI.ad.cat = curCat(UI.ad.cat, true);
  const out = PRODUCTS.filter(p => p.stock === false).length, q = (UI.ad.q || '').trim();
  return `<div class="srch">${ic('search', 20)}<input type="text" data-bind="ad.q" data-on="adSearch" value="${esc(UI.ad.q || '')}" placeholder="${T('ابحث عن منتج', 'Search products')}" autocomplete="off" aria-label="${T('البحث', 'Search')}"></div>
    <div class="chips" data-sk="ad-chips">${CATS.map(c => `<button class="chip ${UI.ad.cat === c.id && !q ? 'on' : ''}" data-a="adCat" data-id="${c.id}">${esc(L(c))} <span class="cn">${catCount(c.id)}</span></button>`).join('')}</div>
    <div class="adm-acts"><button class="btn sm" data-a="pNew">${ic('plus', 18)}${T('إضافة منتج', 'Add a product')}</button><button class="btn sm line" data-a="catMgr">${ic('rows', 18)}${T('الأقسام', 'Categories')}</button></div>
    <p class="note">${T(`غير متوفر الآن: ${out} منتج. أي إضافة أو تعديل يظهر فورًا في تطبيق العميل.`, `Unavailable now: ${out}. Anything you add or change shows in the customer app straight away.`)}</p>
    <div class="ac flush" id="admenu">${adMenuBody()}</div>`;
}

function adBranches() {
  const st = dayStats();
  return `<div class="adm-acts"><button class="btn sm" data-a="brNew">${ic('plus', 18)}${T('إضافة فرع', 'Add a branch')}</button></div>` + BRANCHES.map(b => {
    const p = bPaused(b.id), l = st.list.filter(o => o.branch === b.id), n = SRV.orders.filter(o => o.branch === b.id && live(o) && o.st === 0).length;
    return `<section class="ac"><div class="row-s"><div class="grow"><h3>${esc(L(b))}</h3><small class="grey">${esc(L(b.addr))}</small></div>${bChip(b)}<button class="ibtn" data-a="brEdit" data-id="${b.id}" aria-label="${esc(T(`تعديل ${L(b)}`, `Edit ${L(b)}`))}">${ic('pencil', 17)}</button></div>
      <div class="kv"><span>${T('أوقات العمل', 'Working hours')}</span><span>${esc(hoursText(b))}</span></div>
      <div class="kv"><span>${T('الموقع على الخريطة', 'Place on the map')}</span>${hasLoc(b) ? `<a class="tel" href="${mapUrl(b.lat, b.lng)}" target="_blank" rel="noopener noreferrer">${T('محدد، عرضه', 'Set, show it')}</a>` : `<span class="grey">${T('غير محدد', 'Not set')}</span>`}</div>
      <div class="kv"><span>${T('طلبات اليوم', 'Orders today')}</span><b>${l.length}</b></div>
      <div class="kv"><span>${T('بانتظار القبول', 'Waiting to be accepted')}</span><b>${n}</b></div>
      <div class="srow"><span class="grow"><b>${T('استقبال الطلبات', 'Accepting orders')}</b><small>${p ? T('متوقف: يظهر الفرع مغلقًا للعملاء', 'Paused: customers see the branch as closed') : T('يعمل حسب أوقات العمل', 'On, following the working hours')}</small></span>${sw(!p, 'branchPause', `data-id="${b.id}"`, T('استقبال الطلبات', 'Accepting orders'))}</div>
      ${deskRow(b)}</section>`;
  }).join('');
}
/* 0.7: a branch can have its own order desk: its own secret code, and it sees and handles that branch's orders only */
function deskRow(b) {
  const d = (SRV.desks || []).find(x => x.branch === b.id);
  if (!d) return `<div class="srow"><span class="grow"><b>${T('شاشة استقبال خاصة بالفرع', 'The branch’s own order desk')}</b><small>${T('برمز سري خاص، ترى طلبات هذا الفرع فقط', 'With its own secret code; it sees this branch’s orders only')}</small></span><button class="pbtn" data-a="deskAdd" data-id="${b.id}">${ic('plus', 15)}${T('إنشاء', 'Create')}</button></div>`;
  return `<div class="srow"><span class="grow"><b>${T('شاشة استقبال خاصة بالفرع', 'The branch’s own order desk')}</b><small>${d.active ? T('تعمل: تدخلها من رابط الاستقبال باختيار الفرع ورمزه', 'On: sign in on the order desk link by picking the branch and its code') : T('موقوفة: لا يمكن الدخول بها', 'Off: nobody can sign in with it')}</small></span>
    <button class="pbtn" data-a="deskPin" data-id="${b.id}" aria-label="${T('تغيير الرمز', 'Change the code')}">${ic('key', 16)}</button>${sw(d.active, 'deskOn', `data-id="${b.id}"`, T('شاشة الفرع', 'Branch desk'))}<button class="pbtn" data-a="deskDel" data-id="${b.id}" aria-label="${T('حذف', 'Remove')}">${ic('trash', 16)}</button></div>`;
}

/* ---------- news: what customers read in the News tab. Newest on top; each with a photo from the phone, a title and its text.
   The first ones are the app's own until the admin edits them (then they keep their own picture until one is added). ---------- */
function adNews() {
  const all = newsAll();
  const thumb = n => n.img ? `<span class="bn-th" style="background-image:url(/api/img/${n.img.id}/t)"></span>` : `<span class="bn-th" style="background:${n.bg}"></span>`;
  const rows = all.map((n, k) => `<div class="srow bnrow nwrow ${n.on ? '' : 'off'}">${thumb(n)}<span class="grow"><b>${esc(L(n.t) || T('بدون عنوان', 'No title'))}</b><small><span class="ltr">${dISO(n.ts)}</span>${n.on ? '' : ` · ${T('موقوف: لا يظهر للعملاء', 'Paused: customers do not see it')}`}</small></span>
    <button class="pbtn" data-a="nwMove" data-id="${n.id}" data-d="up" ${k ? '' : 'disabled'} aria-label="${T('لأعلى', 'Up')}">${ic('up', 15)}</button><button class="pbtn" data-a="nwMove" data-id="${n.id}" data-d="down" ${k < all.length - 1 ? '' : 'disabled'} aria-label="${T('لأسفل', 'Down')}">${ic('chevdown', 15)}</button>
    <button class="pbtn" data-a="nwEdit" data-id="${n.id}" aria-label="${esc(T(`تعديل ${L(n.t)}`, `Edit ${L(n.t)}`))}">${ic('pencil', 14)}</button>${sw(n.on, 'nwOn', `data-id="${n.id}"`, L(n.t))}</div>`).join('');
  return `<div class="adm-acts"><button class="btn sm" data-a="nwAdd">${ic('plus', 18)}${T('إضافة خبر', 'Add news')}</button></div>
    <p class="note">${T(`تظهر للعملاء في تبويب «الأخبار» فورًا، بالترتيب هنا (الأعلى أولًا). الخبر الجديد يُضاف في الأعلى. ${all.length} من ${40}.`, `Customers see them in the News tab at once, in this order (top first). A new item goes on top. ${all.length} of 40.`)}</p>
    <section class="ac flush">${rows || `<div class="colx">${ic('book', 30)}<p>${T('لا توجد أخبار بعد', 'No news yet')}</p></div>`}</section>`;
}
function newsForm(id) {
  const n = id ? newsAll().find(x => x.id === id) : null;
  UI.nwf = {id:n ? n.id : null, builtin:!!(n && n.builtin), up:false,
    v:{tar:n ? n.t.ar || '' : '', ten:n ? n.t.en || '' : '', bar:n ? (n.b.ar || []).join('\n') : '', ben:n && n.b.en !== n.b.ar ? (n.b.en || []).join('\n') : '', img:n && n.img ? n.img : null}};
  openSheet({k:'nwf'});
}
NEED.nwf = () => { const f = UI.nwf; return !!f && !f.up && !UI.busy && (f.builtin || f.v.tar.trim().length >= 2); };
SHEETS.nwf = function () {
  const f = UI.nwf; if (!f) return '';
  const v = f.v, fld = (k, label, ltr) => `<div class="field"><label>${label}</label><input class="inp" type="text" maxlength="90" ${ltr ? 'dir="ltr"' : ''} data-bind="nwf.v.${k}" value="${esc(v[k])}"></div>`;
  const area = (k, label, ltr) => `<div class="field"><label>${label}</label><textarea class="inp nw-ta" maxlength="3000" ${ltr ? 'dir="ltr"' : ''} data-bind="nwf.v.${k}">${esc(v[k])}</textarea></div>`;
  const prev = v.img ? `<span class="bf-pv nw-pv" style="background-image:url(/api/img/${v.img.id}/t)"></span>` : `<span class="bf-pv nw-pv none">${ic('photo', 30)}</span>`;
  return sheetWrap(`<div class="sbody pe"><h2 class="sttl">${f.id ? T('تعديل الخبر', 'Edit the news') : T('خبر جديد', 'New news item')}</h2>
    <div class="pe-ph">${prev}<div class="pe-pb">${f.up ? `<span class="pe-up"><span class="spin sm"></span>${T('جاري رفع الصورة…', 'Uploading the photo…')}</span>`
      : `<button class="btn line sm" data-a="nwPhoto">${ic('photo', 18)}${v.img ? T('تغيير الصورة', 'Change the photo') : T('إضافة صورة', 'Add a photo')}</button>${v.img ? `<button class="btn text sm" data-a="nwNoPhoto">${T('حذف الصورة', 'Remove the photo')}</button>` : ''}`}
      <small>${T('صورة عريضة (مثل 16 إلى 10). بدون صورة يظهر لون.', 'A wide picture (about 16 to 10). Without one, a colour shows.')}${f.builtin && !v.img ? ' ' + T('الأخبار الأولى تبقى بصورتها الأصلية حتى تضيف صورة.', 'The first news keep their own picture until you add one.') : ''}</small></div></div>
    ${fld('tar', T('العنوان', 'Title'))}${area('bar', T('نص الخبر (كل سطر فقرة)', 'The text (each line is a paragraph)'))}
    ${fld('ten', T('العنوان بالإنجليزي (اختياري)', 'Title in English (optional)'), true)}${area('ben', T('النص بالإنجليزي (اختياري)', 'The text in English (optional)'), true)}
    ${f.id ? `<button type="button" class="btn text dngt" data-a="nwDel">${ic('trash', 18)}${T('حذف الخبر', 'Delete the news')}</button>` : ''}</div>
    <div class="sfoot"><button class="btn" ${needAttr('nwf')} data-a="nwSave">${f.id ? T('حفظ', 'Save') : T('نشر الخبر', 'Publish')}</button></div>`, f.id ? T('تعديل الخبر', 'Edit the news') : T('خبر جديد', 'New news item'), 'tall pe-sheet');
};
async function nwUpload(file) {
  const f = UI.nwf; if (!f || f.up) return;
  f.up = true; render();
  try { const ph = await shrinkPhoto(file); const r = await api('/admin/img', ph, {timeout:90000}); f.v.img = r.img; }
  catch (err) {
    if (err && err.status === 401) { f.up = false; onSignedOut(); return; }
    toast(err instanceof ApiErr ? errText(err) : T('تعذّر فتح هذه الصورة، جرّب صورة أخرى بصيغة JPG أو PNG', 'This photo could not be opened. Try another one as JPG or PNG'));
  }
  f.up = false;
  if (UI.nwf === f) { UI.dirty = true; syncBtns(); }
}
const putNews = n => { if (!n) return; const l = SRV.news || (SRV.news = []), i = l.findIndex(x => x.id === n.id); if (i >= 0) l[i] = n; else l.unshift(n); };

/* ---------- reports: any period, its totals, and the same as an Excel file. The server adds everything up
   (the screen only holds the last 14 days of orders), so a report reaches back as far as the orders do. ---------- */
Object.assign(IC, {
  report:'<path d="M6.5 3h8l4 4v14h-12z"/><path d="M14.5 3v4h4"/><path d="M9.5 17.5v-3M12.5 17.5v-6M15.5 17.5v-4"/>',
  dl:'<path d="M12 4v11"/><path d="m7.5 10.5 4.5 4.5 4.5-4.5"/><path d="M5 19.5h14"/>'
});
UI.rp = {p:'month', f:'', t:'', cf:'', ct:'', tbl:false, bar:-1, all:false, cache:{}, busy:'', err:'', msg:'', timer:0, file:null, ready:false, dl:false};
const MONTHS = {ar:['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
  en:['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']};
const XLSX_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const RP_MAX = 366;   /* days in one report, as the server allows */
const rpToday = () => SRV.today || todayISO();
const okDay = s => /^\d{4}-\d{2}-\d{2}$/.test(s || '') && !isNaN(Date.parse(s + 'T00:00:00Z')) && new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s;
const daysIn = (f, t) => Math.round((Date.parse(t + 'T00:00:00Z') - Date.parse(f + 'T00:00:00Z')) / 864e5) + 1;
/* the period the chips stand for, in the server's days */
function rpPeriod() {
  const r = UI.rp, t = rpToday(), y = +t.slice(0, 4), m = +t.slice(5, 7);
  if (r.p === 'today') return [t, t];
  if (r.p === 'last') { const py = m === 1 ? y - 1 : y, pm = m === 1 ? 12 : m - 1; return [`${py}-${pad2(pm)}-01`, `${py}-${pad2(pm)}-${pad2(new Date(Date.UTC(py, pm, 0)).getUTCDate())}`]; }
  if (r.p === 'custom' && r.cf) return [r.cf, r.ct];
  return [t.slice(0, 8) + '01', t];
}
const rpKey = () => rpPeriod().join('|');
NEED.rpRange = () => { const r = UI.rp; return okDay(r.f) && okDay(r.t) && r.f <= r.t && daysIn(r.f, r.t) <= RP_MAX; };
function rpLabel(f, t) {
  const M = MONTHS[S.lang], p = s => [+s.slice(0, 4), +s.slice(5, 7), +s.slice(8, 10)], [y0, m0, a] = p(f), [y1, m1, b] = p(t);
  if (f === t) return `${a} ${M[m0 - 1]} ${y0}`;
  if (y0 === y1 && m0 === m1) return `${a} – ${b} ${M[m0 - 1]} ${y0}`;
  if (y0 === y1) return `${a} ${M[m0 - 1]} – ${b} ${M[m1 - 1]} ${y0}`;
  return `${a} ${M[m0 - 1]} ${y0} – ${b} ${M[m1 - 1]} ${y1}`;
}
/* show the answer now, unless the person is typing (then the 500 ms beat does it) */
const rpShow = () => { const ae = document.activeElement; if (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) UI.dirty = true; else render(); };
async function rpLoad(k) {
  const r = UI.rp, [from, to] = k.split('|'), rev = SRV.rev;
  r.busy = k;
  try {
    const d = await api('/admin/report', {from, to});
    r.cache[k] = {d, at:Date.now(), rev};
    const keys = Object.keys(r.cache); if (keys.length > 8) delete r.cache[keys[0]];
    if (r.err === k) r.err = '';
  } catch (e) {
    if (e.status === 401) { r.busy = ''; onSignedOut(); return; }
    if (!r.cache[k]) { r.err = k; r.msg = errText(e); }
  } finally { if (r.busy === k) r.busy = ''; }
  rpShow();
}
/* the report of the period on screen: from the memory, asked for when missing; one that reaches today follows new orders (every 15 s at most) */
function rpWant() {
  const r = UI.rp, k = rpKey(), c = r.cache[k];
  if (r.busy) return c || null;
  const live = k.split('|')[1] >= rpToday(), old = c && live && c.rev !== SRV.rev;
  if (!c && r.err !== k) rpLoad(k);
  else if (old && Date.now() - c.at >= 15000) rpLoad(k);
  else if (old && !r.timer) r.timer = setTimeout(() => { r.timer = 0; UI.dirty = true; }, 15000 - (Date.now() - c.at) + 50);
  return c || null;
}
const kfmt = n => n >= 1e6 ? `${r2(n / 1e6)}M` : n >= 1e4 ? `${r2(n / 1e3)}K` : num(n);
const niceStep = mx => { const raw = Math.max(1, mx) / 3, p = 10 ** Math.floor(Math.log10(raw)); return [1, 2, 2.5, 5, 10].find(k => k * p >= raw) * p; };
/* sales by day, or by month when the period is longer than a month; the best day carries its figure until another bar is tapped */
function rpPoints(d) {
  const t = rpToday(), W = DAYS[S.lang];
  if (d.days.length <= 31) return d.days.map(x => { const dt = new Date(x.day + 'T12:00:00Z'); return {lb:String(+x.day.slice(8)), full:`${W[dt.getUTCDay()]} ${x.day.slice(8)}/${x.day.slice(5, 7)}`, v:x.sales, n:x.n, now:x.day === t}; });
  const by = {};
  d.days.forEach(x => { const k = x.day.slice(0, 7), b = by[k] || (by[k] = {v:0, n:0}); b.v += x.sales; b.n += x.n; });
  return Object.keys(by).sort().map(k => { const M = MONTHS[S.lang][+k.slice(5) - 1]; return {lb:M.slice(0, S.lang === 'ar' ? 6 : 3), full:`${M} ${k.slice(0, 4)}`, v:r2(by[k].v), n:by[k].n, now:k === t.slice(0, 7)}; });
}
function rpChart(pts) {
  const mx = Math.max(0, ...pts.map(x => x.v)), step = niceStep(mx), top = step * 3, every = Math.ceil(pts.length / 8);
  const best = mx > 0 ? pts.findIndex(x => x.v === mx) : -1, sel = UI.rp.bar >= 0 && UI.rp.bar < pts.length ? UI.rp.bar : best;
  const ticks = [0, 1, 2, 3].map(i => `<span style="bottom:${i * 100 / 3}%">${kfmt(i * step)}</span>`).join('');
  const lines = [0, 1, 2, 3].map(i => `<div class="gl" style="bottom:${i * 100 / 3}%"></div>`).join('');
  const bars = pts.map((x, i) => {
    const h = x.v > 0 ? Math.max(1.5, x.v / top * 100) : 0;
    return `<button class="bar ${i === sel ? 'sel' : ''}" data-a="rpBar" data-i="${i}" aria-label="${esc(x.full)}: ${fmt(x.v)} ${T('ر.س', 'SAR')}, ${x.n} ${T('طلب', 'orders')}"><span class="cm"><i style="height:${h}%"></i><em class="tip" style="bottom:calc(${h}% + 5px)">${fmt(x.v)}</em></span><span class="bd">${i % every === 0 ? esc(x.lb) : ''}</span></button>`;
  }).join('');
  const s = pts[sel];
  return `<div class="chart rpc" role="group" aria-label="${T('المبيعات حسب اليوم', 'Sales by day')}"><div class="yax">${ticks}</div><div class="plot"><div class="gls">${lines}</div><div class="bars">${bars}</div></div></div>
    ${s ? `<p class="ch-n">${esc(s.full)}: ${s.n} ${T('طلب', 'orders')} · ${moneyT(s.v)}</p>` : ''}`;
}
function rpTable(pts, months) {
  return `<table class="tbl dk"><thead><tr><th>${months ? T('الشهر', 'Month') : T('اليوم', 'Day')}</th><th>${T('الطلبات', 'Orders')}</th><th>${T('المبيعات', 'Sales')}</th></tr></thead><tbody>${pts.map(x => `<tr><td>${esc(x.full)}${x.now ? ` <small>(${months ? T('الشهر الحالي', 'this month') : T('اليوم', 'today')})</small>` : ''}</td><td>${x.n}</td><td>${money(x.v)}</td></tr>`).join('')}</tbody></table>`;
}
const rpModeName = id => ({pickup:T('استلام من الفرع', 'Pickup'), delivery:T('توصيل', 'Delivery'), ship:T('شحن', 'Shipping')}[id] || id);
const rpPayName = id => ({mada:T('مدى', 'mada'), stc:'STC Pay', wallet:T('رصيد المحفظة', 'Wallet credit')}[id] || payLabel(id));
function rpXlsxBtn() {
  const r = UI.rp;
  if (r.dl) return `<button class="btn sm line" disabled>${T('جارِ تجهيز الملف…', 'Making the file…')}</button>`;
  return `<button class="btn sm ${r.ready ? '' : 'line'}" data-a="rpXlsx">${ic('dl', 18)}${r.ready ? T('الملف جاهز، اضغط لحفظه', 'The file is ready: tap to save it') : T('تنزيل Excel', 'Download Excel')}</button>`;
}
function adReport() {
  const r = UI.rp, [f, t] = rpPeriod(), today = rpToday();
  const ps = [['today', T('اليوم', 'Today')], ['month', T('هذا الشهر', 'This month')], ['last', T('الشهر الماضي', 'Last month')], ['custom', T('فترة محددة', 'Pick dates')]];
  const chips = `<div class="seg rp-seg" role="group" aria-label="${T('الفترة', 'Period')}">${ps.map(([id, lb]) => `<button class="${r.p === id ? 'on' : ''}" data-a="rpP" data-id="${id}" aria-pressed="${r.p === id}">${lb}</button>`).join('')}</div>`;
  const cus = r.p !== 'custom' ? '' : `<section class="ac rp-cus"><div class="rp-dt"><div class="field"><label for="rpf">${T('من', 'From')}</label><input id="rpf" class="inp ltr" type="date" min="2020-01-01" max="${today}" data-bind="rp.f" value="${esc(r.f)}"></div>
      <div class="field"><label for="rpt">${T('إلى', 'To')}</label><input id="rpt" class="inp ltr" type="date" min="2020-01-01" max="${today}" data-bind="rp.t" value="${esc(r.t)}"></div></div>
      <button class="btn sm" data-a="rpApply" ${needAttr('rpRange')}>${T('عرض التقرير', 'Show the report')}</button><small class="grey">${T('البداية قبل النهاية، والمدة سنة على الأكثر', 'The start comes first; one year at most')}</small></section>`;
  const bar = `<div class="rp-bar"><b>${esc(rpLabel(f, t))}</b>${rpXlsxBtn()}</div>`;
  const c = rpWant();
  if (!c) {
    const k = rpKey();
    const body = r.err === k ? `<div class="colx">${ic('info', 30)}<p>${esc(r.msg)}</p><button class="btn sm" data-a="rpRetry">${T('حاول مرة أخرى', 'Try again')}</button></div>`
      : `<div class="colx" aria-busy="true">${ic('report', 30)}<p>${T('جارِ تجهيز التقرير…', 'Making the report…')}</p></div>`;
    return chips + cus + bar + body;
  }
  const d = c.d, s = d.sum, pts = rpPoints(d), longP = d.days.length > 31;
  const hero = `<section class="hero"><small>${T('المبيعات', 'Sales')}</small><b class="hero-v">${money(s.sales)}</b><small>${T(`${s.n} طلب · شامل الضريبة`, `${s.n} orders · incl. VAT`)}</small>
    <div class="ch-h"><span>${longP ? T('المبيعات حسب الشهر', 'Sales by month') : T('المبيعات حسب اليوم', 'Sales by day')}</span><button class="sbb sm" data-a="rpTbl">${r.tbl ? T('الرسم', 'Chart') : T('جدول', 'Table')}</button></div>
    ${r.tbl ? rpTable(pts, longP) : rpChart(pts)}${longP ? `<p class="ch-n">${T('التفاصيل اليومية في ملف Excel.', 'The day-by-day figures are in the Excel file.')}</p>` : ''}</section>`;
  const kpis = `<div class="kpis"><div class="kpi"><small>${T('عدد الطلبات', 'Orders')}</small><b>${num(s.n)}</b></div><div class="kpi"><small>${T('متوسط قيمة الطلب', 'Average order')}</small><b>${money(s.avg)}</b></div>
    <div class="kpi"><small>${T('الأصناف المباعة', 'Items sold')}</small><b>${num(s.items)}</b></div><div class="kpi"><small>${T('عدد العملاء', 'Customers')}</small><b>${num(s.cust)}</b></div></div>`;
  const brs = `<section class="ac rp-br"><h3>${T('الفروع', 'Branches')}</h3><table class="tbl"><thead><tr><th>${T('الفرع', 'Branch')}</th><th>${T('الطلبات', 'Orders')}</th><th>${T('المبيعات', 'Sales')}</th><th>${T('النسبة', 'Share')}</th></tr></thead><tbody>${d.branches.map(b => `<tr><td><b>${esc(L(b.name))}</b></td><td>${num(b.n)}</td><td>${money(b.sales)}</td><td><span class="ltr">${s.sales ? Math.round(b.sales / s.sales * 100) : 0}%</span></td></tr>`).join('')}</tbody></table></section>`;
  const shown = r.all ? d.top : d.top.slice(0, 10), mq = d.top.length ? d.top[0].qty : 1;
  const top = `<section class="ac rp-top"><h3>${T('الأكثر مبيعًا', 'Best sellers')}</h3>${shown.length ? `<ul class="top">${shown.map(p => `<li><span class="nm">${esc(L(p.name))}</span><b class="ltr">${num(p.qty)}</b><span class="tb"><i style="width:${Math.max(6, p.qty / mq * 100)}%"></i></span><small class="grey">${money(p.sales)}${p.free ? ` · ${T(`${p.free} مجانًا`, `${p.free} free`)}` : ''}</small></li>`).join('')}</ul>
      ${d.top.length > 10 ? `<button class="btn text" data-a="rpAll">${r.all ? T('عرض أقل', 'Show fewer') : T(`عرض الكل (${d.top.length})`, `Show all (${d.top.length})`)}</button>` : ''}${d.np > d.top.length && r.all ? `<p class="note">${T('بقية المنتجات في ملف Excel.', 'The other products are in the Excel file.')}</p>` : ''}`
    : `<p class="grey">${T('لا توجد مبيعات في هذه الفترة', 'No sales in this period')}</p>`}</section>`;
  const kv = (a, b) => `<div class="kv"><span>${a}</span><span>${b}</span></div>`;
  const amounts = `<section class="ac rp-amt"><h3>${T('تفاصيل المبالغ', 'Amounts')}</h3>${kv(T('المبيعات بدون الضريبة', 'Sales without VAT'), money(s.net))}${kv(T('ضريبة القيمة المضافة', 'VAT'), money(s.vat))}
    ${kv(T('الخصومات (أكواد الخصم)', 'Discounts (codes)'), money(s.disc))}${kv(T('رسوم التوصيل والشحن', 'Delivery and shipping fees'), money(s.fees))}
    ${s.bal ? kv(T('مدفوع من رصيد المحفظة', 'Paid from wallet credit'), money(s.bal)) : ''}${s.rej ? kv(T('طلبات مرفوضة (غير محسوبة)', 'Rejected orders (not counted)'), `<span class="ltr">${s.rej}</span>`) : ''}</section>`;
  const ways = d.modes.length || d.pays.length ? `<section class="ac rp-ways"><h3>${T('طريقة الطلب', 'How customers ordered')}</h3>${d.modes.map(m => kv(esc(rpModeName(m.id)), `${T(`${m.n} طلب`, `${m.n} orders`)} · ${money(m.sales)}`)).join('')}
    <h3 class="rp-h">${T('طريقة الدفع', 'How they paid')}</h3>${d.pays.map(p => kv(esc(rpPayName(p.id)), `${p.n ? T(`${p.n} طلب · `, `${p.n} orders · `) : ''}${money(p.amount)}`)).join('')}</section>` : '';
  const note = `<p class="note">${T('المبيعات شاملة الضريبة ولا تشمل الطلبات المرفوضة. ملف Excel فيه كل طلب بالتفصيل.', 'Sales include VAT and leave out rejected orders. The Excel file lists every order.')}</p>`;
  return `${chips}${cus}${bar}<div class="ov rp"><div class="ov-a">${hero}${brs}${amounts}</div><div class="ov-b">${kpis}${top}${ways}</div></div>${note}`;
}
/* the Excel file: on a phone the share sheet (save to Files, WhatsApp, Mail...); on a computer a download */
function rpGive(f) {
  if (matchMedia('(pointer: coarse)').matches && navigator.canShare && navigator.canShare({files:[f]})) {
    navigator.share({files:[f]}).then(() => { UI.rp.ready = false; UI.dirty = true; }).catch(e => {
      if (e && e.name === 'NotAllowedError') { UI.rp.ready = true; UI.dirty = true; }   /* the tap went stale while the file was made: one more tap */
    });
    return;
  }
  const u = URL.createObjectURL(f), a = document.createElement('a');
  a.href = u; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 60000);
  toast(T('تم تنزيل ملف Excel', 'The Excel file was downloaded'));
}

function adPromo() {
  const codes = Object.entries(SRV.codes || {}).sort(),
    used = c => SRV.orders.filter(o => o.dcode === c && !o.rej).length;
  const rows = codes.map(([c, v]) => `<div class="srow"><span class="grow"><b class="ltr">${esc(c)}</b><small>${v.on ? T('فعّال: يطبّقه العميل عند إكمال الطلب', 'On: customers can apply it at checkout') : T('متوقف: يظهر للعميل أن الكود غير صحيح', 'Off: customers see it as invalid')}</small></span><button class="pbtn" data-a="edPct" data-id="${esc(c)}" aria-label="${T('نسبة الخصم', 'Discount')}">${v.pct}%${ic('pencil', 14)}</button>${sw(v.on, 'adCode', `data-id="${esc(c)}"`, c)}</div>`).join('');
  const all = bannersAll();
  const bnThumb = b => b.img ? `<span class="bn-th" style="background-image:url(/api/img/${b.img.id}/t)"></span>` : IMG.hb && IMG.hb[b.id] ? `<span class="bn-th im-hb-${b.id}"></span>` : `<span class="bn-th" style="background:${b.bg}"></span>`;
  const bn = all.map((b, k) => `<div class="srow bnrow">${bnThumb(b)}<span class="grow"><b>${esc(L(b.t) || T('إعلان بصورة', 'Picture banner'))}</b><small>${esc(L(b.s))}</small></span>
    <button class="pbtn" data-a="bnMove" data-id="${b.id}" data-d="up" ${k ? '' : 'disabled'} aria-label="${T('لأعلى', 'Up')}">${ic('up', 15)}</button><button class="pbtn" data-a="bnMove" data-id="${b.id}" data-d="down" ${k < all.length - 1 ? '' : 'disabled'} aria-label="${T('لأسفل', 'Down')}">${ic('chevdown', 15)}</button>
    <button class="pbtn" data-a="bnEdit" data-id="${b.id}" aria-label="${esc(T(`تعديل ${L(b.t)}`, `Edit ${L(b.t)}`))}">${ic('pencil', 14)}</button>${sw(SRV.bn[b.id] !== false, 'adBn', `data-id="${b.id}"`, L(b.t))}</div>`).join('');
  const tlThumb = v => v.img ? `<span class="tl-th" style="background-image:url(/api/img/${v.img.id}/t)"></span>` : IMG.ht && IMG.ht[v.id] ? `<span class="tl-th im-ht-${v.id}"></span>` : `<span class="tl-th">${art(v.art, v.tone)}</span>`;
  const tlRow = k => { const v = tileView(k); return `<div class="srow tlrow tlrow-${k}">${tlThumb(v)}<span class="grow"><b>${esc(L(v.t))}</b><small>${esc(L(v.s))}</small></span><button class="pbtn" data-a="tlEdit" data-id="${k}" aria-label="${esc(T(`تعديل ${L(v.t)}`, `Edit ${L(v.t)}`))}">${ic('pencil', 14)}</button></div>`; };
  const tl = ['order', 'gift'].map(tlRow).join('');
  const rw = (SRV.rewards || []).map(r => `<div class="srow"><span class="grow"><b>${esc(L(r))}</b><small>${ic('star', 12)} ${num(r.pts)} ${T('نقطة', 'points')}${r.pid && !liveP(r.pid) ? ` · ${T('المنتج لم يعد في القائمة', 'the product left the menu')}` : ''}</small></span>
    <button class="pbtn" data-a="rwEdit" data-id="${r.id}" aria-label="${esc(T(`تعديل ${L(r)}`, `Edit ${L(r)}`))}">${ic('pencil', 14)}</button>${sw(r.on !== false, 'rwOn', `data-id="${r.id}"`, L(r))}</div>`).join('');
  const days = SRV.tdays || TIER_DAYS;
  const tiers = SRV.tiers.map(t => `<div class="srow"><span class="grow"><b>${esc(L(TIER_NAME[t.id]))}</b><small>${t.min ? T(`تفتح عند ${num(t.min)} نقطة خلال ${days} يوم`, `Opens at ${num(t.min)} points in ${days} days`) : T('لكل العملاء من أول طلب', 'Every customer, from the first order')}</small></span><button class="pbtn" data-a="edTier" data-id="${t.id}" aria-label="${esc(T(`تعديل ${L(TIER_NAME[t.id])}`, `Edit ${L(TIER_NAME[t.id])}`))}">${num(t.per10)} ${T('لكل', 'per')} ${money(10)}${ic('pencil', 14)}</button></div>`).join('');
  return `<section class="ac tiers"><h3>${T('مستويات العضوية', 'Membership tiers')}</h3><p class="grey" style="margin-bottom:4px;line-height:1.6">${T(`النقاط التي يكسبها العميل لكل 10 ريال حسب مستواه، والمستوى حسب نقاطه خلال آخر ${days} يوم. التعديل يطبّق على الطلبات القادمة.`, `Points a customer earns for every 10 SAR by tier; the tier follows his points of the last ${days} days. A change applies to the next orders.`)}</p>${tiers}</section>
    <section class="ac"><h3>${T('المكافآت', 'Rewards')}</h3><p class="grey" style="margin-bottom:4px;line-height:1.6">${T('ما يستبدله العميل بنقاطه. المفتاح يوقف المكافأة ويعيدها.', 'What customers redeem their points for. The switch pauses a reward.')}</p>${rw || `<p class="grey">${T('لا توجد مكافآت', 'No rewards')}</p>`}
      <div class="rw-add"><button class="btn line sm" data-a="rwAdd" data-k="p">${ic('plus', 18)}${T('مكافأة منتج', 'Product reward')}</button><button class="btn line sm" data-a="rwAdd" data-k="c">${ic('plus', 18)}${T('رصيد في المحفظة', 'Wallet credit')}</button></div></section>
    <section class="ac"><h3>${T('أكواد الخصم', 'Discount codes')}</h3>${rows || `<p class="grey">${T('لا توجد أكواد', 'No codes')}</p>`}<button class="btn line sm" style="margin-top:12px" data-a="codeAdd">${ic('plus', 18)}${T('إضافة كود', 'Add a code')}</button></section>
    <section class="ac"><h3>${T('التوصيل', 'Delivery')}</h3>
      <div class="srow"><span class="grow"><b>${T('التوصيل بالمناديب', 'Delivery with drivers')}</b><small>${deliveryOn() ? T('يعمل: يظهر خيار التوصيل للعميل ويصل الطلب للمناديب', 'On: customers can choose delivery and drivers get the orders') : T('متوقف: لا يظهر خيار التوصيل للعميل', 'Off: customers cannot choose delivery')}</small></span>${sw(deliveryOn(), 'adDelOn', '', T('التوصيل', 'Delivery'))}</div>
      <div class="srow"><span class="grow"><b>${T('رسوم التوصيل', 'Delivery fee')}</b><small>${T('تُضاف على كل طلب توصيل (شاملة الضريبة).', 'Added to every delivery order (including VAT).')}</small></span><button class="pbtn" data-a="edDel">${money(deliveryFee())}${ic('pencil', 14)}</button></div>
      <div class="srow"><span class="grow"><b>${T('الحد الأدنى لطلب التوصيل', 'Smallest delivery order')}</b><small>${deliveryMin() ? T('قيمة الأصناف قبل رسوم التوصيل', 'The items, before the delivery fee') : T('بدون حد أدنى', 'No minimum')}</small></span><button class="pbtn" data-a="edDelMin">${deliveryMin() ? money(deliveryMin()) : T('بدون', 'None')}${ic('pencil', 14)}</button></div>
      <div class="srow"><span class="grow"><b>${T('نطاق التوصيل', 'Delivery area')}</b><small>${deliveryKm() ? T(`حتى ${fmtKm(deliveryKm())} كم من الفرع، والعميل يحدد موقعه على الخريطة. فرع بلا موقع على الخريطة لا يُقاس.`, `Up to ${fmtKm(deliveryKm())} km from the branch; the customer sets the spot on the map. A branch with no place on the map is not measured.`) : T('بدون حد للمسافة', 'No distance limit')}</small></span><button class="pbtn" data-a="edDelKm">${deliveryKm() ? `${fmtKm(deliveryKm())} ${T('كم', 'km')}` : T('بدون', 'None')}${ic('pencil', 14)}</button></div></section>
    <section class="ac"><h3>${T('الشحن', 'Shipping')}</h3><div class="srow"><span class="grow"><b>${T('رسوم الشحن', 'Shipping fee')}</b><small>${T('تُضاف على طلبات الحبوب المشحونة، ومجانية على مجموعة المذاق.', 'Added to shipped bean orders, and free on the taste collection.')}</small></span><button class="pbtn" data-a="edShip">${money(SRV.ship)}${ic('pencil', 14)}</button></div></section>
    <section class="ac"><h3>${T('إعلانات الصفحة الرئيسية', 'Home page banners')}</h3>${bn}<button class="btn line sm" style="margin-top:12px" data-a="bnAdd">${ic('plus', 18)}${T('إضافة إعلان', 'Add a banner')}</button></section>
    <section class="ac"><h3>${T('مربعات الصفحة الرئيسية', 'Home page tiles')}</h3><p class="grey" style="margin-bottom:4px;line-height:1.6">${T('«اطلب الآن» و«أرسل هدية»: صورتهما وكلامهما.', '«Order now» and «Send a gift»: their photo and words.')}</p>${tl}</section>
    <section class="ac"><h3>${T('شاشة الترحيب', 'Welcome screen')}</h3><p class="grey" style="margin-bottom:4px;line-height:1.6">${T('أول شاشة يشوفها العميل لما يفتح التطبيق قبل تسجيل الدخول: صورتها وكلامها.', 'The first screen a customer sees when opening the app before signing in: its photo and words.')}</p>${tlRow('welcome')}</section>
    <p class="note">${T(`كود الخصم استُخدم ${codes.reduce((a, [c]) => a + used(c), 0)} مرة في آخر 14 يومًا.`, `Codes were used ${codes.reduce((a, [c]) => a + used(c), 0)} times in the last 14 days.`)}</p>`;
}

function adDrivers() {
  const list = SRV.drivers || [];
  return `<p class="note">${T('كل مندوب له اسم ورمز سري خاص به، يدخل بهما من رابط المندوب. الطلب الجاهز للتوصيل يصل لكل المناديب المتاحين، وأول من يأخذه يوصله.', 'Every driver has a name and a secret code of his own, and signs in with them on the driver link. A ready delivery reaches every free driver, and the first to take it brings it.')}</p>
    <section class="ac flush">${list.map(d => `<div class="acu drvrow ${d.active ? '' : 'off'}"><span class="av">${esc(d.name.charAt(0))}</span><span class="grow"><b>${esc(d.name)}</b><small>${d.active ? (d.busy ? T(`معه ${d.busy} طلب الآن`, `${d.busy} order(s) now`) : T('متاح', 'Free')) : T('موقوف', 'Switched off')}${d.phone ? ` · <span class="ltr">0${esc(d.phone)}</span>` : ''}</small></span>
      <button class="pbtn" data-a="drvPhoneEd" data-id="${d.id}" aria-label="${T('رقم الجوال', 'Mobile number')}">${ic('phone', 16)}</button><button class="pbtn" data-a="drvPin" data-id="${d.id}" aria-label="${T('تغيير الرمز', 'Change the code')}">${ic('key', 16)}</button>${sw(d.active, 'drvOn', `data-id="${d.id}"`, d.name)}<button class="pbtn" data-a="drvDel" data-id="${d.id}" aria-label="${T('حذف', 'Remove')}">${ic('trash', 16)}</button></div>`).join('') || `<p class="grey" style="padding:14px 0">${T('لا يوجد مناديب بعد', 'No drivers yet')}</p>`}</section>
    <button class="btn" data-a="drvAdd">${ic('userplus', 20)}${T('إضافة مندوب', 'Add a driver')}</button>`;
}

function adCust() {
  return `<section class="ac flush">${(SRV.cust || []).map(c => `<button class="acu" data-a="edPts" data-id="${c.id}"><span class="av">${esc(c.name.charAt(0))}</span><span class="grow"><b>${esc(c.name)}</b><small><span class="ltr">•••${esc(c.tail)}</span> · ${T(`${c.orders} طلب`, `${c.orders} orders`)} · ${money(c.spent)}${c.tier ? ` · ${esc(L(TIER_NAME[c.tier] || MEMBER))}` : ''}${c.bal ? ` · ${T('المحفظة', 'Wallet')} ${money2(c.bal)}` : ''}</small></span><span class="pts"><b>${num(c.pts)}</b><small>${T('نقطة', 'pts')}</small></span></button>`).join('') || `<p class="grey" style="padding:14px 0">${T('لا يوجد عملاء بعد', 'No customers yet')}</p>`}</section>
    <p class="note">${T('اضغط على العميل لإضافة نقاط له، تصله في أقرب وقت.', 'Tap a customer to add points. They reach his phone within moments.')}</p>`;
}

function adSet() {
  return `<section class="ac"><h3>${T('التشغيل', 'Operations')}</h3>
      <div class="srow"><span class="grow"><b>${T('تنبيه صوتي', 'Sound alert')}</b><small>${T('على هذا الجهاز فقط', 'On this device only')}</small></span>${sw(S.sound, 'sound', '', T('تنبيه صوتي', 'Sound'))}</div></section>
    <section class="ac"><h3>${T('الرموز السرية', 'Secret codes')}</h3><p class="grey" style="margin-bottom:10px;line-height:1.6">${T('تغيير الرمز يتطلب رمز الإدارة الحالي. رموز المناديب من تبويب المناديب.', 'Changing a code needs the current admin code. Driver codes are in the Drivers tab.')}</p>
      <button class="btn line" data-a="pinChange" data-id="admin">${ic('key', 18)}${T('تغيير رمز الإدارة', 'Change the admin code')}</button>
      <button class="btn line" style="margin-top:10px" data-a="pinChange" data-id="recv">${ic('key', 18)}${T('تغيير رمز الاستقبال', 'Change the order desk code')}</button></section>
    ${taxCard()}${backupCard()}
    <section class="ac"><h3>${T('الحساب', 'Account')}</h3><button class="btn line" data-a="signOut">${ic('logout', 18)}${T('تسجيل الخروج', 'Sign out')}</button></section>
    <section class="ac"><h3>${T('قبل الإطلاق', 'Before launch')}</h3><p class="grey" style="margin-bottom:12px;line-height:1.6">${T('يحذف كل الطلبات والعملاء المسجلين في الخادم (طلبات التجربة)، وتبقى المنتجات والأسعار والفروع والمناديب كما هي. لا يمكن التراجع.', 'Deletes every order and customer kept on the server (test orders). Products, prices, branches and drivers stay. This cannot be undone.')}</p><button class="btn line danger" data-a="wipeAsk">${T('حذف الطلبات والعملاء', 'Delete orders and customers')}</button></section>`;
}

/* 0.7: the seller on the simplified tax invoice (ZATCA phase 1). Empty until the VAT number is entered. */
function taxCard() {
  const t = SRV.tax;
  const rows = t ? [[T('اسم المنشأة', 'Business name'), esc(t.name)], [T('الرقم الضريبي', 'VAT number'), `<span class="ltr">${esc(t.vat)}</span>`]].concat(t.cr ? [[T('السجل التجاري', 'Commercial registration'), `<span class="ltr">${esc(t.cr)}</span>`]] : []).concat(t.addr ? [[T('العنوان', 'Address'), esc(t.addr)]] : []) : [];
  return `<section class="ac"><h3>${T('الفاتورة الضريبية', 'Tax invoice')}</h3><p class="grey" style="margin-bottom:10px;line-height:1.6">${t ? T('كل طلب جديد معه فاتورة ضريبية مبسطة برمز QR (المرحلة الأولى من الفوترة الإلكترونية)، يراها العميل في طلبه وتُطبع مع إيصال الطلب من شاشة الاستقبال.', 'Every new order has a simplified tax invoice with a QR code (e-invoicing phase one). The customer sees it in the order, and the order desk prints it with the ticket.') : T('عند إدخال الرقم الضريبي تظهر للعميل فاتورة ضريبية مبسطة برمز QR لكل طلب جديد، وتُطبع مع إيصال الطلب.', 'Once the VAT number is entered, every new order gets a simplified tax invoice with a QR code, and it prints with the ticket.')}</p>
    ${rows.map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('')}
    <button class="btn line" style="margin-top:10px" data-a="taxEdit">${ic(t ? 'pencil' : 'plus', 18)}${t ? T('تعديل البيانات', 'Edit the details') : T('إدخال الرقم الضريبي', 'Enter the VAT number')}</button>${t ? `<button class="btn text dngt" data-a="taxOff">${T('إيقاف الفاتورة الضريبية', 'Switch the tax invoice off')}</button>` : ''}</section>`;
}
/* the copy goes where the admin keeps files: on a phone the share sheet (Save to Files, Google Drive...), on a computer a
   download. A phone wants that inside a fresh tap: when the file took too long, one more tap on "save the copy". */
function giveCopy() {
  const f = UI.dbFile; if (!f) return;
  if (matchMedia('(pointer: coarse)').matches && navigator.canShare && navigator.canShare({files:[f]})) {
    navigator.share({files:[f]}).then(() => { UI.dbFile = null; UI.dirty = true; toast(T('تم حفظ النسخة', 'The copy was saved')); })
      .catch(e => { if (!(e && e.name === 'NotAllowedError')) UI.dbFile = null; UI.dirty = true; });
    return;
  }
  const u = URL.createObjectURL(f), a = document.createElement('a');
  a.href = u; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 60000);
  UI.dbFile = null; toast(T('تم تنزيل النسخة', 'The copy was downloaded'));
}
/* 0.7.7: the copy that goes out by e-mail every day, locked with a password (set on the server: why_server.py mailkey) */
function mailLine(m) {
  if (!m) return '';
  const to = m.to.join('، ');
  const err = m.err === 'big' ? T('نسخة اليوم كبيرة على الإيميل فلم تُرفق، نزّل نسخة من هنا.', 'Today’s copy was too big for e-mail; download one here.')
    : m.err ? T('آخر محاولة إرسال لم تنجح، ويعيد الخادم المحاولة بعد قليل.', 'The last try to send did not work; the server tries again shortly.') : '';
  return `<p class="grey" style="margin-bottom:10px;line-height:1.6">${T(`تُرسل نسخة مقفلة بكلمة سر كل يوم الساعة ${m.hour}:00 إلى ${esc(to)}.${m.ok ? ` آخر إرسال: ${m.ok}.` : ''}`, `A password-locked copy is e-mailed every day at ${m.hour}:00 to ${esc(to)}.${m.ok ? ` Last sent: ${m.ok}.` : ''}`)}</p>${err ? `<p style="color:var(--red);margin-bottom:10px;line-height:1.6">${err}</p>` : ''}`;
}
/* 0.7: the server keeps a copy every day on itself; the admin can take one away too */
function backupCard() {
  const b = SRV.backups || {n:0, last:'', keep:14};
  return `<section class="ac"><h3>${T('النسخ الاحتياطي', 'Backups')}</h3><p class="grey" style="margin-bottom:10px;line-height:1.6">${T(`يحفظ الخادم نسخة من البيانات كل يوم ويبقي آخر ${b.keep} نسخة، لكنها على نفس الخادم.${b.last ? ` آخر نسخة: ${b.last}.` : ''} لحماية أفضل نزّل نسخة من وقت لآخر واحفظها خارج الخادم (جهازك أو Google Drive). فيها بيانات العملاء، فاحفظها في مكان آمن.`, `The server keeps a copy of the data every day and the last ${b.keep} of them, but on the same server.${b.last ? ` Last copy: ${b.last}.` : ''} For better safety, download a copy now and then and keep it off the server (your computer or Google Drive). It holds the customers' details: keep it somewhere safe.`)}</p>
    ${mailLine(b.mail)}
    ${UI.dbFile ? `<button class="btn" data-a="dbGive">${ic('down', 18)}${T('حفظ النسخة', 'Save the copy')}</button>` : `<button class="btn line" data-a="dbCopy">${ic('down', 18)}${T('تنزيل نسخة الآن', 'Download a copy now')}</button>`}
    <p class="note" style="margin-top:8px">${T('الملف مضغوط (zip) وفيه قاعدة البيانات وورقة تشرحها. هو للاسترجاع عند الحاجة، لا للقراءة: لو فتحته يظهر رموزًا غير مفهومة، وهذا طبيعي.', 'The file is a zip with the database and a note about it. It is for restoring if ever needed, not for reading: opened, it shows unreadable signs, which is normal.')}</p></section>`;
}

function scrMain() {
  const secs = ADM(), cur = UI.ad.sec, more = ['report', 'news', 'promo', 'drivers', 'cust', 'set'].includes(cur);
  const body = ({home:adHome, orders:adOrders, menu:adMenu, branches:adBranches, report:adReport, news:adNews, promo:adPromo, drivers:adDrivers, cust:adCust, set:adSet}[cur] || adHome)();
  const title = (secs.find(s => s[0] === cur) || secs[0])[1];
  const bottom = secs.slice(0, 4).map(([id, lb, ico]) => `<button class="${cur === id ? 'on' : ''}" data-a="adSec" data-id="${id}" ${cur === id ? 'aria-current="page"' : ''}>${ic(ico, 22)}<span>${lb}</span></button>`).join('') + `<button class="${more ? 'on' : ''}" data-a="adMore">${ic('dots', 22)}<span>${T('المزيد', 'More')}</span></button>`;
  return `<div class="screen sx adm">
    ${sbar(T('لوحة الإدارة', 'Admin dashboard'), T('إدارة المقهى', 'Manage the café'), `<button class="sbb ${S.sound ? 'on' : ''}" data-a="sound" aria-label="${T('التنبيه الصوتي', 'Sound alert')}">${ic(S.sound ? 'bell' : 'bellx', 19)}</button><button class="sbb" data-a="signOut" aria-label="${T('تسجيل الخروج', 'Sign out')}">${ic('logout', 18)}</button>`)}
    <div class="adm-b"><nav class="adm-side" aria-label="${T('الأقسام', 'Sections')}">${secs.map(([id, lb, ico]) => `<button class="${cur === id ? 'on' : ''}" data-a="adSec" data-id="${id}">${ic(ico, 22)}<span>${lb}</span></button>`).join('')}</nav>
      <main class="adm-main"><h1 class="adm-t">${title}</h1><div class="scroll adm-sc" data-sk="ad-${cur}">${body}</div></main></div>
    <nav class="adm-tabs" aria-label="${T('الأقسام', 'Sections')}">${bottom}</nav></div>`;
}

/* ---------- sheets ---------- */
SHEETS.more = function () {
  const row = (id, ico, t, s) => miRow(ico, t, s, `data-a="adSec" data-id="${id}"`);
  return sheetWrap(`<div class="sbody"><h2 class="sttl">${T('المزيد', 'More')}</h2>
    ${row('report', 'report', T('التقارير', 'Reports'), T('المبيعات لأي فترة، وتنزيلها ملف Excel', 'Sales for any period, and an Excel file'))}
    ${row('news', 'book', T('الأخبار', 'News'), T('أضف خبرًا بصورة، وعدّله أو أوقفه', 'Add news with a photo; edit or pause it'))}
    ${row('promo', 'tag', T('العروض والرسوم', 'Offers and fees'), T('مستويات العضوية وأكواد الخصم والتوصيل والشحن والإعلانات ومربعات الرئيسية وشاشة الترحيب', 'Membership tiers, discount codes, delivery, shipping, banners, home tiles and the welcome screen'))}
    ${row('drivers', 'moto', T('المناديب', 'Drivers'), T('إضافة المناديب وإدارة رموزهم', 'Add drivers and manage their codes'))}
    ${row('cust', 'user', T('العملاء', 'Customers'), T('النقاط والطلبات', 'Points and orders'))}
    ${row('set', 'gear', T('الإعدادات', 'Settings'), T('الرموز السرية والخروج', 'Secret codes and sign-out'))}</div>`, T('المزيد', 'More'));
};
SHEETS.odetail = function () {
  const o = ordById(UI.sheet.id); if (!o) return '';
  return sheetWrap(`<div class="sbody" data-sk="sheet">${ticket(o)}</div>`, `${T('طلب', 'Order')} ${o.no}`);
};

/* one small form for everything the admin types: a number, a code, a name with a secret code */
/* a Saudi mobile as the server keeps it (5XXXXXXXX), from 05…, 5… or +9665…; '' if it is not one */
const drvPh = v => { let p = String(v || '').replace(/\D/g, ''); if (p.startsWith('966')) p = p.slice(3); if (p.startsWith('0')) p = p.slice(1); return /^5\d{8}$/.test(p) ? p : ''; };
const openForm = cfg => { UI.fm = Object.assign({v:{}, fields:[], ok:T('حفظ', 'Save'), valid:() => true}, cfg); UI.focus = '.sheet .inp'; openSheet({k:'form'}); };
NEED.fm = () => !!UI.fm && UI.fm.valid(UI.fm.v) && !UI.busy;
SHEETS.form = function () {
  const f = UI.fm;
  const fields = f.fields.map(x => {
    const common = `data-bind="fm.v.${x.k}" data-enter="fmSave" autocomplete="off" value="${esc(f.v[x.k] == null ? '' : f.v[x.k])}"`;
    if (x.type === 'num') return `<div class="field"><label>${esc(x.label)}</label><div class="phone"><span class="cc">${esc(x.unit)}</span><input class="inp ltr" type="text" inputmode="decimal" data-fmt="num" ${common}></div></div>`;
    if (x.type === 'int') return `<div class="field"><label>${esc(x.label)}</label><input class="inp ltr" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="${x.max || 10}" data-fmt="digits" placeholder="${esc(x.ph || '')}" ${common}></div>`;
    if (x.type === 'choice') return `<div class="field" role="radiogroup" aria-label="${esc(x.label)}"><label>${esc(x.label)}</label>${x.items.map(([val, t, sub]) => `<button type="button" class="opt ${f.v[x.k] === val ? 'on' : ''} ${x.dis ? 'dis' : ''}" data-a="fmPick" data-k="${x.k}" data-v="${val}" role="radio" aria-checked="${f.v[x.k] === val}" ${x.dis ? 'disabled' : ''}><span class="mk"></span><span class="grow"><b>${esc(t)}</b>${sub ? `<small class="grey" style="display:block;font-weight:400">${esc(sub)}</small>` : ''}</span></button>`).join('')}${x.note ? `<p class="note">${esc(x.note)}</p>` : ''}</div>`;
    if (x.type === 'digits') return `<div class="field"><label>${esc(x.label)}</label><input class="inp ltr pinin" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="${x.max || 10}" data-fmt="digits" placeholder="${esc(x.ph || '••••••')}" ${common}></div>`;
    return `<div class="field"><label>${esc(x.label)}</label><input class="inp" type="text" maxlength="${x.max || 40}" placeholder="${esc(x.ph || '')}" ${x.upper ? 'style="text-transform:uppercase" autocapitalize="characters"' : ''} ${x.ltr ? 'dir="ltr"' : ''} ${common}></div>`;
  }).join('');
  const info = (f.info || []).map(([k, v, ltr]) => `<div class="kv"><span>${esc(k)}</span><b class="${ltr ? 'ltr' : ''}">${esc(v)}</b></div>`).join('');
  return sheetWrap(`<div class="sbody"><h2 class="sttl">${esc(f.title)}</h2>${f.sub ? `<p class="ssub">${esc(f.sub)}</p>` : ''}${info ? `<div class="kvs">${info}</div>` : ''}${fields}
    <button class="btn ${f.danger ? 'dng' : ''}" ${needAttr('fm')} data-a="fmSave">${esc(f.ok)}</button>
    ${f.extra ? `<button class="btn text" data-a="fmExtra">${esc(f.extra)}</button>` : ''}</div>`, f.title);
};

const pinOk = p => /^\d{6,10}$/.test(p || '');
const numIn = (v, lo, hi) => { const n = Number(v); return v !== '' && v != null && isFinite(n) && n >= lo && n <= hi; };

/* ---------- the product form: everything a customer sees about a product ---------- */
const LBK = Object.keys(LB);   /* the usual detail rows of a roastery product (data.js): origin, process, flavours ... */
const lbKey = k => LBK.find(x => LB[x][0] === (k && k.ar)) || '_own';
const two = (a, b) => ({ar:(a || '').trim(), en:(b || '').trim()});
function peOpen(p) {
  const v = p ? {
    ar:p.ar, en:p.en || '', price:String(p.price), cats:(p.cats || [p.cat]).filter(id => CAT[id] && !CAT[id].gone), opts:pOpts(p),
    dar:p.desc ? p.desc.ar : '', den:p.desc ? p.desc.en : '', stock:p.stock !== false, fship:!!p.fship, img:pm(p),
    sar:p.sub ? p.sub.ar : '', sen:p.sub ? p.sub.en : '', cal:p.cal ? String(p.cal) : '', bar:p.badge ? p.badge.ar : '', ben:p.badge ? p.badge.en : '',
    d:(p.d || []).map(r => ({kk:lbKey(r.k), k:r.k, ar:r.v.ar || '', en:r.v.en || ''})), off:(p.off || []).filter(id => BR[id])
  } : {ar:'', en:'', price:'', cats:[UI.ad.cat].filter(id => CAT[id] && !CAT[id].gone), opts:[], dar:'', den:'', stock:true, fship:false, img:null,
    sar:'', sen:'', cal:'', bar:'', ben:'', d:[], off:[]};
  UI.pe = {id:p ? p.id : null, v, v0:JSON.stringify(v), up:false, more:!!(v.sar || v.sen || v.cal || v.bar || v.ben || v.d.length), art:p ? p.art : null, tone:p ? p.tone : null};
  openSheet({k:'prod'});
}
/* until it has a photo a product shows a drawing: a new one draws like the first product of its category */
function peArt() {
  const e = UI.pe; if (e.art) return [e.art, e.tone];
  const c = e.v.cats[0], f = PRODUCTS.find(p => inCat(p, c));
  return f ? [f.art, f.tone] : [{drink:'hot', food:'cake', retail:'bag'}[(CAT[c] || {}).kind] || 'hot', '#C8965A'];
}
NEED.pe = () => { const e = UI.pe; return !!e && !e.up && !UI.busy && (e.v.ar || '').trim().length >= 2 && numIn(toLatin(e.v.price), 0.5, 50000) && e.v.cats.length > 0; };
const peDirty = () => !!UI.pe && (UI.pe.up || JSON.stringify(UI.pe.v) !== UI.pe.v0);
function detRow(r, i) {
  return `<div class="pe-dr"><div class="pe-dr-h"><select class="inp" data-bind="pe.v.d.${i}.kk" aria-label="${T('عنوان السطر', 'Row label')}">${LBK.map(k => `<option value="${k}" ${r.kk === k ? 'selected' : ''}>${esc(T(LB[k][0], LB[k][1]))}</option>`).join('')}${r.kk === '_own' ? `<option value="_own" selected>${esc(L(r.k))}</option>` : ''}</select>
    <button type="button" class="ibtn" data-a="peDetDel" data-i="${i}" aria-label="${T('حذف السطر', 'Remove the row')}">${ic('trash', 17)}</button></div>
    <input class="inp" type="text" maxlength="160" data-bind="pe.v.d.${i}.ar" value="${esc(r.ar)}" placeholder="${T('القيمة بالعربي', 'Value in Arabic')}" autocomplete="off" aria-label="${T('القيمة بالعربي', 'Value in Arabic')}">
    <input class="inp" type="text" maxlength="160" dir="ltr" data-bind="pe.v.d.${i}.en" value="${esc(r.en)}" placeholder="${T('القيمة بالإنجليزي (اختياري)', 'Value in English (optional)')}" autocomplete="off" aria-label="${T('القيمة بالإنجليزي', 'Value in English')}"></div>`;
}
SHEETS.prod = function () {
  const e = UI.pe; if (!e) return '';
  const v = e.v, isNew = !e.id, kind = v.cats.length ? (CAT[v.cats[0]] || {}).kind : '';
  const [art, tone] = peArt(), pv = {img:v.img, art, tone};
  const txt = (k, label, max, extra) => `<div class="field"><label for="pe-${k}">${label}</label><input id="pe-${k}" class="inp" type="text" maxlength="${max}" data-bind="pe.v.${k}" value="${esc(v[k])}" autocomplete="off" ${extra || ''}></div>`;
  const area = (k, label, extra) => `<div class="field"><label for="pe-${k}">${label}</label><textarea id="pe-${k}" class="inp" maxlength="600" rows="3" data-bind="pe.v.${k}" ${extra || ''}>${esc(v[k])}</textarea></div>`;
  const photo = `<div class="pe-ph"><span class="pe-pv" style="background:${tileBg(pv)}">${pic(pv, 'fits')}</span><div class="pe-pb">
    ${e.up ? `<span class="pe-up" role="status"><span class="spin sm"></span>${T('جاري تجهيز الصورة ورفعها…', 'Preparing and uploading the photo…')}</span>`
      : `<button type="button" class="btn sm ${v.img ? 'line' : ''}" data-a="pePhoto">${ic('photo', 18)}${v.img ? T('تغيير الصورة', 'Change the photo') : T('إضافة صورة', 'Add a photo')}</button>${v.img ? `<button type="button" class="btn sm text dngt" data-a="peNoPhoto">${ic('trash', 16)}${T('حذف الصورة', 'Remove the photo')}</button>` : ''}`}
    <small>${T('تُصغَّر الصورة تلقائيًا قبل رفعها. الأفضل صورة مربعة والمنتج في وسطها.', 'The photo is made smaller before it is sent. A square photo with the product in the middle works best.')}</small></div></div>`;
  const cats = `<div class="field"><label>${T('القسم', 'Category')}</label><div class="pe-cats">${CATS.map(c => { const on = v.cats.includes(c.id); return `<button type="button" class="chip ${on ? 'on' : ''}" data-a="peCat" data-id="${c.id}" aria-pressed="${on}">${esc(L(c))}</button>`; }).join('')}</div>
    <small class="grey pe-hint">${T('يمكن اختيار أكثر من قسم من نفس النوع.', 'You may pick more than one category of the same kind.')}</small></div>`;
  const opts = `<div class="field"><label>${T('خيارات يختارها العميل (اختياري)', 'Options the customer picks (optional)')}</label>${Object.keys(OPT).map(g => { const G = OPT[g], on = v.opts.includes(g); return `<button type="button" class="opt chk ${on ? 'on' : ''}" data-a="peOpt" data-id="${g}" role="checkbox" aria-checked="${on}"><span class="mk">${on ? ic('check', 14) : ''}</span><span class="grow"><b>${esc(L(G))}</b><small>${esc(G.items.map(i => L(i) + (i.d ? ` (+${fmt(i.d)})` : '')).join(T('، ', ', ')))}</small></span></button>`; }).join('')}</div>`;
  const flags = `<div class="ac pe-fl"><div class="srow"><span class="grow"><b>${T('متوفر للطلب', 'Available to order')}</b><small>${T('أوقفه مؤقتًا إذا نفد، فيظهر للعميل «نفد».', 'Switch it off while it is sold out; customers see “Sold out”.')}</small></span>${sw(v.stock, 'peFlag', 'data-k="stock"', T('متوفر للطلب', 'Available to order'))}</div>
    ${kind === 'retail' ? `<div class="srow"><span class="grow"><b>${T('شحن مجاني', 'Free shipping')}</b><small>${T('لا تُضاف رسوم الشحن على طلب فيه هذا المنتج.', 'No shipping fee on an order that has this product.')}</small></span>${sw(v.fship, 'peFlag', 'data-k="fship"', T('شحن مجاني', 'Free shipping'))}</div>` : ''}</div>
    ${BRANCHES.length > 1 ? `<div class="ac pe-fl"><h3 class="pe-h" style="margin:0 0 4px">${T('الفروع التي يتوفر فيها', 'Branches that have it')}</h3><p class="note" style="margin:0 0 6px">${T('أوقفه في فرع لا يقدّمه، فيظهر للعميل «غير متوفر بالفرع» عند اختيار ذلك الفرع.', 'Switch it off at a branch that does not make it; customers who pick that branch see “Not at this branch”.')}</p>
      ${BRANCHES.map(b => `<div class="srow"><span class="grow"><b>${esc(L(b))}</b></span>${sw(!v.off.includes(b.id), 'peOff', `data-id="${b.id}"`, L(b))}</div>`).join('')}</div>` : ''}`;
  const more = e.more ? `<div class="pe-more">
    ${txt('sar', T('سطر تحت الاسم (مثل: 250 جرام)', 'Line under the name (e.g. 250 g)'), 40)}${txt('sen', T('السطر بالإنجليزي', 'The line in English'), 40, 'dir="ltr"')}
    <div class="field"><label for="pe-cal">${T('السعرات الحرارية', 'Calories')}</label><input id="pe-cal" class="inp ltr" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="4" data-fmt="digits" data-bind="pe.v.cal" value="${esc(v.cal)}" placeholder="0" autocomplete="off"></div>
    ${txt('bar', T('شارة على الصورة (مثل: منتج جديد)', 'Badge on the photo (e.g. New)'), 24)}${txt('ben', T('الشارة بالإنجليزي', 'The badge in English'), 24, 'dir="ltr"')}
    <h3 class="pe-h">${T('تفاصيل المنتج', 'Product details')}</h3><p class="note">${T('مثل المنشأ والمعالجة والنكهات، تظهر في صفحة المنتج.', 'Such as origin, process and flavours; they show on the product page.')}</p>
    ${v.d.map(detRow).join('')}${v.d.length < 10 ? `<button type="button" class="btn sm line" data-a="peDetAdd">${ic('plus', 16)}${T('إضافة سطر', 'Add a row')}</button>` : ''}</div>` : '';
  return sheetWrap(`<div class="sbody pe" data-sk="sheet"><h2 class="sttl">${isNew ? T('إضافة منتج', 'Add a product') : T('تعديل المنتج', 'Edit the product')}</h2>
    ${photo}
    ${txt('ar', T('الاسم بالعربي', 'Name in Arabic'), 60)}${txt('en', T('الاسم بالإنجليزي', 'Name in English'), 60, 'dir="ltr"')}
    <div class="field"><label for="pe-price">${T('السعر شامل الضريبة', 'Price including VAT')}</label><div class="phone"><span class="cc">${T('ر.س', 'SAR')}</span><input id="pe-price" class="inp ltr" type="text" inputmode="decimal" data-fmt="num" data-bind="pe.v.price" value="${esc(v.price)}" placeholder="0" autocomplete="off"></div></div>
    ${cats}
    ${area('dar', T('الوصف بالعربي (اختياري)', 'Description in Arabic (optional)'))}${area('den', T('الوصف بالإنجليزي (اختياري)', 'Description in English (optional)'), 'dir="ltr"')}
    ${opts}${flags}
    <button type="button" class="pe-mt" data-a="peMore" aria-expanded="${e.more}"><span>${T('تفاصيل إضافية (اختياري)', 'More details (optional)')}</span>${ic(e.more ? 'up' : 'chevdown', 18)}</button>${more}
    ${isNew ? '' : `<button type="button" class="btn text dngt pe-del" data-a="peDel">${ic('trash', 18)}${T('حذف المنتج', 'Delete the product')}</button>`}</div>
    <div class="sfoot"><button class="btn" ${needAttr('pe')} data-a="peSave">${isNew ? T('إضافة المنتج', 'Add the product') : T('حفظ التعديلات', 'Save the changes')}</button></div>`,
  isNew ? T('إضافة منتج', 'Add a product') : T('تعديل المنتج', 'Edit the product'), 'tall pe-sheet');
};

/* a photo from the phone is made small here, a large copy and a small one, so it uploads quickly and the server stays light */
let peFile = null;
function fileInput() {
  if (peFile) return peFile;
  peFile = document.createElement('input');
  peFile.type = 'file'; peFile.accept = 'image/*'; peFile.className = 'vh-file'; peFile.tabIndex = -1; peFile.setAttribute('aria-hidden', 'true');
  peFile.addEventListener('change', () => { const f = peFile.files && peFile.files[0]; peFile.value = ''; if (f) (UI.onFile || peUpload)(f); });
  document.body.appendChild(peFile);
  return peFile;
}
const blobOf = (cv, type, q) => new Promise(r => { try { cv.toBlob(r, type, q); } catch (e) { r(null); } });
const b64Of = blob => new Promise((ok, no) => { const fr = new FileReader(); fr.onload = () => ok(String(fr.result).split(',')[1] || ''); fr.onerror = no; fr.readAsDataURL(blob); });
async function drawPhoto(img, W, H, side, q) {
  const k = Math.min(1, side / Math.max(W, H)), w = Math.max(1, Math.round(W * k)), h = Math.max(1, Math.round(H * k));
  let src = img, cw = W, ch = H;
  while (cw > w * 2) {   /* halve in steps: one big jump loses detail */
    const nw = Math.max(w, Math.round(cw / 2)), nh = Math.max(h, Math.round(ch / 2)), c = document.createElement('canvas');
    c.width = nw; c.height = nh; c.getContext('2d').drawImage(src, 0, 0, nw, nh); src = c; cw = nw; ch = nh;
  }
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const g = cv.getContext('2d', {willReadFrequently:true});   /* the corners are read back below */
  g.fillStyle = '#F3F3F3'; g.fillRect(0, 0, w, h);   /* a see-through photo gets the tile colour behind it */
  g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high'; g.drawImage(src, 0, 0, w, h);
  /* the four corners: alike, the photo sits on a plain background of that colour; different, it fills the tile */
  const n = Math.max(4, Math.floor(Math.min(w, h) / 40));
  const px = [[0, 0], [w - n, 0], [0, h - n], [w - n, h - n]].map(([x, y]) => {
    const d = g.getImageData(x, y, n, n).data, m = d.length / 4, s = [0, 0, 0];
    for (let i = 0; i < d.length; i += 4) { s[0] += d[i]; s[1] += d[i + 1]; s[2] += d[i + 2]; }
    return s.map(x2 => x2 / m);
  });
  const avg = [0, 1, 2].map(i => Math.floor(px.reduce((a, p) => a + p[i], 0) / 4));
  const spread = Math.max(...px.map(p => Math.max(...[0, 1, 2].map(i => Math.abs(p[i] - avg[i])))));
  let blob = await blobOf(cv, 'image/webp', q);
  if (!blob || blob.type !== 'image/webp') blob = await blobOf(cv, 'image/jpeg', q);   /* Safari on the iPhone writes no WebP */
  if (!blob) throw new Error('encode');
  return {b64:await b64Of(blob), bg:'#' + avg.map(x => x.toString(16).padStart(2, '0')).join(''), f:spread <= 26 ? 'c' : 'v'};
}
/* read as a data: address: the page's security rules allow images from this site and data: only (no blob:) */
const dataUrlOf = file => new Promise((ok, no) => { const fr = new FileReader(); fr.onload = () => ok(String(fr.result)); fr.onerror = () => no(fr.error); fr.readAsDataURL(file); });
async function shrinkPhoto(file) {
  if (file.size > 40e6) throw new ApiErr(413, 'too_big');
  const img = new Image();
  img.src = await dataUrlOf(file);
  await (img.decode ? img.decode() : new Promise((ok, no) => { img.onload = ok; img.onerror = no; }));
  const W = img.naturalWidth, H = img.naturalHeight;
  if (!W || !H) throw new Error('empty');
  const big = await drawPhoto(img, W, H, 1000, .84), small = await drawPhoto(img, W, H, 320, .8);
  img.src = '';
  return {full:big.b64, thumb:small.b64, bg:big.bg, f:big.f};
}
async function peUpload(file) {
  const e = UI.pe; if (!e || e.up) return;
  e.up = true; render();
  try {
    const ph = await shrinkPhoto(file);
    const r = await api('/admin/img', ph, {timeout:90000});
    e.v.img = r.img;
  } catch (err) {
    if (err && err.status === 401) { e.up = false; onSignedOut(); return; }
    toast(err instanceof ApiErr ? errText(err) : T('تعذّر فتح هذه الصورة، جرّب صورة أخرى بصيغة JPG أو PNG', 'This photo could not be opened. Try another one as JPG or PNG'));
  }
  e.up = false;
  if (UI.pe === e) { UI.dirty = true; syncBtns(); }   /* the form shows it at the next beat (never while a field is being typed in) */
}

/* ---------- rewards: a product for points, or wallet credit for points ---------- */
function rewardForm(r, kind) {
  const isP = kind === 'p', p0 = r && r.pid ? PROD[r.pid] : null;
  const prods = PRODUCTS.filter(p => !p.gone).map(p => [p.id, L(p), money(p.price).replace(/<[^>]+>/g, '') + ' ' + T('ر.س', 'SAR')]);
  const fields = [isP ? {k:'pid', type:'choice', label:T('المنتج', 'Product'), items:prods} : {k:'credit', type:'num', label:T('مبلغ الرصيد', 'Credit amount'), unit:T('ر.س', 'SAR')},
    {k:'pts', type:'int', max:6, label:T('النقاط المطلوبة', 'Points needed')},
    {k:'ar', type:'text', max:40, label:T('الاسم بالعربي (اختياري)', 'Name in Arabic (optional)'), ph:isP ? T('اسم المنتج', 'The product name') : T('رصيد في المحفظة', 'Wallet credit')},
    {k:'en', type:'text', max:40, ltr:true, label:T('الاسم بالإنجليزي (اختياري)', 'Name in English (optional)')}];
  const keep = (n, d) => r && n && n !== d ? n : '';
  openForm({title:r ? T('تعديل المكافأة', 'Edit the reward') : isP ? T('مكافأة منتج', 'Product reward') : T('رصيد في المحفظة', 'Wallet credit'),
    sub:isP ? T('يضيفه العميل إلى سلته مجانًا وتُخصم النقاط عند الطلب.', 'The customer adds it to the cart for free; the points go when he orders.') : T('يُضاف المبلغ لمحفظة العميل فورًا.', 'The amount is added to the customer\'s wallet right away.'),
    v:{pid:r && r.pid || '', credit:r && r.credit ? String(r.credit) : '', pts:r ? String(r.pts) : '', ar:keep(r && r.ar, p0 && p0.ar), en:keep(r && r.en, p0 && (p0.en || p0.ar))}, fields,
    valid:v => numIn(v.pts, 1, 100000) && Number.isInteger(Number(v.pts)) && (isP ? !!v.pid && !!liveP(v.pid) : numIn(v.credit, 1, 1000)),
    extra:r ? T('حذف المكافأة', 'Delete the reward') : '',
    async runExtra() { const x = await doStaff('/admin/reward', {op:'del', id:r.id}, T('تم حذف المكافأة', 'Reward deleted')); if (x) SRV.rewards = SRV.rewards.filter(y => y.id !== r.id); return !!x; },
    async run(v) {
      const q = {pts:Number(v.pts), ar:v.ar.trim(), en:v.en.trim(), on:r ? r.on !== false : true};
      if (r) q.id = r.id;
      if (isP) q.pid = v.pid; else q.credit = Number(v.credit);
      const x = await doStaff('/admin/reward', {op:'save', r:q}, r ? T('تم حفظ المكافأة', 'Reward saved') : T('تمت إضافة المكافأة', 'Reward added'));
      if (x && x.reward) { const l = SRV.rewards || (SRV.rewards = []), i = l.findIndex(y => y.id === x.reward.id); if (i >= 0) l[i] = x.reward; else l.push(x.reward); }
      return !!x;
    }});
}

/* ---------- home banners: a picture from the phone (or the words on a colour), and where a tap takes the customer ---------- */
function bannerForm(b) {
  const v = b ? bnView(b) : null, a = v ? v.a : 'menu';
  const builtin = !!(b && BANNERS.some(x => x.id === b.id));
  UI.bnf = {id:b ? b.id : null, builtin, up:false, v:{tar:v ? v.t.ar || '' : '', ten:v ? v.t.en || '' : '', sar:v ? v.s.ar || '' : '', sen:v ? v.s.en || '' : '',
    to:['menu', 'points', 'gift'].includes(a) ? a : 'prod', pid:['menu', 'points', 'gift'].includes(a) ? '' : a, img:b && b.img ? b.img : null}};
  openSheet({k:'bnf'});
}
NEED.bnf = () => { const f = UI.bnf; return !!f && !f.up && !UI.busy && (f.builtin || !!f.v.img || f.v.tar.trim().length >= 2) && (f.v.to !== 'prod' || !!liveP(f.v.pid)); };
SHEETS.bnf = function () {
  const f = UI.bnf; if (!f) return '';
  const v = f.v, fld = (k, label, ltr) => `<div class="field"><label>${label}</label><input class="inp" type="text" maxlength="${k[0] === 't' ? 60 : 90}" ${ltr ? 'dir="ltr"' : ''} data-bind="bnf.v.${k}" value="${esc(v[k])}"></div>`;
  const prev = v.img ? `<span class="bf-pv" style="background-image:url(/api/img/${v.img.id}/t)"></span>` : `<span class="bf-pv none">${ic('photo', 30)}</span>`;
  const tos = [['menu', T('القائمة', 'The menu')], ['points', T('النقاط والمكافآت', 'Points and rewards')], ['gift', T('إرسال هدية', 'Send a gift')], ['prod', T('منتج', 'A product')]];
  return sheetWrap(`<div class="sbody pe"><h2 class="sttl">${f.id ? T('تعديل الإعلان', 'Edit the banner') : T('إعلان جديد', 'New banner')}</h2>
    <div class="pe-ph">${prev}<div class="pe-pb">${f.up ? `<span class="pe-up"><span class="spin sm"></span>${T('جاري رفع الصورة…', 'Uploading the photo…')}</span>`
      : `<button class="btn line sm" data-a="bnPhoto">${ic('photo', 18)}${v.img ? T('تغيير الصورة', 'Change the photo') : T('إضافة صورة', 'Add a photo')}</button>${v.img ? `<button class="btn text sm" data-a="bnNoPhoto">${T('حذف الصورة', 'Remove the photo')}</button>` : ''}`}
      <small>${T('صورة منتج (مربعة): تظهر بجانب العنوان والزر. صورة عريضة (2 إلى 1) فيها كلامها: تظهر كاملة وحدها.', 'A product photo (square) shows next to the title and the button. A wide picture (2 to 1) with its own words shows whole, by itself.')}${f.builtin ? ' ' + (v.img ? T('حذف الصورة يرجّع صورة الإعلان الأصلية.', 'Removing the photo brings the banner\'s own picture back.') : T('بدون صورة تبقى صورة الإعلان الأصلية.', 'Without one, the banner keeps its own picture.')) : ''}</small></div></div>
    ${fld('tar', T('العنوان بالعربي', 'Title in Arabic'))}${fld('ten', T('العنوان بالإنجليزي (اختياري)', 'Title in English (optional)'), true)}
    ${fld('sar', T('سطر تحت العنوان (اختياري)', 'Line under the title (optional)'))}${fld('sen', T('السطر بالإنجليزي (اختياري)', 'The line in English (optional)'), true)}
    <div class="field" role="radiogroup" aria-label="${T('عند الضغط عليه', 'When tapped')}"><label>${T('عند الضغط عليه يفتح', 'A tap opens')}</label>${tos.map(([id, l]) => `<button type="button" class="opt ${v.to === id ? 'on' : ''}" data-a="bnTo" data-v="${id}" role="radio" aria-checked="${v.to === id}"><span class="mk"></span><span class="grow">${l}</span></button>`).join('')}</div>
    ${v.to === 'prod' ? `<div class="field"><label>${T('المنتج', 'Product')}</label><select class="inp" data-bind="bnf.v.pid"><option value="">${T('اختر المنتج', 'Pick the product')}</option>${PRODUCTS.filter(p => !p.gone).map(p => `<option value="${p.id}" ${v.pid === p.id ? 'selected' : ''}>${esc(L(p))}</option>`).join('')}</select></div>` : ''}
    ${f.id ? `<button type="button" class="btn text dngt" data-a="bnDel">${ic('trash', 18)}${T('حذف الإعلان', 'Delete the banner')}</button>` : ''}</div>
    <div class="sfoot"><button class="btn" ${needAttr('bnf')} data-a="bnSave">${f.id ? T('حفظ', 'Save') : T('إضافة الإعلان', 'Add the banner')}</button></div>`, f.id ? T('تعديل الإعلان', 'Edit the banner') : T('إعلان جديد', 'New banner'), 'tall pe-sheet');
};
async function bnUpload(file) {
  const f = UI.bnf; if (!f || f.up) return;
  f.up = true; render();
  try { const ph = await shrinkPhoto(file); const r = await api('/admin/img', ph, {timeout:90000}); f.v.img = r.img; }
  catch (err) {
    if (err && err.status === 401) { f.up = false; onSignedOut(); return; }
    toast(err instanceof ApiErr ? errText(err) : T('تعذّر فتح هذه الصورة، جرّب صورة أخرى بصيغة JPG أو PNG', 'This photo could not be opened. Try another one as JPG or PNG'));
  }
  f.up = false;
  if (UI.bnf === f) { UI.dirty = true; syncBtns(); }
}

/* ---------- 0.7.12: the two home tiles: a photo from the phone and the words; "as it was" brings the app's own back ---------- */
function tileForm(k) {
  const v = tileView(k);
  UI.tlf = {id:k, up:false, own:v.own, v:{tar:v.t.ar || '', ten:v.t.en || '', sar:v.s.ar || '', sen:v.s.en || '', img:v.img}};
  openSheet({k:'tlf'});
}
NEED.tlf = () => { const f = UI.tlf; return !!f && !f.up && !UI.busy && f.v.tar.trim().length >= 2; };
SHEETS.tlf = function () {
  const f = UI.tlf; if (!f) return '';
  const v = f.v, fld = (k, label, n, ltr) => `<div class="field"><label>${label}</label><input class="inp" type="text" maxlength="${n}" ${ltr ? 'dir="ltr"' : ''} data-bind="tlf.v.${k}" value="${esc(v[k])}"></div>`;
  const prev = v.img ? `<span class="bf-pv tl-pv" style="background-image:url(/api/img/${v.img.id}/t)"></span>`
    : IMG.ht && IMG.ht[f.id] ? `<span class="bf-pv tl-pv im-ht-${f.id}"></span>` : `<span class="bf-pv tl-pv none">${ic('photo', 30)}</span>`;
  return sheetWrap(`<div class="sbody pe"><h2 class="sttl">${f.id === 'welcome' ? T('شاشة الترحيب', 'Welcome screen') : T('تعديل المربع', 'Edit the tile')}</h2>
    <div class="pe-ph">${prev}<div class="pe-pb">${f.up ? `<span class="pe-up"><span class="spin sm"></span>${T('جاري رفع الصورة…', 'Uploading the photo…')}</span>`
      : `<button class="btn line sm" data-a="tlPhoto">${ic('photo', 18)}${v.img ? T('تغيير الصورة', 'Change the photo') : T('إضافة صورة', 'Add a photo')}</button>${v.img ? `<button class="btn text sm" data-a="tlNoPhoto">${T('حذف الصورة', 'Remove the photo')}</button>` : ''}`}
      <small>${f.id === 'welcome' ? T('صورة طولية (مثل صورة الجوال) تملأ الشاشة، والكلام يظهر أسفلها.', 'A tall photo (like a phone photo) fills the screen; the words show at its bottom.') : T('صورة مربعة أو طولية والمنتج في وسطها، تظهر أسفل المربع.', 'A square or tall photo with the product in the middle; it shows at the bottom of the tile.')} ${v.img ? T('حذف الصورة يرجّع الصورة الأصلية.', 'Removing it brings the original photo back.') : T('بدون صورة تبقى الصورة الأصلية.', 'Without one, the original photo stays.')}</small></div></div>
    ${fld('tar', T('العنوان بالعربي', 'Title in Arabic'), 30)}${fld('ten', T('العنوان بالإنجليزي (اختياري)', 'Title in English (optional)'), 30, true)}
    ${fld('sar', T('الوصف بالعربي (اختياري)', 'Description in Arabic (optional)'), 90)}${fld('sen', T('الوصف بالإنجليزي (اختياري)', 'Description in English (optional)'), 90, true)}
    ${f.own ? `<button type="button" class="btn text" data-a="tlReset">${f.id === 'welcome' ? T('رجّع الشاشة كما كانت', 'Put the screen back as it was') : T('رجّع المربع كما كان', 'Put the tile back as it was')}</button>` : ''}</div>
    <div class="sfoot"><button class="btn" ${needAttr('tlf')} data-a="tlSave">${T('حفظ', 'Save')}</button></div>`, T('تعديل المربع', 'Edit the tile'), 'tall pe-sheet');
};
async function tlUpload(file) {
  const f = UI.tlf; if (!f || f.up) return;
  f.up = true; render();
  try { const ph = await shrinkPhoto(file); const r = await api('/admin/img', ph, {timeout:90000}); f.v.img = r.img; }
  catch (err) {
    if (err && err.status === 401) { f.up = false; onSignedOut(); return; }
    toast(err instanceof ApiErr ? errText(err) : T('تعذّر فتح هذه الصورة، جرّب صورة أخرى بصيغة JPG أو PNG', 'This photo could not be opened. Try another one as JPG or PNG'));
  }
  f.up = false;
  if (UI.tlf === f) { UI.dirty = true; syncBtns(); }
}

/* the menu on this page, right after a change: the server's own copy follows a moment later */
function putProduct(p) {
  if (!p || !p.id) return;
  PROD[p.id] = p;
  const i = PRODUCTS.findIndex(x => x.id === p.id);
  if (i >= 0) PRODUCTS[i] = p; else PRODUCTS.push(p);
}
function dropProduct(id) {
  const i = PRODUCTS.findIndex(x => x.id === id); if (i >= 0) PRODUCTS.splice(i, 1);
  if (PROD[id]) PROD[id] = Object.assign({}, PROD[id], {gone:1});
}
/* the menu changed (here or on another device) */
function afterCatalog() {
  UI.ad.cat = curCat(UI.ad.cat, true);
  if (UI.pe && UI.pe.id && !liveP(UI.pe.id)) {
    if (!UI.pe.deleting) toast(T('حُذف هذا المنتج من جهاز آخر', 'This product was deleted on another device'));
    UI.pe = null; if (UI.sheet && UI.sheet.k === 'prod') UI.sheet = null;
  }
  if (UI.pe) UI.pe.v.cats = UI.pe.v.cats.filter(id => CAT[id] && !CAT[id].gone);
  if (UI.bf && UI.bf.id && !liveB(UI.bf.id)) { UI.bf = null; if (UI.sheet && UI.sheet.k === 'brf') UI.sheet = null; }
  UI.dirty = true;
}

/* ---------- categories ---------- */
SHEETS.cats = function () {
  /* tapping a category opens it for editing; the arrows move it, the bin deletes it (only when it is empty) */
  const rows = CATS.map((c, i) => `<div class="cat-r"><button class="cat-b" data-a="catEdit" data-id="${c.id}" aria-label="${esc(T(`تعديل ${L(c)}`, `Edit ${L(c)}`))}"><span class="grow"><b>${esc(L(c))} <span class="cn" title="${T('عدد المنتجات', 'Products')}">${catCount(c.id)}</span></b><small>${esc(kindName(c.kind))}</small></span>${ic('pencil', 15)}</button>
    <span class="cat-a"><button class="ibtn" data-a="catMove" data-id="${c.id}" data-d="-1" ${i === 0 ? 'disabled' : ''} aria-label="${esc(T(`${L(c)}: للأعلى`, `${L(c)}: move up`))}">${ic('up', 18)}</button>
    <button class="ibtn" data-a="catMove" data-id="${c.id}" data-d="1" ${i === CATS.length - 1 ? 'disabled' : ''} aria-label="${esc(T(`${L(c)}: للأسفل`, `${L(c)}: move down`))}">${ic('chevdown', 18)}</button>
    <button class="ibtn" data-a="catDel" data-id="${c.id}" aria-label="${esc(T(`حذف ${L(c)}`, `Delete ${L(c)}`))}">${ic('trash', 17)}</button></span></div>`).join('');
  return sheetWrap(`<div class="sbody" data-sk="sheet"><h2 class="sttl">${T('الأقسام', 'Categories')}</h2><p class="ssub">${T('بهذا الترتيب تظهر في تطبيق العميل. القسم الفارغ لا يظهر للعملاء.', 'Customers see them in this order. An empty category is hidden from them.')}</p>
    <div class="ac flush">${rows}</div><button class="btn" data-a="catAdd">${ic('plus', 20)}${T('إضافة قسم', 'Add a category')}</button></div>`, T('الأقسام', 'Categories'));
};
function catForm(c) {
  const used = c ? catCount(c.id) > 0 : false, kind0 = c ? (c.kind === 'retail' ? 'retail' : 'drink') : '';
  openForm({title:c ? T('تعديل القسم', 'Edit the category') : T('قسم جديد', 'New category'), v:{ar:c ? c.ar : '', en:c ? c.en || '' : '', kind:kind0}, back:'cats',
    fields:[{k:'ar', type:'text', label:T('الاسم بالعربي', 'Name in Arabic'), max:40}, {k:'en', type:'text', label:T('الاسم بالإنجليزي (اختياري)', 'Name in English (optional)'), max:40, ltr:true},
      {k:'kind', type:'choice', label:T('نوع القسم', 'Kind of category'), dis:used, note:used ? T('لا يتغيّر نوع قسم فيه منتجات.', 'A category with products keeps its kind.') : '',
        items:[['drink', T('طلبات الفرع', 'Branch orders'), T('مشروبات وحلويات تُحضَّر في الفرع: استلام أو توصيل', 'Drinks and sweets made at the branch: pickup or delivery')],
          ['retail', T('منتجات المحمصة', 'Roastery products'), T('حبوب وأدوات: شحن أو استلام أو توصيل', 'Beans and tools: shipping, pickup or delivery')]]}],
    valid:v => (v.ar || '').trim().length >= 2 && !!v.kind,
    async run(v) {
      const body = {ar:v.ar.trim(), en:(v.en || '').trim()};
      if (!c || v.kind !== kind0) body.kind = v.kind;   /* unchanged: it stays as it is (desserts stay desserts) */
      const r = await doStaff('/admin/cat', c ? {op:'save', id:c.id, c:body} : {op:'save', c:body}, c ? T('تم حفظ القسم', 'Category saved') : T('تمت إضافة القسم، أضف إليه منتجات ليظهر للعملاء', 'Category added. Add products to it so customers see it'));
      return !!r;
    }});
}

/* ---------- the branch form: name, address, working hours, place on the map ---------- */
const hhmmOk = t => /^([01]\d|2[0-3]):[0-5]\d$/.test(t || '');
function bfOpen(b) {
  const h = b ? b.h : [480, 1440];
  const v = {ar:b ? b.ar : '', en:b ? b.en || '' : '', aar:b ? (b.addr || {}).ar || '' : '', aen:b ? (b.addr || {}).en || '' : '',
    allDay:h === '24', open:Array.isArray(h) ? hm(h[0]) : '08:00', close:Array.isArray(h) ? hm(h[1]) : '00:00',
    loc:'', lat:b && hasLoc(b) ? b.lat : null, lng:b && hasLoc(b) ? b.lng : null};
  UI.bf = {id:b ? b.id : null, v, v0:JSON.stringify(v), busy:'', msg:''};
  openSheet({k:'brf'});
}
NEED.bf = () => { const f = UI.bf; if (!f || f.busy || UI.busy) return false; const v = f.v; return (v.ar || '').trim().length >= 2 && (v.aar || '').trim().length >= 3 && (v.allDay || (hhmmOk(v.open) && hhmmOk(v.close) && v.open !== v.close)); };
const bfDirty = () => !!UI.bf && (!!UI.bf.busy || JSON.stringify(UI.bf.v) !== UI.bf.v0);
/* coordinates written in a map link or as two numbers (the server reads short links, see brLink) */
function coordsIn(text) {
  let t = String(text || ''); try { t = decodeURIComponent(t); } catch (e) {}
  t = toLatin(t).replace(/٫/g, '.');
  const pats = [/!3d(-?\d{1,2}(?:\.\d+)?)!4d(-?\d{1,3}(?:\.\d+)?)/, /[?&](?:q|query|ll|sll|destination|daddr|center|coordinate)=\s*(-?\d{1,2}\.\d+)\s*,\s*\+?(-?\d{1,3}\.\d+)/,
    /@(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+)/, /\/(?:search|place|dir)\/(-?\d{1,2}\.\d+),\s*\+?(-?\d{1,3}\.\d+)/, /^\s*\(?\s*(-?\d{1,2}\.\d+)\s*[,،\s]\s*(-?\d{1,3}\.\d+)\s*\)?\s*$/];
  for (const re of pats) {
    const m = re.exec(t);
    if (m) { const la = Number(m[1]), lo = Number(m[2]); if (la >= -90 && la <= 90 && lo >= -180 && lo <= 180 && (la || lo)) return {lat:Math.round(la * 1e6) / 1e6, lng:Math.round(lo * 1e6) / 1e6}; }
  }
  return null;
}
SHEETS.brf = function () {
  const f = UI.bf; if (!f) return '';
  const v = f.v, isNew = !f.id;
  const txt = (k, label, max, extra) => `<div class="field"><label for="bf-${k}">${label}</label><input id="bf-${k}" class="inp" type="text" maxlength="${max}" data-bind="bf.v.${k}" value="${esc(v[k])}" autocomplete="off" ${extra || ''}></div>`;
  const hours = `<div class="ac pe-fl"><div class="srow"><span class="grow"><b>${T('مفتوح 24 ساعة', 'Open 24 hours')}</b></span>${sw(v.allDay, 'bfAllDay', '', T('مفتوح 24 ساعة', 'Open 24 hours'))}</div>
    ${v.allDay ? '' : `<div class="bf-hrs"><div class="field"><label for="bf-open">${T('يفتح', 'Opens')}</label><input id="bf-open" class="inp ltr" type="time" data-bind="bf.v.open" value="${esc(v.open)}"></div>
      <div class="field"><label for="bf-close">${T('يغلق', 'Closes')}</label><input id="bf-close" class="inp ltr" type="time" data-bind="bf.v.close" value="${esc(v.close)}"></div></div>
      <small class="grey pe-hint">${T('إذا كان يغلق بعد منتصف الليل اكتب وقت الإغلاق كما هو، مثل 02:00.', 'If it closes after midnight, type the closing time as it is, such as 02:00.')}</small>`}</div>`;
  const where = hasLoc(v) ? `<div class="bf-ok">${ic('check', 18)}<span class="grow"><b>${T('تم تحديد الموقع', 'The place is set')}</b><small class="ltr">${v.lat.toFixed(5)}, ${v.lng.toFixed(5)}</small></span><a class="tel" href="${mapUrl(v.lat, v.lng)}" target="_blank" rel="noopener noreferrer">${T('عرض', 'Show')}</a><button type="button" class="btn text dngt sm" data-a="bfNoLoc">${T('إزالة', 'Remove')}</button></div>`
    : `<p class="note">${T('بدون موقع لا تظهر للعميل الاتجاهات ولا المسافة.', 'Without a place, customers get no directions and no distance.')}</p>`;
  const loc = `<div class="field"><label for="bf-loc">${T('الموقع على الخريطة', 'Place on the map')}</label>
    <input id="bf-loc" class="inp" type="text" dir="ltr" maxlength="800" data-bind="bf.v.loc" data-on="bfLoc" value="${esc(v.loc)}" placeholder="${T('الصق رابط خرائط جوجل أو الإحداثيات', 'Paste a Google Maps link or the coordinates')}" autocomplete="off" inputmode="url">
    ${f.busy ? `<span class="pe-up" role="status"><span class="spin sm"></span>${f.busy === 'link' ? T('جاري قراءة الرابط…', 'Reading the link…') : T('جاري تحديد موقعك…', 'Finding where you are…')}</span>` : ''}
    <small class="grey pe-hint">${T('من خرائط جوجل: مشاركة ثم نسخ الرابط، أو المس المكان مطولًا وانسخ الإحداثيات.', 'From Google Maps: Share, then Copy link; or touch and hold the place and copy its coordinates.')}</small>
    ${f.msg ? `<em class="em" role="alert">${esc(f.msg)}</em>` : ''}
    <button type="button" class="btn sm line bf-here" data-a="bfHere" ${f.busy ? 'disabled' : ''}>${ic('nav', 16)}${T('موقعي الحالي (إذا كنت في الفرع)', 'Where I am now (when at the branch)')}</button>
    ${where}</div>`;
  return sheetWrap(`<div class="sbody pe" data-sk="sheet"><h2 class="sttl">${isNew ? T('إضافة فرع', 'Add a branch') : T('تعديل الفرع', 'Edit the branch')}</h2>
    ${txt('ar', T('اسم الفرع بالعربي', 'Branch name in Arabic'), 60)}${txt('en', T('اسم الفرع بالإنجليزي (اختياري)', 'Branch name in English (optional)'), 60, 'dir="ltr"')}
    ${txt('aar', T('العنوان بالعربي', 'Address in Arabic'), 160)}${txt('aen', T('العنوان بالإنجليزي (اختياري)', 'Address in English (optional)'), 160, 'dir="ltr"')}
    <h3 class="pe-h">${T('أوقات العمل', 'Working hours')}</h3>${hours}
    ${loc}
    ${isNew ? '' : `<button type="button" class="btn text dngt pe-del" data-a="brDel">${ic('trash', 18)}${T('حذف الفرع', 'Delete the branch')}</button>`}</div>
    <div class="sfoot"><button class="btn" ${needAttr('bf')} data-a="brSave">${isNew ? T('إضافة الفرع', 'Add the branch') : T('حفظ التعديلات', 'Save the changes')}</button></div>`,
  isNew ? T('إضافة فرع', 'Add a branch') : T('تعديل الفرع', 'Edit the branch'), 'tall pe-sheet');
};
/* what was pasted is read a moment after the typing stops: coordinates here, a link (often a short maps.app.goo.gl one)
   by the server, which can open it. The field is then left, so the result shows at once. */
let bfTimer = 0;
const bfLeave = () => { const el = document.activeElement; if (el && el.id === 'bf-loc') el.blur(); };
async function bfResolve(text) {
  const f = UI.bf; if (!f || (f.v.loc || '').trim() !== text) return;
  f.busy = 'link'; f.msg = ''; bfLeave(); render();
  try {
    const r = await api('/admin/maplink', {url:text}, {timeout:20000});
    if (UI.bf === f && (f.v.loc || '').trim() === text) { f.v.lat = r.lat; f.v.lng = r.lng; f.v.loc = ''; }
  } catch (e) {
    if (e.status === 401) { f.busy = ''; onSignedOut(); return; }
    if (UI.bf === f) f.msg = errText(e);
  }
  f.busy = ''; if (UI.bf === f) render();
}

/* ---------- actions ---------- */
Object.assign(A, {
  adSec(d) { UI.ad.sec = d.id; UI.sheet = null; render(); },
  adMore() { openSheet({k:'more'}); },
  adGoNew() { UI.ad.sec = 'orders'; UI.ad.f = 'new'; render(); },
  adBar(d) { UI.ad.bar = UI.ad.bar === Number(d.i) ? -1 : Number(d.i); render(); },
  adTbl() { UI.ad.tbl = !UI.ad.tbl; render(); },
  /* reports */
  rpP(d) {
    const r = UI.rp;
    if (d.id === 'custom' && r.p !== 'custom') { const [f, t] = rpPeriod(); r.f = r.cf = f; r.t = r.ct = t; }   /* starts from the period on screen */
    r.p = d.id; r.bar = -1; r.all = false; r.ready = false; render();
  },
  rpApply() { const r = UI.rp; if (!NEED.rpRange()) return; r.cf = r.f; r.ct = r.t; r.bar = -1; r.all = false; r.ready = false; render(); },
  rpBar(d) { UI.rp.bar = UI.rp.bar === Number(d.i) ? -1 : Number(d.i); render(); },
  rpTbl() { UI.rp.tbl = !UI.rp.tbl; render(); },
  rpAll() { UI.rp.all = !UI.rp.all; render(); },
  rpRetry() { UI.rp.err = ''; render(); },
  async rpXlsx() {
    const r = UI.rp, k = rpKey(), fk = k + '|' + S.lang;
    if (r.dl) return;
    /* a file made a moment ago for the same period: give it within this tap (the share sheet needs a fresh tap) */
    if (r.file && r.file.k === fk && (r.ready || r.file.rev === SRV.rev)) { r.ready = false; rpGive(r.file.f); render(); return; }
    r.dl = true; r.ready = false; render();
    const [from, to] = k.split('|'), ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 45000);
    try {
      let res;
      try {
        res = await fetch(API + '/admin/xlsx', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({from, to, lang:S.lang}), credentials:'same-origin', cache:'no-store', signal:ctl.signal});
      } catch (e) { throw new ApiErr(0, 'net'); }
      if (!res.ok) { let j = null; try { j = await res.json(); } catch (e) { /* not JSON */ } throw new ApiErr(res.status, (j && j.error) || (res.status >= 500 ? 'server' : 'bad_response'), j); }
      const m = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || ''), blob = await res.blob();
      r.file = {k:fk, f:new File([blob], m ? m[1] : `Why-report-${from}_${to}.xlsx`, {type:XLSX_TYPE}), rev:SRV.rev};
      rpGive(r.file.f);
    } catch (e) {
      if (e.status === 401) { onSignedOut(); return; }
      toast(errText(e instanceof ApiErr ? e : new ApiErr(0, 'net')));
    } finally { clearTimeout(timer); r.dl = false; rpShow(); }
  },
  adF(d) { UI.ad.f = d.id; render(); },
  adOrder(d) { openSheet({k:'odetail', id:d.id}); },
  adOrdSearch() { const el = $('#adords'); if (el) el.innerHTML = adOrdersBody(); },
  adCat(d) { UI.ad.cat = d.id; UI.ad.q = ''; render(); },
  adSearch() { const el = $('#admenu'); if (el) el.innerHTML = adMenuBody(); },

  /* products */
  async adStock(d) {
    const p = liveP(d.id); if (!p) return;
    const on = p.stock === false;   /* it is out now: switching on makes it available */
    const r = await doStaff('/admin/product', {op:'stock', id:d.id, stock:on}, on ? T('صار متوفرًا للعملاء', 'Customers can order it again') : T('أُوقف مؤقتًا، يظهر للعملاء «نفد»', 'Paused; customers see “Sold out”'));
    if (r) { putProduct(r.product); render(); }
  },
  pNew() { peOpen(null); },
  pEdit(d) { const p = liveP(d.id); if (p) peOpen(p); },
  pePhoto() { if (UI.pe && !UI.pe.up) { UI.onFile = null; fileInput().click(); } },
  peNoPhoto() { if (UI.pe) { UI.pe.v.img = null; render(); } },
  peCat(d) {
    const v = UI.pe.v, c = CAT[d.id]; if (!c) return;
    const i = v.cats.indexOf(d.id);
    if (i >= 0) { if (v.cats.length > 1) v.cats.splice(i, 1); else toast(T('يبقى المنتج في قسم واحد على الأقل', 'A product stays in one category at least')); }
    else if (v.cats.length && (CAT[v.cats[0]] || {}).kind !== c.kind) { v.cats = [d.id]; toast(T(`«${L(c)}» من نوع آخر، فصار المنتج فيه وحده`, `“${L(c)}” is of another kind, so the product is now in it alone`)); }
    else v.cats.push(d.id);
    v.cats.sort((a, b) => CATS.findIndex(x => x.id === a) - CATS.findIndex(x => x.id === b));
    render();
  },
  peOpt(d) { const v = UI.pe.v, i = v.opts.indexOf(d.id); if (i >= 0) v.opts.splice(i, 1); else v.opts.push(d.id); render(); },
  peFlag(d) { const v = UI.pe.v; v[d.k] = !v[d.k]; render(); },
  peOff(d) { const v = UI.pe.v, i = v.off.indexOf(d.id); if (i >= 0) v.off.splice(i, 1); else v.off.push(d.id); render(); },
  peMore() { UI.pe.more = !UI.pe.more; render(); },
  peDetAdd() {
    const v = UI.pe.v; if (v.d.length >= 10) return;
    v.d.push({kk:LBK.find(k => !v.d.some(r => r.kk === k)) || LBK[0], k:null, ar:'', en:''});
    UI.focus = `[data-bind="pe.v.d.${v.d.length - 1}.ar"]`; render();
  },
  peDetDel(d) { UI.pe.v.d.splice(Number(d.i), 1); render(); },
  async peSave() {
    const e = UI.pe; if (!e || !NEED.pe()) return;
    const v = e.v;
    const p = {ar:v.ar.trim(), en:v.en.trim(), price:r2(Number(toLatin(v.price))), cats:v.cats.slice(), opts:v.opts.slice(), desc:two(v.dar, v.den),
      sub:two(v.sar, v.sen), cal:v.cal ? Number(v.cal) : 0, badge:two(v.bar, v.ben), stock:v.stock, fship:v.fship, img:v.img ? v.img.id : null, off:v.off.filter(id => BR[id]),
      d:v.d.map(r => ({k:r.kk === '_own' ? r.k : {ar:LB[r.kk][0], en:LB[r.kk][1]}, v:two(r.ar, r.en)})).filter(r => r.k && (r.v.ar || r.v.en))};
    const r = await doStaff('/admin/product', e.id ? {op:'save', id:e.id, p} : {op:'save', p},
      e.id ? T('تم حفظ التعديلات، تظهر للعملاء الآن', 'Saved. Customers see it now') : T('تمت إضافة المنتج، يظهر للعملاء الآن', 'Product added. Customers see it now'));
    if (!r) return;
    putProduct(r.product);
    if (!e.id) { UI.ad.cat = p.cats[0]; UI.ad.q = ''; }
    UI.pe = null; UI.sheet = null; render();
  },
  peDel() {
    const e = UI.pe, p = e && PROD[e.id]; if (!p) return;
    UI.dlg = {t:T('حذف المنتج', 'Delete the product'), b:T(`سيختفي «${esc(L(p))}» من التطبيق ولن يستطيع العملاء طلبه. الطلبات السابقة تبقى كما هي.`, `“${esc(L(p))}” leaves the app and customers can no longer order it. Past orders stay as they are.`), ok:T('حذف', 'Delete'), danger:true,
      async fn() {
        e.deleting = true;   /* the server's new menu may arrive before its answer: that is this deletion, not someone else's */
        const r = await doStaff('/admin/product', {op:'delete', id:p.id}, T('تم حذف المنتج', 'Product deleted'));
        if (r) { dropProduct(p.id); UI.pe = null; UI.sheet = null; render(); } else e.deleting = false;
      }};
    render();
  },

  /* branches */
  brNew() { bfOpen(null); },
  brEdit(d) { const b = liveB(d.id); if (b) bfOpen(b); },
  bfAllDay() { UI.bf.v.allDay = !UI.bf.v.allDay; render(); },
  bfNoLoc() { const v = UI.bf.v; v.lat = null; v.lng = null; v.loc = ''; UI.bf.msg = ''; render(); },
  bfLoc() {
    const f = UI.bf; clearTimeout(bfTimer); f.msg = '';
    bfTimer = setTimeout(() => {
      const t = (f.v.loc || '').trim(); if (UI.bf !== f || !t) return;
      const c = coordsIn(t);
      if (c) { f.v.lat = c.lat; f.v.lng = c.lng; f.v.loc = ''; bfLeave(); render(); }
      else if (/^https?:\/\//i.test(t)) bfResolve(t);
      else { f.msg = errText({code:'bad_link'}); UI.dirty = true; }   /* shown once the field is left */
    }, 800);
  },
  bfHere() {
    const f = UI.bf; if (!f || f.busy) return;
    if (!navigator.geolocation) { f.msg = T('تحديد الموقع غير مدعوم في هذا المتصفح', 'Location is not supported in this browser'); render(); return; }
    f.busy = 'here'; f.msg = ''; render();
    navigator.geolocation.getCurrentPosition(
      p => { f.busy = ''; f.v.lat = Math.round(p.coords.latitude * 1e6) / 1e6; f.v.lng = Math.round(p.coords.longitude * 1e6) / 1e6; f.v.loc = ''; if (UI.bf === f) render(); },
      () => { f.busy = ''; f.msg = T('تعذّر تحديد موقعك: اسمح للمتصفح بالموقع، أو الصق رابط الموقع', 'Could not find you: allow location, or paste the link of the place'); if (UI.bf === f) render(); },
      {enableHighAccuracy:true, timeout:15000, maximumAge:0});
  },
  async brSave() {
    const f = UI.bf; if (!f || !NEED.bf()) return;
    const v = f.v;
    const b = {ar:v.ar.trim(), en:v.en.trim(), addr:two(v.aar, v.aen), all_day:v.allDay, open:v.allDay ? null : v.open, close:v.allDay ? null : v.close, lat:hasLoc(v) ? v.lat : null, lng:hasLoc(v) ? v.lng : null};
    const r = await doStaff('/admin/branches', f.id ? {op:'save', id:f.id, b} : {op:'save', b},
      f.id ? T('تم حفظ الفرع، يظهر للعملاء الآن', 'Branch saved. Customers see it now') : T('تمت إضافة الفرع، يظهر للعملاء الآن', 'Branch added. Customers see it now'));
    if (r) { UI.bf = null; UI.sheet = null; render(); }
  },
  brDel() {
    const f = UI.bf, b = f && BR[f.id]; if (!b) return;
    if (BRANCHES.length <= 1) { toast(errText({code:'last_branch'})); return; }
    UI.dlg = {t:T('حذف الفرع', 'Delete the branch'), b:T(`سيختفي «${esc(L(b))}» من التطبيق ولن يستقبل طلبات. الطلبات السابقة تبقى كما هي.`, `“${esc(L(b))}” leaves the app and takes no more orders. Past orders stay as they are.`), ok:T('حذف', 'Delete'), danger:true,
      async fn() { const r = await doStaff('/admin/branches', {op:'delete', id:b.id}, T('تم حذف الفرع', 'Branch deleted')); if (r) { UI.bf = null; UI.sheet = null; render(); } }};
    render();
  },

  /* categories */
  catMgr() { openSheet({k:'cats'}); },
  catAdd() { catForm(null); },
  catEdit(d) { const c = CAT[d.id]; if (c && !c.gone) catForm(c); },
  async catMove(d) {
    const r = await doStaff('/admin/cat', {op:'move', id:d.id, d:Number(d.d)});
    if (r) { const i = CATS.findIndex(x => x.id === d.id), j = i + Number(d.d); if (i >= 0 && j >= 0 && j < CATS.length) [CATS[i], CATS[j]] = [CATS[j], CATS[i]]; render(); }
  },
  catDel(d) {
    const c = CAT[d.id]; if (!c) return;
    if (catCount(c.id)) { toast(errText({code:'cat_not_empty'})); return; }
    if (CATS.length <= 1) { toast(errText({code:'last_cat'})); return; }
    UI.dlg = {t:T('حذف القسم', 'Delete the category'), b:T(`سيُحذف قسم «${esc(L(c))}» من التطبيق.`, `The category “${esc(L(c))}” leaves the app.`), ok:T('حذف', 'Delete'), danger:true,
      async fn() { const r = await doStaff('/admin/cat', {op:'delete', id:c.id}, T('تم حذف القسم', 'Category deleted')); if (r) { const i = CATS.findIndex(x => x.id === c.id); if (i >= 0) CATS.splice(i, 1); render(); } }};
    render();
  },
  fmPick(d) { if (UI.fm) { UI.fm.v[d.k] = d.v; render(); } },

  /* offers and fees */
  async adCode(d) { const c = SRV.codes[d.id]; if (c) { const r = await doStaff('/admin/code', {code:d.id, on:!c.on}); if (r) c.on = !c.on; render(); } },
  edTier(d) {
    const i = SRV.tiers.findIndex(t => t.id === d.id); if (i < 0) return;
    const t = SRV.tiers[i], days = SRV.tdays || TIER_DAYS;
    const build = v => SRV.tiers.map((x, k) => k === i ? {id:x.id, min:i ? Number(v.min) : 0, per10:Number(v.per)} : Object.assign({}, x));
    const fields = [{k:'per', type:'int', max:3, label:T('النقاط لكل 10 ريال', 'Points for every 10 SAR')}];
    if (i) fields.push({k:'min', type:'int', max:7, label:T(`تفتح عند (نقاط خلال ${days} يوم)`, `Opens at (points in ${days} days)`)});
    openForm({title:L(TIER_NAME[t.id]), sub:T('كل مستوى أعلى يحتاج نقاطًا أكثر ويعطي نقاطًا مثل الذي قبله أو أكثر. يطبّق على الطلبات القادمة.', 'Each higher tier needs more points and gives at least as many as the one below. Applies to the next orders.'),
      v:{per:String(t.per10), min:String(t.min)}, fields,
      valid:v => numIn(v.per, 1, 100) && Number.isInteger(Number(v.per)) && (!i || (numIn(v.min, 1, 1000000) && Number.isInteger(Number(v.min)))) && tiersRise(build(v)),
      async run(v) { const l = build(v); const r = await doStaff('/admin/tiers', {tiers:l}, T('تم تحديث مستويات العضوية', 'Membership tiers updated')); if (r) SRV.tiers = l; return !!r; }});
  },
  edPct(d) {
    const c = SRV.codes[d.id]; if (!c) return;
    openForm({title:T(`نسبة خصم ${d.id}`, `${d.id} discount`), sub:T('تُحسب من مجموع الطلب', 'Taken off the order subtotal'), v:{n:String(c.pct)}, fields:[{k:'n', type:'num', label:T('نسبة الخصم', 'Discount'), unit:'%'}],
      valid:v => numIn(v.n, 1, 90) && Number.isInteger(Number(v.n)),
      async run(v) { const r = await doStaff('/admin/code', {code:d.id, pct:Number(v.n)}, T('تم تحديث نسبة الخصم', 'Discount updated')); return !!r; }});
  },
  codeAdd() {
    openForm({title:T('كود خصم جديد', 'New discount code'), sub:T('أحرف إنجليزية وأرقام فقط، من 3 إلى 20.', 'English letters and digits only, 3 to 20.'), v:{c:'', n:'10'},
      fields:[{k:'c', type:'text', label:T('الكود', 'Code'), max:20, ph:'WHY20', upper:true}, {k:'n', type:'num', label:T('نسبة الخصم', 'Discount'), unit:'%'}],
      valid:v => /^[A-Za-z0-9]{3,20}$/.test(v.c || '') && numIn(v.n, 1, 90) && Number.isInteger(Number(v.n)),
      async run(v) { const r = await doStaff('/admin/code', {code:v.c.toUpperCase(), on:true, pct:Number(v.n)}, T('تمت إضافة الكود', 'Code added')); return !!r; }});
  },
  rwAdd(d) { rewardForm(null, d.k); },
  rwEdit(d) { const r = (SRV.rewards || []).find(x => x.id === d.id); if (r) rewardForm(r, r.pid ? 'p' : 'c'); },
  async rwOn(d) {
    const r = (SRV.rewards || []).find(x => x.id === d.id); if (!r) return;
    const q = Object.assign({}, r, {on:r.on === false});
    const res = await doStaff('/admin/reward', {op:'save', r:q}, q.on ? T('عادت المكافأة للعملاء', 'The reward is back') : T('أوقفت المكافأة', 'The reward is paused'));
    if (res && res.reward) { Object.assign(r, res.reward); render(); }
  },
  /* news */
  nwAdd() { newsForm(null); },
  nwEdit(d) { newsForm(d.id); },
  nwPhoto() { if (UI.nwf && !UI.nwf.up) { UI.onFile = nwUpload; fileInput().click(); } },
  nwNoPhoto() { if (UI.nwf) { UI.nwf.v.img = null; render(); } },
  async nwSave() {
    const f = UI.nwf; if (!f || !NEED.nwf()) return;
    const v = f.v, n = {t:{ar:v.tar.trim(), en:v.ten.trim()}, b:{ar:v.bar.trim(), en:v.ben.trim()}, img:v.img ? {id:v.img.id} : null};
    const r = await doStaff('/admin/news', {op:'save', id:f.id || undefined, n}, f.id ? T('تم حفظ الخبر', 'News saved') : T('تم نشر الخبر', 'News published'));
    if (r && r.news) { putNews(r.news); UI.nwf = null; UI.sheet = null; render(); }
  },
  nwDel() {
    const f = UI.nwf; if (!f || !f.id) return;
    UI.dlg = {t:T('حذف الخبر', 'Delete the news'), b:T('يختفي الخبر من تبويب الأخبار عند العملاء. لا يمكن التراجع.', 'It leaves the customers\' News tab. This cannot be undone.'), ok:T('حذف', 'Delete'), danger:true,
      async fn() { const r = await doStaff('/admin/news', {op:'del', id:f.id}, T('تم حذف الخبر', 'News deleted')); if (r) { SRV.news = (SRV.news || []).filter(x => x.id !== f.id); UI.nwf = null; UI.sheet = null; render(); } }};
    render();
  },
  async nwMove(d) { const r = await doStaff('/admin/news', {op:d.d, id:d.id}); if (r && SRV.news) { const l = SRV.news, i = l.findIndex(x => x.id === d.id), j = d.d === 'up' ? i - 1 : i + 1; if (i >= 0 && j >= 0 && j < l.length) { [l[i], l[j]] = [l[j], l[i]]; render(); } } },
  async nwOn(d) {
    const x = (SRV.news || []).find(n => n.id === d.id); if (!x) return;
    const on = x.on === false;
    const r = await doStaff('/admin/news', {op:'on', id:d.id, on}, on ? T('الخبر ظاهر للعملاء', 'Customers see it now') : T('أوقفت الخبر', 'The news item is paused'));
    if (r) { x.on = on; render(); }
  },
  bnAdd() { bannerForm(null); },
  bnEdit(d) { const b = (SRV.banners || []).find(x => x.id === d.id); if (b) bannerForm(b); },
  async bnMove(d) { const r = await doStaff('/admin/banners', {op:d.d, id:d.id}); if (r) { const l = SRV.banners, i = l.findIndex(x => x.id === d.id), j = d.d === 'up' ? i - 1 : i + 1; if (i >= 0 && j >= 0 && j < l.length) { [l[i], l[j]] = [l[j], l[i]]; render(); } } },
  bnPhoto() { if (UI.bnf && !UI.bnf.up) { UI.onFile = bnUpload; fileInput().click(); } },
  bnNoPhoto() { if (UI.bnf) { UI.bnf.v.img = null; render(); } },
  tlEdit(d) { if (HOME_TILES[d.id]) tileForm(d.id); },
  tlPhoto() { if (UI.tlf && !UI.tlf.up) { UI.onFile = tlUpload; fileInput().click(); } },
  tlNoPhoto() { if (UI.tlf) { UI.tlf.v.img = null; render(); } },
  async tlSave() {
    const f = UI.tlf; if (!f || !NEED.tlf()) return;
    const v = f.v, t = {t:{ar:v.tar.trim(), en:v.ten.trim()}, s:{ar:v.sar.trim(), en:v.sen.trim()}, img:v.img ? {id:v.img.id} : null};
    const r = await doStaff('/admin/tiles', {op:'save', id:f.id, t}, T('تم الحفظ', 'Saved'));
    if (r && r.tiles) { SRV.tiles = r.tiles; UI.tlf = null; UI.sheet = null; render(); }
  },
  async tlReset() {
    const f = UI.tlf; if (!f) return;
    const r = await doStaff('/admin/tiles', {op:'reset', id:f.id}, T('رجع كما كان', 'Back as it was'));
    if (r && r.tiles) { SRV.tiles = r.tiles; UI.tlf = null; UI.sheet = null; render(); }
  },
  bnTo(d) { if (UI.bnf) { UI.bnf.v.to = d.v; render(); } },
  async bnSave() {
    const f = UI.bnf; if (!f || !NEED.bnf()) return;
    const v = f.v, b = {t:{ar:v.tar.trim(), en:v.ten.trim()}, s:{ar:v.sar.trim(), en:v.sen.trim()}, a:v.to === 'prod' ? v.pid : v.to, img:v.img ? {id:v.img.id} : null};
    const r = await doStaff('/admin/banners', {op:'save', id:f.id || undefined, b}, f.id ? T('تم حفظ الإعلان', 'Banner saved') : T('تمت إضافة الإعلان', 'Banner added'));
    if (r && r.banner) { const l = SRV.banners, i = l.findIndex(x => x.id === r.banner.id); if (i >= 0) l[i] = r.banner; else l.push(r.banner); UI.bnf = null; UI.sheet = null; render(); }
  },
  bnDel() {
    const f = UI.bnf; if (!f || !f.id) return;
    UI.dlg = {t:T('حذف الإعلان', 'Delete the banner'), b:T('يختفي الإعلان من الصفحة الرئيسية عند العملاء.', 'The banner leaves the customers\' home page.'), ok:T('حذف', 'Delete'), danger:true,
      async fn() { const r = await doStaff('/admin/banners', {op:'del', id:f.id}, T('تم حذف الإعلان', 'Banner deleted')); if (r) { SRV.banners = SRV.banners.filter(x => x.id !== f.id); UI.bnf = null; UI.sheet = null; render(); } }};
    render();
  },
  async adBn(d) {
    const on = bannersAll().filter(b => SRV.bn[b.id] !== false);
    if (SRV.bn[d.id] !== false && on.length <= 1) { toast(T('يجب أن يبقى إعلان واحد على الأقل', 'At least one banner must stay on')); return; }
    const want = SRV.bn[d.id] === false;
    const r = await doStaff('/admin/banner', {id:d.id, on:want});
    if (r) { if (want) delete SRV.bn[d.id]; else SRV.bn[d.id] = false; render(); }
  },
  async adDelOn() { const want = !deliveryOn(); const r = await doStaff('/admin/fees', {delivery_on:want}); if (r) { SRV.delivery.on = want; render(); } },
  edDel() {
    openForm({title:T('رسوم التوصيل', 'Delivery fee'), sub:T('تُضاف على كل طلب توصيل', 'Added to every delivery order'), v:{n:String(deliveryFee())}, fields:[{k:'n', type:'num', label:T('الرسوم شاملة الضريبة', 'Fee including VAT'), unit:T('ر.س', 'SAR')}],
      valid:v => numIn(v.n, 0, 200),
      async run(v) { const r = await doStaff('/admin/fees', {delivery_fee:Number(v.n)}, T('تم تحديث رسوم التوصيل', 'Delivery fee updated')); if (r) SRV.delivery.fee = r2(Number(v.n)); return !!r; }});
  },
  edDelMin() {
    openForm({title:T('الحد الأدنى لطلب التوصيل', 'Smallest delivery order'), sub:T('قيمة الأصناف قبل رسوم التوصيل. اكتب 0 لإلغاء الحد الأدنى.', 'The items, before the delivery fee. Enter 0 for no minimum.'), v:{n:String(deliveryMin())}, fields:[{k:'n', type:'num', label:T('الحد الأدنى', 'Minimum'), unit:T('ر.س', 'SAR')}],
      valid:v => numIn(v.n, 0, 1000),
      async run(v) { const r = await doStaff('/admin/fees', {delivery_min:Number(v.n)}, T('تم تحديث الحد الأدنى', 'Minimum updated')); if (r) SRV.delivery.min = r2(Number(v.n)); return !!r; }});
  },
  edDelKm() {
    openForm({title:T('نطاق التوصيل', 'Delivery area'), sub:T('أبعد مسافة من الفرع (بخط مستقيم). اكتب 0 لإلغاء الحد. تُقاس من موقع الفرع على الخريطة.', 'The farthest distance from the branch (in a straight line). Enter 0 for no limit. Measured from the branch’s place on the map.'), v:{n:String(deliveryKm())}, fields:[{k:'n', type:'num', label:T('المسافة', 'Distance'), unit:T('كم', 'km')}],
      valid:v => numIn(v.n, 0, 100),
      async run(v) { const r = await doStaff('/admin/fees', {delivery_km:Number(v.n)}, T('تم تحديث نطاق التوصيل', 'Delivery area updated')); if (r) SRV.delivery.km = Math.round(Number(v.n) * 10) / 10; return !!r; }});
  },
  edShip() {
    openForm({title:T('رسوم الشحن', 'Shipping fee'), sub:T('تُضاف على طلبات الحبوب المشحونة', 'Added to shipped bean orders'), v:{n:String(SRV.ship)}, fields:[{k:'n', type:'num', label:T('الرسوم شاملة الضريبة', 'Fee including VAT'), unit:T('ر.س', 'SAR')}],
      valid:v => numIn(v.n, 0, 200),
      async run(v) { const r = await doStaff('/admin/fees', {ship:Number(v.n)}, T('تم تحديث رسوم الشحن', 'Shipping fee updated')); if (r) SRV.ship = r2(Number(v.n)); return !!r; }});
  },

  /* the tax invoice */
  taxEdit() {
    const t = SRV.tax || {name:'', vat:'', cr:'', addr:''};
    openForm({title:T('الفاتورة الضريبية', 'Tax invoice'), sub:T('كما في شهادة التسجيل في ضريبة القيمة المضافة. الرقم الضريبي 15 رقمًا يبدأ وينتهي بـ 3.', 'As on the VAT registration certificate. The VAT number is 15 digits starting and ending with 3.'), v:{name:t.name, vat:t.vat, cr:t.cr || '', addr:t.addr || ''},
      fields:[{k:'name', type:'text', label:T('اسم المنشأة', 'Business name'), max:80}, {k:'vat', type:'int', label:T('الرقم الضريبي', 'VAT number'), max:15, ph:'3XXXXXXXXXXXXX3'},
        {k:'cr', type:'int', label:T('السجل التجاري (اختياري)', 'Commercial registration (optional)'), max:10}, {k:'addr', type:'text', label:T('العنوان (اختياري)', 'Address (optional)'), max:160}],
      valid:v => (v.name || '').trim().length >= 2 && /^3\d{13}3$/.test(v.vat || '') && (!v.cr || /^\d{10}$/.test(v.cr)),
      async run(v) {
        const body = {name:v.name.trim(), vat:v.vat, cr:v.cr || '', addr:(v.addr || '').trim()};
        const r = await doStaff('/admin/tax', body, T('تم الحفظ، تظهر الفاتورة في الطلبات الجديدة', 'Saved. New orders have the invoice'));
        if (r) SRV.tax = body;
        return !!r;
      }});
  },
  taxOff() {
    UI.dlg = {t:T('إيقاف الفاتورة الضريبية', 'Switch the tax invoice off'), b:T('لن تكون للطلبات الجديدة فاتورة ضريبية. الطلبات السابقة تبقى فواتيرها.', 'New orders will have no tax invoice. Past orders keep theirs.'), ok:T('إيقاف', 'Switch off'), danger:true,
      async fn() { const r = await doStaff('/admin/tax', {vat:''}, T('أُوقفت الفاتورة الضريبية', 'Tax invoice switched off')); if (r) { SRV.tax = null; render(); } }};
    render();
  },
  /* a copy of the database, to keep off the server (asks for the admin code: it holds the customers' details) */
  dbGive() { giveCopy(); },
  dbCopy() {
    openForm({title:T('تنزيل نسخة من البيانات', 'Download a copy of the data'), sub:T('اكتب رمز الإدارة. الملف فيه كل البيانات ومنها بيانات العملاء، فاحفظه في مكان آمن ولا ترسله لأحد.', 'Type the admin code. The file holds all the data, the customers\' details too: keep it somewhere safe and do not send it to anyone.'), v:{pin:''},
      fields:[{k:'pin', type:'digits', label:T('رمز الإدارة', 'Admin code')}], valid:v => pinOk(v.pin), ok:T('تنزيل', 'Download'),
      async run(v) {
        UI.busy = true; syncBtns();
        try {
          let res;
          try { res = await fetch(API + '/admin/dbcopy', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({pin:v.pin}), credentials:'same-origin', cache:'no-store'}); }
          catch (e) { throw new ApiErr(0, 'net'); }
          if (!res.ok) { let j = null; try { j = await res.json(); } catch (e) { /* not JSON */ } throw new ApiErr(res.status, (j && j.error) || 'server', j); }
          const m = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || ''), blob = await res.blob();
          UI.dbFile = new File([blob], m ? m[1] : 'why-backup.zip', {type:'application/zip'});
          giveCopy();
          return true;
        } catch (e) {
          if (e.status === 401) { onSignedOut(); return false; }
          toast(errText(e)); UI.fm.v.pin = ''; return false;
        } finally { UI.busy = false; }
      }});
  },

  /* the order desk of one branch */
  deskAdd(d) {
    const b = BR[d.id]; if (!b) return;
    openForm({title:T(`شاشة ${L(b)}`, `${L(b)} desk`), sub:T('رمز سري من 6 إلى 10 أرقام، تعطيه موظفي الفرع. يدخلون به من رابط الاستقبال بعد اختيار الفرع.', 'A secret code of 6 to 10 digits for the branch staff. They sign in with it on the order desk link after picking the branch.'), v:{pin:''},
      fields:[{k:'pin', type:'digits', label:T('الرمز السري', 'Secret code')}], valid:v => pinOk(v.pin),
      async run(v) { const r = await doStaff('/admin/desk', {op:'add', branch:b.id, pin:v.pin}, T('تم إنشاء شاشة الفرع', 'The branch desk is ready')); if (r) { SRV.desks = (SRV.desks || []).concat({branch:b.id, active:true}); } return !!r; }});
  },
  deskPin(d) {
    const b = BR[d.id]; if (!b) return;
    openForm({title:T(`رمز شاشة ${L(b)}`, `${L(b)} desk code`), sub:T('الرمز الجديد من 6 إلى 10 أرقام. تخرج الشاشة من أجهزتها وتحتاج الرمز الجديد.', 'The new code is 6 to 10 digits. The desk is signed out everywhere and needs the new code.'), v:{pin:''},
      fields:[{k:'pin', type:'digits', label:T('الرمز الجديد', 'New code')}], valid:v => pinOk(v.pin),
      async run(v) { const r = await doStaff('/admin/desk', {op:'pin', branch:b.id, pin:v.pin}, T('تم تغيير الرمز', 'Code changed')); return !!r; }});
  },
  async deskOn(d) {
    const x = (SRV.desks || []).find(y => y.branch === d.id); if (!x) return;
    const r = await doStaff('/admin/desk', {op:'on', branch:d.id, on:!x.active}, x.active ? T('تم إيقاف شاشة الفرع', 'Branch desk switched off') : T('عادت شاشة الفرع', 'Branch desk is back on'));
    if (r) { x.active = !x.active; render(); }
  },
  deskDel(d) {
    const b = BR[d.id]; if (!b) return;
    UI.dlg = {t:T('حذف شاشة الفرع', 'Remove the branch desk'), b:T(`لن يستطيع أحد الدخول برمز شاشة ${L(b)}. تبقى طلباته ظاهرة في شاشة كل الفروع.`, `Nobody can sign in with the ${L(b)} desk code. Its orders still show on the all-branches desk.`), ok:T('حذف', 'Remove'), danger:true,
      async fn() { const r = await doStaff('/admin/desk', {op:'del', branch:b.id}, T('تم حذف شاشة الفرع', 'Branch desk removed')); if (r) { SRV.desks = (SRV.desks || []).filter(y => y.branch !== b.id); render(); } }};
    render();
  },

  /* drivers */
  drvAdd() {
    openForm({title:T('إضافة مندوب', 'Add a driver'), sub:T('اكتب اسمه ورمزًا سريًا من 6 إلى 10 أرقام، وأعطه إياهما. يدخل بهما من رابط المندوب.', 'Type his name and a secret code of 6 to 10 digits, and give both to him. He signs in with them on the driver link.'), v:{name:'', pin:''},
      fields:[{k:'name', type:'text', label:T('الاسم', 'Name'), max:40}, {k:'pin', type:'digits', label:T('الرمز السري', 'Secret code')}, {k:'phone', type:'digits', label:T('رقم الجوال (اختياري، يظهر للعميل أثناء التوصيل)', 'Mobile (optional, the customer sees it during his delivery)'), max:10}],
      valid:v => (v.name || '').trim().length >= 2 && pinOk(v.pin) && (!v.phone || !!drvPh(v.phone)),
      async run(v) { const r = await doStaff('/admin/driver', Object.assign({op:'add', name:v.name.trim(), pin:v.pin}, v.phone ? {phone:drvPh(v.phone)} : {}), T('تمت إضافة المندوب', 'Driver added')); return !!r; }});
  },
  drvPhoneEd(d) {
    const x = (SRV.drivers || []).find(y => String(y.id) === d.id); if (!x) return;
    openForm({title:T(`رقم ${x.name}`, `${x.name}'s number`), sub:T('يظهر للعميل أثناء توصيل طلبه فقط، ليتصل بالمندوب أو يراسله واتساب. اتركه فارغًا لإخفائه.', 'The customer sees it only while his order is on its way, to call or WhatsApp the driver. Leave it empty to hide it.'), v:{phone:x.phone ? '0' + x.phone : ''},
      fields:[{k:'phone', type:'digits', label:T('رقم الجوال', 'Mobile number'), max:10}],
      valid:v => !v.phone || !!drvPh(v.phone),
      async run(v) { const r = await doStaff('/admin/driver', {op:'phone', id:x.id, phone:v.phone ? drvPh(v.phone) : ''}, v.phone ? T('تم حفظ الرقم', 'Number saved') : T('تم حذف الرقم', 'Number removed')); return !!r; }});
  },
  drvPin(d) {
    const x = (SRV.drivers || []).find(y => String(y.id) === d.id); if (!x) return;
    openForm({title:T(`رمز ${x.name}`, `${x.name}'s code`), sub:T('الرمز الجديد من 6 إلى 10 أرقام. يخرج المندوب من أجهزته ويحتاج الرمز الجديد.', 'The new code is 6 to 10 digits. The driver is signed out everywhere and needs the new code.'), v:{pin:''}, fields:[{k:'pin', type:'digits', label:T('الرمز الجديد', 'New code')}],
      valid:v => pinOk(v.pin),
      async run(v) { const r = await doStaff('/admin/driver', {op:'pin', id:x.id, pin:v.pin}, T('تم تغيير الرمز', 'Code changed')); return !!r; }});
  },
  async drvOn(d) { const x = (SRV.drivers || []).find(y => String(y.id) === d.id); if (x) await doStaff('/admin/driver', {op:x.active ? 'off' : 'on', id:x.id}, x.active ? T('تم إيقاف المندوب', 'Driver switched off') : T('عاد المندوب للعمل', 'Driver is back on')); },
  drvDel(d) {
    const x = (SRV.drivers || []).find(y => String(y.id) === d.id); if (!x) return;
    UI.dlg = {t:T('حذف المندوب', 'Remove the driver'), b:T(`سيُحذف ${x.name} ولن يستطيع الدخول. الطلبات التي وصّلها تبقى في السجل.`, `${x.name} will be removed and cannot sign in. His finished deliveries stay on record.`), ok:T('حذف', 'Remove'), danger:true, fn() { doStaff('/admin/driver', {op:'remove', id:x.id}, T('تم حذف المندوب', 'Driver removed')); }};
    render();
  },

  /* customers: add points */
  edPts(d) {
    const c = (SRV.cust || []).find(y => String(y.id) === d.id); if (!c) return;
    /* what the customer typed when signing up (older accounts have none of it) */
    const info = [
      c.email && [T('البريد الإلكتروني', 'Email'), c.email, true],
      c.birth && [T('تاريخ الميلاد', 'Date of birth'), c.birth, true],
      c.gender && [T('الجنس', 'Gender'), c.gender === 'f' ? T('أنثى', 'Female') : T('ذكر', 'Male')],
      c.invite && [T('رمز الدعوة', 'Invite code'), c.invite, true],
      c.email && [T('إشعارات التسويق', 'Marketing notifications'), c.mk ? T('موافق', 'Agreed') : T('غير موافق', 'Not agreed')],
    ].filter(Boolean);
    openForm({title:T('إضافة نقاط', 'Add points'), sub:c.name, info, v:{n:'50'}, fields:[{k:'n', type:'int', label:T('عدد النقاط (حتى 5000)', 'Points to add (up to 5000)'), max:4, ph:'50'}],
      valid:v => numIn(v.n, 1, 5000) && Number.isInteger(Number(v.n)),
      async run(v) { const r = await doStaff('/admin/points', {id:c.id, pts:Number(v.n)}, T(`تمت إضافة ${Number(v.n)} نقطة، تصل العميل خلال لحظات`, `${Number(v.n)} points added. They reach him in a moment`)); return !!r; }});
  },

  /* settings: codes and clean-up */
  pinChange(d) {
    const who = d.id === 'admin' ? T('رمز الإدارة', 'Admin code') : T('رمز الاستقبال', 'Order desk code');
    openForm({title:T(`تغيير ${who}`, `Change the ${who}`), sub:T('اكتب رمز الإدارة الحالي ثم الرمز الجديد مرتين.', 'Type the current admin code, then the new code twice.'), v:{cur:'', pin:'', pin2:''},
      fields:[{k:'cur', type:'digits', label:T('رمز الإدارة الحالي', 'Current admin code')}, {k:'pin', type:'digits', label:T('الرمز الجديد (6 إلى 10 أرقام)', 'New code (6 to 10 digits)')}, {k:'pin2', type:'digits', label:T('أعد كتابة الرمز الجديد', 'Type the new code again')}],
      valid:v => pinOk(v.cur) && pinOk(v.pin) && v.pin === v.pin2,
      async run(v) {
        const r = await doStaff('/admin/pin', {current:v.cur, target:d.id, pin:v.pin}, T('تم تغيير الرمز', 'Code changed'));
        if (r && d.id === 'admin') { toast(T('سجّل الدخول بالرمز الجديد', 'Sign in with the new code')); }
        return !!r;
      }});
  },
  wipeAsk() {
    UI.dlg = {t:T('حذف الطلبات والعملاء', 'Delete orders and customers'), b:T('سيُحذف كل شيء مسجل من طلبات وعملاء في الخادم. لا يمكن التراجع. سنطلب رمز الإدارة للتأكيد.', 'Every order and customer on the server will be deleted. This cannot be undone. We will ask for the admin code to confirm.'), ok:T('متابعة', 'Continue'), danger:true,
      fn() {
        openForm({title:T('تأكيد الحذف', 'Confirm the deletion'), sub:T('اكتب رمز الإدارة لحذف الطلبات والعملاء.', 'Type the admin code to delete the orders and customers.'), v:{pin:''}, fields:[{k:'pin', type:'digits', label:T('رمز الإدارة', 'Admin code')}], ok:T('حذف نهائي', 'Delete for good'), danger:true,
          valid:v => pinOk(v.pin),
          async run(v) { const r = await doStaff('/admin/wipe', {pin:v.pin}, T('تم حذف الطلبات والعملاء', 'Orders and customers deleted')); return !!r; }});
      }};
    render();
  },

  /* the form sheet */
  async fmSave() {
    const f = UI.fm; if (!f || UI.busy || !f.valid(f.v)) return;
    const ok = await f.run(f.v);
    if (ok) { f.v = {}; UI.fm = null; UI.sheet = null; if (f.back) openSheet({k:f.back}); else render(); }
    else { UI.dirty = true; }
  },
  async fmExtra() {
    const f = UI.fm; if (!f || UI.busy || !f.runExtra) return;
    if (await f.runExtra()) { UI.fm = null; UI.sheet = null; render(); }
  }
});

/* closing the product form with unsaved changes asks first (the cross, the shade, Escape) */
const closeSheet = A.close;
A.close = function () {
  if (UI.sheet && UI.sheet.k === 'prod' && peDirty()) {
    UI.dlg = {t:T('تجاهل التعديلات؟', 'Discard the changes?'), b:T('لم تُحفظ التعديلات على هذا المنتج.', 'The changes to this product were not saved.'), ok:T('تجاهل', 'Discard'), danger:true, fn() { UI.pe = null; closeSheet(); }};
    render(); return;
  }
  if (UI.sheet && UI.sheet.k === 'brf' && bfDirty()) {
    UI.dlg = {t:T('تجاهل التعديلات؟', 'Discard the changes?'), b:T('لم تُحفظ التعديلات على هذا الفرع.', 'The changes to this branch were not saved.'), ok:T('تجاهل', 'Discard'), danger:true, fn() { UI.bf = null; closeSheet(); }};
    render(); return;
  }
  if (UI.sheet && UI.sheet.k === 'prod') UI.pe = null;
  if (UI.sheet && UI.sheet.k === 'brf') UI.bf = null;
  closeSheet();
};

function boot() {
  applyLang(); UI.mode = 'boot'; render(); startPoll();
}
