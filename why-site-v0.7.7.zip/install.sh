#!/usr/bin/env bash
# Why! installer.
# Puts the Why! cafe system on this server:
#   - the server program (orders and accounts, one SQLite file) as the service "why-server", with strict limits
#   - the four pages: Why! (customers) /   ORDER DESK /reception/   MANAGEMENT /admin/   DELIVERY /driver/
#   - ONE marked block in the Caddyfile that serves the pages and hands /api to the server program
#
#   bash install.sh                install or update
#   bash install.sh status         show what is running (changes nothing)
#   bash install.sh remove         take Why! down (the customer data is kept)
#   options:  --yes  (do not ask)     --domain NAME  (use another name)
#
# What it touches: /opt/why-site (this folder), /opt/why-server (the program), /var/lib/why (the data and its daily
# backups), /var/www/why (the pages), the service why-server, a system user "why", and ONE marked block in the
# Caddyfile (a backup is made first, the file is checked before it is applied, and it is restored if the check fails).
# It never stops, restarts or removes anything else: the auction bot and every other site keep running as they are.
set -uo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SETTINGS="$APP_DIR/settings.txt"
WEB_ROOT="${WHY_WEB_ROOT:-/var/www/why}"
RUN_DIR="${WHY_RUN_DIR:-/opt/why-server}"
DATA_DIR="${WHY_DATA_DIR:-/var/lib/why}"
UNIT_DIR="${WHY_UNIT_DIR:-/etc/systemd/system}"
UNIT_NAME="why-server"
UNIT="$UNIT_DIR/$UNIT_NAME.service"
SVC_USER="${WHY_USER:-why}"
DB="$DATA_DIR/why.db"
SERVER_SRC="$APP_DIR/source/server"
PORT_FIRST="${WHY_PORT_START:-8787}"
WAIT_SECS="${WHY_WAIT_SECS:-30}"      # how long to wait for the server program to answer after (re)starting it
CF_DEFAULT="${WHY_CADDYFILE:-/etc/caddy/Caddyfile}"
DEFAULT_DOMAIN="whycoffee.duckdns.org"
VERSION="$(cat "$APP_DIR/VERSION" 2>/dev/null || echo "?")"
BEGIN_MARK="# >>> why-site (managed by install.sh in /opt/why-site; do not edit between the markers)"
END_MARK="# <<< why-site"
PAGES="/ /reception/ /admin/ /driver/"

CMD="install"; ASSUME_YES=0; DOMAIN_ARG=""; MODE=""
while [ $# -gt 0 ]; do
  case "$1" in
    install|status|remove) CMD="$1" ;;
    -y|--yes) ASSUME_YES=1 ;;
    --domain) shift; DOMAIN_ARG="${1:-}" ;;
    --domain=*) DOMAIN_ARG="${1#--domain=}" ;;
    -h|--help) sed -n '2,16p' "$0"; exit 0 ;;
    *) echo "ERROR: unknown option: $1"; exit 2 ;;
  esac
  shift
done

TMP="$(mktemp -d)"; SELFTEST_DIR=""
trap 'rm -rf "$TMP" "${SELFTEST_DIR:-}" "${NEWCODE:-}"' EXIT
UNDO=()          # what to put back, last first, if something fails after we changed it
OLDCODE=""; NEWCODE=""; UNIT_PREV=""; UNIT_EXISTED=0; SVC_WAS_UP=0; PUB_OLD=""; PUB_NEW=""; PORT=""; PYTHON=""
PIN_VALUE=""

say()  { printf '%s\n' "$*"; }
step() { printf '\n== %s\n' "$*"; }
ok()   { printf '   [ok] %s\n' "$*"; }
warn() { printf '   [!]  %s\n' "$*"; }
run_undo() { local i; for ((i = ${#UNDO[@]} - 1; i >= 0; i--)); do "${UNDO[$i]}" || true; done; UNDO=(); }
die()  { printf '\nERROR: %b\n' "$*" >&2; run_undo; exit 1; }
tail_of() { tail -n "${2:-6}" "$1" 2>/dev/null | sed 's/^/      /'; }

setting() { [ -f "$SETTINGS" ] && grep -E "^$1=" "$SETTINGS" | tail -n 1 | cut -d= -f2- || true; }

DOMAIN="${DOMAIN_ARG:-$(setting DOMAIN)}"; DOMAIN="${DOMAIN:-$DEFAULT_DOMAIN}"
DOMAIN="$(printf '%s' "$DOMAIN" | tr 'A-Z' 'a-z')"
printf '%s' "$DOMAIN" | grep -Eq '^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$' \
  || die "The site name looks wrong: $DOMAIN"

need_root() { [ "$(id -u)" = "0" ] || die "Run this as root (the DigitalOcean console already is)."; }

# ---------- looking at the server ----------
valid_ip() { printf '%s' "$1" | grep -Eq '^[0-9]{1,3}(\.[0-9]{1,3}){3}$'; }

my_ips() {   # addresses that identify this server, one per line
  local a md="http://169.254.169.254/metadata/v1"
  a="$(curl -fsS --max-time 4 "$md/interfaces/public/0/ipv4/address" 2>/dev/null || true)"; valid_ip "$a" && echo "$a"
  if [ "$(curl -fsS --max-time 4 "$md/reserved_ip/ipv4/active" 2>/dev/null || true)" = "true" ]; then
    a="$(curl -fsS --max-time 4 "$md/reserved_ip/ipv4/ip_address" 2>/dev/null || true)"; valid_ip "$a" && echo "$a"
  fi
  a="$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || true)"; valid_ip "$a" && echo "$a"
  return 0
}

resolve_ip() { getent ahostsv4 "$1" 2>/dev/null | awk '{print $1; exit}'; }

port_owners() {   # names of the programs listening on TCP port $1 ("unknown" if the name is hidden)
  ss -ltnp 2>/dev/null | awk -v want="$1" '
    NR == 1 && $1 == "State" { next }
    { n = split($4, a, ":"); if (a[n] != want) next
      if (match($0, /users:\(\("[^"]*"/)) { s = substr($0, RSTART + 9, RLENGTH - 9); gsub(/"/, "", s); print s } else print "unknown" }' | sort -u
}

caddy_config_path() {   # the Caddyfile Caddy is really started with
  local p=""
  if command -v systemctl >/dev/null 2>&1; then
    p="$(systemctl cat caddy.service 2>/dev/null | grep -Eo -- '--config[= ]+[^ ]+' | head -n 1 | sed -E 's/--config[= ]+//')"
  fi
  printf '%s' "${p:-$CF_DEFAULT}"
}

# ---------- the Caddyfile block ----------
caddyfile_edit() {   # $1 file, $2 add|fresh|remove   (exit 3 = the name is already used outside our block)
  python3 - "$1" "$2" "$DOMAIN" "$WEB_ROOT" "$APP_DIR/caddy-block.tpl" "$BEGIN_MARK" "$END_MARK" "${PORT:-8787}" <<'PY'
import os, re, sys
path, mode, domain, root, tpl, BEGIN, END, port = sys.argv[1:9]
try:
    text = open(path, encoding="utf-8").read()
except FileNotFoundError:
    text = ""
pat = re.compile(r"\n*" + re.escape(BEGIN) + r".*?" + re.escape(END) + r"[ \t]*\n?", re.S)
while True:   # take our old block out; every other line of the file stays exactly as it was
    m = pat.search(text)
    if not m:
        break
    head, tail = text[:m.start()].rstrip("\n"), text[m.end():].lstrip("\n")
    text = head + ("\n\n" if head and tail else "") + tail
if mode == "fresh":
    text = ""
used = re.compile(r"^\s*(https?://)?" + re.escape(domain) + r"(:\d+)?\s*(,|\{|$)", re.I)
for i, line in enumerate(text.splitlines(), 1):
    if mode != "remove" and used.match(line):
        print("line %d: %s" % (i, line.strip()))
        sys.exit(3)
text = text.rstrip("\n")
if mode in ("add", "fresh"):
    block = open(tpl, encoding="utf-8").read().replace("__DOMAIN__", domain).replace("__ROOT__", root).replace("__PORT__", port).rstrip("\n")
    text = (text + "\n\n" if text.strip() else "") + BEGIN + "\n" + block + "\n" + END
tmp = path + ".why-new"
with open(tmp, "w", encoding="utf-8") as f:
    f.write(text + "\n" if text else "")
os.replace(tmp, path)
PY
}

caddy_check()  { caddy validate --config "$1" --adapter caddyfile >"$TMP/validate.txt" 2>&1; }
caddy_reload() {   # $1 Caddyfile, $2 new|existing
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl is-active --quiet caddy 2>/dev/null; then
      systemctl reload caddy >"$TMP/reload.txt" 2>&1 && return 0
    elif [ "${2:-existing}" = new ]; then
      systemctl restart caddy >"$TMP/reload.txt" 2>&1 && return 0   # installed but not running yet: start it
    fi
  fi
  caddy reload --config "$1" --adapter caddyfile >>"$TMP/reload.txt" 2>&1
}

apply_block() {   # $1 Caddyfile, $2 add|fresh|remove: backup, edit, check, reload, and undo everything if it fails
  local cf="$1" mode="$2" bak="" rc kind=existing
  [ "${MODE:-}" = new ] && kind=new
  if [ -f "$cf" ] && [ "$mode" != fresh ]; then
    if ! caddy_check "$cf"; then
      warn "Caddy's current settings do not pass its own check when run from here:"; tail_of "$TMP/validate.txt" 6
      die "I did not touch the Caddyfile, so nothing was changed. Send me a screenshot of this screen."
    fi
  fi
  if [ -f "$cf" ]; then bak="$cf.bak-$(date +%Y%m%d-%H%M%S)"; cp -p "$cf" "$bak" || die "Could not back up $cf"; ok "backup: $bak"; fi
  undo_cf() { if [ -n "$bak" ]; then cp -p "$bak" "$cf"; else rm -f "$cf"; fi; }
  caddyfile_edit "$cf" "$mode" >"$TMP/edit.txt" 2>&1; rc=$?
  if [ $rc -eq 3 ]; then
    undo_cf
    die "The name $DOMAIN is already written in $cf ($(cat "$TMP/edit.txt")).\n       Remove that entry first, or choose another name. Nothing was changed."
  elif [ $rc -ne 0 ]; then
    undo_cf
    die "Could not edit $cf:\n$(sed 's/^/      /' "$TMP/edit.txt")"
  fi
  if ! caddy_check "$cf"; then
    undo_cf
    warn "Caddy did not accept the new settings, so the old file was put back:"; tail_of "$TMP/validate.txt" 8
    die "Nothing was changed on this server's web server."
  fi
  ok "the new settings are valid"
  if ! caddy_reload "$cf" "$kind"; then
    undo_cf
    warn "Caddy could not reload, so the old file was put back:"; tail_of "$TMP/reload.txt" 8
    die "Your other sites keep running as before."
  fi
  ok "Caddy reloaded (the other sites were not interrupted)"
}

# ---------- the server program ----------
as_why() { runuser -u "$SVC_USER" -- "$@"; }
srv()    { local dir="$1"; shift; as_why "$PYTHON" -I -B "$dir/why_server.py" "$@"; }   # the program's own commands, as the service user

check_python() {
  PYTHON="$(command -v python3 2>/dev/null || true)"
  [ -n "$PYTHON" ] || die "python3 was not found on this server."
  "$PYTHON" -c 'import sys, sqlite3; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>"$TMP/py.txt" \
    || die "Python 3.9 or newer (with sqlite3) is needed here; this server has: $("$PYTHON" -V 2>&1)"
  command -v runuser >/dev/null 2>&1 || die "The command runuser was not found (it comes with Ubuntu and Debian)."
  command -v systemctl >/dev/null 2>&1 || die "This server does not use systemd; the Why! server needs it."
}

pick_port() {   # keep the port the service already uses; otherwise the first free one from 8787
  local p i
  if [ -f "$UNIT" ]; then
    p="$(grep -Eo -- '--port [0-9]+' "$UNIT" | head -n 1 | awk '{print $2}')"
    if [ -n "$p" ]; then PORT="$p"; return 0; fi
  fi
  for i in $(seq 0 12); do
    p=$((PORT_FIRST + i))
    if [ -z "$(port_owners "$p")" ]; then PORT="$p"; return 0; fi
  done
  die "No free local port between $PORT_FIRST and $((PORT_FIRST + 12)). Nothing was changed."
}

ensure_user() {
  if getent passwd "$SVC_USER" >/dev/null 2>&1; then ok "the service user '$SVC_USER' already exists"; return 0; fi
  useradd --system --user-group --no-create-home --home-dir "$DATA_DIR" --shell /usr/sbin/nologin "$SVC_USER" >"$TMP/useradd.txt" 2>&1 \
    || { tail_of "$TMP/useradd.txt"; die "Could not create the service user '$SVC_USER'."; }
  ok "created the service user '$SVC_USER' (no password, it cannot log in)"
}

ensure_dirs() {
  mkdir -p "$DATA_DIR" "$(dirname "$RUN_DIR")" || die "Could not create $DATA_DIR"
  chown "$SVC_USER:$SVC_USER" "$DATA_DIR" 2>"$TMP/chown.txt" || { tail_of "$TMP/chown.txt"; die "Could not give $DATA_DIR to the user '$SVC_USER'."; }
  chmod 700 "$DATA_DIR"
  ok "data folder: $DATA_DIR (only the service user can open it)"
}

render_unit() {   # writes $TMP/unit from the template
  local tpl="$APP_DIR/why-server.service.tpl"
  [ -f "$tpl" ] || die "why-server.service.tpl is missing from the package. Unzip the package again."
  sed -e "s|__USER__|$SVC_USER|g" -e "s|__PYTHON__|$PYTHON|g" -e "s|__RUN_DIR__|$RUN_DIR|g" -e "s|__DATA_DIR__|$DATA_DIR|g" -e "s|__PORT__|$PORT|g" "$tpl" >"$TMP/unit" \
    || die "Could not prepare the service file."
}

stage_code() {   # copy the program next to the old one and run its self-test (as the service user, on an empty temporary database)
  [ -f "$SERVER_SRC/why_server.py" ] && [ -f "$SERVER_SRC/catalog.json" ] || die "The server program is missing from the package ($SERVER_SRC). Unzip the package again."
  "$PYTHON" -c 'import json, sys; json.load(open(sys.argv[1], encoding="utf-8"))' "$SERVER_SRC/catalog.json" 2>/dev/null || die "catalog.json in the package is damaged. Unzip the package again."
  NEWCODE="$RUN_DIR.new.$$"
  rm -rf "$NEWCODE"; mkdir -p "$NEWCODE" || die "Could not create $NEWCODE"
  cp "$SERVER_SRC/why_server.py" "$SERVER_SRC/catalog.json" "$NEWCODE/" || die "Could not copy the server program."
  chmod 755 "$NEWCODE"; chmod 644 "$NEWCODE"/*
  SELFTEST_DIR="$(mktemp -d /tmp/why-selftest.XXXXXX)" || die "Could not create a temporary folder."
  chown "$SVC_USER:$SVC_USER" "$SELFTEST_DIR" 2>/dev/null; chmod 700 "$SELFTEST_DIR"
  if ! srv "$NEWCODE" check --db "$SELFTEST_DIR/t.db" --catalog "$NEWCODE/catalog.json" >"$TMP/selftest.txt" 2>&1; then
    tail_of "$TMP/selftest.txt" 8
    rm -rf "$NEWCODE"
    die "The new server program did not pass its self-test. Nothing was changed."
  fi
  ok "the server program passed its self-test"
}

has_pin() { srv "$NEWCODE" check --db "$DB" --catalog "$NEWCODE/catalog.json" 2>/dev/null | grep -q "^staff: $1 "; }

weak_pin() {   # success when the code is too easy to guess
  local p="$1" first="${1:0:1}"
  [ -z "${p//$first/}" ] && return 0                         # 000000, 777777
  case "01234567890123456789" in *"$p"*) return 0 ;; esac    # 123456, 2345678 ...
  case "98765432109876543210" in *"$p"*) return 0 ;; esac    # 654321 ...
  return 1
}

ask_pin() {   # $1 name in English, $2 name in Arabic, $3 a code it must differ from (optional). Result: PIN_VALUE
  local a b n=0
  while [ "$n" -lt 6 ]; do
    n=$((n + 1))
    printf '\n   Secret code for the %s screen: 6 to 10 digits. Typing is hidden.\n   الرمز السري لشاشة %s: من 6 إلى 10 أرقام. الكتابة مخفية.\n' "$1" "$2" >&2
    IFS= read -rs -p "   Code: " a || return 1; printf '\n' >&2
    if ! printf '%s' "$a" | grep -Eq '^[0-9]{6,10}$'; then printf '   [!] 6 to 10 digits only.  /  من 6 إلى 10 أرقام فقط.\n' >&2; continue; fi
    if weak_pin "$a"; then printf '   [!] Too easy to guess (like 123456 or 111111). Choose another.  /  رمز سهل التخمين، اختر غيره.\n' >&2; continue; fi
    if [ -n "${3:-}" ] && [ "$a" = "$3" ]; then printf '   [!] It must be different from the MANAGEMENT code.  /  يجب أن يختلف عن رمز الإدارة.\n' >&2; continue; fi
    IFS= read -rs -p "   Again: " b || return 1; printf '\n' >&2
    if [ "$a" != "$b" ]; then printf '   [!] The two did not match.  /  الرمزان غير متطابقين.\n' >&2; continue; fi
    PIN_VALUE="$a"; return 0
  done
  return 1
}

save_pin() {   # $1 role (admin|recv); the code goes straight to the program through a pipe, never through a file or the command line
  printf '%s\n' "$PIN_VALUE" | srv "$NEWCODE" setpin --role "$1" --pin-stdin --db "$DB" --catalog "$NEWCODE/catalog.json" >"$TMP/setpin.txt" 2>&1 \
    || { PIN_VALUE=""; tail_of "$TMP/setpin.txt" 4; die "Could not save the secret code."; }
}

ensure_pins() {
  local need_admin=0 need_recv=0 admin_pin=""
  has_pin admin || need_admin=1
  has_pin recv  || need_recv=1
  if [ $need_admin = 0 ] && [ $need_recv = 0 ]; then ok "the MANAGEMENT and ORDER DESK codes are already set (they stay as they are)"; return 0; fi
  [ -t 0 ] || die "The secret codes have to be typed by a person at the keyboard.\n       Open the DigitalOcean console and run this again without piping anything in."
  say "   Two secret codes protect the MANAGEMENT screen and the ORDER DESK screen."
  say "   Type them yourself. They are not shown, and only a scrambled form of each is stored."
  say "   رمزان سريان يحميان شاشة الإدارة وشاشة الاستقبال. اكتبهما بنفسك، لا يظهران على الشاشة."
  if [ $need_admin = 1 ]; then
    ask_pin "MANAGEMENT" "الإدارة" "" || die "No MANAGEMENT code was set. Run the installer again when you are ready."
    admin_pin="$PIN_VALUE"; save_pin admin; ok "MANAGEMENT code saved"
  fi
  if [ $need_recv = 1 ]; then
    ask_pin "ORDER DESK" "الاستقبال" "$admin_pin" || die "No ORDER DESK code was set. Run the installer again when you are ready."
    save_pin recv; ok "ORDER DESK code saved"
  fi
  PIN_VALUE=""; admin_pin=""
}

same_as_running() {   # nothing to update: same program, same service file, and it answers
  [ -f "$UNIT" ] && [ -f "$RUN_DIR/why_server.py" ] || return 1
  cmp -s "$NEWCODE/why_server.py" "$RUN_DIR/why_server.py" && cmp -s "$NEWCODE/catalog.json" "$RUN_DIR/catalog.json" && cmp -s "$TMP/unit" "$UNIT" || return 1
  systemctl is-active --quiet "$UNIT_NAME" 2>/dev/null && wait_api 3
}

wait_api() {   # $1 = tries, one per second
  local i
  for i in $(seq 1 "${1:-30}"); do
    if curl -fsS --max-time 3 "http://127.0.0.1:$PORT/api/health" >"$TMP/health.json" 2>/dev/null && grep -q '"ok":true' "$TMP/health.json"; then return 0; fi
    sleep 1
  done
  return 1
}

undo_service() {   # put the previous program back; on a first install leave nothing half-done
  warn "putting the previous state of the server program back"
  systemctl stop "$UNIT_NAME" >/dev/null 2>&1 || true
  if [ -n "$OLDCODE" ] && [ -d "$OLDCODE" ]; then
    rm -rf "$RUN_DIR"; mv "$OLDCODE" "$RUN_DIR"; OLDCODE=""
    if [ -n "$UNIT_PREV" ] && [ -f "$UNIT_PREV" ]; then cp -p "$UNIT_PREV" "$UNIT"; systemctl daemon-reload >/dev/null 2>&1 || true; fi
    if [ "$SVC_WAS_UP" = 1 ]; then
      if systemctl start "$UNIT_NAME" >/dev/null 2>&1 && wait_api "$WAIT_SECS"; then ok "the previous version is running again"
      else warn "the previous version did not answer after it was put back; run: bash $APP_DIR/install.sh status   and   journalctl -u $UNIT_NAME -n 30"; fi
    fi
  else
    systemctl disable "$UNIT_NAME" >/dev/null 2>&1 || true
    rm -f "$UNIT"; systemctl daemon-reload >/dev/null 2>&1 || true
    rm -rf "$RUN_DIR"
  fi
}

install_server() {   # swap in the new program, write the service file, (re)start, wait until it answers
  if [ "$UNIT_EXISTED" = 1 ] && [ -f "$DB" ]; then
    srv "$NEWCODE" backup --db "$DB" --catalog "$NEWCODE/catalog.json" >"$TMP/backup.txt" 2>&1 \
      || { tail_of "$TMP/backup.txt" 5; die "Could not back up the database before the update, so nothing was changed."; }
    ok "database backed up first ($(sed -n 's/^backup saved: //p' "$TMP/backup.txt" | tail -n 1))"
  fi
  OLDCODE=""
  if [ -d "$RUN_DIR" ]; then OLDCODE="$RUN_DIR.old.$$"; rm -rf "$OLDCODE"; mv "$RUN_DIR" "$OLDCODE" || die "Could not move the old program aside."; fi
  mv "$NEWCODE" "$RUN_DIR" || { [ -n "$OLDCODE" ] && mv "$OLDCODE" "$RUN_DIR"; die "Could not install the server program."; }
  NEWCODE=""
  UNDO+=(undo_service)
  install -m 644 "$TMP/unit" "$UNIT" || die "Could not write $UNIT"
  systemctl daemon-reload >"$TMP/sc.txt" 2>&1 || { tail_of "$TMP/sc.txt" 4; die "systemctl daemon-reload failed."; }
  systemctl enable "$UNIT_NAME" >"$TMP/sc.txt" 2>&1 || warn "could not make the server start at boot ($(tail -n 1 "$TMP/sc.txt"))"
  if [ "$SVC_WAS_UP" = 1 ]; then systemctl restart "$UNIT_NAME" >"$TMP/sc.txt" 2>&1; else systemctl start "$UNIT_NAME" >"$TMP/sc.txt" 2>&1; fi \
    || { tail_of "$TMP/sc.txt" 6; journalctl -u "$UNIT_NAME" --no-pager -n 12 2>/dev/null | cut -c1-200 | sed 's/^/      /'; die "The Why! server could not start. The previous state was put back."; }
  if ! wait_api "$WAIT_SECS"; then
    warn "the server did not answer on 127.0.0.1:$PORT. Its log:"
    journalctl -u "$UNIT_NAME" --no-pager -n 12 2>/dev/null | cut -c1-200 | sed 's/^/      /'
    die "The Why! server did not come up. The previous state was put back."
  fi
  UNDO=()
  rm -rf "$OLDCODE"; OLDCODE=""
  ok "the Why! server is running (service $UNIT_NAME, port $PORT on this machine only)"
}

# ---------- commands ----------
detect_server() {
  HOST_NOW="$(hostname 2>/dev/null || echo unknown)"
  IPS="$(my_ips | awk '!seen[$0]++')"
  MYIP="$(printf '%s\n' "$IPS" | sed -n '1p')"
  [ -n "$MYIP" ] || die "Could not find this server's public address. Is the internet reachable from here?"
  RESOLVED="$(resolve_ip "$DOMAIN")"
  if [ -z "$RESOLVED" ]; then
    die "The name $DOMAIN does not exist yet.\n       Open duckdns.org, create the name, set its IP to $MYIP and press update.\n       Wait one minute, then run this command again."
  fi
  if ! printf '%s\n' "$IPS" | grep -qx "$RESOLVED"; then
    die "$DOMAIN points to $RESOLVED, but this server is $MYIP.\n       If this is the right server: open duckdns.org, set the IP of the name to $MYIP, press update, wait one minute and run this again.\n       If you meant another server: open that server's console instead.\n       Nothing was changed."
  fi
  V6WARN="$(getent ahostsv6 "$DOMAIN" 2>/dev/null | awk '$1 !~ /^::ffff:/ {print $1; exit}')"   # a real IPv6 address on the name
  if [ -n "$V6WARN" ] && ip -6 addr show scope global 2>/dev/null | grep -qF "$V6WARN"; then V6WARN=""; fi
  OWN80="$(port_owners 80)"; OWN443="$(port_owners 443)"
  ALL="$(printf '%s\n%s\n' "$OWN80" "$OWN443" | sed '/^$/d' | sort -u)"
  if [ -z "$ALL" ]; then
    MODE=new
  elif [ "$ALL" = "caddy" ]; then
    MODE=existing
  elif printf '%s\n' "$ALL" | grep -q 'docker-proxy'; then
    die "Ports 80/443 on this server belong to a Docker gateway (docker-proxy), not to a plain Caddy.\n       This installer does not edit that setup. Nothing was changed.\n       Send me a screenshot of this screen and I will prepare the right method for this server."
  else
    die "Ports 80/443 are used by: $(printf '%s' "$ALL" | tr '\n' ' ').\n       This installer only works with Caddy or on a server with free web ports. Nothing was changed."
  fi
}

show_plan() {
  local first=""
  [ -f "$UNIT" ] || first=" (first time)"
  say ""
  say "Why! installer $VERSION"
  say "  This server:  $HOST_NOW  (public address $MYIP)"
  say "  Site name:    $DOMAIN -> $RESOLVED  (points to this server)"
  [ -n "${V6WARN:-}" ] && say "  [!] The name also has an IPv6 address ($V6WARN) that is not this server. If the certificate does not come up, clear the IPv6 box at duckdns.org."
  if [ "$MODE" = new ]; then
    say "  Web server:   none yet (ports 80 and 443 are free); Caddy will be installed"
  else
    say "  Web server:   Caddy is running; your other sites keep working"
  fi
  say "  Will do$first:"
  say "    - install the Why! server program as the service \"$UNIT_NAME\" (127.0.0.1:$PORT only; at most 96 MB of memory"
  say "      and 40% of one CPU, so the other programs on this server are never starved)"
  [ -f "$UNIT" ] || say "    - create a system user \"$SVC_USER\" (no password, cannot log in) and the folder $DATA_DIR for the data"
  say "    - ask you for the MANAGEMENT and ORDER DESK secret codes (only if they are not set yet)"
  say "    - publish the four pages at https://$DOMAIN  (/  /reception/  /admin/  /driver/)"
  if [ "$MODE" = new ]; then say "    - write the Caddy settings for the site"; else say "    - add one marked block to $CF (a backup is made first)"; fi
  say "  It does not stop, restart or change any other service."
  say "  Nothing has been changed yet."
}

confirm() {
  [ "$ASSUME_YES" = 1 ] && return 0
  local was; was="$(setting VERSION)"
  if [ -f "$SETTINGS" ] && [ "$(setting CONFIRMED_HOST)" = "$HOST_NOW" ] && [ "$(setting DOMAIN)" = "$DOMAIN" ] && [ "${was%.*}" = "${VERSION%.*}" ]; then
    say "  (this server and name were confirmed before, continuing)"; return 0
  fi
  [ -t 0 ] || die "No keyboard input here. Run it again with --yes if you are sure."
  printf '\nIs this the right server? (y/n) '
  local ans=""; read -r ans || true
  case "$ans" in y|Y|yes|YES) ;; *) say "Stopped. Nothing was changed."; exit 1 ;; esac
}

undo_publish() {   # the pages as they were (or none, on a first install)
  [ -n "$PUB_NEW" ] || return 0
  rm -rf "$WEB_ROOT"
  if [ -n "$PUB_OLD" ] && [ -d "$PUB_OLD" ]; then mv "$PUB_OLD" "$WEB_ROOT"; fi
  PUB_OLD=""; PUB_NEW=""
}

publish_files() {
  local p
  for p in index.html reception/index.html admin/index.html driver/index.html; do
    [ -f "$APP_DIR/site/$p" ] && grep -q 'id="app"' "$APP_DIR/site/$p" || die "The site folder is missing or damaged ($APP_DIR/site/$p). Unzip the package again."
  done
  local new="$WEB_ROOT.new.$$" old="$WEB_ROOT.old.$$"
  rm -rf "$new" "$old"; mkdir -p "$(dirname "$WEB_ROOT")" || die "Could not create $(dirname "$WEB_ROOT")"
  cp -a "$APP_DIR/site" "$new" || die "Could not copy the site files."
  find "$new" -type d -exec chmod 755 {} + ; find "$new" -type f -exec chmod 644 {} +
  [ -d "$WEB_ROOT" ] && { mv "$WEB_ROOT" "$old" && PUB_OLD="$old"; }
  mv "$new" "$WEB_ROOT" || { [ -n "$PUB_OLD" ] && mv "$PUB_OLD" "$WEB_ROOT"; die "Could not publish the files."; }
  PUB_NEW="$WEB_ROOT"
  UNDO+=(undo_publish)
  ok "pages are in $WEB_ROOT ($(find "$WEB_ROOT" -type f | wc -l | tr -d ' ') files)"
}

install_caddy() {
  say "   Installing Caddy (official repository) ..."
  export DEBIAN_FRONTEND=noninteractive
  local apt="apt-get -o DPkg::Lock::Timeout=240 -o Dpkg::Options::=--force-confold -y"
  command -v apt-get >/dev/null 2>&1 || die "This server has no apt-get. This installer supports Ubuntu and Debian."
  $apt update >"$TMP/apt1.txt" 2>&1 || { tail_of "$TMP/apt1.txt" 6; die "apt-get update failed."; }
  $apt install curl gnupg ca-certificates apt-transport-https >"$TMP/apt2.txt" 2>&1 || { tail_of "$TMP/apt2.txt" 6; die "Could not install the helper packages."; }
  local key=/usr/share/keyrings/caddy-stable-archive-keyring.gpg list=/etc/apt/sources.list.d/caddy-stable.list
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --batch --yes --dearmor -o "$key" 2>"$TMP/gpg.txt" || die "Could not download the Caddy signing key."
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' >"$list" || die "Could not download the Caddy repository list."
  chmod o+r "$key" "$list"
  $apt update >"$TMP/apt3.txt" 2>&1 || { tail_of "$TMP/apt3.txt" 6; die "apt-get update failed after adding the Caddy repository."; }
  $apt install caddy >"$TMP/apt4.txt" 2>&1 || { tail_of "$TMP/apt4.txt" 8; die "Could not install Caddy."; }
  command -v caddy >/dev/null 2>&1 || die "Caddy was installed but the command was not found."
  ok "Caddy $(caddy version 2>/dev/null | cut -d' ' -f1) installed"
}

open_firewall() {
  command -v ufw >/dev/null 2>&1 || return 0
  ufw status 2>/dev/null | grep -qi 'status: active' || return 0
  local r; for r in 80/tcp 443/tcp 443/udp; do ufw allow "$r" >/dev/null 2>&1 || warn "could not open $r in ufw"; done
  ok "opened ports 80 and 443 in the ufw firewall"
}

https_get() {   # $1 path: prints the HTTP status, the body is left in $TMP/page.html
  local code
  code="$(curl -sS --max-time 15 --resolve "$DOMAIN:443:127.0.0.1" -o "$TMP/page.html" -w '%{http_code}' "https://$DOMAIN$1" 2>"$TMP/curl.err")" || code=000
  printf '%s' "$code"
}

wait_https() {
  local i code shown=0 waited=0
  for i in $(seq 1 40); do
    code="$(https_get /)"
    if [ "$code" = "200" ] && grep -q 'id="app"' "$TMP/page.html"; then return 0; fi
    waited=$((i * 3))
    if [ $((waited - shown)) -ge 9 ]; then shown=$waited; say "   waiting for the HTTPS certificate ... ${waited}s"; fi
    sleep 3
  done
  return 1
}

verify_pages() {   # every page, and the server program through the same address
  local p code
  for p in /reception/ /admin/ /driver/; do
    code="$(https_get "$p")"
    if [ "$code" = 200 ] && grep -q 'id="app"' "$TMP/page.html"; then ok "https://$DOMAIN$p answers"; else warn "https://$DOMAIN$p answered HTTP $code"; return 1; fi
  done
  code="$(https_get /api/health)"
  if [ "$code" = 200 ] && grep -q '"ok":true' "$TMP/page.html"; then ok "the server program answers through https://$DOMAIN/api"; else warn "https://$DOMAIN/api/health answered HTTP $code"; return 2; fi
}

diagnose() {
  local log; log="$(journalctl -u caddy --no-pager -n 80 2>/dev/null || true)"; printf '%s\n' "$log" >"$TMP/caddy.log"
  if [ -n "${V6WARN:-}" ]; then
    warn "The name has an IPv6 address ($V6WARN) that is not this server, and the certificate service tries it first. Open duckdns.org, clear the IPv6 box of the name, press update, wait a minute and run this again."
  elif printf '%s' "$log" | grep -qiE 'ratelimited|too many certificates|rate limit|too many failed'; then
    warn "The free certificate service is busy for this name right now. Wait an hour and run this command again."
  elif printf '%s' "$log" | grep -qiE 'no valid a records|no such host|nxdomain|dns problem'; then
    warn "The certificate service could not find the name yet. Wait two minutes and run this command again."
  elif printf '%s' "$log" | grep -qiE 'timeout during connect|connection refused|connection timed out|i/o timeout|firewall|secondary validation'; then
    warn "The internet cannot reach this server on port 80/443. In DigitalOcean open Networking > Firewalls and allow HTTP (80) and HTTPS (443) from everywhere, or remove the firewall from this droplet. Then run this again."
  else
    warn "The HTTPS address did not come up in time."
  fi
  say "   Caddy log (last lines):"; grep -iE 'error|warn' "$TMP/caddy.log" | tail -n 5 | cut -c1-200 | sed 's/^/      /'
}

save_settings() {
  { echo "DOMAIN=$DOMAIN"; echo "CONFIRMED_HOST=$HOST_NOW"; echo "VERSION=$VERSION"; echo "MODE=$MODE"; echo "PORT=$PORT"; } >"$SETTINGS"
}

do_install() {
  need_root
  step "1/7 Looking at this server"
  detect_server
  ok "server $HOST_NOW, public address $MYIP"
  ok "$DOMAIN points to this server"
  CF="$(caddy_config_path)"
  if [ "$MODE" = existing ]; then
    command -v caddy >/dev/null 2>&1 || die "Caddy is running but the caddy command was not found."
    case "$CF" in *.json) die "Caddy uses a JSON settings file ($CF). This installer only edits a Caddyfile. Nothing was changed." ;; esac
    [ -f "$CF" ] || die "Caddy is running but its settings file was not found ($CF)."
    ok "Caddy is already serving this server ($CF)"
  else
    command -v caddy >/dev/null 2>&1 && ok "Caddy is installed but not running" || ok "ports 80 and 443 are free"
  fi
  check_python
  pick_port
  [ -f "$UNIT" ] && UNIT_EXISTED=1
  ok "Python: $("$PYTHON" -V 2>&1), the server will use 127.0.0.1:$PORT"
  local mem; mem="$(awk '/MemAvailable/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 999)"
  [ "${mem:-999}" -lt 100 ] && warn "only ${mem} MB of memory is free; the Why! server needs about 40 MB, and it is capped at 96 MB"
  show_plan
  confirm

  step "2/7 Preparing the server program"
  ensure_user
  ensure_dirs
  render_unit
  stage_code

  step "3/7 Secret codes"
  ensure_pins

  step "4/7 Starting the Why! server"
  if systemctl is-active --quiet "$UNIT_NAME" 2>/dev/null; then SVC_WAS_UP=1; fi
  [ -f "$UNIT" ] && { cp -p "$UNIT" "$TMP/unit.prev"; UNIT_PREV="$TMP/unit.prev"; }
  if same_as_running; then
    rm -rf "$NEWCODE"; NEWCODE=""
    ok "the server program is already up to date and answering; it was not restarted"
  else
    install_server
  fi

  step "5/7 Publishing the pages"
  publish_files

  step "6/7 Setting up Caddy"
  if [ "$MODE" = new ]; then
    FRESH=0
    if ! command -v caddy >/dev/null 2>&1; then install_caddy; FRESH=1; fi
    open_firewall
    if [ "$FRESH" = 1 ] || [ ! -s "$CF" ]; then apply_block "$CF" fresh; else apply_block "$CF" add; fi
    systemctl enable caddy >/dev/null 2>&1 || true
    systemctl is-active --quiet caddy 2>/dev/null || systemctl start caddy >"$TMP/start.txt" 2>&1 || { tail_of "$TMP/start.txt" 6; die "Caddy could not start."; }
  else
    apply_block "$CF" add
  fi
  UNDO=(); [ -n "$PUB_OLD" ] && rm -rf "$PUB_OLD"; PUB_OLD=""; PUB_NEW=""   # Caddy accepted the settings: the new pages stay

  step "7/7 Checking https://$DOMAIN"
  if ! wait_https; then diagnose; die "The pages, the server and the Caddy settings are in place, but https://$DOMAIN did not answer yet.\n       Caddy keeps trying in the background. Run: bash install.sh status"; fi
  ok "https://$DOMAIN answers with the Why! app"
  verify_pages
  case $? in
    1) die "The customer page works but another page does not answer. Run: bash install.sh status" ;;
    2) die "The pages work but the server program does not answer through https://$DOMAIN/api.\n       Run: bash install.sh status   (and send me a screenshot of it)" ;;
  esac
  systemctl is-active --quiet caddy 2>/dev/null && ok "Caddy is running" || warn "could not confirm that Caddy is running"
  save_settings
  ok "settings saved in $SETTINGS"
  say ""
  say "DONE. Open: https://$DOMAIN"
  say "  Why!        https://$DOMAIN/"
  say "  ORDER DESK  https://$DOMAIN/reception/"
  say "  MANAGEMENT  https://$DOMAIN/admin/"
  say "  DELIVERY    https://$DOMAIN/driver/"
  say "  The data is kept in $DATA_DIR (a copy is made every day, and before every update)."
}

do_status() {
  need_root
  say "Why! $VERSION"
  say "  name:        $DOMAIN"
  say "  confirmed:   $(setting CONFIRMED_HOST || true)  (installed version: $(setting VERSION || true))"
  local ips res; ips="$(my_ips | awk '!seen[$0]++')"; res="$(resolve_ip "$DOMAIN")"
  say "  server IP:   $(printf '%s' "$ips" | sed -n '1p')    name points to: ${res:-nothing}"
  if [ -n "$res" ] && printf '%s\n' "$ips" | grep -qx "$res"; then say "  name -> here: yes"; else say "  name -> here: NO (fix the IP at duckdns.org)"; fi
  CF="$(caddy_config_path)"
  if command -v caddy >/dev/null 2>&1; then
    systemctl is-active --quiet caddy 2>/dev/null && say "  Caddy:       running" || say "  Caddy:       NOT running"
    if [ -f "$CF" ] && grep -qF "$BEGIN_MARK" "$CF"; then say "  Caddyfile:   the Why! block is present ($CF)"; else say "  Caddyfile:   the Why! block is MISSING in $CF (run: bash install.sh)"; fi
  else
    say "  Caddy:       not installed"
  fi
  PORT="$(setting PORT)"; PORT="${PORT:-8787}"
  if [ -f "$UNIT" ]; then
    systemctl is-active --quiet "$UNIT_NAME" 2>/dev/null && say "  server:      running (service $UNIT_NAME, port $PORT)" || say "  server:      NOT running (service $UNIT_NAME)  -> run: systemctl status $UNIT_NAME"
    if curl -fsS --max-time 4 "http://127.0.0.1:$PORT/api/health" >"$TMP/health.json" 2>/dev/null && grep -q '"ok":true' "$TMP/health.json"; then
      say "  server test: answers ($(sed -n 's/.*"v":"\([^"]*\)".*/version \1/p' "$TMP/health.json"))"
    else say "  server test: does NOT answer on 127.0.0.1:$PORT"; fi
  else
    say "  server:      not installed (run: bash install.sh)"
  fi
  [ -d "$DATA_DIR/backups" ] && say "  backups:     $(ls "$DATA_DIR"/backups/why-*.db 2>/dev/null | wc -l | tr -d ' ') database copies in $DATA_DIR/backups (latest: $(ls "$DATA_DIR"/backups/why-*.db 2>/dev/null | tail -n 1 | sed 's|.*/why-||; s|\.db$||'))"
  local p
  for p in $PAGES; do
    [ -f "$WEB_ROOT${p}index.html" ] && say "  page $p   present" || say "  page $p   MISSING"
  done
  local code; code="$(https_get /)"
  say "  https test:  HTTP $code (200 is good)"
  ls "$CF".bak-* >/dev/null 2>&1 && say "  backups:     $(ls "$CF".bak-* | wc -l | tr -d ' ') Caddyfile backup(s) next to $CF"
  return 0
}

do_remove() {
  need_root
  CF="$(caddy_config_path)"
  say "This takes Why! down: the pages and the server program. Other sites, the auction bot and Caddy itself are not touched."
  say "The customer data in $DATA_DIR is NOT deleted."
  if [ "$ASSUME_YES" != 1 ]; then
    [ -t 0 ] || die "No keyboard input here. Run it again with --yes if you are sure."
    printf 'Continue? (y/n) '; local ans=""; read -r ans || true
    case "$ans" in y|Y|yes|YES) ;; *) say "Stopped. Nothing was changed."; exit 1 ;; esac
  fi
  if [ -f "$CF" ] && grep -qF "$BEGIN_MARK" "$CF" && command -v caddy >/dev/null 2>&1; then apply_block "$CF" remove; else ok "no Why! block in the Caddyfile"; fi
  rm -rf "$WEB_ROOT" && ok "pages removed"
  if [ -f "$UNIT" ]; then
    systemctl stop "$UNIT_NAME" >/dev/null 2>&1 || true
    systemctl disable "$UNIT_NAME" >/dev/null 2>&1 || true
    rm -f "$UNIT"; systemctl daemon-reload >/dev/null 2>&1 || true
    ok "the Why! server was stopped and removed"
  fi
  rm -rf "$RUN_DIR"
  say ""
  say "DONE. Why! is down. The files in $APP_DIR and the data in $DATA_DIR are still here; run: bash install.sh  to bring it back."
}

case "$CMD" in
  install) do_install ;;
  status)  do_status ;;
  remove)  do_remove ;;
esac
