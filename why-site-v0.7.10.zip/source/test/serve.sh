#!/bin/bash
# Fresh test setup: builds the pages that exist, makes an empty database with test PINs, starts the real server on $1 (default 8790).
#   admin PIN 123456, reception PIN 654321   (tests only)
# The server runs in the background; stop it with:  pkill -f "why_server.py serve --db /tmp/whytest"
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
PORT=${1:-8790}
D=/tmp/whytest
pkill -f "why_server.py serve --db $D" 2>/dev/null || true
sleep 0.4
rm -rf "$D" && mkdir -p "$D/site"
cd "$ROOT/prototype"
python3 build.py --app cust --out "$D/site/index.html" >/dev/null
for pair in recv:reception admin:admin driver:driver; do
  app=${pair%%:*}; dir=${pair##*:}
  if [ -f "src/$app.js" ]; then mkdir -p "$D/site/$dir"; python3 build.py --app "$app" --out "$D/site/$dir/index.html" >/dev/null; fi
done
cp sw.js "$D/site/sw.js"
cd "$ROOT/server"
export WHY_PBKDF2_ITERS=2000
echo 123456 | python3 why_server.py setpin --role admin --db "$D/why.db" --catalog catalog.json --pin-stdin >/dev/null
echo 654321 | python3 why_server.py setpin --role recv --db "$D/why.db" --catalog catalog.json --pin-stdin >/dev/null
nohup python3 why_server.py serve --db "$D/why.db" --catalog catalog.json --static "$D/site" --port "$PORT" > "$D/server.log" 2>&1 &
for i in $(seq 1 40); do curl -fs "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1 && break; sleep 0.25; done
curl -fs "http://127.0.0.1:$PORT/api/health" && echo
