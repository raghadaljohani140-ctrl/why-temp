__DOMAIN__ {
	root * __ROOT__
	encode zstd gzip
	header {
		X-Content-Type-Options nosniff
		Referrer-Policy no-referrer
		X-Robots-Tag "noindex, nofollow"
		Content-Security-Policy "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' https://maps.googleapis.com https://*.googleapis.com https://*.gstatic.com blob:; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob: https://tile.openstreetmap.org https://*.googleapis.com https://*.gstatic.com https://*.google.com https://*.googleusercontent.com; media-src 'self'; connect-src 'self' https://*.googleapis.com https://*.google.com https://*.gstatic.com data: blob:; frame-src https://*.google.com; manifest-src 'self'; worker-src 'self' blob:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
		-Server
	}
	@html path / /index.html /reception /reception/ /reception/index.html /admin /admin/ /admin/index.html /driver /driver/ /driver/index.html /sw.js
	header @html Cache-Control "no-cache"
	@manifest path /manifest.webmanifest /reception/manifest.webmanifest /admin/manifest.webmanifest /driver/manifest.webmanifest
	header @manifest Content-Type "application/manifest+json"
	reverse_proxy /api/* 127.0.0.1:__PORT__ {
		header_up X-Forwarded-Proto {scheme}
		header_up X-Forwarded-Host {host}
	}
	file_server
}
