/* Core: helpers, icons, product art, state, business rules */

/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = () => Math.random().toString(36).slice(2, 9);
const num = n => Number(n).toLocaleString('en-US');
const r2 = n => Math.round(n * 100) / 100;
const fmt = n => { n = r2(n); return Number.isInteger(n) ? String(n) : n.toFixed(2); };
const fmt2 = n => r2(n).toFixed(2);
const fmt1 = n => Number(n).toFixed(1);
const fmtKm = n => String(Math.round(Number(n) * 10) / 10);   /* 7.5, 10 */
const pad2 = n => String(n).padStart(2, '0');
const toLatin = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const hexRgb = h => { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)); };
const mix = (a, b, t) => { const A = hexRgb(a), B = hexRgb(b); return '#' + A.map((v, i) => Math.round(v * (1 - t) + B[i] * t).toString(16).padStart(2, '0')).join(''); };
const tint = (c, t = .84) => mix(c, '#FFFFFF', t);

/* ---------- state ---------- */
/* APP is set by build.py: 'cust' (the customer app), 'recv' (the order desk), 'admin' (management) or 'driver' (delivery). Each app is a page of its own and keeps its own saved state. */
const KEY = APP === 'cust' ? 'why-app-v1' : 'why-' + APP + '-v1';
const WELCOME_PTS = 100;
/* a random key for this phone: the server knows the customer's orders by it (it never sees it in clear, only its hash) */
const newDev = () => {
  try { const a = new Uint8Array(16); crypto.getRandomValues(a); return Array.from(a, b => b.toString(16).padStart(2, '0')).join(''); }
  catch (e) { return Array.from({length:32}, () => Math.floor(Math.random() * 16).toString(16)).join(''); }
};
/* arev: the revision of the account this phone last got from the server (0.7); null = signed in before 0.7, the phone still counts.
   wal: the wallet's movements, gseen: the gifts this phone has already told about (null until the first account arrives). */
const fresh = () => ({v:4, lang:'ar', session:false, guest:false, user:null, pts:0, tier:null, ledger:[], orders:[], gifts:[], sent:[], bal:0, cart:[], branch:'b1', notifs:[],
  dev:newDev(), since:0, ack:[], seen:[], pub:null, cat:null, addr:null, sound:true, rcBr:'all', arev:null, wal:[], gseen:null});
function load() {
  try { const r = localStorage.getItem(KEY); if (r) { const o = JSON.parse(r); if (o && o.v === 4) return Object.assign(fresh(), o); } } catch (e) {}
  return fresh();
}
let S = load();
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

const T = (ar, en) => S.lang === 'ar' ? ar : en;
const L = o => o ? (S.lang === 'ar' ? (o.ar || o.en || '') : (o.en || o.ar || '')) : '';   /* a text missing in one language shows the other */
const txt = v => typeof v === 'string' ? v : L(v);

/* Saudi riyal sign, drawn as a glyph so it needs no font */
const SARSVG = '<svg class="sar" viewBox="0 0 1124.14 1256.39" fill="currentColor" aria-hidden="true"><path d="M699.62,1113.02h0c-20.06,44.48-33.32,92.75-38.4,143.37l424.51-90.24c20.06-44.47,33.31-92.75,38.4-143.37l-424.51,90.24Z"/><path d="M1085.73,895.8c20.06-44.47,33.32-92.75,38.4-143.37l-330.68,70.33v-135.2l292.27-62.11c20.06-44.47,33.32-92.75,38.4-143.37l-330.68,70.27V66.13c-50.67,28.45-95.67,66.32-132.25,110.99v403.35l-132.25,28.11V0c-50.67,28.44-95.67,66.32-132.25,110.99v525.69l-295.91,62.88c-20.06,44.47-33.33,92.75-38.4,143.37l334.31-71.05v136.97l-295.91,62.88c-20.06,44.47-33.33,92.75-38.4,143.37l334.31-71.05v211.84h0c50.67-28.45,95.67-66.32,132.25-110.99v-217.69l132.25-28.11v246.8h0c50.67-28.45,95.67-66.32,132.25-110.99v-77l292.27-62.11Z"/></svg>';
const money = n => `<span class="amt">${fmt(n)}${SARSVG}</span>`;
const money2 = n => `<span class="amt">${fmt2(n)}${SARSVG}</span>`;
const minus = n => `<span class="amt"><span class="ltr">-${fmt2(n)}</span>${SARSVG}</span>`;
const moneyT = n => `${fmt(n)} ${T('ر.س', 'SAR')}`;
const validPhone = p => /^5\d{8}$/.test(p || '');
const validEmail = e => typeof e === 'string' && e.length <= 120 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const todayISO = () => { const d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); };
const validBirth = b => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(b || ''); if (!m) return false; const d = new Date(+m[1], +m[2] - 1, +m[3]); return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3] && b >= '1920-01-01' && b <= todayISO(); };
const fmt05 = d => { const x = '0' + d; return [x.slice(0, 3), x.slice(3, 6), x.slice(6)].filter(Boolean).join('-'); };   /* 512345678 → 051-234-5678 */
const phoneFmt = p => `+966 ${p.slice(0, 2)} ${p.slice(2, 5)} ${p.slice(5)}`;

/* dates follow the reference app: 2026-09-22, 08:55 - 2026-09-22, and "Saturday 22 January - 05:00 PM" */
const dISO = ts => { const d = new Date(ts); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; };
const dNews = ts => { const d = new Date(ts); return `${pad2(d.getHours())}:${pad2(d.getMinutes())} - ${dISO(ts)}`; };
function dLong(ts) {
  const d = new Date(ts); let h = d.getHours(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
  let day = dISO(ts);
  try {
    const parts = new Intl.DateTimeFormat(S.lang === 'ar' ? 'ar-u-ca-gregory-nu-latn' : 'en-GB', {weekday:'long', day:'numeric', month:'long'}).formatToParts(d);
    const g = t => (parts.find(p => p.type === t) || {}).value || '';
    day = `${g('weekday')} ${g('day')} ${g('month')}`;
  } catch (e) {}
  return `${day} - ${pad2(h)}:${pad2(d.getMinutes())} ${ap}`;
}
/* staff pages show the server's clock: a tablet with a wrong time must not show wrong ages */
const nowS = () => Date.now() + (APP === 'cust' ? 0 : SRV.skew || 0);
function ago(ts) {
  const m = Math.floor((nowS() - ts) / 6e4);
  if (m < 1) return T('الآن', 'Now');
  if (m < 60) return T(`قبل ${m} د`, `${m} min ago`);
  const h = Math.floor(m / 60);
  if (h < 24) return T(`قبل ${h} س`, `${h} h ago`);
  return dISO(ts);
}
const PAGE_TITLE = {cust:['واي!', 'Why!'], recv:['واي! | الاستقبال', 'Why! | Order Desk'], admin:['واي! | الإدارة', 'Why! | Management'], driver:['واي! | المندوب', 'Why! | Delivery']};
function applyLang() {
  const h = document.documentElement;
  h.lang = S.lang; h.dir = S.lang === 'ar' ? 'rtl' : 'ltr';
  document.title = (PAGE_TITLE[APP] || PAGE_TITLE.cust)[S.lang === 'ar' ? 0 : 1];
}
function toast(m) {
  const box = $('#toasts'); if (!box) return;
  const d = document.createElement('div'); d.className = 'toast'; d.textContent = m; box.appendChild(d);
  setTimeout(() => d.remove(), 2800);
}

/* ---------- UI state (not persisted) ---------- */
const newCo = () => ({mode:'', carrier:CARRIERS[0], addr:Object.assign({city:'', street:'', note:''}, S.addr || {}, {lat:null, lng:null}), serve:'in', pay:'card', useBal:true, code:'', codeOk:false, codeErr:'', pick:0});   /* pick: a pickup time (ms), 0 = as soon as possible */
const newG = () => ({step:1, type:'item', pid:giftItems()[0] || 'latte', amt:50, amtx:'', phone:'', name:'', msg:'', pay:'card', gid:'',
  del:false, addr:{city:'', street:'', note:'', lat:null, lng:null}});   /* del: the sender has the product brought to the recipient */
const GIFT_MIN = 10, GIFT_MAX = 1000;   /* an amount the customer types (gift card, wallet top-up): whole riyals */
const newTp = () => ({amt:50, amtx:'', pay:'card'});
const newF = () => ({phone:'', name:'', email:'', invite:'', birth:'', gender:'', terms:false, mk:false, q:'', pname:''});
const authInit = mode => ({step:'phone', mode:mode || 'login', secs:0, err:'', bad:false, errs:{}, verified:'', note:''});
const UI = {
  tab:'home', stack:[], sheet:null, dlg:null, proc:null,
  auth:authInit(), otp:['', '', '', '', ''], intro:{i:0},
  f:newF(), co:newCo(), g:newG(), tp:newTp(), hf:'all', rate:{id:null, s:0, c:''},
  cat:'hot', bn:0, seg:'orders', gseg:'recv', gsub:'item', sc:{}, fresh:{sheet:false, page:false}, focus:null, bsh:null,
  mode:APP === 'cust' ? 'cust' : 'login', offline:false, rc:{tab:'new', code:{}, mq:''}, dv:{tab:'avail', code:{}}, ad:{sec:'home', cat:'hot', q:'', oq:'', f:'all', tbl:false, bar:-1}, lg:{name:'', pin:'', err:'', busy:false, br:null, desks:null}, ed:{}, rj:{reason:'out'}, dr:{name:'', pin:''}
};
/* every action a button can name (data-a) lives in A; cust.js, staff.js and the staff apps add theirs */
const A = {};

/* ---------- icons ---------- */
const IC = {
  home:'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  cup:'<path d="M4 8h13v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 10h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3v2.5M12 3v2.5"/>',
  receipt:'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  gift:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  bell:'<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  star:'<path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.9l-5.2 2.8 1-5.9-4.3-4.1 5.9-.8z"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  minus:'<path d="M5 12h14"/>',
  check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  x:'<path d="M6 6l12 12M18 6 6 18"/>',
  chev:'<path d="m9 6 6 6-6 6"/>',
  back:'<path d="m15 6-6 6 6 6"/>',
  chevdown:'<path d="m6 9 6 6 6-6"/>',
  pin:'<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  timer:'<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.5 1.5M9.5 2.8h5M12 2.8v3"/>',
  book:'<path d="M12 6.5C10 5 7 4.5 4 5v13c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V5c-3-.5-6 0-8 1.5z"/><path d="M12 6.5v13"/>',
  bag:'<path d="M5 8h14l-1 12H6z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/>',
  fork:'<path d="M7 3v6a2 2 0 0 0 2 2 2 2 0 0 0 2-2V3M9 3v18"/><path d="M17 21V3c-2.2 1.4-3 4-3 7 0 1.6 1 2.6 3 2.7"/>',
  flame:'<path d="M12 3c1 3.6 5 5.4 5 10a5 5 0 0 1-10 0c0-2 1-3.2 2-4.2.2 1.2.8 2 1.6 2.4C10.2 8.4 10.5 5.5 12 3z"/>',
  tag:'<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-7 7"/><circle cx="9" cy="9" r="1.1"/><circle cx="15" cy="15" r="1.1"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  phone:'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  chat:'<path d="M4 20l1.3-4A8 8 0 1 1 8 18.7z"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  logout:'<path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4M16 8l4 4-4 4M20 12H9"/>',
  trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  doc:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
  idcard:'<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.6-1.5 1.7-2 3-2s2.4.5 3 2M14.5 10h4M14.5 13.5h3"/>',
  headset:'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="13" width="4" height="6" rx="1.5"/><rect x="17" y="13" width="4" height="6" rx="1.5"/><path d="M19 19c0 1.5-2 2.5-5 2.5"/>',
  userplus:'<circle cx="10" cy="8" r="3.5"/><path d="M3.5 20c0-3.6 3-6 6.5-6 1 0 2 .2 2.8.6M18 14v6M15 17h6"/>',
  card:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/>',
  car:'<path d="M4 16v-4l2-5h12l2 5v4"/><path d="M3 16h18v3H3z"/><path d="M7 13h.01M17 13h.01"/>',
  store:'<path d="M4 9 5.5 4h13L20 9M4 9v11h16V9M4 9a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0A2.7 2.7 0 0 0 20 9M10 20v-5h4v5"/>',
  truck:'<path d="M2 6h11v10H2zM13 10h4l3 3v3h-7"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  send:'<path d="M21 3 3 10.5l7 2.5 2.5 7z"/><path d="m10 13 11-10"/>',
  lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  wallet:'<path d="M4 7a2 2 0 0 1 2-2h12v4"/><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M16 13.5h2"/>',
  nav:'<path d="M12 2.8 21.2 12 12 21.2 2.8 12z"/><path d="M9.5 15v-3.1a1.4 1.4 0 0 1 1.4-1.4H15M13 8.3l2.2 2.2L13 12.7"/>'
};
/* filled versions for the active tab */
const ICF = {
  timer:'<circle cx="12" cy="13.5" r="8" fill="currentColor"/><path d="M9.5 2.8h5M12 2.8v3"/><path d="M12 9.5v4l2.5 1.5" stroke="#fff"/>',
  gift:'<rect x="3" y="8" width="18" height="4.5" rx="1" fill="currentColor"/><path d="M5 12.5V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7.5z" fill="currentColor"/><path d="M12 8v13" stroke="#fff"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
  pin:'<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z" fill="currentColor"/><circle cx="12" cy="9.5" r="2.6" fill="#fff" stroke="none"/>',
  book:'<path d="M12 6.5C10 5 7 4.5 4 5v13c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V5c-3-.5-6 0-8 1.5z" fill="currentColor"/><path d="M12 6.5v13" stroke="#fff"/>',
  star:'<path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.9l-5.2 2.8 1-5.9-4.3-4.1 5.9-.8z" fill="currentColor"/>'
};
const ic = (n, s = 22, c = '') => `<svg class="${c}" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;
const icf = (n, s = 22, c = '') => `<svg class="${c}" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICF[n] || IC[n] || ''}</svg>`;
/* the ! brand mark */
const MARK = '<path d="M12 2.6c1.5 0 2.6 1.2 2.5 2.7l-.7 8.6a1.8 1.8 0 0 1-3.6 0l-.7-8.6c-.1-1.5 1-2.7 2.5-2.7z"/><circle cx="12" cy="19.4" r="2.2"/>';
const mark = (s = 24, c = '') => IMG.mark
  ? `<span class="mark-i im-mark ${c}" style="width:${s}px;height:${s}px" aria-hidden="true"></span>`
  : `<svg class="${c}" width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${MARK}</svg>`;

/* ---------- product art (flat SVG, drawn in code) ---------- */
const K = '#111111';
const SW = `stroke="${K}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"`;
function art(kind, tone = '#8A5232') {
  const f = b => `<svg viewBox="0 0 120 120" aria-hidden="true">${b}</svg>`;
  const steam = x => `<path d="M${x} 20c-4 6 4 9 0 15" fill="none" stroke="${K}" stroke-opacity=".3" stroke-width="3.5" stroke-linecap="round"/>`;
  const dark = mix(tone, K, .3);
  switch (kind) {
    case 'hot': return f(`${steam(44)}${steam(60)}${steam(76)}<path d="M26 48h66v14a30 30 0 0 1-30 30h-6A30 30 0 0 1 26 62z" fill="#fff" ${SW}/><path d="M92 54h6a9 9 0 0 1 0 18h-8" fill="none" ${SW}/><ellipse cx="59" cy="48" rx="33" ry="7" fill="${tone}" ${SW}/><ellipse cx="59" cy="48" rx="13" ry="3" fill="#fff" fill-opacity=".55"/><path d="M20 102h78" fill="none" ${SW}/>`);
    case 'iced': return f(`<path d="M70 8 61 46" fill="none" stroke="#ECB444" stroke-width="5" stroke-linecap="round"/><path d="M34 30h52l-6 76a6 6 0 0 1-6 5H46a6 6 0 0 1-6-5z" fill="#fff" fill-opacity=".75" ${SW}/><path d="M37 52h46l-4.4 52a3 3 0 0 1-3 2.6H44.4a3 3 0 0 1-3-2.6z" fill="${tone}"/><rect x="44" y="56" width="16" height="16" rx="3" fill="#fff" fill-opacity=".55" transform="rotate(-10 52 64)"/><rect x="62" y="70" width="16" height="16" rx="3" fill="#fff" fill-opacity=".45" transform="rotate(12 70 78)"/><rect x="46" y="86" width="14" height="14" rx="3" fill="#fff" fill-opacity=".4" transform="rotate(8 53 93)"/>`);
    case 'espresso': return f(`${steam(52)}${steam(68)}<path d="M34 56h52v10a22 22 0 0 1-22 22h-8A22 22 0 0 1 34 66z" fill="#fff" ${SW}/><path d="M86 60h5a7 7 0 0 1 0 14h-6" fill="none" ${SW}/><ellipse cx="60" cy="56" rx="26" ry="5.5" fill="${dark}" ${SW}/><ellipse cx="60" cy="56" rx="12" ry="2.4" fill="#D58F2B" fill-opacity=".75"/><ellipse cx="60" cy="98" rx="36" ry="6" fill="#fff" ${SW}/>`);
    case 'filter': return f(`<path d="M30 26h60l-15 32H45z" fill="#fff" ${SW}/><path d="M26 26h68" fill="none" ${SW}/><path d="M44 34l7 16M76 34l-7 16" fill="none" stroke="${tone}" stroke-width="3" stroke-linecap="round"/><path d="M60 64v6M60 76v3" fill="none" stroke="${tone}" stroke-width="4" stroke-linecap="round"/><path d="M38 82h44v10a16 16 0 0 1-16 16H54a16 16 0 0 1-16-16z" fill="#fff" ${SW}/><ellipse cx="60" cy="82" rx="22" ry="4" fill="${tone}" ${SW}/>`);
    case 'matcha': return f(`<path d="M72 14 56 50" fill="none" stroke="#C8965A" stroke-width="5" stroke-linecap="round"/><path d="M16 54h88c0 26-19 42-44 42S16 80 16 54z" fill="#fff" ${SW}/><ellipse cx="60" cy="54" rx="44" ry="8" fill="${tone}" ${SW}/><path d="M38 54c8-3 14 3 22 0s12-2 18 0" fill="none" stroke="#fff" stroke-opacity=".6" stroke-width="3" stroke-linecap="round"/><rect x="44" y="94" width="32" height="8" rx="4" fill="#fff" ${SW}/>`);
    case 'brownie': return f(`<ellipse cx="60" cy="100" rx="46" ry="7" fill="#fff" ${SW}/><path d="M26 54 36 34h48l10 20z" fill="#6B3A22" ${SW}/><path d="M26 54h68v38a4 4 0 0 1-4 4H30a4 4 0 0 1-4-4z" fill="${tone}" ${SW}/><path d="M40 44h14M64 40h16M52 48h12" fill="none" stroke="#C8965A" stroke-width="3" stroke-linecap="round"/><circle cx="46" cy="76" r="3" fill="#6B3A22"/><circle cx="72" cy="68" r="3" fill="#6B3A22"/><circle cx="82" cy="82" r="3" fill="#6B3A22"/>`);
    case 'cookie': return f(`<circle cx="60" cy="62" r="40" fill="${tone}" ${SW}/><g fill="#4A2A1A"><ellipse cx="44" cy="48" rx="6" ry="5"/><ellipse cx="72" cy="44" rx="6" ry="5"/><ellipse cx="58" cy="66" rx="6" ry="5"/><ellipse cx="82" cy="70" rx="5" ry="5"/><ellipse cx="42" cy="78" rx="5" ry="5"/><ellipse cx="66" cy="88" rx="5" ry="4"/></g><path d="M30 40c6-8 14-12 22-13" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="3" stroke-linecap="round"/>`);
    case 'cake': return f(`<ellipse cx="60" cy="102" rx="46" ry="7" fill="#fff" ${SW}/><rect x="24" y="64" width="72" height="34" rx="6" fill="${tone}" ${SW}/><rect x="24" y="52" width="72" height="14" rx="5" fill="${mix(tone, '#fff', .3)}" ${SW}/><path d="M24 50a8 8 0 0 1 8-8h56a8 8 0 0 1 8 8v4c-6 8-8-2-14 2s-8-4-14 0-8-4-14 0-8-4-14 2-6-2-10-2z" fill="#FFF2DC" ${SW}/><ellipse cx="48" cy="38" rx="9" ry="6" fill="#6B3A22" ${SW}/><ellipse cx="72" cy="38" rx="9" ry="6" fill="#6B3A22" ${SW}/>`);
    case 'bag': return f(`<path d="M30 30h60l6 8v66a6 6 0 0 1-6 6H30a6 6 0 0 1-6-6V38z" fill="${tone}" ${SW}/><rect x="24" y="24" width="72" height="14" rx="4" fill="${dark}" ${SW}/><circle cx="60" cy="31" r="2.6" fill="#fff"/><rect x="36" y="50" width="48" height="48" rx="8" fill="#FFF8EC" ${SW}/><ellipse cx="60" cy="63" rx="5" ry="7" fill="${tone}" transform="rotate(30 60 63)"/><path d="M60 74v10" stroke="#ECB444" stroke-width="5.5" stroke-linecap="round"/><circle cx="60" cy="92" r="3" fill="#ECB444"/>`);
    case 'box': return f(`<rect x="22" y="54" width="76" height="52" rx="6" fill="${tone}" ${SW}/><rect x="16" y="40" width="88" height="20" rx="6" fill="${mix(tone, '#fff', .18)}" ${SW}/><path d="M60 40v66" fill="none" stroke="#FFF8EC" stroke-width="10"/><path d="M60 40c-6-14-24-14-24-6s15 9 24 6zM60 40c6-14 24-14 24-6s-15 9-24 6z" fill="#FFF8EC" ${SW}/>`);
    case 'tin': return f(`<rect x="34" y="32" width="52" height="74" rx="8" fill="${tone}" ${SW}/><rect x="30" y="22" width="60" height="16" rx="6" fill="#fff" ${SW}/><rect x="42" y="54" width="36" height="38" rx="6" fill="#FFF8EC" ${SW}/><path d="M60 82c-8-6-8-16 0-22 8 6 8 16 0 22z" fill="${tone}" stroke="${K}" stroke-width="2.5" stroke-linejoin="round"/>`);
    case 'cups': return f(`<path d="M30 40h46l-6 62H36z" fill="#fff" ${SW}/><path d="M36 82h34l-1.6 18H37.6z" fill="${tone}"/><rect x="26" y="34" width="54" height="8" rx="4" fill="#fff" ${SW}/><path d="M60 52h40l-5 50H66z" fill="#fff" ${SW}/><rect x="56" y="46" width="48" height="8" rx="4" fill="#fff" ${SW}/>`);
    /* empty-state illustrations */
    case 'tote': return f(`<path d="M42 46c0-18 8-30 18-30s18 12 18 30" fill="none" ${SW}/><path d="M24 46h72l-6 60a6 6 0 0 1-6 5H36a6 6 0 0 1-6-5z" fill="#F4F1EC" ${SW}/><circle cx="60" cy="76" r="17" fill="#fff" ${SW}/><path d="M60 67v9" stroke="#ECB444" stroke-width="5" stroke-linecap="round"/><circle cx="60" cy="85" r="2.8" fill="#ECB444"/>`);
    case 'giftbag': return f(`<path d="M44 40c0-12 6-20 16-20s16 8 16 20" fill="none" ${SW}/><path d="M26 40h68l-5 66a6 6 0 0 1-6 5H37a6 6 0 0 1-6-5z" fill="#F4F1EC" ${SW}/><path d="M26 40h68" fill="none" ${SW}/><path d="M60 40v71" stroke="#ECB444" stroke-width="8"/><path d="M60 40c-5-12-20-12-20-5s13 8 20 5zM60 40c5-12 20-12 20-5s-13 8-20 5z" fill="#ECB444" ${SW}/>`);
    case 'bellart': return f(`<path d="M60 18v8" fill="none" ${SW}/><path d="M34 82V58a26 26 0 0 1 52 0v24l8 10H26z" fill="#F4F1EC" ${SW}/><path d="M52 98a8 8 0 0 0 16 0" fill="#ECB444" ${SW}/><path d="M46 62a14 14 0 0 1 8-12" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/>`);
    default: return f(`<circle cx="60" cy="60" r="30" fill="${tone}"/>`);
  }
}
/* product photos: the server keeps them (the admin uploads them), p.img = {id, bg, f, r}; without one the drawn art is used.
   f "c": the photo sits on a plain background of colour bg; f "v": it fills the tile. r: width / height.
   Lists and tiles load the small copy (/t), the product sheet the large one. */
const pm = p => { const m = p && p.img; return m && /^[0-9a-f]{32}$/.test(m.id) ? m : null; };
const imgUrl = (m, big) => `/api/img/${m.id}${big ? '' : '/t'}`;
const tileBg = p => { const m = pm(p); return m && /^#[0-9a-f]{6}$/i.test(m.bg || '') ? m.bg : '#F3F3F3'; };
/* mode "fit": the whole photo, centred, with soft side edges that melt into the tile colour (product sheet, gift tiles);
   "fits": the same from the small copy, for small tiles */
function pic(p, mode) {
  const m = pm(p);
  if (!m) return art(p.art, p.tone);
  if (mode === 'fit' || mode === 'fits') return `<span class="im fe" style="--r:${Number(m.r) || 1};background-image:url(${imgUrl(m, mode === 'fit')})" aria-hidden="true"></span>`;
  return `<span class="im ${m.f === 'c' ? 'ct' : ''}" style="background-image:url(${imgUrl(m, mode === 'big')})" aria-hidden="true"></span>`;
}
const th = (p, cls = 'th') => `<span class="${cls}" style="background:${tileBg(p)}">${pic(p)}</span>`;
/* a staff page's own logo: the w with ORDER DESK or MANAGEMENT under it, the scooter with DELIVERY; "compact" is the
   version for small places (the top bar), where the words are a little larger. It takes the colour of the text around it. */
const APPLOGO = (h, compact) => {
  const k = compact ? 'lockupc' : 'lockup', m = IMG[k];
  return m ? `<span class="lk-i im-${k}" style="width:${Math.round(h * m.r)}px;height:${h}px" role="img" aria-label="${esc(IMG.name || 'Why!')}"></span>` : LOGO(Math.round(h * .5));
};
const LOGO = h => IMG.logo
  ? `<span class="logo-i im-logo" style="width:${Math.round(h * IMG.logo.r)}px;height:${h}px" role="img" aria-label="${T('واي', 'Why')}"></span>`
  : `<div class="logo">${T('واي', 'Why')}<b>!</b></div>`;
/* the why! wordmark in the colour of the text around it (the membership cards) */
const LOGOM = h => IMG.logo
  ? `<span class="logo-m im-logom" style="width:${Math.round(h * IMG.logo.r)}px;height:${h}px" role="img" aria-label="${T('واي', 'Why')}"></span>`
  : `<b class="logo-t" style="font-size:${h}px">why!</b>`;
function coverHTML(n, cls) {
  if (n.img && /^[0-9a-f]{32}$/.test(n.img.id)) return `<span class="${cls} imb" style="background-image:url(/api/img/${n.img.id})"></span>`;   /* the admin's photo */
  return IMG.n[n.id] ? `<span class="${cls} imb im-n-${n.id}"></span>` : `<span class="${cls}" style="background:${n.bg}"></span>`;
}

/* ---------- a small street map (OpenStreetMap tiles, no library): points [{lat, lng, cls, html}] in a w x h box ---------- */
const TILE = 256;
const mapX = (lng, z) => (lng + 180) / 360 * TILE * 2 ** z;
const mapY = (lat, z) => { const r = lat * Math.PI / 180; return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * TILE * 2 ** z; };
function mapHTML(pts, w, h, label, line) {
  const all = pts.concat((line || []).map(([lat, lng]) => ({lat, lng})));   /* the road is in view too */
  let z = 17;
  for (; z > 4; z--) {
    const xs = all.map(p => mapX(p.lng, z)), ys = all.map(p => mapY(p.lat, z));
    if (Math.max(...xs) - Math.min(...xs) <= w - 80 && Math.max(...ys) - Math.min(...ys) <= h - 80) break;
  }
  const ax = all.map(p => mapX(p.lng, z)), ay = all.map(p => mapY(p.lat, z)), xs = ax.slice(0, pts.length), ys = ay.slice(0, pts.length), n = 2 ** z;
  const x0 = (Math.max(...ax) + Math.min(...ax) - w) / 2, y0 = (Math.max(...ay) + Math.min(...ay) - h) / 2;
  let tiles = '';
  for (let tx = Math.floor(x0 / TILE); tx <= Math.floor((x0 + w) / TILE); tx++) {
    for (let ty = Math.max(0, Math.floor(y0 / TILE)); ty <= Math.min(n - 1, Math.floor((y0 + h) / TILE)); ty++) {
      tiles += `<img class="mt" alt="" draggable="false" referrerpolicy="strict-origin-when-cross-origin" src="https://tile.openstreetmap.org/${z}/${((tx % n) + n) % n}/${ty}.png" style="left:${Math.round(tx * TILE - x0)}px;top:${Math.round(ty * TILE - y0)}px">`;
    }
  }
  const marks = pts.map((p, k) => `<span class="mp ${p.cls}" style="left:${Math.round(xs[k] - x0)}px;top:${Math.round(ys[k] - y0)}px">${p.html || ''}</span>`).join('');
  const road = line && line.length > 1 ? (() => { const d = line.map(([lat, lng]) => `${Math.round(mapX(lng, z) - x0)},${Math.round(mapY(lat, z) - y0)}`).join(' ');
    return `<svg class="road" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true"><polyline points="${d}" class="rc"/><polyline points="${d}" class="rl"/></svg>`; })() : '';
  return `<div class="osm" style="width:${w}px;height:${h}px" role="img" aria-label="${esc(label || '')}">${tiles}${road}${marks}<span class="osm-c">© OpenStreetMap</span></div>`;
}

/* ---------- a live map (OpenStreetMap tiles, no library): pan with a finger, zoom with + and −.
   liveMap() writes the empty frame during render(); mountMaps() fills it after each render from MAPS[key],
   which keeps the centre and zoom, so a re-render shows the same place. In "pick" mode a pin stays in the
   middle and the place under it is handed to cfg.pick when the person stops moving the map. ---------- */
const MAP_HOME = {lat:24.4672, lng:39.6024};   /* Madinah: where a map opens when nothing better is known */
const MAPS = {};
const unX = (x, z) => x / (TILE * 2 ** z) * 360 - 180;
const unY = (y, z) => { const n = Math.PI * (1 - 2 * y / (TILE * 2 ** z)); return Math.atan((Math.exp(n) - Math.exp(-n)) / 2) * 180 / Math.PI; };
function liveMap(key, cfg, cls) {
  let m = MAPS[key];
  if (!m || cfg.reset) m = MAPS[key] = {lat:cfg.lat, lng:cfg.lng, z:cfg.z || 14, fit:cfg.fit || null};
  m.pts = cfg.pts || []; m.pick = cfg.pick || null; m.under = cfg.under || null;   /* under: what covers the bottom of the map (a sheet) */
  return `<div class="lmap ${cls || ''}" data-map="${key}" role="application" aria-label="${esc(cfg.label || T('خريطة', 'Map'))}"><div class="lm-l"></div>
    ${m.pick ? `<span class="lm-pin" aria-hidden="true"><svg viewBox="0 0 24 24" width="40" height="40"><path d="M12 22s7.5-6.6 7.5-12.4A7.5 7.5 0 0 0 4.5 9.6C4.5 15.4 12 22 12 22z" fill="#0F0F0F" stroke="#fff" stroke-width="1.6"/><circle cx="12" cy="9.6" r="2.8" fill="#ECB444"/></svg></span>` : ''}
    <div class="lm-z"><button type="button" data-zm="1" aria-label="${T('تكبير', 'Zoom in')}">${ic('plus', 18)}</button><button type="button" data-zm="-1" aria-label="${T('تصغير', 'Zoom out')}">${ic('minus', 18)}</button></div><span class="osm-c">© OpenStreetMap</span></div>`;
}
const mapCenterOn = (key, lat, lng, z) => { const m = MAPS[key]; if (m) { m.lat = lat; m.lng = lng; if (z) m.z = z; m.fit = null; } };
function drawMap(el, m) {
  const w = el.clientWidth, full = el.clientHeight, lay = el.querySelector('.lm-l');
  if (!w || !full || !lay) return;
  const cov = m.under ? $(m.under) : null, h = cov ? Math.max(full * .3, full - Math.min(cov.getBoundingClientRect().height, full * .7)) : full;   /* the part one can see */
  if (m.fit && m.fit.length) {   /* the first time: every point in view */
    let z = 17;
    for (; z > 4; z--) { const xs = m.fit.map(p => mapX(p.lng, z)), ys = m.fit.map(p => mapY(p.lat, z)); if (Math.max(...xs) - Math.min(...xs) <= w - 100 && Math.max(...ys) - Math.min(...ys) <= h - 140) break; }
    const xs = m.fit.map(p => mapX(p.lng, z)), ys = m.fit.map(p => mapY(p.lat, z));
    m.z = Math.min(z, 16); m.lng = unX((Math.max(...xs) + Math.min(...xs)) / 2, z); m.lat = unY((Math.max(...ys) + Math.min(...ys)) / 2, z); m.fit = null;
  }
  const n = 2 ** m.z, x0 = mapX(m.lng, m.z) - w / 2, y0 = mapY(m.lat, m.z) - h / 2;
  m._x0 = x0; m._y0 = y0; m._w = w; m._h = h;   /* for the gestures */
  let html = '';
  for (let tx = Math.floor(x0 / TILE); tx <= Math.floor((x0 + w) / TILE); tx++) {
    for (let ty = Math.max(0, Math.floor(y0 / TILE)); ty <= Math.min(n - 1, Math.floor((y0 + full) / TILE)); ty++) {
      html += `<img class="mt" alt="" draggable="false" referrerpolicy="strict-origin-when-cross-origin" src="https://tile.openstreetmap.org/${m.z}/${((tx % n) + n) % n}/${ty}.png" style="left:${Math.round(tx * TILE - x0)}px;top:${Math.round(ty * TILE - y0)}px">`;
    }
  }
  m.pts.forEach(p => {
    const x = mapX(p.lng, m.z) - x0, y = mapY(p.lat, m.z) - y0;
    if (x < -40 || y < -40 || x > w + 40 || y > full + 40) return;
    html += p.a ? `<button type="button" class="${p.cls}" style="left:${Math.round(x)}px;top:${Math.round(y)}px" data-a="${p.a}" data-id="${p.id}" aria-label="${esc(p.label || '')}">${p.html || ''}</button>`
      : `<span class="${p.cls}" style="left:${Math.round(x)}px;top:${Math.round(y)}px">${p.html || ''}</span>`;
  });
  lay.style.transform = '';
  lay.innerHTML = html;
}
/* one finger moves the map, two fingers pinch it bigger or smaller (the picture follows the fingers, then settles on the nearest
   zoom level with the place between the fingers kept under them); + and −, and the mouse wheel on a computer, zoom too */
function mountMaps() {
  document.querySelectorAll('.lmap').forEach(el => {
    const key = el.dataset.map, m = MAPS[key];
    if (!m) return;
    drawMap(el, m);
    const lay = el.querySelector('.lm-l'), ptrs = new Map();
    let d = null, pin = null, eat = false;
    const settle = () => { if (m.pick) m.pick(r6(m.lat), r6(m.lng)); };
    const swallow = () => { eat = true; setTimeout(() => { eat = false; }, 0); };   /* only the click that ends a gesture (if the browser sends one) */
    const capture = id => { try { el.setPointerCapture(id); } catch (er) { /* fine */ } };
    const two = () => { const [a, b] = [...ptrs.values()]; return {dist:Math.max(1, Math.hypot(a.x - b.x, a.y - b.y)), x:(a.x + b.x) / 2, y:(a.y + b.y) / 2}; };
    const zoomTo = (nz, mx, my, tx, ty) => {   /* the world point that was at (mx, my) goes to (mx + tx, my + ty) at zoom nz */
      nz = Math.max(3, Math.min(19, nz));
      const s = 2 ** (nz - m.z), wx = (m._x0 + mx) * s, wy = (m._y0 + my) * s;
      m.z = nz; m.lng = unX(wx - (mx + tx) + m._w / 2, nz); m.lat = Math.max(-85, Math.min(85, unY(wy - (my + ty) + m._h / 2, nz)));
    };
    el.addEventListener('pointerdown', e => {
      if (e.target.closest('.lm-z')) return;
      ptrs.set(e.pointerId, {x:e.clientX, y:e.clientY});
      if (ptrs.size === 1) { d = {x:e.clientX, y:e.clientY, id:e.pointerId, moved:false}; return; }
      if (ptrs.size === 2 && !pin) {   /* the second finger: a pinch starts where the map is now */
        if (d && d.moved) { const p = ptrs.get(d.id) || d; m.lng = unX(mapX(m.lng, m.z) - (p.x - d.x), m.z); m.lat = Math.max(-85, Math.min(85, unY(mapY(m.lat, m.z) - (p.y - d.y), m.z))); drawMap(el, m); }
        d = null;
        const r = el.getBoundingClientRect(), g = two();
        pin = {d0:g.dist, x0:g.x, y0:g.y, mx:g.x - r.left, my:g.y - r.top, sc:1, tx:0, ty:0};
        UI.mapDrag = true; ptrs.forEach((v, id) => capture(id));
        lay.style.transformOrigin = `${pin.mx}px ${pin.my}px`;
      }
    });
    el.addEventListener('pointermove', e => {
      if (!ptrs.has(e.pointerId)) return;
      ptrs.set(e.pointerId, {x:e.clientX, y:e.clientY});
      if (pin) {
        if (ptrs.size < 2) return;
        const g = two();
        pin.sc = Math.max(1 / 16, Math.min(16, g.dist / pin.d0)); pin.tx = g.x - pin.x0; pin.ty = g.y - pin.y0;
        lay.style.transform = `translate(${pin.tx}px,${pin.ty}px) scale(${pin.sc})`;
        return;
      }
      if (!d || e.pointerId !== d.id) return;
      const dx = e.clientX - d.x, dy = e.clientY - d.y;
      if (!d.moved && Math.hypot(dx, dy) < 6) return;
      if (!d.moved) { d.moved = true; UI.mapDrag = true; capture(d.id); }
      lay.style.transform = `translate(${dx}px,${dy}px)`;
    });
    const end = e => {
      if (!ptrs.has(e.pointerId)) return;
      ptrs.delete(e.pointerId);
      if (pin) {
        if (ptrs.size) return;   /* wait for the last finger, then settle */
        const p = pin; pin = null; d = null; UI.mapDrag = false; swallow();
        lay.style.transformOrigin = '';
        zoomTo(m.z + Math.round(Math.log2(p.sc)), p.mx, p.my, p.tx, p.ty);
        drawMap(el, m); settle();
        return;
      }
      if (!d || e.pointerId !== d.id) return;
      const moved = d.moved, dx = e.clientX - d.x, dy = e.clientY - d.y; d = null; UI.mapDrag = false;
      if (!moved) return;
      swallow();
      m.lng = unX(mapX(m.lng, m.z) - dx, m.z); m.lat = Math.max(-85, Math.min(85, unY(mapY(m.lat, m.z) - dy, m.z)));
      drawMap(el, m); settle();
    };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    el.addEventListener('click', e => { if (eat) { eat = false; e.stopPropagation(); e.preventDefault(); } }, true);
    el.addEventListener('wheel', e => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      zoomTo(m.z + (e.deltaY < 0 ? 1 : -1), e.clientX - r.left, e.clientY - r.top, 0, 0);   /* around the pointer, like other maps */
      drawMap(el, m); settle();
    }, {passive:false});
    el.querySelectorAll('[data-zm]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); m.z = Math.max(3, Math.min(19, m.z + Number(b.dataset.zm))); drawMap(el, m); }));
  });
}
const r6 = n => Math.round(n * 1e5) / 1e5;

/* ---------- membership tiers: the customer's tier comes from the server (S.tier = {id, pts}), the values from SRV.tiers ---------- */
const tiersOk = l => Array.isArray(l) && l.length === TIERS.length && l.every((t, i) => t && t.id === TIERS[i].id && Number.isInteger(t.min) && Number.isInteger(t.per10) && t.per10 > 0);
const tiersRise = l => tiersOk(l) && l[0].min === 0 && l.every((t, i) => t.per10 >= 1 && t.per10 <= 100 && (!i || (t.min > l[i - 1].min && t.per10 >= l[i - 1].per10)));
function tierOf(pts) { let t = SRV.tiers[0]; SRV.tiers.forEach(x => { if (pts >= x.min) t = x; }); return t; }
const tierPts = () => S.session && S.tier ? S.tier.pts : 0;
const myTier = () => (S.session && S.tier && SRV.tiers.find(x => x.id === S.tier.id)) || tierOf(tierPts());
const tierName = t => L(TIER_NAME[(t || myTier()).id] || MEMBER);
/* points for a payment: per10 points for every 10 SAR, whole points only (the server works it out the same way) */
const tierEarn = (sar, t) => Math.floor(Math.round(Number(sar) * 100) * (t || myTier()).per10 / 1000);
const ptsWord = n => S.lang === 'ar' ? (n === 1 ? 'نقطة' : n === 2 ? 'نقطتان' : n >= 3 && n <= 10 ? 'نقاط' : 'نقطة') : (n === 1 ? 'point' : 'points');

/* ---------- points and notifications ----------
   Since 0.7 the server keeps the points, the wallet and the gifts; the phone shows the copy it last got (applyAcct).
   A phone signed in before 0.7 still counts on its own (legacyAcct) until its first talk with the server hands that over. */
const legacyAcct = () => S.arev == null;
function addPts(n, label, type) {   /* only while the phone still counts (legacyAcct) */
  if (!n) return;
  S.pts += n;
  S.ledger.unshift({id:uid(), ts:Date.now(), pts:n, type:type || (n > 0 ? 'earn' : 'spend'), label});
}
/* what the phone tells the server it counted, once, so the account opens with it */
const legacyBody = () => legacyAcct() && S.user ? {pts:Math.max(0, Math.round(S.pts)), bal:Math.max(0, r2(S.bal)), since:S.since} : undefined;
function applyAcct(a) {
  if (!a || typeof a !== 'object' || !S.session) return false;
  const first = S.gseen == null, seen = new Set(S.gseen || []);
  const news = (a.gifts || []).filter(g => g.state === 'new' && !seen.has(g.id));
  S.arev = a.arev; S.pts = Number(a.pts) || 0; S.bal = Number(a.bal) || 0;
  S.ledger = a.ledger || []; S.wal = a.wallet || []; S.gifts = a.gifts || []; S.sent = a.sent || [];
  S.gseen = Array.from(new Set((S.gseen || []).concat(S.gifts.map(g => g.id)))).slice(-300);
  if (news.length) {
    const fr = txt(news[0].from) || T('صديق', 'a friend');
    const n = news.length, many = n === 2 ? 'هديتان' : n <= 10 ? `${n} هدايا` : `${n} هدية`;
    const t = n > 1 ? {ar:`وصلتك ${many}`, en:`You received ${n} gifts`} : {ar:`وصلتك هدية من ${fr}`, en:`${fr} sent you a gift`};
    note(t, {ar:'تجدها في تبويب الهدايا.', en:'You will find it in the Gifts tab.'}, 'gift', {tab:'gifts', seg:'recv', sub:news[0].kind});
    if (!first) toast(L(t));
  }
  return true;
}
/* signed out or deleted: nothing of the account stays on this phone (it comes back from the server at the next sign-in) */
function clearAcct() {
  Object.assign(S, {session:false, guest:false, user:null, pts:0, tier:null, ledger:[], orders:[], gifts:[], sent:[], bal:0, notifs:[], ack:[], seen:[], addr:null, arev:null, wal:[], gseen:null, since:0});
  TRK = {};
}
/* go: where tapping it leads ({p:'order', id} | {tab:'gifts', seg, sub} | {p:'points'} | {p:'topup'}) */
function note(t, b, ico, go) { S.notifs.unshift({id:uid(), ts:Date.now(), t, b, ico:ico || 'bell', read:false, go:go || null}); }
const unread = () => S.notifs.filter(n => !n.read).length;

/* ---------- products, options, cart ---------- */
function liveP(id) { const p = PROD[id]; return p && !p.gone ? p : null; }   /* a product still on the menu (it may be sold out) */
const pOpts = p => ((p && p.opts) || []).filter(g => OPT[g]);                    /* an option group this page does not know is left out */
function defSel(p) { const s = {}; pOpts(p).forEach(g => { const G = OPT[g]; s[g] = G.type === 'check' ? [] : G.items[0].id; }); return s; }
/* a choice made before the admin changed the product: what still exists is kept, the rest goes back to the first choice */
function normSel(p, sel) {
  const s = {}; sel = sel || {};
  pOpts(p).forEach(g => {
    const G = OPT[g], x = sel[g];
    if (G.type === 'check') s[g] = (Array.isArray(x) ? x : []).filter(id => G.items.some(i => i.id === id));
    else s[g] = G.items.some(i => i.id === x) ? x : G.items[0].id;
  });
  return s;
}
function optDelta(g, id) { const it = OPT[g] && OPT[g].items.find(i => i.id === id); return it ? it.d : 0; }
function unitPrice(p, sel) {
  let v = p.price; sel = sel || {};
  pOpts(p).forEach(g => { const G = OPT[g], x = sel[g]; if (G.type === 'check') (x || []).forEach(id => v += optDelta(g, id)); else v += optDelta(g, x); });
  return v;
}
/* the names of the chosen options; for an order, its own choices (the product may have changed since) */
function selText(sel, groups) {
  const out = []; sel = sel || {};
  (groups || Object.keys(sel)).forEach(g => {
    const G = OPT[g], x = sel[g]; if (!G) return;
    if (G.type === 'check') (Array.isArray(x) ? x : []).forEach(id => { const it = G.items.find(i => i.id === id); if (it) out.push(L(it)); });
    else { const it = G.items.find(i => i.id === x); if (it) out.push(L(it)); }
  });
  return out.join(T('، ', ', '));
}
const selLabels = (p, sel) => selText(sel, pOpts(p));
/* the name of an ordered item as it was when it was ordered (orders from before 0.4 have none: the menu names them) */
const itemName = it => it.n ? L(it.n) : (PROD[it.pid] ? L(PROD[it.pid]) : T('منتج لم يعد متوفرًا', 'A product no longer offered'));
/* what can be sent as a gift: the chosen few while they are on the menu, otherwise the first drinks (function: UI needs it early) */
function giftItems() { const l = GIFT_ITEMS.filter(id => liveP(id)); return l.length ? l : PRODUCTS.filter(p => (CAT[p.cat] || {}).kind !== 'retail').slice(0, 6).map(p => p.id); }
const selKey = sel => JSON.stringify(Object.keys(sel).sort().map(k => [k, Array.isArray(sel[k]) ? sel[k].slice().sort() : sel[k]]));
function addCart(pid, sel, qty, extra) {
  const copy = JSON.parse(JSON.stringify(sel));
  if (!extra) {
    const ex = S.cart.find(c => c.pid === pid && !c.rw && !c.gift && selKey(c.sel) === selKey(copy));
    if (ex) { ex.qty = Math.min(20, ex.qty + qty); save(); return ex; }
  }
  const it = Object.assign({uid:uid(), pid, sel:copy, qty}, extra || {});
  S.cart.push(it); save(); return it;
}
function cartLines() {
  return S.cart.filter(c => PROD[c.pid]).map(c => {
    const p = PROD[c.pid], free = !!(c.rw || c.gift), unit = free ? 0 : unitPrice(p, c.sel);
    return {c, p, free, unit, total:unit * c.qty, kind:(CAT[p.cat] || {}).kind || 'drink'};
  });
}
const cartCount = () => S.cart.reduce((a, c) => a + c.qty, 0);
const cartSub = () => cartLines().reduce((a, l) => a + l.total, 0);
const cartPts = () => S.cart.reduce((a, c) => a + (c.rw && RW(c.rw) ? RW(c.rw).pts * c.qty : 0), 0);
const retailOnly = lines => lines.length > 0 && lines.every(l => l.kind === 'retail');
const hasRetail = lines => lines.some(l => l.kind === 'retail');
function effMode(lines) {
  const ro = retailOnly(lines); let m = UI.co.mode;
  if (!m) m = ro ? 'ship' : 'pickup';
  if (m === 'ship' && !ro) m = 'pickup';
  if (m === 'delivery' && !deliveryOn()) m = ro ? 'ship' : 'pickup';
  return m;
}
/* The order summary shows each line without VAT, then the VAT line, then the total. The VAT line absorbs cent rounding. */
function breakdown(q) {
  const c = v => Math.round(v * 100);
  const lines = q.lines.map(l => ({l, ex:c(l.total / 1.15)}));
  const shipEx = c(q.ship / 1.15), discEx = c(q.disc / 1.15);
  const vatC = c(q.total) - (lines.reduce((a, x) => a + x.ex, 0) + shipEx - discEx);
  return {lines:lines.map(x => ({l:x.l, ex:x.ex / 100})), shipEx:shipEx / 100, discEx:discEx / 100, vat:vatC / 100};
}
function calc() {
  const lines = cartLines(), mode = effMode(lines), co = UI.co;
  const sub = lines.reduce((a, l) => a + l.total, 0);
  const freeShip = lines.some(l => l.p.fship);
  const ship = mode === 'ship' ? (freeShip ? 0 : shipFee()) : (mode === 'delivery' ? deliveryFee() : 0);
  const cd = SRV.codes[co.code];
  const disc = co.codeOk && cd && cd.on ? r2(sub * cd.pct / 100) : 0;
  const total = Math.max(0, r2(sub + ship - disc));
  const bal = co.useBal ? Math.min(S.bal, total) : 0;
  const pay = r2(total - bal);
  const q = {lines, mode, sub, ship, freeShip, disc, total, bal, pay, ptsCost:cartPts(), earn:tierEarn(pay), ro:retailOnly(lines)};
  q.bd = breakdown(q); q.vat = q.bd.vat;
  return q;
}
/* ---------- branches ---------- */
function liveB(id) { const b = BR[id]; return b && !b.gone ? b : null; }   /* a branch still open for business (a deleted one stays known) */
const hm = m => `${pad2(Math.floor(m / 60) % 24)}:${pad2(m % 60)}`;
/* the opening hours as people read them: h is '24' or [open, close] in minutes (close past midnight is past 1440) */
function hoursText(b) {
  if (!b || b.h === '24') return T('24 ساعة', '24 hours');
  if (!Array.isArray(b.h)) return '';
  return T(`من ${hm(b.h[0])} إلى ${hm(b.h[1])}`, `${hm(b.h[0])} to ${hm(b.h[1])}`);
}
const hasLoc = b => !!b && typeof b.lat === 'number' && typeof b.lng === 'number';
const dirUrl = b => `https://www.google.com/maps/dir/?api=1&destination=${b.lat},${b.lng}`;
const mapUrl = (lat, lng) => `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
function kmBetween(a, b) {
  const r = x => x * Math.PI / 180, dLa = r(b.lat - a.lat), dLo = r(b.lng - a.lng);
  const h = Math.sin(dLa / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLo / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(h)));
}
function openAt(b, ms) {
  if (!b) return false;
  if (b.h === '24') return true;
  const d = new Date(ms), m = d.getHours() * 60 + d.getMinutes();
  return (m >= b.h[0] && m < b.h[1]) || (m + 1440 >= b.h[0] && m + 1440 < b.h[1]);
}
function isOpen(b) {
  if (!b) return false;
  if (SRV.br[b.id] && SRV.br[b.id].pause) return false;
  return openAt(b, Date.now());
}
/* pickup later (0.7): every 15 minutes from 15 minutes ahead, while the branch stays open, at most 12 hours ahead */
function pickSlots(b) {
  const out = [], step = 15 * 6e4, now = Date.now() + (SRV.skew || 0);
  for (let t = Math.ceil((now + 15 * 6e4) / step) * step; t <= now + 12 * 36e5 && out.length < 48; t += step) {
    if (openAt(b, t)) out.push(t); else if (out.length) break;
  }
  return out;
}
const clockAt = ts => { const d = new Date(ts); const h = d.getHours(); return `${h % 12 || 12}:${pad2(d.getMinutes())} ${h >= 12 ? T('م', 'PM') : T('ص', 'AM')}`; };   /* 5:30 م */

/* ---------- orders ---------- */
/* pickup: the customer comes to the branch. ship: a carrier brings beans. delivery: the café's own driver brings anything. */
const STAGES = {
  pickup:[{ar:'تم استلام الطلب', en:'Order received'}, {ar:'قيد التحضير', en:'Being prepared'}, {ar:'جاهز للإستلام', en:'Ready for pickup'}, {ar:'تم الإستلام', en:'Collected'}],
  ship:[{ar:'تم استلام الطلب', en:'Order received'}, {ar:'قيد التجهيز', en:'Packing your order'}, {ar:'تم الشحن', en:'Shipped'}, {ar:'تم التسليم', en:'Delivered'}],
  delivery:[{ar:'تم استلام الطلب', en:'Order received'}, {ar:'قيد التحضير', en:'Being prepared'}, {ar:'في الطريق إليك', en:'On its way to you'}, {ar:'تم التوصيل', en:'Delivered'}]
};
const WAIT_DRIVER = {ar:'جاهز للتوصيل', en:'Ready for delivery'};
/* the orders this screen works with: the customer's own, or (staff apps) everybody's as the server sends them */
const allOrders = () => (APP === 'cust' ? S.orders : SRV.orders).slice().sort((a, b) => b.ts - a.ts);
const ordById = id => allOrders().find(o => o.id === id);
const ORD = ordById;
const shipFee = () => SRV.ship;
const deliveryOn = () => !!SRV.delivery.on;
const deliveryFee = () => SRV.delivery.fee;
/* 0.7: the smallest delivery order and how far from the branch the drivers go (0 = no limit) */
const deliveryMin = () => Number(SRV.delivery.min) || 0;
const deliveryKm = () => Number(SRV.delivery.km) || 0;
/* what stops a delivery to this spot from this branch: a short reason, or '' when it can go */
function deliveryBlock(sub, addr, b) {
  const mn = deliveryMin(), km = deliveryKm();
  if (mn && sub < mn - 1e-9) return T(`الحد الأدنى لطلب التوصيل ${fmt(mn)} ر.س، أضف أصنافًا بقيمة ${fmt2(r2(mn - sub))} ر.س`, `The smallest delivery order is ${fmt(mn)} SAR. Add ${fmt2(r2(mn - sub))} SAR more`);
  if (km && hasLoc(b)) {
    if (addr.lat == null) return T('حدّد موقع التوصيل على الخريطة', 'Set the delivery spot on the map');
    const d = kmBetween(addr, b);
    if (d > km) return T(`الموقع يبعد ${d.toFixed(1)} كم عن الفرع، والتوصيل حتى ${fmtKm(km)} كم`, `The spot is ${d.toFixed(1)} km from the branch; we deliver up to ${fmtKm(km)} km`);
  }
  return '';
}
/* 0.7: a product the admin (or the branch's desk) marked as not available at a branch */
const offAt = (p, bid) => !!(p && Array.isArray(p.off) && p.off.includes(bid || S.branch));
function advance(o, k) {
  o.at = o.at || [o.ts];
  const now = Date.now();
  for (let j = o.st + 1; j <= k; j++) { o.at[j] = now; notifyStage(o, j); }
  o.st = k;
  if (k === 3) { o.fin = true; o.done = true; }
}
/* The server owns the status. This phone only shows it. */
const stageOf = o => o.rej ? 0 : o.st;
const stageLabel = (o, i) => o.mode === 'delivery' && i === 2 && !o.driver ? L(WAIT_DRIVER) : L(STAGES[o.mode][i]);
function notifyStage(o, k) {
  if (APP !== 'cust') return;
  const b = BR[o.branch];
  if (k === 1) note({ar:`طلبك ${o.no} قيد التحضير`, en:`Order ${o.no} is being prepared`}, {ar:'بدأنا بتجهيز طلبك الآن.', en:'We have started on it.'}, 'receipt', {p:'order', id:o.id});
  if (k === 2 && o.mode === 'pickup') {
    note({ar:`طلبك ${o.no} جاهز للإستلام`, en:`Order ${o.no} is ready`}, {ar:`رمز الإستلام ${o.code}. أظهره للموظف في ${b.ar}.`, en:`Code ${o.code}. Show it to the staff at ${b.en}.`}, 'check', {p:'order', id:o.id});
    toast(T(`طلبك ${o.no} جاهز للإستلام`, `Order ${o.no} is ready`));
  }
  if (k === 2 && o.mode === 'ship') note({ar:`تم شحن طلبك ${o.no}`, en:`Order ${o.no} has shipped`}, {ar:`رقم الشحنة ${o.code} عبر ${o.carrier}.`, en:`Tracking ${o.code} with ${o.carrier}.`}, 'truck', {p:'order', id:o.id});
  if (k === 2 && o.mode === 'delivery') note({ar:`طلبك ${o.no} جاهز للتوصيل`, en:`Order ${o.no} is ready for delivery`}, {ar:'بانتظار أول مندوب متاح.', en:'Waiting for the next free driver.'}, 'truck', {p:'order', id:o.id});
  if (k === 3 && o.mode !== 'pickup') note({ar:`تم ${o.mode === 'ship' ? 'تسليم' : 'توصيل'} طلبك ${o.no}`, en:`Order ${o.no} was delivered`}, {ar:'نتمنى لك تجربة رائعة.', en:'Enjoy your coffee.'}, 'check', {p:'order', id:o.id});
}
/* the driver says he is at the door (he can say it again after a minute) */
function notifyArrived(o) {
  const d = (o.driver && o.driver.name) || T('المندوب', 'Your driver');
  note({ar:`المندوب وصل بطلبك ${o.no}`, en:`Your driver is here with order ${o.no}`}, {ar:`${d} عند موقعك الآن. جهّز رمز الإستلام ${o.code}.`, en:`${d} is at your place now. Have the code ${o.code} ready.`}, 'pin', {p:'order', id:o.id});
  toast(T('المندوب وصل! جهّز رمز الإستلام', 'Your driver is here! Have your code ready'));
}
/* a driver took the order: tell the customer once */
function notifyDriver(o) {
  note({ar:`طلبك ${o.no} في الطريق إليك`, en:`Order ${o.no} is on its way`}, {ar:`المندوب ${o.driver.name} في الطريق. جهّز رمز الإستلام ${o.code}.`, en:`${o.driver.name} is bringing it. Have the code ${o.code} ready.`}, 'truck', {p:'order', id:o.id});
  toast(T(`طلبك ${o.no} في الطريق إليك`, `Order ${o.no} is on its way`));
}
/* the café turned an order down: what the customer used goes back, points earned from it are taken off */
const REASONS = [
  {id:'out', ar:'نفد أحد الأصناف', en:'An item is sold out'},
  {id:'busy', ar:'الفرع مزدحم حاليًا', en:'The branch is too busy right now'},
  {id:'close', ar:'الفرع على وشك الإغلاق', en:'The branch is about to close'},
  {id:'reach', ar:'تعذّر التواصل مع العميل', en:'We could not reach the customer'},
  {id:'other', ar:'سبب آخر', en:'Another reason'}
];
function rejectOrder(o, rej) {
  if (o.rej || o.fin) return;
  const r = rej.why;
  o.rej = {ts:rej.ts || Date.now(), why:{ar:r.ar, en:r.en}, by:rej.by || ''};
  if (legacyAcct()) {   /* the phone still counts: it gives back itself (the server does it once the account lives there) */
    if (o.bal) S.bal = r2(S.bal + o.bal);
    if (o.spent) addPts(o.spent, {ar:`إرجاع نقاط الطلب ${o.no}`, en:`Points returned for order ${o.no}`}, 'bonus');
    if (o.earn) addPts(-Math.min(o.earn, S.pts), {ar:`إلغاء نقاط الطلب ${o.no}`, en:`Points reversed for order ${o.no}`}, 'spend');
    o.items.forEach(it => { if (it.gift) { const g = S.gifts.find(x => x.id === it.gift); if (g) g.state = 'new'; } });
  }
  if (rej.by === 'cust') note({ar:`تم إلغاء طلبك ${o.no}`, en:`Order ${o.no} was cancelled`}, {ar:'رجعت إلى حسابك النقاط والرصيد المستخدمان، ويُرد المدفوع إلى وسيلة الدفع.', en:'The points and balance you used are back, and your payment will be refunded.'}, 'x', {p:'order', id:o.id});
  else note({ar:`تعذّر تنفيذ طلبك ${o.no}`, en:`Order ${o.no} could not be prepared`}, {ar:`${r.ar}. سيُرد المبلغ المدفوع إلى وسيلة الدفع.`, en:`${r.en}. Your payment will be refunded.`}, 'x', {p:'order', id:o.id});
}

/* ---------- account ---------- */
function resetData() { const lang = S.lang, dev = S.dev; S = Object.assign(fresh(), {lang, dev}); UI.co = newCo(); UI.g = newG(); UI.stack = []; UI.sheet = null; UI.tab = 'home'; }
