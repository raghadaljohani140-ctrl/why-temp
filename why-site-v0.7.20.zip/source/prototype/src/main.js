/* Main: what every page shares: the render loop, the sheet and dialog actions, the events common to all pages */

function render() {
  $$('[data-sk]').forEach(el => { UI.sc[el.dataset.sk] = [el.scrollLeft, el.scrollTop]; });
  const v = $('#view');
  document.body.classList.toggle('staff', APP !== 'cust');
  /* 0.7.15: a playing video goes on playing through a redraw; 0.7.18: so does a Google map (a new one is a new map load) */
  const keep = {}; $$('video[data-keep], .gm-host[data-keep]', v).forEach(el => { keep[el.dataset.keep] = el; });
  v.innerHTML = view();
  $$('video[data-keep], .gm-host[data-keep]', v).forEach(el => { const old = keep[el.dataset.keep]; if (old) el.replaceWith(old); });
  // only the top-most screen is live: covered screens (and everything under a sheet/dialog) stay inert
  const scr = $$('#view > .screen'), modal = !!(UI.sheet || UI.dlg || UI.proc);
  scr.forEach((el, i) => el.toggleAttribute('inert', modal || i < scr.length - 1));
  $$('[data-sk]', v).forEach(el => { const s = UI.sc[el.dataset.sk]; if (s) { el.scrollLeft = s[0]; el.scrollTop = s[1]; } });
  const sl = $('#slides');
  if (sl) sl.scrollTo({left:(S.lang === 'ar' ? -1 : 1) * UI.intro.i * sl.clientWidth, behavior:'instant'});
  mountMaps();
  if (UI.focus) { const el = $(UI.focus); if (el) { el.focus(); if (el.select) el.select(); } UI.focus = null; }
  UI.fresh = {sheet:false, page:false};
}
const syncBtns = () => $$('[data-need]').forEach(b => { b.disabled = !NEED[b.dataset.need](); });
function setPath(o, p, v) { const k = p.split('.'); let c = o; for (let i = 0; i < k.length - 1; i++) c = c[k[i]]; c[k[k.length - 1]] = v; }
function openSheet(s) { UI.sheet = s; UI.fresh.sheet = true; delete UI.sc.sheet; render(); }

Object.assign(A, {
  sheet(d) { openSheet({k:d.k}); },
  close() {
    if (UI.sheet && UI.sheet.k === 'auth') { UI.auth = authInit(); UI.otp = ['', '', '', '', '']; }
    UI.sheet = null; UI.fm = null; render();
  },
  dlgNo() { UI.dlg = null; render(); },
  dlgYes() { const f = UI.dlg && UI.dlg.fn; UI.dlg = null; if (f) f(); render(); }
});

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const t = e.target.closest('[data-a]');
  if (!t || t.disabled) return;
  const f = A[t.dataset.a]; if (f) f(t.dataset, t, e);
});
document.addEventListener('input', e => {
  const t = e.target;
  if (!t.dataset.bind) return;
  let v = t.value;
  if (t.dataset.fmt === 'num') {
    v = toLatin(v).replace(/[٫,]/g, '.').replace(/[^\d.]/g, ''); v = (v.match(/^\d*\.?\d{0,2}/) || [''])[0];
    if (v !== t.value) t.value = v;
  }
  if (t.dataset.fmt === 'phone') {
    v = toLatin(v).replace(/\D/g, ''); if (v.startsWith('966')) v = v.slice(3); v = v.replace(/^0+/, '').slice(0, 9);
    if (v !== t.value) t.value = v;
  }
  if (t.dataset.fmt === 'phone05') {   /* typed as 05x-xxx-xxxx, kept as the nine digits after the 0 */
    const raw = toLatin(v).replace(/\D/g, '');
    let d = raw.replace(/^0+/, ''); if (d.startsWith('966')) d = d.slice(3); d = d.replace(/^0+/, '').slice(0, 9);
    v = d;
    const shown = d ? fmt05(d) : (raw.startsWith('0') ? '0' : '');
    if (shown !== t.value) t.value = shown;
  }
  if (t.dataset.fmt === 'digits') {
    v = toLatin(v).replace(/\D/g, '').slice(0, t.maxLength > 0 ? t.maxLength : 10);   /* a VAT number is 15 digits */
    if (v !== t.value) t.value = v;
  }
  setPath(UI, t.dataset.bind, v);
  syncBtns();
  if (t.dataset.on && A[t.dataset.on]) A[t.dataset.on](t.dataset, t);
});
document.addEventListener('change', e => {
  const t = e.target;
  if (!t.dataset || !t.dataset.bind || !/^(time|date|select-one)$/.test(t.type)) return;
  setPath(UI, t.dataset.bind, t.value);
  syncBtns();
  if (t.dataset.on && A[t.dataset.on]) A[t.dataset.on](t.dataset, t);
});
/* going back from outside the page (the iPhone app: a swipe from the left edge): first an open question, then a sheet,
   then the page's own back button. Returns false when there is nowhere to go back to. */
window.whyBack = () => {
  if (UI.dlg) { A.dlgNo(); return true; }
  if (UI.sheet) { A.close(); return true; }
  const b = [...document.querySelectorAll('#view [data-a="back"]')].filter(x => x.offsetParent !== null).pop();
  if (b) { b.click(); return true; }
  return false;
};
document.addEventListener('keydown', e => {
  const t = e.target;
  if (e.key === 'Enter' && t.dataset && t.dataset.enter && A[t.dataset.enter]) { e.preventDefault(); A[t.dataset.enter](t.dataset, t); }
  if (e.key === 'Escape') { if (UI.dlg) A.dlgNo(); else if (UI.sheet) A.close(); }
});
