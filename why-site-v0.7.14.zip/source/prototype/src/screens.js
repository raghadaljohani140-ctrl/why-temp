/* Screens: HTML builders only. State lives in S (saved) and UI (session).
   Structure and wording follow the Coffematics app; screens that were not in the reference screenshots are written in the same plain style. */

Object.assign(NEED, {
  phone:() => validPhone(UI.f.phone),
  signup:() => validPhone(UI.f.phone) && (UI.f.name || '').trim().length >= 2,
  name:() => (UI.f.name || '').trim().length >= 2,
  pname:() => (UI.f.pname || '').trim().length >= 2,
  otp:() => UI.otp.every(x => x),
  gphone:() => validPhone(UI.g.phone) && (!giftDel() || (UI.g.addr.city.trim().length > 1 && UI.g.addr.street.trim().length > 1 && !deliveryBlock(giftPrice(UI.g) - deliveryFee(), UI.g.addr, BR[S.branch]))),
  gstep1:() => UI.g.type === 'item' || (Number.isInteger(UI.g.amt) && UI.g.amt >= GIFT_MIN && UI.g.amt <= GIFT_MAX),
  tpamt:() => Number.isInteger(UI.tp.amt) && UI.tp.amt >= GIFT_MIN && UI.tp.amt <= GIFT_MAX
});

const hdr = (title, r) => `<header class="hdr"><button class="back" data-a="back" aria-label="${T('رجوع', 'Back')}">${ic('back', 24, 'flip')}</button><h1 class="ttl">${title}</h1><div class="hr">${r || '<span class="sp"></span>'}</div></header>`;
const lockState = (kind, msg) => `<div class="empty"><div class="eart">${art(kind, '#C8965A')}</div><h2>${msg}</h2><button class="btn sm" data-a="login">${T('تسجيل الدخول', 'Log in')}</button></div>`;
const phoneField = (label, bind, val, extra = '') => `<div class="field"><label>${label}</label><div class="phone"><span class="cc">+966</span><input class="inp" type="tel" inputmode="numeric" autocomplete="tel-national" placeholder="5X XXX XXXX" data-bind="${bind}" data-fmt="phone" value="${esc(val)}" maxlength="12" ${extra}></div></div>`;
const stCls = i => i === 3 ? 'done' : (i === 2 ? 'ready' : 'prep');
const stChip = o => { if (o.rej) return `<span class="st rej"><i></i>${o.rej.by === 'cust' ? T('ملغي', 'Cancelled') : T('مرفوض', 'Rejected')}</span>`; const i = stageOf(o); return `<span class="st ${stCls(i)}"><i></i>${esc(stageLabel(o, i))}</span>`; };
const mcIcon = '<span class="mc"><i></i><i></i></span>';
const payRows = (cur, act) => [['card', mcIcon, T('بطاقة الدفع', 'Payment card')], ['apple', ic('card', 22), 'Apple Pay']].map(([id, ico, l]) => `<button class="pay ${cur === id ? 'on' : ''}" data-a="${act}" data-id="${id}"><span class="mk"></span>${ico}<span class="grow">${l}</span></button>`).join('');

/* quarter-circle pattern used on the points cards */
const PAT = '<svg class="pat" viewBox="0 0 350 172" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><path d="M0 172V70A102 102 0 0 1 102 172z" style="fill:var(--pri-l)"/><path d="M0 0H92A92 92 0 0 1 0 92z" style="fill:var(--pri-d)"/><path d="M168 0h80a80 80 0 0 1-80 80z" style="fill:var(--pri-l);opacity:.55"/><path d="M350 172V120a52 52 0 0 0-52 52z" style="fill:var(--pri-d);opacity:.7"/></svg>';

/* ---------- shared bits ---------- */
function tabBar() {
  const tabs = [['orders', 'timer', T('طلباتي', 'Orders')], ['gifts', 'gift', T('الهدايا', 'Gifts')], ['home', '', T('الرئيسية', 'Home')], ['branches', 'pin', T('الفروع', 'Branches')], ['news', 'book', T('الأخبار', 'News')]];
  return `<nav class="tabs ${UI.tab === 'home' ? 'hump' : ''}" aria-label="${T('التنقل', 'Navigation')}">${tabs.map(([id, ico, lb]) => {
    const on = UI.tab === id;
    if (id === 'home') {
      return on
        ? `<button class="tab home on" data-a="tab" data-id="home" aria-current="page"><span class="hb">${mark(24)}</span><span>${lb}</span></button>`
        : `<button class="tab" data-a="tab" data-id="home">${mark(19)}<span>${lb}</span></button>`;
    }
    return `<button class="tab ${on ? 'on' : ''}" data-a="tab" data-id="${id}">${on ? icf(ico, 24) : ic(ico, 24)}<span>${lb}</span></button>`;
  }).join('')}</nav>`;
}
function cartFab(low) {
  const n = cartCount();
  return `<button class="fab ${low ? 'low' : ''}" data-a="push" data-p="cart" aria-label="${T('السلة', 'Cart')}">${ic('bag', 26)}${n ? `<span class="badge">${n}</span>` : ''}</button>`;
}
function loyalHTML() {
  return `<button class="loyal tc t-${myTier().id}" data-a="push" data-p="member">${MPAT}<span class="mkc">${LOGOM(26)}</span><span class="tx"><span class="lbl">${T('رصيد النقاط', 'Points balance')}</span><span class="num">${num(S.session ? S.pts : 0)}</span><span class="mem">${tierName()}${ic('chev', 16, 'flip')}</span></span></button>`;
}

/* ---------- onboarding (phone mock-ups are static copies of the real screens) ---------- */
const mockHome = () => `<div class="htop">${LOGO(30)}<div class="hbtns"><span class="rb">${ic('user', 21)}</span><span class="rb">${ic('bell', 21)}</span><span class="rb">${ic('star', 21)}</span></div></div>
  <div class="hello"><span>${T('مرحبا بك!', 'Welcome!')}</span><b>${T('أحمد', 'Ahmed')}</b></div>
  <div class="loyal tc t-basic">${MPAT}<span class="mkc">${LOGOM(26)}</span><span class="tx"><span class="lbl">${T('رصيد النقاط', 'Points balance')}</span><span class="num">1,250</span><span class="mem">${L(MEMBER)}${ic('chev', 16, 'flip')}</span></span></div>
  <div class="rdm"><span class="grow"><b>${T('استبدل نقاطك الآن!', 'Redeem your points now!')}</b><small>${T('استبدل نقاطك بمجموعة من المكافآت الرائعة', 'Redeem your points for a range of great rewards')}</small></span>${ic('chev', 20, 'flip')}</div>
  <div class="tiles">${tileOf('order', '', 'div')}${tileOf('gift', '', 'div')}</div>`;
const mockPoints = () => `<div class="hdr"><span class="back">${ic('back', 24, 'flip')}</span><h1 class="ttl">${T('نقاطي', 'My points')}</h1><div class="hr"><span class="sp"></span></div></div>
  <div class="ptscard">${PAT}<span><span class="num">1,250</span><small>${T('إجمالي النقاط', 'Total points')}</small></span><span class="starc">${ic('star', 28)}</span></div>
  <div class="prow"><span class="btn">${T('إستبدل', 'Redeem')}</span><span class="btn line">${ic('clock', 18)}${T('العمليات السابقة', 'Previous transactions')}</span></div>`;
const mockGifts = () => `<h1 class="tt">${T('الهدايا', 'Gifts')}</h1>
  <div class="seg"><button tabindex="-1" class="on">${T('المستقبلة', 'Received')}</button><button tabindex="-1">${T('المرسلة', 'Sent')}</button></div>
  <div class="utabs"><button tabindex="-1" class="on">${T('المنتجات', 'Products')}</button><button tabindex="-1">${T('البطاقات', 'Cards')}</button></div>
  <div class="gcard"><div class="gh"><span class="av">${T('ر', 'R')}</span><div class="grow"><b>${T('من رزان', 'From Razan')}</b><small>${T('السبت 22 يناير - 05:00 PM', 'Saturday 22 January - 05:00 PM')}</small></div></div>
    <div class="gi"><span>X1 ${T('اسبريسو', 'Espresso')}</span><span>11.0</span></div><div class="gi"><span>X1 ${T('كابتشينو', 'Cappuccino')}</span><span>16.0</span></div>
    <div class="bubble">${T('هلا سارة! هذي هدية بسيطة، طلبي المفضل انجوي!', 'Hi Sara! A small gift, my favourite order, enjoy!')}</div></div>`;

/* 0.7.13: the welcome screen: a photo over the whole screen, the words at the bottom; "start" goes to the slides, "skip" to their end */
function scrWelcome() {
  const v = tileView('welcome'), up = v.img, ph = !up && IMG.ht && IMG.ht.welcome;
  const photo = up ? `<span class="wl-ph" style="background-image:url(/api/img/${up.id})"></span>`
    : ph ? `<span class="wl-ph im-ht-welcome"${ph.pos ? ` style="background-position:${ph.pos}"` : ''}></span>` : `<span class="wl-ph none"></span>`;
  return `<div class="screen wl">${photo}<button class="wl-skip" data-a="welSkip">${T('تخطي', 'Skip')}</button>
    <div class="wl-tx"><h1>${esc(L(v.t))}</h1><p>${esc(L(v.s))}</p><button class="btn wl-go" data-a="welGo">${T('للبدء', 'Get started')}</button></div></div>`;
}
function scrIntro() {
  const i = UI.intro.i;
  const sl = [
    {h:T('مرحبا بك في واي!', 'Welcome to Why!'), p:T('تجربة رقمية فريدة، مكافآت مميزة و مزايا حصرية', 'A unique digital experience, special rewards and exclusive perks'), m:mockHome()},
    {h:T('اجمع النقاط مع كل عملية شراء', 'Collect points with every purchase'), p:T('استبدل نقاطك بمنتجاتك المفضلة من واي!', 'Redeem your points for your favourites from Why!'), m:mockPoints()},
    {h:T('اهدي من تحب وشاركهم اللحظات الجميلة', 'Gift the ones you love and share the good moments'), p:T('أرسل الهدايا لأحبائك بسهولة، واستبدل نقاطك بمكافآت حصرية داخل التطبيق.', 'Send gifts to your loved ones easily, and redeem your points for exclusive rewards inside the app.'), m:mockGifts()}
  ];
  return `<div class="screen">
    <div class="intro-top"><div class="segs" id="segs">${sl.map((s, k) => `<i class="${k <= i ? 'on' : ''}"></i>`).join('')}</div><span class="count" id="cnt">${i + 1}/3</span></div>
    <div class="slides" id="slides">${sl.map(s => `<div class="slide"><h2>${s.h}</h2><p>${s.p}</p><div class="mockwrap"><div class="mock"><div class="mock-in">${s.m}</div></div></div></div>`).join('')}</div>
    <div class="intro-cta"><button class="btn" data-a="openAuth" data-m="login">${T('تسجيل الدخول', 'Log in')}</button><button class="btn line" data-a="openAuth" data-m="signup">${T('إنشاء حساب', 'Create account')}</button><button class="btn text" data-a="guest">${T('المتابعة كضيف', 'Continue as guest')}</button></div>
  </div>`;
}

/* ---------- tabs ---------- */
/* what a banner's button says: from where it takes the customer */
const bnGo = a => a === 'points' ? T('نقاطي', 'My points') : a === 'gift' ? T('أرسل هدية', 'Send a gift') : a === 'menu' ? T('اطلب الآن', 'Order now')
  : (PROD[a] && (CAT[PROD[a].cat] || {}).kind === 'retail') ? T('تسوّق الآن', 'Shop now') : T('اطلب الآن', 'Order now');
/* 0.7.10: a text banner with its own photo (assets/home): the photo on one side, melting into its own colour, the words on the other.
   0.7.11: a photo the admin uploads does the same when it is not wide (a product photo); a wide one (2 to 1) is a whole picture. */
const hb = id => IMG.hb && IMG.hb[id];
const upImg = b => b.img && /^[0-9a-f]{32}$/.test(b.img.id) ? b.img : null;
const inkOn = bg => {   /* black or white words, whichever reads better on this colour */
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(bg || ''); if (!m) return '#0F0F0F';
  const l = [m[1], m[2], m[3]].map(h => { const c = parseInt(h, 16) / 255; return c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4); });
  const y = .2126 * l[0] + .7152 * l[1] + .0722 * l[2];
  return (1.05 / (y + .05)) > ((y + .05) / .0555) ? '#FFFFFF' : '#0F0F0F';
};
const pbCard = (b, bg, ink, photo) => `<button class="bn pb ${ink === '#FFFFFF' ? 'lt' : ''}" style="background:${bg};color:${ink}" data-a="bn" data-t="${esc(b.a)}">${photo}<span class="tx"><span class="t">${esc(L(b.t))}</span><span class="s">${esc(L(b.s))}</span><span class="go">${bnGo(b.a)}</span></span></button>`;
const bnCard = b => upImg(b) && (Number(b.img.r) >= 1.5 || !L(b.t))
  ? `<button class="bn imb" style="aspect-ratio:${Math.max(1.5, Number(b.img.r) || 2)};background-image:url(/api/img/${b.img.id})" data-a="bn" data-t="${esc(b.a)}" aria-label="${esc(L(b.t))}"></button>`
  : upImg(b)
  ? pbCard(b, /^#[0-9a-f]{6}$/i.test(b.img.bg || '') ? b.img.bg : '#F3F3F3', inkOn(b.img.bg || '#F3F3F3'), `<span class="bp" style="background-image:url(/api/img/${b.img.id})" aria-hidden="true"></span>`)
  : hb(b.id)
  ? pbCard(b, hb(b.id).bg, hb(b.id).ink.toUpperCase(), `<span class="bp im-hb-${b.id}" aria-hidden="true"${hb(b.id).pos ? ` style="background-position:${hb(b.id).pos}"` : ''}></span>`)
  : IMG.b[b.id]
  ? `<button class="bn imb im-b-${b.id}" style="aspect-ratio:${IMG.b[b.id].r}" data-a="bn" data-t="${esc(b.a)}" aria-label="${esc(L(b.t))}"></button>`
  : `<button class="bn" style="background:${b.bg}${b.ink ? ';color:' + b.ink : ''}" data-a="bn" data-t="${esc(b.a)}"><span class="t">${esc(L(b.t))}</span><span class="s">${esc(L(b.s))}</span></button>`;
/* a home tile: its photo (assets/home) or, without one, the drawing */
/* a home tile: the admin's photo and words (0.7.12), or the app's own photo (assets/home), or without either the drawing */
const tileOf = (k, a, tag = 'button') => {
  const v = tileView(k), up = v.img, ph = !up && IMG.ht && IMG.ht[k];
  const bg = up ? (/^#[0-9a-f]{6}$/i.test(up.bg || '') ? up.bg : '#F3F3F3') : ph ? ph.bg : '';
  const pic = up ? `<span class="tp" style="background-image:url(/api/img/${up.id})" aria-hidden="true"></span>`
    : ph ? `<span class="tp im-ht-${k}" aria-hidden="true"${ph.pos ? ` style="background-position:${ph.pos}"` : ''}></span>`
    : `<span class="ta">${art(v.art, v.tone)}</span>`;
  return `<${tag} class="tile ${bg ? 'ph' : ''}" ${bg ? `style="background:${bg}"` : ''} ${a}><b>${esc(L(v.t))}</b><small>${esc(L(v.s))}</small>${pic}</${tag}>`;
};
function scrHome() {
  const name = S.session && S.user ? esc(S.user.name) : T('ضيف', 'Guest');
  const nUn = unread();
  return `<div class="screen">
    <div class="htop">${LOGO(34)}<div class="hbtns">
      <button class="rb" data-a="sheet" data-k="profile" aria-label="${T('حسابي', 'Account')}">${ic('user', 21)}</button>
      <button class="rb" data-a="push" data-p="notifs" aria-label="${T('الإشعارات', 'Notifications')}">${ic('bell', 21)}${nUn ? `<span class="badge">${nUn}</span>` : ''}</button>
      <button class="rb" data-a="push" data-p="points" aria-label="${T('نقاطي', 'My points')}">${ic('star', 21)}</button></div></div>
    <div class="scroll wt" data-sk="tab-home">
      <div class="hello"><span>${T('مرحبا بك!', 'Welcome!')}</span><b>${name}</b></div>
      ${loyalHTML()}
      <button class="rdm" data-a="push" data-p="rewards"><span class="grow"><b>${T('استبدل نقاطك الآن!', 'Redeem your points now!')}</b><small>${T('استبدل نقاطك بمجموعة من المكافآت الرائعة', 'Redeem your points for a range of great rewards')}</small></span>${ic('chev', 20, 'flip')}</button>
      <div class="tiles">
        ${tileOf('order', 'data-a="toMenu"')}
        ${tileOf('gift', 'data-a="push" data-p="giftsend"')}
      </div>
      <div class="carousel" id="bn" data-sk="home-bn">${bannersLive().map(bnCard).join('')}</div>
      <div class="dots" id="bnd">${bannersLive().map((b, k) => `<i class="${k === UI.bn ? 'on' : ''}"></i>`).join('')}</div>
    </div>
    ${cartFab()}${tabBar()}</div>`;
}

const newsCard = n => `<button class="nw" data-a="news" data-id="${n.id}">${n.vid ? `<span class="nw-v">${coverHTML(n, 'cov')}<i class="vplay" aria-label="${T('فيديو', 'Video')}"></i></span>` : coverHTML(n, 'cov')}<span class="m"><b>${esc(L(n.t))}</b><small class="ltr">${dNews(n.ts)}</small></span></button>`;
function scrNews() {
  const list = newsLive();
  return `<div class="screen"><h1 class="tt c">${T('الأخبار', 'News')}</h1><div class="scroll wt" data-sk="tab-news">${list.length ? list.map(newsCard).join('') : emptyHTML('tote', '#C8965A', T('لا توجد أخبار حاليًا', 'No news right now'))}</div>${tabBar()}</div>`;
}

const ordCard = o => `<button class="ord" data-a="push" data-p="order" data-id="${o.id}"><span class="r"><b>${T('طلب', 'Order')} ${o.no}</b>${stChip(o)}</span><span class="grey">${esc(itemsSummary(o))}</span><span class="r"><small>${dLong(o.ts)}</small><b>${money2(o.total)}</b></span></button>`;
function scrOrders() {
  const top = `<h1 class="tt">${T('طلباتي', 'My orders')}</h1>`;
  if (!S.session) return `<div class="screen">${top}<div class="scroll wt" data-sk="tab-orders">${lockState('tote', T('سجّل دخولك لعرض طلباتك.', 'Log in to see your orders.'))}</div>${tabBar()}</div>`;
  const list = UI.seg === 'points' ? S.orders.filter(o => o.spent > 0) : S.orders;
  return `<div class="screen">${top}
    <div class="utabs"><button class="${UI.seg === 'orders' ? 'on' : ''}" data-a="seg" data-id="orders">${T('الطلبات', 'Orders')}</button><button class="${UI.seg === 'points' ? 'on' : ''}" data-a="seg" data-id="points">${T('طلبات النقاط', 'Points orders')}</button></div>
    <div class="scroll wt" data-sk="tab-orders">${list.length ? list.map(ordCard).join('') : emptyHTML('tote', '#C8965A', T('لا يوجد طلبات مسجلة', 'No orders yet'))}</div>${tabBar()}</div>`;
}

function gcRecv(g) {
  const p = g.kind === 'item' ? PROD[g.pid] : null, used = g.state !== 'new', inCart = S.cart.some(c => c.gift === g.id), fr = txt(g.from);
  const row = p ? `<div class="gi"><span>X1 ${esc(L(p))}</span><span>${fmt1(unitPrice(p, defSel(p)))}</span></div>` : `<div class="gi"><span>${T('بطاقة هدية', 'Gift card')}</span><span>${fmt1(g.amt)}</span></div>`;
  const btn = used ? `<span class="st done" style="margin-top:12px"><i></i>${T('تم الإستخدام', 'Used')}</span>`
    : `<button class="btn sm" data-a="gUse" data-id="${g.id}" ${inCart ? 'disabled' : ''}>${p ? (inCart ? T('في السلة', 'In cart') : T('إستخدم الآن', 'Use now')) : T('إضافة إلى الرصيد', 'Add to balance')}</button>`;
  return `<div class="gcard"><div class="gh"><span class="av">${esc(fr.charAt(0))}</span><div class="grow"><b>${T('من', 'From')} ${esc(fr)}</b><small>${dLong(g.ts)}</small></div></div>${row}${g.msg && txt(g.msg) ? `<div class="bubble">${esc(txt(g.msg))}</div>` : ''}${btn}</div>`;
}
function gcSent(g) {
  const p = g.kind === 'item' ? PROD[g.pid] : null;
  const row = p ? `<div class="gi"><span>X1 ${esc(L(p))}</span><span>${fmt1(g.price)}</span></div>` : `<div class="gi"><span>${T('بطاقة هدية', 'Gift card')}</span><span>${fmt1(g.amt)}</span></div>`;
  const st = g.state === 'used' ? `<span class="st done" style="margin-top:12px"><i></i>${T('استخدمها المستلم', 'The recipient used it')}</span>`
    : g.state === 'void' ? `<span class="st rej" style="margin-top:12px"><i></i>${T('لم تُنفّذ، ويُرد المبلغ', 'Not delivered; refunded')}</span>`
    : g.state === 'new' ? `<span class="st prep" style="margin-top:12px"><i></i>${T('بانتظار المستلم', 'Waiting for the recipient')}</span>` : '';
  return `<div class="gcard"><div class="gh"><span class="av">${esc((g.toName || '#').charAt(0))}</span><div class="grow"><b>${T('إلى', 'To')} ${g.toName ? esc(g.toName) : `<span class="ltr">${phoneFmt(g.to)}</span>`}</b><small>${dLong(g.ts)}</small></div></div>${row}${g.msg ? `<div class="bubble">${esc(g.msg)}</div>` : ''}${g.oid && g.state !== 'void' && ORD(g.oid) ? `<button class="btn line sm" style="margin-top:12px" data-a="push" data-p="order" data-id="${g.oid}">${ic('truck', 18)}${T('مع التوصيل · تتبّع الطلب', 'With delivery · track it')}</button>` : st}</div>`;
}
function scrGifts() {
  const top = `<h1 class="tt">${T('الهدايا', 'Gifts')}</h1>`;
  if (!S.session) return `<div class="screen">${top}<div class="scroll wt" data-sk="tab-gifts">${lockState('giftbag', T('سجّل دخولك لإرسال الهدايا وإستقبالها.', 'Log in to send and receive gifts.'))}</div>${tabBar()}</div>`;
  const recv = UI.gseg === 'recv', list = (recv ? S.gifts : S.sent).filter(g => g.kind === UI.gsub);
  const wal = recv && UI.gsub === 'card' ? `<div class="wal">${ic('wallet', 24)}<span class="grow"><b>${T('رصيد المحفظة', 'Wallet balance')}</b><small class="grey" style="display:block">${money2(S.bal)}</small></span><button class="btn sm" data-a="push" data-p="topup">${ic('plus', 16)}${T('شحن', 'Top up')}</button></div>` : '';
  return `<div class="screen">${top}
    <div class="seg"><button class="${recv ? 'on' : ''}" data-a="gseg" data-id="recv">${T('المستقبلة', 'Received')}</button><button class="${recv ? '' : 'on'}" data-a="gseg" data-id="sent">${T('المرسلة', 'Sent')}</button></div>
    <div class="utabs"><button class="${UI.gsub === 'item' ? 'on' : ''}" data-a="gsub" data-id="item">${T('المنتجات', 'Products')}</button><button class="${UI.gsub === 'card' ? 'on' : ''}" data-a="gsub" data-id="card">${T('البطاقات', 'Cards')}</button></div>
    <div class="scroll wt" data-sk="tab-gifts">${wal}${list.length ? list.map(recv ? gcRecv : gcSent).join('') : emptyHTML('giftbag', '#ECB444', T('لا توجد حالياً أي هدية', 'There are no gifts right now'))}</div>${tabBar()}</div>`;
}

/* the distance shows once the customer asked for it (the phone's location is used on this screen only, never kept) */
const brKm = b => UI.myLoc && hasLoc(b) ? kmBetween(UI.myLoc, b) : null;
function brCard(b) {
  const on = S.branch === b.id, d = brKm(b);
  return `<div class="br ${on ? 'on' : ''}" data-a="selBranch" data-id="${b.id}" role="button" tabindex="0"><b>${esc(L(b))}</b><small>${esc(L(b.addr))}</small>${d != null ? `<div class="kvl">${T('يبعد عنك', 'Distance')} : <span class="ltr">${d.toFixed(2)}</span> ${T('كم', 'km')}</div>` : ''}<div class="kvl">${T('أوقات العمل', 'Working hours')} : ${esc(hoursText(b))}</div>${hasLoc(b) ? `<a class="dir" href="${dirUrl(b)}" target="_blank" rel="noopener noreferrer" aria-label="${esc(T(`الاتجاهات إلى ${L(b)}`, `Directions to ${L(b)}`))}">${ic('nav', 20)}</a>` : ''}${openChip(b)}</div>`;
}
/* the branches on a real map (OpenStreetMap): a branch shows once the admin placed it on the map; the customer's own dot after "nearest to me" */
function branchMap() {
  const geo = BRANCHES.filter(hasLoc);
  const pts = geo.map(b => ({lat:b.lat, lng:b.lng, cls:`pin ${S.branch === b.id ? 'on' : ''} ${isOpen(b) ? '' : 'off'}`, a:'selBranch', id:b.id, label:L(b), html:ic('store', 18)}));
  if (UI.myLoc) pts.push({lat:UI.myLoc.lat, lng:UI.myLoc.lng, cls:'me'});
  const fit = geo.length ? geo.map(b => ({lat:b.lat, lng:b.lng})) : null;
  return liveMap('br', {lat:MAP_HOME.lat, lng:MAP_HOME.lng, z:12, fit, pts, under:'#bsheet', label:T('خريطة الفروع', 'Map of the branches')});
}
function scrBranches() {
  const list = UI.myLoc ? BRANCHES.slice().sort((a, b) => (brKm(a) == null ? 1e9 : brKm(a)) - (brKm(b) == null ? 1e9 : brKm(b))) : BRANCHES.slice();
  const near = BRANCHES.some(hasLoc) ? `<button class="near ${UI.myLoc ? 'on' : ''}" data-a="nearMe" ${UI.locating ? 'disabled' : ''}>${ic('nav', 16)}${UI.locating ? T('جاري تحديد موقعك…', 'Finding you…') : UI.myLoc ? T('مرتبة حسب الأقرب إليك', 'Sorted by distance from you') : T('رتّبها حسب الأقرب إليّ', 'Sort by the nearest to me')}</button>` : '';
  return `<div class="screen"><div class="mapfull">${branchMap()}</div>
    <div class="bsheet" id="bsheet" ${UI.bsh ? `style="--bh:${UI.bsh}px"` : ''}><div class="bs-grab" id="bsgrab"><i></i></div><div class="bs-list" data-sk="tab-branches">${near}${list.map(brCard).join('')}</div></div>${tabBar()}</div>`;
}

/* ---------- pages (pushed over the tabs) ---------- */
const prow = p => {
  const off = offAt(p) && (CAT[p.cat] || {}).kind !== 'retail', out = p.stock === false || off;   /* beans can still be shipped */
  const tag = p.stock === false ? `<span class="tag dim">${T('نفد', 'Sold out')}</span>` : off ? `<span class="tag dim">${T('غير متوفر', 'Not here')}</span>` : p.badge ? `<span class="tag">${L(p.badge)}</span>` : '';
  const sub = p.sub ? L(p.sub) : (p.cal ? T(`${p.cal} سعرة حرارية`, `${p.cal} kcal`) : '');
  return `<button class="prod ${out ? 'out' : ''}" data-a="product" data-id="${p.id}"><span class="pt" style="background:${tileBg(p)}">${pic(p)}${tag}</span><span class="pm"><span class="nm">${esc(L(p))}</span><span class="sub">${esc(sub)}</span><span class="pr">${money(p.price)}</span></span><span class="plusb">${ic(out ? 'x' : 'plus', 18)}</span></button>`;
};
function menuBody() {
  const q = (UI.f.q || '').trim().toLowerCase();
  UI.cat = curCat(UI.cat);
  const list = q ? PRODUCTS.filter(p => (p.ar + ' ' + p.en).toLowerCase().includes(q)) : PRODUCTS.filter(p => (p.cats || [p.cat]).includes(UI.cat));
  if (!list.length) return emptyHTML('hot', '#C8965A', T('لا توجد نتائج', 'No results'));
  const hint = !q && (CAT[UI.cat] || {}).kind === 'retail' ? `<div class="hint">${T('منتجات المحمصة تُشحن إليك، أو تستلمها من الفرع.', 'Roastery products ship to you, or you can pick them up at a branch.')}</div>` : '';
  return hint + list.map(prow).join('');
}
function pgMenu(i) {
  UI.cat = curCat(UI.cat);
  return hdr(T('القائمة', 'Menu')) + `<div class="srch">${ic('search', 20)}<input type="text" data-bind="f.q" data-on="search" value="${esc(UI.f.q || '')}" placeholder="${T('البحث', 'Search')}" aria-label="${T('البحث', 'Search')}" enterkeyhint="search" autocomplete="off"><button class="clr" id="clr" data-a="clearSearch" aria-label="${T('مسح', 'Clear')}" ${UI.f.q ? '' : 'hidden'}>${ic('x', 14)}</button></div>
    <div class="chips" data-sk="menu-chips">${CATS.filter(c => catHas(c.id)).map(c => `<button class="chip ${UI.cat === c.id ? 'on' : ''}" data-a="cat" data-id="${c.id}">${esc(L(c))}</button>`).join('')}</div>
    <div class="scroll pb" data-sk="pg-${i}" style="padding-bottom:calc(env(safe-area-inset-bottom) + 96px)"><div id="menuin">${menuBody()}</div></div>${cartCount() ? cartFab(true) : ''}`;
}

function cartRow(l) {
  const c = l.c, p = l.p;
  const flag = (c.rw ? `<span class="giftflag">${ic('star', 14)} ${T('مكافأة', 'Reward')} · ${num(RW(c.rw).pts)}</span>` : c.gift ? `<span class="giftflag">${ic('gift', 14)} ${T('هدية', 'Gift')}</span>` : '')
    + (offAt(p) && l.kind !== 'retail' ? `<span class="offflag">${T(`غير متوفر في ${L(BR[S.branch])}`, `Not available at ${L(BR[S.branch])}`)}</span>` : '');
  const ctl = l.free ? `<span class="grey ltr">X${c.qty}</span>` : `<div class="step"><button data-a="cq" data-id="${c.uid}" data-d="-1" aria-label="${T('أنقص', 'Less')}">${ic('minus', 16)}</button><b>${c.qty}</b><button data-a="cq" data-id="${c.uid}" data-d="1" aria-label="${T('زد', 'More')}">${ic('plus', 16)}</button></div>`;
  return `<div class="ci">${th(p)}<div class="info"><b>${esc(L(p))}</b><small>${esc(selLabels(p, c.sel))}</small>${flag}<div class="ctl">${ctl}<b>${l.free ? T('مجاني', 'Free') : money(l.total)}</b></div></div><button class="rm" data-a="crm" data-id="${c.uid}" aria-label="${T('حذف', 'Remove')}">${ic('trash', 20)}</button></div>`;
}
function pgCart(i) {
  const lines = cartLines();
  if (!lines.length) return hdr(T('السلة', 'Cart')) + `<div class="scroll" data-sk="pg-${i}">${emptyHTML('tote', '#C8965A', T('السلة فارغة', 'Your cart is empty'), `<button class="btn sm" data-a="toMenu">${T('تصفح القائمة', 'Browse the menu')}</button>`)}</div>`;
  return hdr(T('السلة', 'Cart'), `<button class="back" data-a="clearCart" aria-label="${T('تفريغ السلة', 'Empty cart')}">${ic('trash', 21)}</button>`)
    + `<div class="scroll pad" data-sk="pg-${i}">${lines.map(cartRow).join('')}<p class="grey" style="margin:14px 0">${T('الأسعار شاملة ضريبة القيمة المضافة (%15).', 'Prices include 15% VAT.')}</p></div>
    <div class="foot"><button class="btn split" data-a="toCheckout"><span>${T('إستكمال الطلب', 'Continue')}</span><span>${money2(cartSub())}</span></button></div>`;
}

/* the delivery place: the customer moves the map until the pin is on the door, or asks for the phone's location */
function pickMap(key, addr, b) {
  const start = addr.lat != null ? addr : hasLoc(b) ? {lat:b.lat, lng:b.lng} : MAP_HOME;
  const map = liveMap(key, {lat:start.lat, lng:start.lng, z:addr.lat != null ? 17 : 14, pick:(lat, lng) => { addr.lat = lat; addr.lng = lng; const s = $('#pk-' + key); if (s) s.innerHTML = pickState(true); },
    label:T('حرّك الخريطة لتحديد موقع التوصيل', 'Move the map to set the delivery spot')}, 'pick');
  return `<div class="pkw"><label class="pkl">${T('الموقع على الخريطة', 'Spot on the map')}</label>${map}
    <div class="pkb"><span class="pks" id="pk-${key}">${pickState(addr.lat != null)}</span><button class="btn line sm" data-a="useLoc" data-k="${key}">${ic('nav', 16)}${T('موقعي الحالي', 'My location')}</button></div></div>`;
}
const pickState = set => set ? `<span class="good">${ic('check', 16)}${T('تم تحديد الموقع', 'Spot set')}</span>` : `<span class="grey">${T('حرّك الخريطة حتى يكون الدبوس على موقعك', 'Move the map until the pin is on your spot')}</span>`;
function pgCheckout(i) {
  const q = calc(), co = UI.co, b = BR[S.branch], open = isOpen(b);
  const title = T('إستكمال الطلب', 'Checkout');
  if (!q.lines.length) return hdr(title) + `<div class="scroll">${emptyHTML('tote', '#C8965A', T('السلة فارغة', 'Your cart is empty'), `<button class="btn sm" data-a="toMenu">${T('تصفح القائمة', 'Browse the menu')}</button>`)}</div>`;
  const pick = q.mode === 'pickup', ship = q.mode === 'ship';
  const pickRow = `<div class="rcw ${pick ? 'on' : ''}"><div class="rc ${pick ? 'on' : ''}" data-a="mode" data-id="pickup" role="radio" aria-checked="${pick}"><span class="mk"></span><span class="grow"><b>${T('استلام من الفرع', 'Pickup from branch')}</b><small>${T('إستلم من', 'Pick up from')} ${esc(L(b))}</small>${open ? '' : `<small style="color:var(--red)">${T('الفرع مغلق حاليًا', 'This branch is closed now')}</small>`}</span><button class="chg" data-a="sheet" data-k="branch" aria-label="${T('تغيير الفرع', 'Change branch')}">${ic('chevdown', 20)}</button></div>
    ${pick ? `<div class="rcb"><h4 class="sh">${T('خيارات التقديم', 'Serving options')}</h4><div class="chips"><button class="chip ${co.serve === 'in' ? 'on' : ''}" data-a="serve" data-id="in">${ic('fork', 18)}${T('داخل الفرع', 'Dine in')}</button><button class="chip ${co.serve === 'take' ? 'on' : ''}" data-a="serve" data-id="take">${ic('bag', 18)}${T('تيك أواي', 'Takeaway')}</button></div>${pickTimeHTML(co, b)}</div>` : ''}</div>`;
  const shipRow = hasRetail(q.lines) ? `<div class="rcw ${ship ? 'on' : ''}"><div class="rc ${ship ? 'on' : ''} ${q.ro ? '' : 'dis'}" ${q.ro ? `data-a="mode" data-id="ship"` : ''} role="radio" aria-checked="${ship}" aria-disabled="${!q.ro}"><span class="mk"></span><span class="grow"><b>${T('شحن', 'Shipping')}</b><small>${q.ro ? T('عبر شركات الشحن', 'Via shipping carriers') : T('متاح لحبوب المحمصة والمنتجات فقط', 'Available for roastery beans and products only')}</small></span>${q.ro ? '' : `<span class="pill">${T('غير متاح', 'Unavailable')}</span>`}</div>
    ${ship ? `<div class="rcb"><div class="chips">${CARRIERS.map(c => `<button class="chip ${co.carrier === c ? 'on' : ''}" data-a="carrier" data-id="${c}">${c}</button>`).join('')}</div>${fld(T('المدينة', 'City'), 'co.addr.city', co.addr.city, T('مثال: المدينة المنورة', 'e.g. Madinah'))}${fld(T('الحي والشارع', 'District and street'), 'co.addr.street', co.addr.street, '')}${fld(T('ملاحظات للتوصيل (إختياري)', 'Delivery notes (optional)'), 'co.addr.note', co.addr.note, '')}</div>` : ''}</div>` : '';
  const dOn = deliveryOn(), dSel = q.mode === 'delivery', dBlock = dSel ? deliveryBlock(q.sub, co.addr, b) : '';
  const offHere = q.mode !== 'ship' ? q.lines.filter(l => offAt(l.p)) : [];
  const delRow = `<div class="rcw ${dSel ? 'on' : ''}"><div class="rc ${dSel ? 'on' : ''} ${dOn ? '' : 'dis'}" ${dOn ? 'data-a="mode" data-id="delivery"' : ''} role="radio" aria-checked="${dSel}" aria-disabled="${!dOn}"><span class="mk"></span><span class="grow"><b>${T('توصيل', 'Delivery')}</b><small>${dOn ? T(`يصلك طلبك إلى عنوانك · رسوم التوصيل ${fmt(deliveryFee())} ر.س`, `Brought to your address · delivery fee ${fmt(deliveryFee())} SAR`) + (deliveryMin() ? T(` · الحد الأدنى ${fmt(deliveryMin())} ر.س`, ` · smallest order ${fmt(deliveryMin())} SAR`) : '') + (deliveryKm() && hasLoc(b) ? T(` · حتى ${fmtKm(deliveryKm())} كم من الفرع`, ` · up to ${fmtKm(deliveryKm())} km from the branch`) : '') : T('التوصيل متوقف مؤقتًا', 'Delivery is paused for now')}</small>${dSel && !open ? `<small style="color:var(--red)">${T('الفرع مغلق حاليًا', 'This branch is closed now')}</small>` : ''}</span>${dOn ? '' : `<span class="pill">${T('غير متاح', 'Unavailable')}</span>`}</div>
    ${dSel ? `<div class="rcb"><div class="kv" style="padding-top:0"><span>${T('يُحضَّر من', 'Prepared at')} <b>${esc(L(b))}</b></span><button class="chg" data-a="sheet" data-k="branch" aria-label="${T('تغيير الفرع', 'Change branch')}">${ic('chevdown', 20)}</button></div>${fld(T('المدينة', 'City'), 'co.addr.city', co.addr.city, T('مثال: المدينة المنورة', 'e.g. Madinah'))}${fld(T('الحي والشارع', 'District and street'), 'co.addr.street', co.addr.street, '')}${fld(T('ملاحظات للمندوب (إختياري)', 'Notes for the driver (optional)'), 'co.addr.note', co.addr.note, '')}
      ${pickMap('co', co.addr, b)}${dBlock ? `<div class="err" style="padding:8px 2px 0">${esc(dBlock)}</div>` : ''}</div>` : ''}</div>`;
  const offRows = `<div class="rc dis"><span class="mk"></span><span class="grow"><b>${T('توصيل إلى السيارة', 'Bring it to my car')}</b><small>${T('لوحة + لون + نوع', 'Plate + colour + type')}</small></span><span class="pill">${T('غير متاح مؤقتاً', 'Temporarily unavailable')}</span></div>${delRow}`;
  const bd = q.bd;
  const sumLines = bd.lines.map(x => { const o = selLabels(x.l.p, x.l.c.sel); return `<div class="sum"><span class="lbl"><span class="ltr">x${x.l.c.qty}</span> ${esc(L(x.l.p))}${o ? `<small>( ${esc(o)} )</small>` : ''}</span>${money2(x.ex)}</div>`; }).join('');
  const rows = [sumLines];
  if (q.mode === 'ship') rows.push(`<div class="sum"><span>${T('الشحن', 'Shipping')}</span>${q.ship ? money2(bd.shipEx) : `<span class="good">${T('مجاني', 'Free')}</span>`}</div>`);
  if (q.mode === 'delivery') rows.push(`<div class="sum"><span>${T('رسوم التوصيل', 'Delivery fee')}</span>${money2(bd.shipEx)}</div>`);
  rows.push(`<div class="sum"><span>${T('ضريبة القيمة المضافة (%15)', 'VAT (15%)')}</span>${money2(bd.vat)}</div>`);
  rows.push(`<div class="sum"><span>${T('خصم', 'Discount')}</span><span class="good">${bd.discEx ? minus(bd.discEx) : `<span class="amt"><span class="ltr">-0</span>${SARSVG}</span>`}</span></div>`);
  rows.push(`<div class="sum tot"><span>${T('الإجمالي', 'Total')}</span>${money2(q.total)}</div>`);
  if (q.bal) rows.push(`<div class="sum"><span>${T('من رصيد المحفظة', 'From wallet')}</span><span class="good">${minus(q.bal)}</span></div><div class="sum"><span>${T('المتبقي للدفع', 'Left to pay')}</span>${money2(q.pay)}</div>`);
  if (q.ptsCost) rows.push(`<div class="sum"><span>${T('نقاط مستبدلة', 'Points redeemed')}</span><b class="amt">${num(q.ptsCost)}</b></div>`);
  const foot = q.pay > 0 && co.pay === 'apple'
    ? `<button class="btn apple" data-a="placeOrder">Buy with Apple Pay</button>`
    : `<button class="btn split" data-a="placeOrder"><span>${q.pay > 0 ? T('إتمام الدفع', 'Pay now') : T('تأكيد الطلب', 'Place order')}</span>${q.pay > 0 ? `<span>${money2(q.pay)}</span>` : ''}</button>`;
  return hdr(title) + `<div class="scroll pad" data-sk="pg-${i}">
    <h3 class="sh" style="margin-top:8px">${T('طريقة إستلام الطلب', 'How to receive your order')}</h3>${pickRow}${shipRow}${offRows}
    ${offHere.length ? `<div class="hint warn" style="margin:12px 0 0">${T(`غير متوفر في ${L(b)}: ${offHere.map(l => L(l.p)).join('، ')}. غيّر الفرع أو احذفه من السلة.`, `Not available at ${L(b)}: ${offHere.map(l => L(l.p)).join(', ')}. Change the branch or take it out of the cart.`)}</div>` : ''}
    <div class="codebox" style="margin-top:14px"><div class="cin">${ic('tag', 20)}<input class="inp" data-bind="co.code" value="${esc(co.code)}" placeholder="${T('كود الخصم', 'Discount code')}" data-enter="applyCode" autocapitalize="characters" autocomplete="off"></div><button class="btn sm" data-a="applyCode">${T('تطبيق', 'Apply')}</button></div>
    ${co.codeOk ? `<small style="display:block;color:var(--green);padding:6px 4px;font-weight:700">${T(`تم تطبيق خصم ${(SRV.codes[co.code] || {pct:10}).pct}%`, `${(SRV.codes[co.code] || {pct:10}).pct}% discount applied`)}</small>` : (co.codeErr ? `<div class="err" style="padding:6px 4px 0">${co.codeErr}</div>` : '')}
    <h3 class="sh">${T('ملخص الطلب', 'Order summary')}</h3><div class="card">${rows.join('')}</div>
    ${S.bal > 0 ? `<button class="opt chk ${co.useBal ? 'on' : ''}" data-a="useBal" style="margin-top:12px"><span class="mk">${co.useBal ? ic('check', 14) : ''}</span>${ic('wallet', 22)}<span class="grow">${T('إستخدام رصيد المحفظة', 'Use wallet balance')}</span>${money2(S.bal)}</button>` : ''}
    ${q.pay > 0 ? `<div style="margin-top:12px">${payRows(co.pay, 'payM')}</div>` : `<div class="hint" style="margin:12px 0 0">${T('لا يوجد مبلغ مستحق، الطلب مغطى بالكامل.', 'Nothing to pay. This order is fully covered.')}</div>`}
    <div style="height:14px"></div></div>
    <div class="foot">${foot}</div>`;
}

/* pickup now or at a time later today (within the branch hours) */
function pickTimeHTML(co, b) {
  const slots = pickSlots(b), later = !!co.pick;
  const sel = later ? `<div class="field" style="margin:10px 0 0"><label for="pkt">${T('وقت الاستلام', 'Pickup time')}</label><select id="pkt" class="inp" data-bind="co.pickx" data-on="pickSet">${slots.map(t => `<option value="${t}" ${t === co.pick ? 'selected' : ''}>${clockAt(t)}</option>`).join('')}</select></div>` : '';
  return `<h4 class="sh" style="margin-top:14px">${T('متى تستلم طلبك؟', 'When will you pick it up?')}</h4><div class="chips"><button class="chip ${later ? '' : 'on'}" data-a="pickMode" data-id="now">${ic('timer', 18)}${T('في أقرب وقت', 'As soon as possible')}</button><button class="chip ${later ? 'on' : ''}" data-a="pickMode" data-id="later" ${slots.length ? '' : 'disabled'}>${ic('clock', 18)}${T('وقت لاحق اليوم', 'Later today')}</button></div>${slots.length ? '' : `<small class="grey" style="display:block;margin-top:6px">${T('لا توجد أوقات لاحقة متاحة اليوم في هذا الفرع', 'No later times left today at this branch')}</small>`}${sel}`;
}
const pickRowHTML = o => o.mode === 'pickup' ? `<div class="kv"><span>${T('وقت الاستلام', 'Pickup time')}</span><b>${o.pick ? clockAt(o.pick) : T('في أقرب وقت', 'As soon as possible')}</b></div>` : '';

function pgSuccess(i, pg) {
  const o = ORD(pg.id); if (!o) return hdr('');
  const b = BR[o.branch];
  return `<div class="scroll pad pb" data-sk="pg-${i}"><div class="success"><div class="ok">${ic('check', 44)}</div><h2>${T('تم إستلام طلبك بنجاح', 'We received your order')}</h2><p class="grey">${o.mode === 'ship' ? T('سنقوم بتجهيز طلبك وشحنه قريبًا.', 'We will pack and ship your order soon.') : o.mode === 'delivery' ? T('أرسلنا طلبك إلى الفرع، وسيوصله لك مندوبنا إلى عنوانك.', 'We sent your order to the branch. Our driver will bring it to your address.') : T('أرسلنا طلبك إلى الفرع، وسنخبرك عندما يبدأ الموظف بتحضيره.', 'We sent your order to the branch. We will tell you when the staff start preparing it.')}</p>
    ${o.mode !== 'ship' ? `<div class="code" style="align-self:stretch">${o.code}</div><small class="grey">${o.mode === 'delivery' ? T('أظهر هذا الرمز للمندوب عند الإستلام', 'Show this code to the driver when you receive it') : T('أظهر هذا الرمز للموظف عند الإستلام', 'Show this code to the staff when you collect')}</small>` : ''}
    <div class="card" style="align-self:stretch;margin-top:10px;text-align:start"><div class="kv"><span>${T('رقم الطلب', 'Order number')}</span><b>${o.no}</b></div>${o.mode === 'pickup' ? `<div class="kv"><span>${T('الفرع', 'Branch')}</span><b>${esc(L(b))}</b></div>${pickRowHTML(o)}` : o.mode === 'delivery' ? `<div class="kv"><span>${T('التوصيل إلى', 'Delivering to')}</span><span style="text-align:end">${esc(o.addr.city)}، ${esc(o.addr.street)}</span></div>` : `<div class="kv"><span>${T('الشحن عبر', 'Shipping with')}</span><b>${esc(o.carrier)}</b></div>`}<div class="kv"><span>${T('الإجمالي', 'Total')}</span><b>${money2(o.total)}</b></div><div class="kv"><span>${T('النقاط المكتسبة', 'Points earned')}</span><b class="ltr">+${num(o.earn)}</b></div></div></div>
    ${pushCard(true)}</div>
    <div class="foot"><button class="btn" data-a="trackOrder" data-id="${o.id}">${T('تتبع الطلب', 'Track order')}</button><button class="btn line" data-a="home">${T('الرئيسية', 'Home')}</button></div>`;
}

function pgOrderRej(o, i) {
  const items = o.items.map(it => `<div class="kv"><span><span class="ltr">x${it.qty}</span> ${esc(itemName(it))}</span><span>${it.rw || it.gift ? '—' : money2(it.unit * it.qty)}</span></div>`).join('');
  return hdr(`${T('طلب', 'Order')} ${o.no}`) + `<div class="scroll pad pb" data-sk="pg-${i}">
    <div class="sum"><span class="grey">${dLong(o.ts)}</span>${stChip(o)}</div>
    <div class="card" style="margin:12px 0;text-align:center"><div class="rjic">${ic('x', 30)}</div><h3 style="margin:8px 0 4px">${o.rej.by === 'cust' ? T('ألغيت هذا الطلب', 'You cancelled this order') : T('تعذّر تنفيذ طلبك', 'We could not prepare your order')}</h3>${o.rej.by === 'cust' ? '' : `<p style="font-weight:700">${esc(L(o.rej.why))}</p>`}
      <p class="grey" style="margin-top:8px;line-height:1.6">${T('سيُرد المبلغ المدفوع إلى وسيلة الدفع، وتعود إلى حسابك النقاط والرصيد المستخدمان.', 'Your payment will be refunded, and any points or balance you used go back to your account.')}</p></div>
    <div class="card"><h3 style="margin-bottom:6px">${T('تفاصيل الطلب', 'Order details')}</h3>${items}<div class="sum tot"><span>${T('الإجمالي', 'Total')}</span>${money2(o.total)}</div></div></div>
    <div class="foot"><button class="btn" data-a="reorder" data-id="${o.id}">${T('إعادة الطلب', 'Order again')}</button></div>`;
}

/* the driver on his way: a small map with him and the delivery address (his position comes with every sync) */
const MOTO = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M9 17h6l-3-7H8M13 6h3l2 4 0 4"/></svg>';
function trackHTML(o) {
  const p = TRK[o.id], a = o.addr || {};
  if (!p) return `<div class="card trk-w"><b>${T('المندوب في الطريق إليك', 'Your driver is on the way')}</b><small class="grey">${T('يظهر موقعه هنا على الخريطة عندما يشارك تطبيق المندوب موقعه.', 'His position shows here on the map once the driver app shares it.')}</small></div>`;
  const pts = [{lat:p.lat, lng:p.lng, cls:'drv', html:MOTO}];
  if (a.lat != null && a.lng != null) pts.push({lat:a.lat, lng:a.lng, cls:'dst', html:ic('pin', 16)});
  const secs = Math.max(0, Math.round((Date.now() + (SRV.skew || 0) - p.ts) / 1000));
  const w = Math.min(window.innerWidth || 390, 430) - 40;
  const way = p.way, line = way && way.pts ? way.pts : null;
  const eta = way && !o.arr ? `<div class="trk-e"><b>${T(`يصلك خلال ${way.min} ${way.min === 1 ? 'دقيقة' : way.min === 2 ? 'دقيقتين' : way.min <= 10 ? 'دقائق' : 'دقيقة'}`, `Arrives in ${way.min} min`)}</b><span>${way.est ? T('تقريبًا', 'about') : ''} ${T(`${way.km} كم`, `${way.km} km`)}</span></div>` : '';
  return `<div class="trk">${mapHTML(pts, w, 230, T('موقع المندوب على الخريطة', 'Where your driver is on the map'), line)}${eta}
    <div class="trk-l"><span class="live"></span><b>${o.arr ? T('المندوب عند موقعك', 'Your driver is at your place') : T('المندوب في الطريق إليك', 'Your driver is on the way')}</b><small>${secs < 60 ? T('الآن', 'just now') : T(`قبل ${Math.round(secs / 60)} د`, `${Math.round(secs / 60)} min ago`)}</small></div></div>`;
}
/* the driver: his name, and while the order is on its way his number (call or WhatsApp), if he gave one */
function drvCardHTML(o) {
  const ph = o.st === 2 && /^5\d{8}$/.test(o.dphone || '') ? o.dphone : '';
  return `<div class="card drvc" style="margin:14px 0"><div class="kv"><span>${T('المندوب', 'Your driver')}</span><b>${esc(o.driver.name)}</b></div>${ph ? `<div class="drv-act"><a class="btn line sm" href="tel:+966${ph}">${ic('phone', 18)}${T('اتصال', 'Call')}</a><a class="btn line sm" href="https://wa.me/966${ph}" target="_blank" rel="noopener noreferrer">${ic('chat', 18)}${T('واتساب', 'WhatsApp')}</a></div><small class="grey ltr" style="display:block;text-align:center;margin-top:6px">${phoneFmt(ph)}</small>` : ''}</div>`;
}
function pgOrder(i, pg) {
  const o = ORD(pg.id); if (!o) return hdr(T('الطلب', 'Order')) + '<div class="scroll"></div>';
  if (o.rej) return pgOrderRej(o, i);
  const st = stageOf(o), list = STAGES[o.mode], b = BR[o.branch], del = o.mode === 'delivery';
  const tl = `<ul class="tl">${list.map((s, k) => `<li class="${k <= st ? 'on' : ''}"><span class="dot">${k <= st ? ic('check', 12) : ''}</span><span>${esc(stageLabel(o, k))}</span></li>`).join('')}</ul>`;
  const codeBox = o.mode !== 'ship'
    ? `<div class="card" style="margin:14px 0"><small class="grey">${del ? T('رمز الإستلام من المندوب', 'Code for the driver') : T('رمز الإستلام', 'Pickup code')}</small><div class="code">${o.code}</div><small class="grey">${o.gift ? T('أرسله للمستلم ليعطيه للمندوب', 'Send it to the recipient to give to the driver') : del ? T('أظهره للمندوب عند الإستلام', 'Show it to the driver when you receive the order') : T('أظهره للموظف عند الإستلام', 'Show it to the staff when you collect')}</small></div>${del && o.driver && !o.fin ? drvCardHTML(o) : ''}`
    : `<div class="card" style="margin:14px 0"><div class="kv"><span>${T('رقم الشحنة', 'Tracking number')}</span><b class="ltr">${o.code}</b></div><div class="kv"><span>${T('شركة الشحن', 'Carrier')}</span><b>${esc(o.carrier)}</b></div></div>`;
  const items = o.items.map(it => { return `<div class="kv"><span><span class="ltr">x${it.qty}</span> ${esc(itemName(it))}${it.rw ? ' · ' + T('مكافأة', 'Reward') : ''}${it.gift ? ' · ' + T('هدية', 'Gift') : ''}<br><small class="grey">${esc(selText(it.sel))}</small></span><span>${it.rw || it.gift ? '—' : money2(it.unit * it.qty)}</span></div>`; }).join('');
  const where = o.mode === 'ship' ? `<div class="kv"><span>${T('العنوان', 'Address')}</span><span style="text-align:end">${esc(o.addr.city)}، ${esc(o.addr.street)}</span></div>`
    : `<div class="kv"><span>${T('الفرع', 'Branch')}</span><span style="text-align:end">${esc(L(b))}</span></div>${del ? `<div class="kv"><span>${T('العنوان', 'Address')}</span><span style="text-align:end">${esc(o.addr.city)}، ${esc(o.addr.street)}</span></div>` : ''}${o.serve ? `<div class="kv"><span>${T('خيارات التقديم', 'Serving')}</span><span>${o.serve === 'take' ? T('تيك أواي', 'Takeaway') : T('داخل الفرع', 'Dine in')}</span></div>` : ''}${pickRowHTML(o)}`;
  const trk = (del && o.driver && !o.fin && o.st === 2 && o.arr ? `<div class="arrv">${ic('pin', 22)}<span class="grow"><b>${T('المندوب وصل إلى موقعك', 'Your driver is here')}</b><small>${T('جهّز رمز الإستلام وأظهره له', 'Have your code ready to show him')}</small></span></div>` : '')
    + (del && o.driver && !o.fin && o.st === 2 ? trackHTML(o) : '');
  const gft = o.gift ? `<div class="card" style="margin:14px 0">${ic('gift', 22)}<div class="kv" style="padding-top:6px"><span>${T('هدية إلى', 'Gift to')}</span><b>${esc(o.gift.name || '')} <span class="ltr">${phoneFmt(o.gift.phone)}</span></b></div>${o.gift.msg ? `<div class="bubble">${esc(o.gift.msg)}</div>` : ''}</div>` : '';
  const foot = o.mode === 'pickup' && st === 2 ? `<div class="foot"><button class="btn" data-a="confirmPickup" data-id="${o.id}">${T('تأكيد الإستلام', 'Confirm pickup')}</button></div>`
    : st === 3 ? `<div class="foot"><button class="btn" data-a="reorder" data-id="${o.id}">${T('إعادة الطلب', 'Order again')}</button></div>`
    : o.st === 0 && !o.fin ? `<div class="foot"><button class="btn danger" data-a="cancelOrder" data-id="${o.id}">${ic('x', 18)}${T('إلغاء الطلب', 'Cancel order')}</button></div>` : '';
  const cancelNote = o.st === 0 && !o.fin ? `<p class="grey" style="margin:10px 2px 0;font-size:13px">${T('يمكنك إلغاء الطلب قبل أن يقبله الفرع.', 'You can cancel the order until the branch accepts it.')}</p>` : '';
  return hdr(`${T('طلب', 'Order')} ${o.no}`) + `<div class="scroll pad pb" data-sk="pg-${i}">
    <div class="sum"><span class="grey">${dLong(o.ts)}</span>${stChip(o)}</div>${tl}${cancelNote}${o.fin ? orderRateHTML(o) : ''}${trk}${gft}${codeBox}
    <div class="card"><h3 style="margin-bottom:6px">${T('تفاصيل الطلب', 'Order details')}</h3>${where}<div class="kv"><span>${T('طريقة الدفع', 'Payment')}</span><span>${esc(payLabel(o.payM))}</span></div>${items}
      <div class="sum" style="padding-top:12px"><span>${T('المجموع', 'Subtotal')}</span>${money2(o.sub)}</div>
      ${o.ship ? `<div class="sum"><span>${del ? T('رسوم التوصيل', 'Delivery fee') : T('الشحن', 'Shipping')}</span>${money2(o.ship)}</div>` : ''}
      ${o.disc ? `<div class="sum"><span>${T('خصم', 'Discount')}</span><span class="good">${minus(o.disc)}</span></div>` : ''}
      <div class="sum tot"><span>${T('الإجمالي', 'Total')}</span>${money2(o.total)}</div>
      <div class="sum"><small>${T('شامل ضريبة القيمة المضافة (%15)', 'Includes 15% VAT')} ${fmt2(o.vat)}</small><small>${T('النقاط', 'Points')} <span class="ltr">+${num(o.earn)}</span></small></div>
      ${o.inv ? `<button class="btn line sm" style="margin-top:12px" data-a="push" data-p="invoice" data-id="${o.id}">${ic('receipt', 18)}${T('الفاتورة الضريبية', 'Tax invoice')}</button>` : ''}</div>
    </div>` + foot;
}

/* stars and a few words once the order is done (once; the management reads them) */
const STARW = [null, {ar:'سيئ', en:'Poor'}, {ar:'مقبول', en:'Fair'}, {ar:'جيد', en:'Good'}, {ar:'جيد جدًا', en:'Very good'}, {ar:'ممتاز', en:'Excellent'}];
function orderRateHTML(o) {
  const stars = (n, act) => `<div class="stars" role="${act ? 'radiogroup' : 'img'}" aria-label="${act ? T('تقييمك', 'Your rating') : T(`${n} من 5`, `${n} of 5`)}">${[1, 2, 3, 4, 5].map(k => act
    ? `<button class="${k <= n ? 'on' : ''}" data-a="rateStar" data-id="${o.id}" data-s="${k}" role="radio" aria-checked="${k === n}" aria-label="${k}">${ic('star', 30)}</button>`
    : `<i class="${k <= n ? 'on' : ''}">${ic('star', 22)}</i>`).join('')}</div>`;
  if (o.rate) return `<div class="card rate done"><b>${T('تقييمك', 'Your rating')}</b>${stars(o.rate.s)}${o.rate.c ? `<p class="grey">${esc(o.rate.c)}</p>` : ''}</div>`;
  const r = UI.rate.id === o.id ? UI.rate : {s:0, c:''};
  const words = (STARW[r.s] && L(STARW[r.s])) || '';
  return `<div class="card rate"><b>${T('كيف كانت تجربتك؟', 'How was it?')}</b>${stars(r.s, true)}<small class="grey rw-w">${esc(words) || T('اختر من نجمة إلى خمس', 'Choose one to five stars')}</small>
    ${r.s ? `<textarea class="inp" data-bind="rate.c" maxlength="300" rows="2" placeholder="${T('أضف ملاحظة (إختياري)', 'Add a note (optional)')}">${esc(r.c)}</textarea><button class="btn sm" data-a="rateSend" data-id="${o.id}" style="margin-top:10px">${T('إرسال التقييم', 'Send rating')}</button>` : ''}</div>`;
}

const ledgerRow = e => `<div class="lg-row"><span><b>${esc(txt(e.label))}</b><small class="ltr">${dISO(e.ts)}</small></span><span class="pv ${e.pts > 0 ? '' : 'minusv'}"><span class="ltr">${e.pts > 0 ? '+' : '-'}${num(Math.round(Math.abs(e.pts)))}</span>${ic('star', 18)}</span></div>`;
function pgPoints(i) {
  return hdr(T('نقاطي', 'My points')) + `<div class="scroll pb" data-sk="pg-${i}">
    <div class="ptscard">${PAT}<span><span class="num">${num(S.pts)}</span><small>${T('إجمالي النقاط', 'Total points')}</small></span><span class="starc">${ic('star', 28)}</span></div>
    <div class="prow"><button class="btn" data-a="push" data-p="rewards">${T('إستبدل', 'Redeem')}</button><button class="btn line" data-a="push" data-p="hist">${ic('clock', 18)}${T('العمليات السابقة', 'Previous transactions')}</button></div>
    <h4 class="sh" style="margin:6px 20px 0">${T('آخر العمليات', 'Latest')}</h4>
    <div style="padding-bottom:12px">${S.ledger.length ? S.ledger.slice(0, 5).map(ledgerRow).join('') + (S.ledger.length > 5 ? `<button class="btn text" data-a="push" data-p="hist">${T(`عرض كل العمليات (${S.ledger.length})`, `See all (${S.ledger.length})`)}</button>` : '') : emptyHTML('tote', '#C8965A', T('لا توجد عمليات سابقة', 'No previous transactions'))}</div></div>`;
}
/* every points movement: all, earned or spent */
function pgHist(i) {
  const f = UI.hf || 'all', list = S.ledger.filter(e => f === 'all' || (f === 'earn' ? e.pts > 0 : e.pts < 0));
  const tabs = [['all', T('الكل', 'All')], ['earn', T('المكتسبة', 'Earned')], ['spend', T('المستبدلة', 'Spent')]];
  const tot = k => num(Math.round(S.ledger.filter(e => k === 'earn' ? e.pts > 0 : e.pts < 0).reduce((a, e) => a + Math.abs(e.pts), 0)));
  return hdr(T('العمليات السابقة', 'Previous transactions')) + `<div class="utabs">${tabs.map(([id, l]) => `<button class="${f === id ? 'on' : ''}" data-a="histF" data-id="${id}">${l}</button>`).join('')}</div>
    <div class="scroll pb" data-sk="pg-${i}"><div class="hsum"><span>${T('مكتسبة', 'Earned')} <b class="ltr">+${tot('earn')}</b></span><span>${T('مستبدلة', 'Spent')} <b class="ltr">-${tot('spend')}</b></span><span>${T('الرصيد', 'Balance')} <b class="ltr">${num(S.pts)}</b></span></div>
    ${list.length ? list.map(ledgerRow).join('') : emptyHTML('tote', '#C8965A', T('لا توجد عمليات هنا', 'Nothing here yet'))}</div>`;
}
/* the wallet: the customer adds an amount (a chip or typed), pays, and the credit is there for any order */
const walRow = e => `<div class="lg-row"><span><b>${esc(txt(e.label))}</b><small class="ltr">${dISO(e.ts)}</small></span><span class="pv ${e.amt > 0 ? '' : 'minusv'}"><span class="ltr">${e.amt > 0 ? '+' : '-'}${fmt2(Math.abs(e.amt))}</span>${SARSVG}</span></div>`;
function pgTopup(i) {
  const t = UI.tp, ok = NEED.tpamt();
  return hdr(T('شحن المحفظة', 'Top up wallet')) + `<div class="scroll pad pb" data-sk="pg-${i}">
    <div class="wal" style="margin:0 0 16px">${ic('wallet', 24)}<span class="grow"><b>${T('رصيد المحفظة', 'Wallet balance')}</b></span><b>${money2(S.bal)}</b></div>
    <h4 class="sh">${T('المبلغ', 'Amount')}</h4>
    <div class="amts">${[25, 50, 100, 200].map(a => `<button class="chip ${t.amt === a && !t.amtx ? 'on' : ''}" data-a="tpAmt" data-id="${a}">${a}${SARSVG}</button>`).join('')}</div>
    <div class="field" style="margin-top:16px"><label for="tpamtx">${T('أو اكتب المبلغ', 'Or type the amount')}</label><input id="tpamtx" class="inp ltr" type="text" inputmode="numeric" maxlength="4" autocomplete="off" data-bind="tp.amtx" data-fmt="digits" data-on="tpAmtX" value="${esc(t.amtx)}" placeholder="${T(`من ${GIFT_MIN} إلى ${GIFT_MAX} ريال`, `${GIFT_MIN} to ${GIFT_MAX} SAR`)}"></div>
    <p class="grey" style="margin:-4px 2px 14px">${T('الرصيد يُستخدم في أي طلب من «إستخدام رصيد المحفظة» عند الدفع.', 'Use the credit on any order with “Use wallet balance” at checkout.')}</p>
    ${payRows(t.pay, 'tpPayM')}
    ${S.wal.length ? `<h4 class="sh" style="margin-top:22px">${T('حركات المحفظة', 'Wallet activity')}</h4>${S.wal.slice(0, 12).map(walRow).join('')}` : ''}</div>
    <div class="foot">${t.pay === 'apple' ? `<button class="btn apple" data-a="tpPay" ${needAttr('tpamt')}>Top up with Apple Pay</button>` : `<button class="btn split" data-a="tpPay" ${needAttr('tpamt')}><span>${T('إتمام الدفع', 'Pay now')}</span><span id="tpsum">${ok ? money2(t.amt) : ''}</span></button>`}</div>`;
}
const rwRow = (r, avail) => {
  const p = r.pid ? PROD[r.pid] : null, ok = avail >= r.pts;
  return `<div class="rw">${p ? th(p) : `<span class="th" style="background:${tint('#ECB444')}">${art('box', '#ECB444')}</span>`}<div class="grow"><b>${esc(L(r))}</b><div class="cost">${ic('star', 16)}<span class="amt">${num(r.pts)}</span></div></div><button class="btn sm" data-a="redeem" data-id="${r.id}" ${ok ? '' : 'disabled'}>${T('إستبدل', 'Redeem')}</button></div>`;
};
/* ---------- membership: the three tiers like the reference cards, then what each gives, how points are earned and redeemed,
   the rewards and their terms. The tier and its points come from the server; redeeming is the same as on the points pages. */
const liveRewards = () => REWARDS.filter(r => !r.pid || liveP(r.pid)).sort((a, b) => a.pts - b.pts);
const MPAT = (() => {
  const t = 215 / 3, q = (cx, cy, x0, y0, x1, y1, n) => `<path d="M${cx} ${cy}L${x0} ${y0}A${t} ${t} 0 0 1 ${x1} ${y1}Z" style="fill:var(--q${n})"/>`;
  return `<svg class="mpat" viewBox="0 0 ${2 * t} 215" aria-hidden="true">`
    + q(t, t, t, 0, 2 * t, t, 1) + q(t, 2 * t, 0, 2 * t, t, t, 2) + q(t, t, 2 * t, t, t, 2 * t, 3) + q(0, 3 * t, 0, 2 * t, t, 3 * t, 4) + q(t, 3 * t, t, 2 * t, 2 * t, 3 * t, 5) + '</svg>';
})();
const LOCK = '<svg class="mlock" viewBox="0 0 24 24" aria-hidden="true"><path d="M7.5 10V7.6a4.5 4.5 0 0 1 9 0V10" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><rect x="4.5" y="9.5" width="15" height="12" rx="3.2" fill="currentColor"/><circle cx="12" cy="15.4" r="1.7" fill="#fff" opacity=".9"/></svg>';
const rateHTML = t => `${num(t.per10)} ${ptsWord(t.per10)} ${T('لكل', 'per')} ${money(10)}`;
const tierOpen = t => S.session ? tierPts() >= t.min : t.min === 0;
function tierCard(t, i, page) {
  const list = SRV.tiers, nx = list[i + 1], tp = tierPts(), cur = S.session && myTier().id === t.id, open = tierOpen(t);
  let low = `<span class="mrow"><b class="mname">${esc(L(TIER_NAME[t.id]))}</b>${page && cur ? `<span class="mcur">${T('عضويتك', 'Yours')}</span>` : ''}</span>`;
  if (page && !S.session && i === 0) low += `<span class="mprog">${T('سجّل دخولك لتبدأ بجمع النقاط', 'Log in to start collecting points')}</span>`;
  else if (page && cur && nx) low += `<span class="mprog"><b class="ltr">${num(tp)}/${num(nx.min)}</b> ${T('متبقي', 'left')} ${esc(L(TIER_NAME[nx.id].to))}</span>`
    + `<span class="mbar" role="progressbar" aria-label="${T('التقدم نحو المستوى التالي', 'Progress to the next tier')}" aria-valuemin="0" aria-valuemax="${nx.min}" aria-valuenow="${tp}"><i style="width:${Math.max(3, Math.min(100, Math.round(100 * tp / nx.min)))}%"></i></span>`;
  else if (page && cur) low += `<span class="mprog">${T('أعلى مستوى في واي!', 'The top tier at Why!')}</span>`;
  else if (page && !open) low += `<span class="mprog">${T(`تفتح عند ${num(t.min)} نقطة خلال ${SRV.tdays} يوم`, `Opens at ${num(t.min)} points in ${SRV.tdays} days`)}</span>`;
  const info = page ? `<button class="minfo" data-a="tierInfo" data-id="${t.id}">${T('معلومات', 'Info')}${ic('chev', 16, 'flip')}</button>` : '';
  const badge = open ? `<span class="mmk">${LOGOM(28)}</span>` : `<span class="mmk off">${LOGOM(28)}${LOCK}</span>`;
  return `<div class="mcard t-${t.id} ${open ? '' : 'locked'}">${MPAT}${badge}${info}<div class="mbot">${low}</div></div>`;
}
const mbox = (label, val) => `<div class="mbox"><small>${label}</small><b>${val}</b></div>`;
const mli = (lead, html) => `<li class="mli">${lead}<span>${html}</span></li>`;
function pgMember(i) {
  const list = SRV.tiers, me = myTier(), days = SRV.tdays, pts = S.session ? S.pts : 0, avail = S.session ? S.pts - cartPts() : 0, live = liveRewards();
  const n = k => `<span class="mno">${k}</span>`, dot = '<span class="mdot"></span>', icn = k => `<span class="mic">${ic(k, 18)}</span>`;
  const tierRows = list.map(t => `<div class="kv"><span>${esc(L(TIER_NAME[t.id]))}</span><b>${rateHTML(t)}${t.min ? ` · ${T(`من ${num(t.min)} نقطة`, `from ${num(t.min)} points`)}` : ''}</b></div>`).join('');
  return hdr(T('العضوية', 'Membership')) + `<div class="scroll pb mpage" data-sk="pg-${i}">
    <div class="mcards">${list.map((t, k) => tierCard(t, k, true)).join('')}</div>
    ${mbox(T('رصيد النقاط الحالي', 'Current points balance'), `${num(pts)} ${T('نقطة', 'points')}`)}
    ${mbox(T(`إجمالي النقاط خلال ${days} يوم`, `Points in the last ${days} days`), num(tierPts()))}
    ${mbox(T('النقاط', 'Points'), rateHTML(me))}
    ${S.session
      ? `<div class="prow"><button class="btn line" data-a="push" data-p="points">${ic('clock', 18)}${T('سجل النقاط', 'Points history')}</button></div>`
      : `<div class="prow"><button class="btn" data-a="login">${T('تسجيل الدخول', 'Log in')}</button><button class="btn line" data-a="signup">${T('إنشاء حساب', 'Create account')}</button></div>`}
    <section class="msec"><h2>${T('عن العضوية', 'About the membership')}</h2>
      <div class="kv"><span>${T('عضويتك', 'Your membership')}</span><b>${tierName(me)}</b></div>
      <div class="kv"><span>${T('نوع العضوية', 'Type')}</span><b>${T('مجانية لكل عملاء واي! المسجلين', 'Free for every registered Why! customer')}</b></div></section>
    <section class="msec"><h2>${T('مستويات العضوية', 'Membership tiers')}</h2>${tierRows}
      <p class="mnote">${T(`المستوى يتحدد حسب نقاطك خلال آخر ${days} يوم: نقاط طلباتك ونقاط الهدية من واي!. يرتفع تلقائيًا عند الوصول للهدف، وينزل إذا قلّت النقاط.`, `Your tier follows your points of the last ${days} days: points from your orders and bonus points from Why!. It goes up by itself when you reach the goal, and down if the points drop.`)}</p></section>
    <section class="msec"><h2>${T('مميزات العضوية', 'Membership benefits')}</h2><ul class="mlist">
      ${mli(icn('star'), T(`نقاط عن كل ريال تدفعه في طلباتك وهداياك، وتزيد مع مستواك حتى ${rateHTML(list[list.length - 1])}.`, `Points for every riyal you pay on your orders and gifts, rising with your tier up to ${rateHTML(list[list.length - 1])}.`))}
      ${mli(icn('gift'), T(`${num(WELCOME_PTS)} نقطة هدية عند التسجيل لأول مرة.`, `${num(WELCOME_PTS)} points as a gift when you first register.`))}
      ${mli(icn('cup'), T('استبدل نقاطك بمشروبات وحلويات من قائمة المكافآت.', 'Redeem your points for drinks and sweets from the rewards list.'))}
      ${mli(icn('wallet'), T('أو حوّلها إلى رصيد في محفظتك تستخدمه في طلباتك.', 'Or turn them into wallet credit for your orders.'))}
      ${mli(icn('bell'), T('قد تصلك نقاط هدية من واي! في المناسبات والعروض.', 'Why! may send you bonus points on occasions and offers.'))}</ul></section>
    <section class="msec"><h2>${T('طريقة جمع النقاط', 'How to earn points')}</h2><ol class="mlist">
      ${mli(n(1), T('اطلب من التطبيق: استلام من الفرع أو توصيل أو شحن.', 'Order in the app: pickup, delivery or shipping.'))}
      ${mli(n(2), T(`تُحسب لك النقاط حسب مستواك عن كل ريال كامل تدفعه (الآن ${rateHTML(me)})، والمبلغ المدفوع من رصيد المحفظة لا تُحسب عليه نقاط.`, `You get points for every full riyal you pay, by your tier (now ${rateHTML(me)}); the part paid from your wallet balance earns no points.`))}
      ${mli(n(3), T('تُضاف النقاط إلى رصيدك فور إرسال الطلب، وتظهر في سجل النقاط.', 'Points are added as soon as you send the order and show in your points history.'))}
      ${mli(n(4), T('وعند إرسال هدية لصديق تكسب نقاطًا على ما دفعت.', 'Sending a gift to a friend also earns points on what you paid.'))}</ol></section>
    <section class="msec"><h2>${T('طريقة استبدال النقاط', 'How to redeem points')}</h2><ol class="mlist">
      ${mli(n(1), T('اختر مكافأة من القائمة التالية واضغط «إستبدل».', 'Choose a reward from the list below and tap Redeem.'))}
      ${mli(n(2), T('المشروبات والحلويات تُضاف إلى سلتك مجانًا، وتُخصم نقاطها عند إتمام الطلب.', 'Drinks and sweets go into your cart for free; their points are deducted when you place the order.'))}
      ${mli(n(3), T('رصيد المحفظة يُضاف فورًا، وتستخدمه عند الدفع في طلباتك القادمة.', 'Wallet credit is added right away; use it at checkout on your next orders.'))}</ol></section>
    <section class="msec mrw"><h2>${T('المكافآت المتاحة', 'Available rewards')}</h2>
      ${live.length ? live.map(r => rwRow(r, avail)).join('') : `<p class="grey">${T('لا توجد مكافآت متاحة حاليًا.', 'No rewards are available right now.')}</p>`}</section>
    <section class="msec"><h2>${T('شروط الاستفادة من المكافآت', 'Reward terms')}</h2><ul class="mlist">
      ${mli(dot, T('يجب أن يكفي رصيدك لقيمة المكافأة، والمكافآت الموجودة في سلتك تُحسب من رصيدك.', 'Your balance must cover the reward; rewards already in your cart count against it.'))}
      ${mli(dot, T('المكافأة متاحة ما دام منتجها متوفرًا في القائمة.', 'A reward is available while its product is on the menu.'))}
      ${mli(dot, T('إذا اعتذر الفرع عن الطلب تعود نقاط المكافأة إلى رصيدك، وتُلغى النقاط المكتسبة من ذلك الطلب.', 'If the branch declines the order, the reward points come back and the points earned from that order are taken off.'))}
      ${mli(dot, T('النقاط غير قابلة للتحويل إلى نقد.', 'Points cannot be exchanged for cash.'))}</ul>
      <button class="mterms" data-a="push" data-p="terms">${T('الشروط والأحكام كاملة', 'Full terms and conditions')}${ic('chev', 16, 'flip')}</button></section>
  </div>`;
}
/* "معلومات" on a card: that tier's card, the points of the last 30 days and its points per 10 SAR (as in the reference) */
function shMember() {
  const t = SRV.tiers.find(x => x.id === UI.sheet.id) || myTier(), days = SRV.tdays;
  return sheetWrap(`<div class="sbody msh" data-sk="sheet">${tierCard(t, SRV.tiers.indexOf(t), false)}
    ${mbox(T(`إجمالي النقاط خلال ${days} يوم`, `Points in the last ${days} days`), num(tierPts()))}
    ${mbox(T('النقاط', 'Points'), rateHTML(t))}
    ${t.min ? mbox(T('تفتح عند', 'Opens at'), T(`${num(t.min)} نقطة خلال ${days} يوم`, `${num(t.min)} points in ${days} days`)) : ''}</div>`, L(TIER_NAME[t.id]));
}
function pgRewards(i) {
  const avail = S.pts - cartPts();
  return hdr(T('إستبدل نقاطك', 'Redeem your points'), `<span class="ptschip">${ic('star', 16)}<b class="amt">${num(avail)}</b></span>`) + `<div class="scroll pb" data-sk="pg-${i}" style="padding-top:2px">${REWARDS.filter(r => !r.pid || liveP(r.pid)).map(r => rwRow(r, avail)).join('')}</div>`;
}

/* notifications on the phone (0.7): turned on here, after the customer asked for them */
function pushCard(short) {
  const st = pushState();
  if (!S.session || st === 'no' || (short && st !== 'off')) return '';
  const body = st === 'on' ? `<small>${T('مفعّلة على هذا الجهاز: يصلك تنبيه عندما يتغير طلبك أو تصلك هدية.', 'On for this device: you hear when your order moves or a gift arrives.')}</small><button class="btn text sm" data-a="pushOff">${T('إيقاف', 'Turn off')}</button>`
    : st === 'denied' ? `<small>${T('الإشعارات مرفوضة لهذا الموقع. فعّلها من إعدادات المتصفح ثم ارجع هنا.', 'Notifications are blocked for this site. Allow them in the browser settings, then come back.')}</small>`
    : st === 'ios' ? `<small>${T('على الآيفون: أضف التطبيق إلى الشاشة الرئيسية (زر المشاركة ← «إضافة إلى الشاشة الرئيسية»)، ثم افتحه من هناك وفعّل الإشعارات.', 'On an iPhone: add the app to the Home Screen (Share → “Add to Home Screen”), open it from there and turn notifications on.')}</small>`
    : `<small>${T('يصلك تنبيه عندما يجهز طلبك أو يخرج مع المندوب، وعندما تصلك هدية، حتى والتطبيق مغلق.', 'Hear when your order is ready or on its way, and when a gift arrives, even with the app closed.')}</small><button class="btn sm" data-a="pushOn">${ic('bell', 16)}${T('تفعيل الإشعارات', 'Turn on notifications')}</button>`;
  return `<div class="card pushc ${st}"><b>${ic(st === 'denied' ? 'x' : 'bell', 18)}${T('إشعارات على جوالك', 'Notifications on your phone')}</b>${body}</div>`;
}
function pgNotifs(i) {
  const list = S.notifs;
  return hdr(T('الإشعارات', 'Notifications')) + `<div class="scroll pad pb" data-sk="pg-${i}">${pushCard()}${list.length ? list.map(n => { const go = noteTarget(n), inner = `<span class="ic-b">${ic(n.ico || 'bell', 20)}</span><div class="grow"><b>${esc(L(n.t))}</b><small>${esc(L(n.b))}</small><small>${ago(n.ts)}</small></div>`;
    return go ? `<button class="notif go ${n.read ? '' : 'unread'}" data-a="noteGo" data-id="${esc(n.id)}">${inner}${ic('chev', 18, 'flip')}</button>` : `<div class="notif ${n.read ? '' : 'unread'}">${inner}</div>`; }).join('') : emptyHTML('bellart', '#C8965A', T('لا يوجد إشعارات حاليا', 'There are no notifications right now'))}</div>`;
}
function pgArticle(i, pg) {
  const n = newsAll().find(x => x.id === pg.id);
  if (!n) return hdr(T('الأخبار', 'News')) + `<div class="scroll">${emptyHTML('tote', '#C8965A', T('لم يعد هذا الخبر موجودًا', 'This news item is no longer here'))}</div>`;
  const body = (S.lang === 'ar' ? n.b.ar : n.b.en) || [];
  return hdr(T('الأخبار', 'News')) + `<div class="scroll pb" data-sk="pg-${i}"><div class="article">${n.vid ? `<video class="cov vid" controls playsinline preload="metadata" ${n.img && /^[0-9a-f]{32}$/.test(n.img.id) ? `poster="/api/img/${n.img.id}"` : ''} src="/api/vid/${n.vid.id}#t=0.1"></video>` : coverHTML(n, 'cov')}<h2>${esc(L(n.t))}</h2><small class="grey ltr">${dNews(n.ts)}</small><div style="height:12px"></div>${(body.length ? body : n.b.ar || []).map(p => `<p>${esc(p)}</p>`).join('')}</div></div>`;
}
function pgMyProfile(i) {
  const u = S.user || {name:'', phone:''};
  return hdr(T('ملفي', 'My profile')) + `<div class="scroll pad pb" data-sk="pg-${i}">
    <div class="prof"><span class="av">${esc((u.name || '?').trim().charAt(0))}</span><div><h2>${esc(u.name)}</h2><span class="grey ltr">${esc(u.phone)}</span></div></div>
    ${fld(T('الاسم', 'Name'), 'f.pname', UI.f.pname, T('الاسم', 'Name'), 'maxlength="30" data-enter="saveName"')}
    <div class="field"><label>${T('رقم الجوال', 'Mobile number')}</label><div class="inp ro ltr">+966 ${esc(u.phone)}</div></div>
    ${u.email ? `<div class="field"><label>${T('البريد الإلكتروني', 'Email')}</label><div class="inp ro ltr">${esc(u.email)}</div></div>` : ''}
    ${u.birth ? `<div class="field"><label>${T('تاريخ الميلاد', 'Date of birth')}</label><div class="inp ro ltr">${esc(u.birth)}</div></div>` : ''}
    ${u.gender ? `<div class="field"><label>${T('الجنس', 'Gender')}</label><div class="inp ro">${u.gender === 'f' ? T('أنثى', 'Female') : T('ذكر', 'Male')}</div></div>` : ''}
    <button class="btn" data-a="saveName" ${needAttr('pname')}>${T('حفظ', 'Save')}</button>
    <button class="btn danger" data-a="deleteAcct" style="margin-top:12px">${ic('trash', 20)}${T('حذف الحساب', 'Delete account')}</button></div>`;
}
function pgContact(i) {
  return hdr(T('تواصل معنا', 'Contact us')) + `<div class="scroll pad pb" data-sk="pg-${i}">
    <h3 class="sh" style="margin-top:6px">${T('طرق التواصل', 'Ways to reach us')}</h3>
    <a class="cl" href="tel:${SITE.phone.replace(/\s/g, '')}">${ic('phone', 24)}<span class="grow"><b>${T('اتصل بنا', 'Call us')}</b><small class="ltr">${SITE.phone}</small></span></a>
    <a class="cl" href="https://wa.me/${SITE.wa}" target="_blank" rel="noopener">${ic('chat', 24)}<span class="grow"><b>${T('واتساب', 'WhatsApp')}</b><small class="ltr">${SITE.phone}</small></span></a>
    <a class="cl" href="mailto:${SITE.email}">${ic('mail', 24)}<span class="grow"><b>${T('البريد الإلكتروني', 'Email')}</b><small class="ltr">${SITE.email}</small></span></a>
    <a class="cl" href="https://whyroasteryco.com" target="_blank" rel="noopener">${ic('globe', 24)}<span class="grow"><b>${T('متجر المحمصة', 'Roastery store')}</b><small class="ltr">whyroasteryco.com</small></span></a>
    <h3 class="sh">${T('الأسئلة الشائعة', 'Frequently asked questions')}</h3>
    ${FAQ.map(f => `<details class="card"><summary>${esc(L(f.q))}${ic('chevdown', 18)}</summary><p>${esc(L(f.a))}</p></details>`).join('')}</div>`;
}
function pgTerms(i) { return hdr(T('الشروط والأحكام', 'Terms and conditions')) + `<div class="scroll pad pb doc" data-sk="pg-${i}">${TERMS.map(t => `<h3>${esc(L(t.h))}</h3><p>${esc(L(t.p))}</p>`).join('')}</div>`; }

const giftDel = () => UI.g.type === 'item' && UI.g.del && deliveryOn();
const giftPrice = g => g.type === 'card' ? g.amt : unitPrice(PROD[g.pid], defSel(PROD[g.pid])) + (giftDel() ? deliveryFee() : 0);
function pgGiftSend(i) {
  const g = UI.g, price = giftPrice(g);
  const steps = `<div class="steps">${[1, 2, 3].map(n => `<i class="${g.step >= n ? 'on' : ''}"></i>`).join('')}</div>`;
  let body = '';
  if (g.step === 1) {
    body = `<div class="utabs" style="margin-bottom:12px"><button class="${g.type === 'item' ? 'on' : ''}" data-a="gType" data-id="item">${T('المنتجات', 'Products')}</button><button class="${g.type === 'card' ? 'on' : ''}" data-a="gType" data-id="card">${T('البطاقات', 'Cards')}</button></div>
      ${g.type === 'item'
        ? `<div class="gopts pad">${giftItems().map(id => { const p = PROD[id]; return `<button class="gopt ${g.pid === id ? 'on' : ''}" data-a="gItem" data-id="${id}"><span class="tl2" style="background:${tileBg(p)}">${pic(p, 'fits')}</span><span>${esc(L(p))}</span><span class="grey">${money(unitPrice(p, defSel(p)))}</span></button>`; }).join('')}</div>`
        : `<div class="pad"><p class="grey" style="margin-bottom:12px">${T('يضاف المبلغ إلى رصيد المستلم ويستخدمه في أي طلب.', 'The amount is added to the recipient’s balance to use on any order.')}</p><div class="amts">${[25, 50, 100, 200].map(a => `<button class="chip ${g.amt === a && !g.amtx ? 'on' : ''}" data-a="gAmt" data-id="${a}">${a}${SARSVG}</button>`).join('')}</div>
          <div class="field" style="margin-top:16px"><label for="gamtx">${T('أو اكتب المبلغ', 'Or type the amount')}</label><input id="gamtx" class="inp ltr" type="text" inputmode="numeric" maxlength="4" autocomplete="off" data-bind="g.amtx" data-fmt="digits" data-on="gAmtX" value="${esc(g.amtx)}" placeholder="${T(`من ${GIFT_MIN} إلى ${GIFT_MAX} ريال`, `${GIFT_MIN} to ${GIFT_MAX} SAR`)}"></div></div>`}`;
  } else if (g.step === 2) {
    body = `<div class="pad" style="padding-top:6px">
      ${phoneField(T('رقم جوال المستلم', 'Recipient mobile number'), 'g.phone', g.phone)}
      ${fld(T('اسم المستلم (إختياري)', 'Recipient name (optional)'), 'g.name', g.name, T('مثال: سارة', 'e.g. Sara'), 'maxlength="30"')}
      <div class="field"><label>${T('رسالتك (إختياري)', 'Your message (optional)')}</label><textarea class="inp" data-bind="g.msg" maxlength="140" placeholder="${T('اكتب رسالة للمستلم', 'Write a message to the recipient')}">${esc(g.msg)}</textarea></div>
      ${g.type === 'item' ? giftDelHTML(g) : ''}
      ${giftDel() ? '' : `<div class="hint" style="margin:0">${T('تظهر الهدية للمستلم في تبويب «الهدايا» عندما يدخل التطبيق برقمه، حتى لو سجّل لاحقًا.', 'The recipient finds it in the Gifts tab when they sign in with this number, even if they sign up later.')}</div>`}</div>`;
  } else {
    body = `<div class="pad" style="padding-top:6px"><div class="card">
      <div class="kv"><span>${T('الهدية', 'Gift')}</span><b>${g.type === 'card' ? T(`بطاقة ${g.amt} ريال`, `${g.amt} SAR card`) : esc(L(PROD[g.pid]))}</b></div>
      <div class="kv"><span>${T('إلى', 'To')}</span><b class="ltr">${phoneFmt(g.phone)}</b></div>
      ${g.name ? `<div class="kv"><span>${T('الاسم', 'Name')}</span><b>${esc(g.name)}</b></div>` : ''}
      ${g.msg ? `<div class="kv"><span>${T('الرسالة', 'Message')}</span><span style="text-align:end">${esc(g.msg)}</span></div>` : ''}
      ${giftDel() ? `<div class="kv"><span>${T('التوصيل إلى', 'Deliver to')}</span><span style="text-align:end">${esc(g.addr.city.trim())}، ${esc(g.addr.street.trim())}</span></div><div class="kv"><span>${T('يُحضَّر من', 'Prepared at')}</span><b>${esc(L(BR[S.branch]))}</b></div><div class="kv"><span>${T('رسوم التوصيل', 'Delivery fee')}</span>${money2(deliveryFee())}</div>` : ''}
      <div class="sum tot"><span>${T('الإجمالي', 'Total')}</span>${money2(price)}</div>
      <div class="sum"><small>${T('شامل ضريبة القيمة المضافة (%15)', 'Includes 15% VAT')}</small><small>${T('تكسب', 'You earn')} ${num(tierEarn(price))} ${T('نقطة', 'pts')}</small></div></div>
      <div style="margin-top:14px">${payRows(g.pay, 'gPayM')}</div></div>`;
  }
  const foot = g.step < 3 ? `<button class="btn" data-a="gNext" ${needAttr(g.step === 2 ? 'gphone' : 'gstep1')}>${T('التالي', 'Next')}</button>`
    : g.pay === 'apple' ? `<button class="btn apple" data-a="gPay">Buy with Apple Pay</button>` : `<button class="btn split" data-a="gPay"><span>${T('إتمام الدفع', 'Pay now')}</span><span>${money2(price)}</span></button>`;
  return hdr(T('أرسل هدية', 'Send a gift')) + steps + `<div class="scroll pb" data-sk="pg-${i}">${body}</div><div class="foot">${foot}</div>`;
}
/* a product gift can be brought to the recipient: the sender chooses, gives the address and pays the delivery fee */
function giftDelHTML(g) {
  const on = deliveryOn(), b = BR[S.branch];
  const yn = `<div class="seg gdel" role="radiogroup" aria-label="${T('مع التوصيل', 'With delivery')}"><button class="${g.del && on ? '' : 'on'}" data-a="gDel" data-id="0" role="radio" aria-checked="${!(g.del && on)}">${T('لا، يستلمها من التطبيق', 'No, they use it in the app')}</button><button class="${g.del && on ? 'on' : ''}" data-a="gDel" data-id="1" role="radio" aria-checked="${g.del && on}" ${on ? '' : 'disabled'}>${T('نعم، وصّلها له', 'Yes, deliver it')}</button></div>`;
  const head = `<h4 class="sh" style="margin-top:18px">${T('مع التوصيل؟', 'With delivery?')}</h4>${yn}`;
  if (!on) return head + `<p class="grey" style="margin:6px 2px 0">${T('التوصيل متوقف مؤقتًا', 'Delivery is paused for now')}</p>`;
  if (!g.del) return head;
  return head + `<p class="grey" style="margin:8px 2px 12px">${T(`يوصلها مندوبنا إلى المستلم · رسوم التوصيل ${fmt(deliveryFee())} ر.س`, `Our driver brings it to the recipient · delivery fee ${fmt(deliveryFee())} SAR`)}</p>
    <div class="kv" style="padding-top:0"><span>${T('يُحضَّر من', 'Prepared at')} <b>${esc(L(b))}</b></span><button class="chg" data-a="sheet" data-k="branch" aria-label="${T('تغيير الفرع', 'Change branch')}">${ic('chevdown', 20)}</button></div>
    ${fld(T('مدينة المستلم', 'Recipient city'), 'g.addr.city', g.addr.city, T('مثال: المدينة المنورة', 'e.g. Madinah'))}${fld(T('الحي والشارع', 'District and street'), 'g.addr.street', g.addr.street, '')}${fld(T('ملاحظات للمندوب (إختياري)', 'Notes for the driver (optional)'), 'g.addr.note', g.addr.note, '')}
    ${pickMap('gift', g.addr, b)}${(() => { const x = deliveryBlock(giftPrice(g) - deliveryFee(), g.addr, b); return x ? `<div class="err" style="padding:8px 2px 0">${esc(x)}</div>` : ''; })()}`;
}
function pgGiftDone(i, pg) {
  const g = S.sent.find(x => x.id === pg.id); if (!g) return hdr('');
  return `<div class="scroll pad pb" data-sk="pg-${i}"><div class="success"><div class="ok">${ic('gift', 40)}</div><h2>${T('تم إرسال الهدية بنجاح', 'Your gift was sent')}</h2><p class="grey">${T('أرسلناها إلى', 'We sent it to')} <span class="ltr">${phoneFmt(g.to)}</span></p>
    <div class="card" style="align-self:stretch;margin-top:10px;text-align:start"><div class="kv"><span>${T('الهدية', 'Gift')}</span><b>${g.kind === 'card' ? T(`بطاقة ${g.amt} ريال`, `${g.amt} SAR card`) : esc(L(PROD[g.pid]))}</b></div><div class="kv"><span>${T('المدفوع', 'Paid')}</span><b>${money2(g.price)}</b></div><div class="kv"><span>${T('النقاط المكتسبة', 'Points earned')}</span><b class="ltr">+${num(g.earn)}</b></div>${g.oid ? `<div class="hint" style="margin:10px 0 0">${T('الهدية في طريقها مع مندوبنا. تابعها من «طلباتي»، وأرسل رمز الاستلام للمستلم ليعطيه للمندوب.', 'Our driver is bringing it. Follow it in My orders, and send the pickup code to the recipient to give to the driver.')}</div>` : ''}</div></div></div>
    <div class="foot"><button class="btn" data-a="giftsBack">${T('الرجوع إلى الهدايا', 'Back to gifts')}</button></div>`;
}

/* the simplified tax invoice of an order, to show at the counter, print or save as a PDF */
function pgInvoice(i, pg) {
  const o = ORD(pg.id); if (!o || !o.inv) return hdr(T('الفاتورة الضريبية', 'Tax invoice')) + '<div class="scroll"></div>';
  return hdr(T('الفاتورة الضريبية', 'Tax invoice')) + `<div class="scroll pad pb" data-sk="pg-${i}"><div class="paper">${invoiceHTML(o)}</div>
    <p class="grey" style="margin:12px 4px 0;font-size:13px;line-height:1.6">${T('امسح الرمز بتطبيق «الفاتورة الإلكترونية» من هيئة الزكاة والضريبة والجمارك للتحقق منها.', 'Scan the code with the ZATCA e-invoice app to check it.')}</p></div>
    <div class="foot"><button class="btn" data-a="printInv" data-id="${o.id}">${ic('receipt', 20)}${T('طباعة أو حفظ PDF', 'Print or save as PDF')}</button></div>`;
}

function pageHTML(pg, i) {
  const top = i === UI.stack.length - 1;
  const fn = {menu:pgMenu, cart:pgCart, checkout:pgCheckout, success:pgSuccess, order:pgOrder, points:pgPoints, member:pgMember, rewards:pgRewards, notifs:pgNotifs, article:pgArticle, myprofile:pgMyProfile, contact:pgContact, terms:pgTerms, giftsend:pgGiftSend, giftdone:pgGiftDone, hist:pgHist, topup:pgTopup, invoice:pgInvoice}[pg.p];
  const inner = fn ? fn(i, pg) : '';
  return `<section class="screen over ${top && UI.fresh.page ? 'enter-push' : ''}">${inner}</section>`;
}

/* ---------- sheets, dialog, overlay ---------- */

function optGroup(g, s, single) {
  const G = OPT[g], chk = G.type === 'check';
  return `<div class="og">${single ? '' : `<h3><span>${L(G)}</span><small>${chk ? T('إختياري', 'Optional') : T('مطلوب', 'Required')}</small></h3>`}${G.items.map(it => {
    const on = chk ? (s.sel[g] || []).includes(it.id) : s.sel[g] === it.id;
    return `<button class="opt ${chk ? 'chk' : ''} ${on ? 'on' : ''}" data-a="opt" data-g="${g}" data-id="${it.id}" role="${chk ? 'checkbox' : 'radio'}" aria-checked="${on}"><span class="mk">${on && chk ? ic('check', 14) : ''}</span><span class="grow">${L(it)}</span>${it.d ? `<span class="d">(+${fmt(it.d)})${SARSVG}</span>` : ''}</button>`;
  }).join('')}</div>`;
}
function shProduct() {
  const s = UI.sheet, p = PROD[s.pid]; if (!p) return '';
  const price = unitPrice(p, s.sel);
  const desc = p.desc && L(p.desc) ? `<p class="pdesc">${esc(L(p.desc))}</p>` : '';
  const cal = p.cal ? `<div class="cal">${ic('flame', 18)}${T(`${p.cal} سعرة حرارية`, `${p.cal} kcal`)}</div>` : (p.sub ? `<div class="cal">${esc(L(p.sub))}</div>` : '');
  const det = p.d ? `<dl class="pdet">${p.d.map(r => `<div><dt>${esc(L(r.k))}</dt><dd>${esc(L(r.v))}</dd></div>`).join('')}</dl>` : '';
  return sheetWrap(`<div class="sbody flush" data-sk="sheet"><div class="phero ${pm(p) ? 'ph' : ''}" style="background:${tileBg(p)}">${pic(p, 'fit')}</div>
    <div class="pin2"><h2 class="pname">${esc(L(p))}</h2>${cal}${desc}${det}${pOpts(p).length ? `<h3 class="sh">${T('الخيارات', 'Options')}</h3>${pOpts(p).map(g => optGroup(g, s, pOpts(p).length === 1)).join('')}` : ''}</div></div>
    <div class="sfoot"><div class="step"><button data-a="sq" data-d="-1" aria-label="${T('أنقص', 'Less')}">${ic('minus', 18)}</button><b>${s.qty}</b><button data-a="sq" data-d="1" aria-label="${T('زد', 'More')}">${ic('plus', 18)}</button></div>
    <button class="btn split" data-a="sadd"><span>${T('إضافة إلى السلة', 'Add to cart')}</span><span>${money2(price * s.qty)}</span></button></div>`, L(p), 'prodsheet');
}
function shBranch() {
  return sheetWrap(`<div class="sbody" data-sk="sheet"><h2 class="sttl">${T('إختر الفرع', 'Choose a branch')}</h2>${BRANCHES.map(b => `<button class="opt ${S.branch === b.id ? 'on' : ''}" data-a="pickBranch" data-id="${b.id}"><span class="mk"></span><span class="grow"><b>${esc(L(b))}</b><small class="grey" style="display:block">${esc(L(b.addr))}</small></span>${openChip(b)}</button>`).join('')}</div>`, T('إختر الفرع', 'Choose a branch'));
}
function shProfile() {
  const rows = [];
  rows.push(miRow('userplus', T('ادعُ أصدقائك', 'Invite your friends'), T('شارك التجربة مع أصدقائك', 'Share the experience with your friends'), 'data-a="invite"'));
  if (S.session) rows.push(miRow('idcard', T('ملفي', 'My profile'), T('معلومات الحساب الخاصة بك', 'Your account information'), 'data-a="go" data-p="myprofile"'));
  if (S.session) rows.push(miRow('wallet', T('المحفظة', 'Wallet'), T(`الرصيد ${fmt2(S.bal)} ر.س · شحن المحفظة`, `Balance ${fmt2(S.bal)} SAR · top up`), 'data-a="go" data-p="topup"'));
  rows.push(miRow('globe', T('اللغة', 'Language'), T('تغيير اللغة', 'Change language'), 'data-a="sheet" data-k="lang"'));
  rows.push(miRow('doc', T('الشروط والأحكام', 'Terms and conditions'), T('سياسة الإستخدام والشروط والأحكام', 'Usage policy and terms and conditions'), 'data-a="go" data-p="terms"'));
  rows.push(miRow('headset', T('تواصل معنا', 'Contact us'), T('الأسئلة الشائعة وطرق التواصل معنا', 'FAQ and ways to reach us'), 'data-a="go" data-p="contact"'));
  if (S.session) rows.push(miRow('logout', T('تسجيل الخروج', 'Log out'), '', 'data-a="logout"', 'danger'));
  const head = S.session && S.user
    ? `<div class="prof"><span class="av">${esc((S.user.name || '?').trim().charAt(0))}</span><div><h2>${esc(S.user.name)}</h2><span class="grey ltr">${esc(S.user.phone)}</span></div></div>`
    : `<div class="prof"><span class="av">${ic('user', 28)}</span><div><h2>${T('ضيف', 'Guest')}</h2><span class="grey">${T('سجّل دخولك للإستفادة من كل المزايا', 'Log in to enjoy every feature')}</span></div></div><button class="btn" data-a="login" style="margin-bottom:8px">${T('تسجيل الدخول', 'Log in')}</button><button class="btn line" data-a="signup" style="margin-bottom:12px">${T('إنشاء حساب', 'Create account')}</button>`;
  return sheetWrap(`<div class="sbody" data-sk="sheet">${head}${rows.join('')}</div>`, T('حسابي', 'Account'));
}
function shLang() {
  return sheetWrap(`<div class="sbody"><h2 class="sttl">${T('اللغة', 'Language')}</h2>${[['ar', 'العربية'], ['en', 'English']].map(([id, l]) => `<button class="opt ${S.lang === id ? 'on' : ''}" data-a="setLang" data-id="${id}"><span class="mk"></span><span class="grow">${l}</span></button>`).join('')}</div>`, T('اللغة', 'Language'));
}
function shLogin() {
  const why = {order:T('يجب تسجيل الدخول لإتمام طلبك.', 'Log in to complete your order.'), points:T('سجّل دخولك لعرض نقاطك وإستبدالها.', 'Log in to see and redeem your points.'), gift:T('سجّل دخولك لإرسال الهدايا.', 'Log in to send gifts.')}[UI.sheet.why] || T('سجّل دخولك للمتابعة.', 'Log in to continue.');
  return sheetWrap(`<div class="sbody"><div class="lock"><div class="li">${ic('lock', 38)}</div><h2>${T('تسجيل الدخول مطلوب', 'Login required')}</h2><p class="grey" style="margin-bottom:10px">${why}</p><button class="btn" data-a="login">${T('تسجيل الدخول', 'Log in')}</button><button class="btn line" data-a="signup">${T('إنشاء حساب', 'Create account')}</button></div></div>`, T('تسجيل الدخول', 'Log in'));
}
/* ---------- sign in and sign up ----------
   The sign-up form follows the Coffematics one: a tall sheet, each field with its label inside the box, gender as two pills,
   two round tick boxes and one button that asks for the security code. */
const FLAG_SA = '<svg viewBox="0 0 36 24" width="34" height="23" aria-hidden="true"><rect width="36" height="24" rx="4.5" fill="#006C35"/><path d="M7 9.4c2.4-2.6 4.4 1.8 7 0s4.4-2.4 7 0 4.4 1.6 8 0M9 12.6h18" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/><path d="M8.5 17.6h19.5M26 15.6v4" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/></svg>';
const errLine = k => UI.auth.errs[k] ? `<em class="em" role="alert">${esc(UI.auth.errs[k])}</em>` : '';
const flagPhone = extra => `<div class="fl ph ${UI.auth.errs.phone ? 'er' : ''}"><span class="flag">${FLAG_SA}</span><input id="ph" class="fi" type="tel" inputmode="numeric" autocomplete="tel-national" placeholder="05x-xxx-xxxx" dir="ltr" data-bind="f.phone" data-fmt="phone05" data-on="authEdit" value="${esc(UI.f.phone ? fmt05(UI.f.phone) : '')}" aria-label="${T('رقم الجوال', 'Mobile number')}" ${extra || ''}></div>${errLine('phone')}`;
const flo = (id, label, bind, extra) => { const k = bind.split('.')[1]; return `<div class="fl ${UI.auth.errs[k] ? 'er' : ''}"><input id="${id}" class="fi" placeholder=" " data-bind="${bind}" data-on="authEdit" value="${esc(UI.f[k])}" ${extra || ''}><span class="lb">${label}</span></div>${errLine(k)}`; };
const dateField = () => `<div class="fl dt ${UI.f.birth ? 'has' : ''} ${UI.auth.errs.birth ? 'er' : ''}"><input id="bd" class="fi" type="date" min="1920-01-01" max="${todayISO()}" data-bind="f.birth" data-on="birthSet" value="${esc(UI.f.birth)}" aria-label="${T('تاريخ الميلاد', 'Date of birth')}"><span class="lb">${T('تاريخ الميلاد', 'Date of birth')}</span></div>${errLine('birth')}`;
const genderRow = () => `<h3 class="glabel">${T('الجنس', 'Gender')}</h3><div class="gen ${UI.auth.errs.gender ? 'er' : ''}" role="radiogroup" aria-label="${T('الجنس', 'Gender')}">${[['m', T('ذكر', 'Male')], ['f', T('أنثى', 'Female')]].map(([v, l]) => `<button type="button" role="radio" aria-checked="${UI.f.gender === v}" class="${UI.f.gender === v ? 'on' : ''}" data-a="gender" data-v="${v}">${l}</button>`).join('')}</div>${errLine('gender')}`;
const ckRow = (k, html, label) => `<div class="ck ${UI.auth.errs[k] ? 'er' : ''}"><button type="button" class="cb ${UI.f[k] ? 'on' : ''}" role="checkbox" aria-checked="${!!UI.f[k]}" aria-label="${esc(label)}" data-a="tg" data-k="${k}">${UI.f[k] ? ic('check', 15) : ''}</button><span data-a="tg" data-k="${k}">${html}</span></div>${errLine(k)}`;

function shAuth() {
  const a = UI.auth, su = a.mode === 'signup';
  let body = '', cls = 'auth';
  if (a.step === 'phone' && !su) {
    body = `<h2 class="sttl">${T('تسجيل الدخول', 'Log in')}</h2>
      <p class="ssub">${T('أدخل رقم جوالك وسنرسل لك رمز الأمان عبر واتساب.', 'Enter your mobile number and we will send you a security code on WhatsApp.')}</p>
      ${flagPhone('data-enter="sendOtp"')}
      <div class="err" id="perr">${esc(a.err)}</div>
      <button class="btn" data-a="sendOtp" ${needAttr('phone')}>${T('إرسال رمز الأمان', 'Send security code')}</button>
      <button class="swap" data-a="authMode">${T('ليس لديك حساب؟', 'No account yet?')} <b>${T('إنشاء حساب', 'Create account')}</b></button>
      <small class="terms">${T('بالمتابعة أنت توافق على الشروط والأحكام وسياسة الخصوصية.', 'By continuing you accept the terms and the privacy policy.')}</small>`;
  } else if (a.step === 'phone') {
    cls = 'auth su tall';
    const verified = a.verified && a.verified === UI.f.phone;
    body = `<h2 class="sttl">${T('إنشاء حساب', 'Create account')}</h2>
      <p class="ssub">${T('ادخل البيانات الخاصة بك لإنشاء حساب', 'Enter your details to create an account')}</p>
      ${a.note ? `<p class="anote">${esc(a.note)}</p>` : ''}
      ${flagPhone()}
      ${flo('nm', T('الإسم', 'Name'), 'f.name', 'maxlength="30" autocomplete="name"')}
      ${flo('em', T('البريد الإلكتروني', 'Email'), 'f.email', 'type="email" inputmode="email" autocomplete="email" maxlength="120" autocapitalize="none" spellcheck="false"')}
      ${flo('iv', T('رمز الدعوة (اختياري)', 'Invite code (optional)'), 'f.invite', 'maxlength="20" autocapitalize="characters" autocomplete="off" spellcheck="false"')}
      ${dateField()}
      ${genderRow()}
      ${ckRow('terms', `${T('من خلال الإستمرار فأنت موافق على', 'By continuing you agree to the app’s')} <button type="button" class="lnk" data-a="showTerms">${T('الشروط والأحكام', 'terms and conditions')}</button> ${T('الخاصة بالتطبيق', '')}`, T('الموافقة على الشروط والأحكام', 'Agree to the terms and conditions'))}
      ${ckRow('mk', T('أوافق على تلقي إشعارات التسويق والعروض', 'I agree to receive marketing notifications and offers'), T('تلقي إشعارات التسويق والعروض', 'Receive marketing notifications and offers'))}
      <button class="btn" style="margin-top:18px" data-a="sendOtp">${verified ? T('إنشاء حساب', 'Create account') : T('إرسل رمز الأمان', 'Send security code')}</button>
      <button class="swap" data-a="authMode">${T('لديك حساب؟', 'Already have an account?')} <b>${T('تسجيل الدخول', 'Log in')}</b></button>`;
  } else {
    body = `<h2 class="sttl">${T('قم بإدخال رمز الامان', 'Enter the security code')}</h2>
      <p class="ssub">${T('أرسلنا رمزًا من 5 أرقام عبر واتساب إلى', 'We sent a 5-digit code on WhatsApp to')} <span class="ltr">${phoneFmt(UI.f.phone)}</span></p>
      <div class="otp ${a.bad ? 'bad' : ''}">${[0, 1, 2, 3, 4].map(k => `<input data-otp="${k}" type="tel" inputmode="numeric" maxlength="1" autocomplete="${k ? 'off' : 'one-time-code'}" value="${esc(UI.otp[k] || '')}" aria-label="${T('الخانة', 'Digit')} ${k + 1}">`).join('')}</div>
      <div class="err center">${esc(a.err)}</div>
      <p class="center grey" id="resend" style="margin-bottom:14px;min-height:44px;display:flex;align-items:center;justify-content:center;gap:6px">${a.secs > 0 ? `${T('إعادة الإرسال بعد', 'Resend in')} <b id="cd" class="amt" style="color:var(--pri)">0:${pad2(a.secs)}</b>` : `<button class="btn text" data-a="resend">${T('إعادة إرسال الرمز', 'Resend code')}</button>`}</p>
      <button class="btn" data-a="verify" ${needAttr('otp')}>${T('تأكيد رمز الأمان', 'Confirm security code')}</button>
      <button class="swap" data-a="authBack">${T('تغيير رقم الجوال', 'Change mobile number')}</button>
      ${a.via === 'wa' ? '' : `<small class="demo">${T('نسخة تجريبية: رمز التحقق هو 12345', 'Prototype: the code is 12345')}</small>`}`;
  }
  return sheetWrap(`<div class="sbody" data-sk="sheet">${body}</div>`, su ? T('إنشاء حساب', 'Create account') : T('تسجيل الدخول', 'Log in'), cls);
}
function shTerms() {
  return sheetWrap(`<div class="sbody doc" data-sk="sheet"><h2 class="sttl">${T('الشروط والأحكام', 'Terms and conditions')}</h2>${TERMS.map(t => `<h3>${esc(L(t.h))}</h3><p>${esc(L(t.p))}</p>`).join('')}<button class="btn" style="margin-top:20px" data-a="termsBack">${T('رجوع', 'Back')}</button></div>`, T('الشروط والأحكام', 'Terms and conditions'), 'auth su tall');
}
function sheetHTML() {
  const s = UI.sheet; if (!s) return '';
  return ({product:shProduct, branch:shBranch, profile:shProfile, lang:shLang, login:shLogin, auth:shAuth, terms:shTerms, member:shMember}[s.k] || (() => ''))();
}

/* ---------- root ---------- */
function view() {
  const layers = () => sheetHTML() + dlgHTML() + procHTML();
  if (!S.session && !S.guest) return (UI.welDone ? scrIntro() : scrWelcome()) + layers();
  let h = ({home:scrHome, orders:scrOrders, gifts:scrGifts, branches:scrBranches, news:scrNews}[UI.tab] || scrHome)();
  UI.stack.forEach((pg, i) => { h += pageHTML(pg, i); });
  return h + layers();
}
