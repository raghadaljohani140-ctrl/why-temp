/* Driver: a delivery order reaches every free driver as soon as the café accepts it (while it is being prepared), so one can
   take it and get ready. Once it is ready he picks it up, his phone shares where he is (the customer sees him on a map),
   and the customer's 4-digit code closes it. */

const mapOf = a => a ? (a.lat != null ? `https://www.google.com/maps/search/?api=1&query=${a.lat},${a.lng}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.city + ' ' + a.street)}`) : '';
const dvRoute = (o, full) => {
  const b = BR[o.branch], a = o.addr || {city:'', street:''};
  return `<div class="drv-route"><div class="drv-pt"><i class="a"></i><span><small>${T('استلم الطلب من', 'Pick it up at')}</small><b>${esc(L(b))}</b><small>${esc(L(b && b.addr))}${hasLoc(b) ? ` <a class="tel" href="${mapUrl(b.lat, b.lng)}" target="_blank" rel="noopener noreferrer">${T('الخريطة', 'Map')}</a>` : ''}</small></span></div>
    <div class="drv-pt"><i class="b"></i><span><small>${T('سلّمه إلى', 'Bring it to')}</small><b>${esc(a.city)}، ${esc(a.street)}</b>${full && a.note ? `<small>${esc(a.note)}</small>` : ''}</span></div></div>`;
};
const dvHead = o => `<div class="tk-h"><b class="tk-no">${o.no}</b><span class="tk-ty">${ic('moto', 15)}${T('توصيل', 'Delivery')}</span><span class="tk-age" data-ago="${(o.at && o.at[2]) || o.ts}">${ago((o.at && o.at[2]) || o.ts)}</span></div>`;

const dvState = o => o.st === 1
  ? `<div class="tk-n"><span>${ic('clock', 18)}</span><span><b>${T('قيد التحضير في الفرع', 'Being prepared at the branch')}</b><small>${T('استعد للاستلام، ويصلك تنبيه عندما يجهز', 'Get ready to pick it up; you will see when it is ready')}</small></span></div>`
  : `<div class="tk-n ok">${ic('check', 18)}<span><b>${T('جاهز للاستلام', 'Ready to pick up')}</b></span></div>`;
function dvAvail(o) {
  return `<article class="tk s${o.st}" data-id="${o.id}">${dvHead(o)}${dvState(o)}${dvRoute(o, false)}
    <ul class="tk-i">${tkItems(o)}</ul>
    <div class="tk-a"><button class="btn" data-a="drvTake" data-id="${o.id}">${ic('check', 20)}${o.st === 1 ? T('احجز الطلب', 'Book this order') : T('استلام الطلب', 'Take this order')}</button></div></article>`;
}
/* the phone's position, only while one of his orders is on its way (ready); every 10 seconds at most */
let geoWatch = null, geoLast = 0, geoPos = null, geoState = '';
function geoSend(force) {
  if (!geoPos || (!force && Date.now() - geoLast < 10000)) return;
  geoLast = Date.now();
  api('/driver/loc', {lat:geoPos.latitude, lng:geoPos.longitude, acc:Math.round(geoPos.accuracy || 0)}).catch(() => {});
}
function geoTick() {
  const need = UI.mode === 'main' && (SRV.mine || []).some(o => o.st === 2);
  if (need && geoWatch === null && navigator.geolocation) {
    geoWatch = navigator.geolocation.watchPosition(p => {
      const was = geoState; geoState = 'on'; geoPos = p.coords; geoSend(false);
      if (was !== 'on') UI.dirty = true;
    }, e => { geoState = e.code === 1 ? 'denied' : 'off'; UI.dirty = true; }, {enableHighAccuracy:true, maximumAge:5000, timeout:20000});
  } else if (!need && geoWatch !== null) {
    navigator.geolocation.clearWatch(geoWatch); geoWatch = null; geoPos = null; geoState = '';
  } else if (need && Date.now() - geoLast > 30000) geoSend(true);   /* standing still: the customer still sees him */
}
setInterval(geoTick, 3000);
const dvLoc = () => geoState === 'on'
  ? `<div class="tk-n ok">${ic('pin', 18)}<span><b>${T('موقعك يظهر للعميل على الخريطة', 'The customer sees you on the map')}</b><small>${T('أبقِ التطبيق مفتوحًا أثناء التوصيل', 'Keep the app open while you deliver')}</small></span></div>`
  : geoState === 'denied' ? `<div class="tk-n warn">${ic('pin', 18)}<span><b>${T('الموقع غير مسموح', 'Location is not allowed')}</b><small>${T('اسمح للتطبيق بالموقع من إعدادات الجوال ليتابعك العميل', 'Allow location in the phone settings so the customer can follow you')}</small></span></div>`
  : `<div class="tk-n">${ic('pin', 18)}<span><b>${T('مشاركة الموقع', 'Sharing your location')}</b><small>${T('اسمح بالموقع عندما يسألك الجوال ليتابعك العميل', 'Allow location when the phone asks, so the customer can follow you')}</small></span></div>`;
function dvMine(o) {
  const c = custOf(o), ph = c.phone, ready = o.st === 2;
  return `<article class="tk s${o.st}" data-id="${o.id}">${dvHead(o)}${ready ? dvLoc() : dvState(o)}
    <div class="tk-c"><span class="av">${esc(c.name.charAt(0))}</span><span class="grow"><b>${esc(c.name)}</b>${ph ? `<small>${phoneLink(ph)}</small>` : ''}</span>${ph ? `<a class="sbb call" href="tel:+966${esc(ph)}" aria-label="${T('اتصال بالعميل', 'Call the customer')}">${ic('phone', 20)}</a>` : ''}</div>
    ${giftLine(o)}${dvRoute(o, true)}
    <a class="btn line sm drv-map" href="${mapOf(o.addr)}" target="_blank" rel="noopener noreferrer">${ic('nav', 18)}${T('افتح الخريطة', 'Open the map')}</a>
    <ul class="tk-i">${tkItems(o)}</ul>
    <div class="tk-n ok">${ic('check', 18)}<span><b>${T('مدفوع مسبقًا', 'Paid already')}</b><small>${T('لا تستلم مبلغًا من العميل', 'Do not take any money from the customer')}</small></span></div>
    ${ready ? '' : `<div class="tk-v"><button class="btn text" data-a="drvRelease" data-id="${o.id}">${T('إرجاع الطلب للمندوبين', 'Hand the order back')}</button></div>`}
    ${ready ? dvArrive(o) : ''}
    ${ready ? `<div class="tk-v"><div class="field"><label>${T('رمز الإستلام من العميل', 'Code from the customer')}</label><input class="inp ltr" type="text" inputmode="numeric" maxlength="4" autocomplete="off" data-bind="dv.code.${o.id}" data-fmt="digits" data-enter="drvDeliver" data-id="${o.id}" value="${esc(UI.dv.code[o.id] || '')}" placeholder="••••"></div>
      <button class="btn" data-a="drvDeliver" data-id="${o.id}">${ic('check', 20)}${T('تأكيد التسليم', 'Confirm delivery')}</button>
      <button class="btn text" data-a="drvRelease" data-id="${o.id}">${T('إرجاع الطلب للمندوبين', 'Hand the order back')}</button></div>` : ''}</article>`;
}
/* 0.7.5: at the door, the driver tells the customer (his phone rings with a notification); again after a minute */
const ARRIVE_GAP = 60000;
function dvArrive(o) {
  if (!o.arr) return `<div class="tk-v"><button class="btn line" data-a="drvArrive" data-id="${o.id}">${ic('pin', 20)}${T('وصلت للموقع', 'I am here')}</button><small class="grey" style="display:block;text-align:center;margin-top:6px">${T('يصل العميل تنبيه إنك عند موقعه', 'The customer gets a notification that you are at his place')}</small></div>`;
  const ago = Date.now() + (SRV.skew || 0) - o.arr, again = ago >= ARRIVE_GAP;
  return `<div class="tk-n ok">${ic('pin', 18)}<span class="grow"><b>${T('أبلغنا العميل إنك وصلت', 'The customer knows you are here')}</b><small>${ago < 60000 ? T('الآن', 'just now') : T(`قبل ${Math.round(ago / 60000)} د`, `${Math.round(ago / 60000)} min ago`)}</small></span>${again ? `<button class="btn text sm" data-a="drvArrive" data-id="${o.id}">${T('نبّهه مرة ثانية', 'Tell him again')}</button>` : ''}</div>`;
}
/* the driver's own number, once: the customer can then call him while his order is on its way */
function dvPhone() {
  if (!SRV.me || SRV.me.phone || UI.mode !== 'main') return '';
  return `<div class="pz dvph">${ic('phone', 18)}<span class="grow"><b>${T('أضف رقم جوالك', 'Add your mobile number')}</b><small>${T('يظهر للعميل أثناء توصيل طلبه فقط، ليتصل بك إذا احتاج.', 'The customer sees it only while you bring his order, to call you if needed.')}</small>
    <span class="dvph-r"><input class="inp ltr" type="tel" inputmode="numeric" maxlength="10" autocomplete="tel" data-bind="dv.ph" data-fmt="digits" data-enter="drvPhone" placeholder="05XXXXXXXX" value="${esc(UI.dv.ph || '')}"><button class="btn sm" data-a="drvPhone">${T('حفظ', 'Save')}</button></span></span></div>`;
}
function dvDone(o) {
  const a = o.addr || {city:'', street:''};
  return `<article class="tk s3 dn" data-id="${o.id}"><div class="tk-h"><b class="tk-no">${o.no}</b><span class="tk-ty">${ic('check', 15)}${T('تم التوصيل', 'Delivered')}</span><span class="tk-age ltr">${hhmm((o.at && o.at[3]) || o.ts)}</span></div>
    <div class="tk-ad">${ic('pin', 15)}<span>${esc(a.city)}، ${esc(a.street)}</span></div></article>`;
}

function scrMain() {
  const tabs = [['avail', T('متاح', 'Available'), SRV.avail], ['mine', T('طلباتي', 'Mine'), SRV.mine], ['done', T('اليوم', 'Today'), SRV.done]];
  const msg = {avail:T('لا توجد طلبات توصيل الآن', 'No delivery orders right now'), mine:T('ما أخذت أي طلب بعد', 'You have no order yet'), done:T('لم توصّل أي طلب اليوم بعد', 'No deliveries yet today')};
  const card = {avail:dvAvail, mine:dvMine, done:dvDone};
  const me = SRV.me ? SRV.me.name : '';
  return `<div class="screen sx rcv drv">
    ${sbar(T('تطبيق المندوب', 'Driver app'), esc(me), sbarBtns())}
    ${pushStrip()}${dvPhone()}
    ${!deliveryOn() ? `<div class="pz off">${ic('truck', 18)}<span class="grow"><small>${T('التوصيل متوقف من الإدارة، لن تصلك طلبات جديدة', 'Delivery is switched off by the admin. No new orders will come')}</small></span></div>` : ''}
    <div class="rtabs" role="tablist">${tabs.map(([id, lb, l]) => `<button role="tab" aria-selected="${UI.dv.tab === id}" class="${UI.dv.tab === id ? 'on' : ''} ${id === 'avail' && l.length ? 'has' : ''}" data-a="drvTab" data-id="${id}"><b>${l.length}</b><span>${lb}</span></button>`).join('')}</div>
    <div class="scols">${tabs.map(([id, lb, l]) => `<section class="col ${UI.dv.tab === id ? 'on' : ''}" aria-label="${lb}"><div class="col-b" data-sk="dv-${id}">${l.map(card[id]).join('') || `<div class="colx">${ic('moto', 30)}<p>${msg[id]}</p></div>`}</div></section>`).join('')}</div>
  </div>`;
}

Object.assign(A, {
  drvTab(d) { UI.dv.tab = d.id; render(); },
  async drvTake(d) {
    const o = SRV.avail.find(x => x.id === d.id); if (!o) return;
    const r = await doStaff('/driver/order', {id:o.id, op:'take'}, T(`الطلب ${o.no} صار عندك`, `Order ${o.no} is yours`));
    if (r) { UI.dv.tab = 'mine'; render(); }
  },
  async drvDeliver(d) {
    const o = SRV.mine.find(x => x.id === d.id); if (!o) return;
    const v = String(UI.dv.code[o.id] || '').trim();
    if (v.length < 4) { toast(T('أدخل رمز الإستلام من العميل (4 أرقام)', 'Enter the customer’s 4-digit code')); return; }
    const r = await doStaff('/driver/order', {id:o.id, op:'deliver', code:v}, T(`تم توصيل الطلب ${o.no}`, `Order ${o.no} delivered`));
    if (r) delete UI.dv.code[o.id];
    else { UI.dv.code[o.id] = ''; const el = $(`[data-bind="dv.code.${o.id}"]`); if (el) { el.value = ''; el.focus(); } }
  },
  async drvArrive(d) {
    const o = SRV.mine.find(x => x.id === d.id); if (!o) return;
    if (o.arr && Date.now() + (SRV.skew || 0) - o.arr < ARRIVE_GAP) { toast(T('أبلغناه قبل قليل، تقدر تنبهه مرة ثانية بعد دقيقة', 'He was told a moment ago. You can tell him again after a minute')); return; }
    await doStaff('/driver/order', {id:o.id, op:'arrive'}, T('أبلغنا العميل إنك وصلت', 'The customer knows you are here'));
  },
  async drvPhone() {
    let v = String(UI.dv.ph || '').replace(/\D/g, '');
    if (v.startsWith('966')) v = v.slice(3);
    if (v.startsWith('0')) v = v.slice(1);
    if (!/^5\d{8}$/.test(v)) { toast(T('اكتب رقم جوال سعودي صحيح، مثل 05XXXXXXXX', 'Type a valid Saudi mobile number, like 05XXXXXXXX')); return; }
    const r = await doStaff('/driver/phone', {phone:v}, T('تم حفظ رقمك', 'Your number was saved'));
    if (r) { SRV.me = Object.assign({}, SRV.me, {phone:r.phone}); UI.dv.ph = ''; render(); }
  },
  drvRelease(d) {
    const o = SRV.mine.find(x => x.id === d.id); if (!o) return;
    UI.dlg = {t:T('إرجاع الطلب', 'Hand the order back'), b:T(`سيعود الطلب ${o.no} إلى قائمة الطلبات المتاحة ليأخذه مندوب آخر.`, `Order ${o.no} goes back to the list so another driver can take it.`), ok:T('إرجاع', 'Hand back'), danger:true,
      fn() { doStaff('/driver/order', {id:o.id, op:'release'}, T('رجع الطلب للمندوبين', 'The order is back with the drivers')); }};
    render();
  }
});

function boot() {
  UI.lg.name = S.lastName || '';
  applyLang(); UI.mode = 'boot'; render(); startPoll(); pushInit();
}
