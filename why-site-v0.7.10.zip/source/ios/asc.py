#!/usr/bin/env python3
"""App Store Connect, for build.sh (standard library only).

  python3 asc.py beta BUNDLE_PREFIX [BUILD|-] [WAIT_MINUTES]
      external TestFlight for the customer app (needs the secret TF_CONTACT): test information, the public group
      «Owner», the build added and sent to TestFlight App Review; prints the public link.

  python3 asc.py prepare BUNDLE_PREFIX  target:suffix:name ...
      registers the apps' bundle IDs if they are missing, and writes ready.txt: the targets whose app already exists in
      App Store Connect (only those can be sent to TestFlight). Missing apps are reported as GitHub annotations.

The key comes from the environment: ASC_KEY_ID, ASC_ISSUER_ID and ASC_KEY_FILE (the .p8 file). It is never printed.
"""
import base64
import hashlib
import json
import os
import re
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.appstoreconnect.apple.com/v1/"
P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
G = (0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
     0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5)


def _dbl(A):
    X, Y, Z = A
    if not Z or not Y:
        return (0, 1, 0)
    YY = Y * Y % P
    S = 4 * X * YY % P
    ZZ = Z * Z % P
    M = 3 * (X - ZZ) * (X + ZZ) % P
    X3 = (M * M - 2 * S) % P
    return (X3, (M * (S - X3) - 8 * YY * YY) % P, 2 * Y * Z % P)


def _add(A, B):
    if not A[2]:
        return B
    if not B[2]:
        return A
    X1, Y1, Z1 = A
    X2, Y2, Z2 = B
    Z1Z1, Z2Z2 = Z1 * Z1 % P, Z2 * Z2 % P
    U1, U2 = X1 * Z2Z2 % P, X2 * Z1Z1 % P
    S1, S2 = Y1 * Z2 * Z2Z2 % P, Y2 * Z1 * Z1Z1 % P
    if U1 == U2:
        return _dbl(A) if S1 == S2 else (0, 1, 0)
    H, R = (U2 - U1) % P, (S2 - S1) % P
    HH = H * H % P
    HHH, V = H * HH % P, U1 * HH % P
    X3 = (R * R - HHH - 2 * V) % P
    return (X3, (R * (V - X3) - S1 * HHH) % P, H * Z1 * Z2 % P)


def _mul(k):
    R, Q = (0, 1, 0), (G[0], G[1], 1)
    for b in bin(k)[2:]:
        R = _dbl(R)
        if b == "1":
            R = _add(R, Q)
    zi = pow(R[2], -1, P)
    return (R[0] * zi * zi % P, R[1] * zi * zi * zi % P)


def b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def private_number(pem):
    """The secret number of an Apple .p8 key (PKCS#8, P-256)."""
    body = re.sub(r"-----[^-]+-----|\s", "", pem)
    der = base64.b64decode(body)
    at = der.find(b"\x02\x01\x01\x04\x20")   # ECPrivateKey: version 1, then the 32-byte secret
    if at < 0:
        raise SystemExit("ASC_KEY_P8 does not look like an App Store Connect key (.p8)")
    return int.from_bytes(der[at + 5:at + 37], "big")


def token():
    kid, iss = os.environ["ASC_KEY_ID"], os.environ["ASC_ISSUER_ID"]
    d = private_number(open(os.environ["ASC_KEY_FILE"], encoding="utf-8").read())
    head = b64u(json.dumps({"alg": "ES256", "kid": kid, "typ": "JWT"}).encode())
    now = int(time.time())
    body = b64u(json.dumps({"iss": iss, "iat": now, "exp": now + 1000, "aud": "appstoreconnect-v1"}).encode())
    msg = ("%s.%s" % (head, body)).encode()
    z = int.from_bytes(hashlib.sha256(msg).digest(), "big")
    while True:
        k = secrets.randbelow(N - 1) + 1
        r = _mul(k)[0] % N
        s = pow(k, -1, N) * (z + r * d) % N
        if r and s:
            return "%s.%s" % (msg.decode(), b64u(r.to_bytes(32, "big") + s.to_bytes(32, "big")))


def call(tok, path, body=None, method=None, ok=()):
    """One App Store Connect request. The codes in ok (409, say) come back as None instead of stopping the run."""
    req = urllib.request.Request(API + path, method=method or ("POST" if body else "GET"),
                                 data=json.dumps(body).encode() if body else None,
                                 headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        text = e.read().decode("utf-8", "replace")
        if e.code in ok:
            print("(App Store Connect: %s %s)" % (e.code, text[:300]))
            return None
        if e.code == 401:
            raise SystemExit("::error::App Store Connect refused the key (401): check ASC_KEY_ID, ASC_ISSUER_ID and ASC_KEY_P8")
        raise SystemExit("::error::App Store Connect said %s for %s: %s" % (e.code, path, text[:400]))


def prepare(prefix, specs):
    tok = token()
    ready, missing = [], []
    for spec in specs:
        target, suffix, name = spec.split(":", 2)
        ident = "%s.%s" % (prefix, suffix)
        q = urllib.parse.quote(ident)
        found = [x for x in call(tok, "bundleIds?filter[identifier]=%s&limit=50" % q).get("data", [])
                 if x["attributes"]["identifier"] == ident]
        if not found:
            # Apple takes only letters, digits and spaces in a bundle ID's name ("Why!" is refused)
            label = re.sub(r"\s+", " ", re.sub(r"[^A-Za-z0-9 ]+", " ", name)).strip() or "Why"
            call(tok, "bundleIds", {"data": {"type": "bundleIds", "attributes": {"identifier": ident, "name": label, "platform": "IOS"}}})
            print("registered the bundle ID", ident)
        apps = [x for x in call(tok, "apps?filter[bundleId]=%s&limit=50" % q).get("data", [])
                if x["attributes"]["bundleId"] == ident]
        if apps:
            ready.append(target)
            print("app found in App Store Connect:", name, ident)
        else:
            missing.append((name, ident))
    open("ready.txt", "w").write("\n".join(ready) + "\n")
    for name, ident in missing:
        print("::error::Create the app «%s» in App Store Connect (Apps → + → New App) with the Bundle ID %s, then run this again." % (name, ident))
    return 0


BETA_GROUP = "Owner"
WHAT_TO_TEST = ("تصفح التطبيق: القائمة، الأصناف، الفروع، النقاط والهدايا. "
                "إذا عندك أي ملاحظة صوّر الشاشة واضغط Share Beta Feedback واكتبها.")
DESCRIPTION = ("Why! — تطبيق مقهى ومحمصة Why: تصفح القائمة، اطلب استلام أو توصيل، وتابع طلبك ونقاطك.\n"
               "Why! is the app of the Why café and roastery: browse the menu, order for pickup or delivery, and follow your order and points.")
NOTES = ("The menu, branches and offers can be browsed without signing in. Signing in (needed only to place an order) "
         "uses the customer's own mobile number and a one-time code. Orders placed during review reach the café's live order desk, "
         "so please do not complete an order.")


def contact():
    """TF_CONTACT (a repository secret, never in the code): four lines or parts split by |
    first name, last name, mobile (+966...), email. The email is also where testers' feedback goes."""
    raw = os.environ.get("TF_CONTACT", "")
    parts = [x.strip() for x in re.split(r"[|\n]", raw) if x.strip()]
    if len(parts) < 4 or "@" not in parts[3]:
        raise SystemExit("::error::The secret TF_CONTACT is missing or incomplete: four lines — first name, last name, mobile (+966...), email.")
    first, last, phone, email = parts[:4]
    phone = re.sub(r"[\s-]", "", phone)
    if phone.startswith("05"):
        phone = "+966" + phone[1:]
    return first, last, phone, email


def beta(prefix, build_no=None, wait_min=0):
    """External TestFlight for the customer app: test information, a public group «Owner», the build in it, sent to
    TestFlight App Review, and the public link printed. Safe to run again: whatever is already there is kept."""
    first, last, phone, email = contact()
    tok, t0 = token(), time.time()
    ident = prefix + ".why"
    apps = [x for x in call(tok, "apps?filter[bundleId]=%s&limit=50" % urllib.parse.quote(ident)).get("data", [])
            if x["attributes"]["bundleId"] == ident]
    if not apps:
        raise SystemExit("::error::No app with the Bundle ID %s in App Store Connect." % ident)
    app = apps[0]
    aid, loc = app["id"], app["attributes"].get("primaryLocale") or "en-US"

    # test information (the description and feedback email testers see)
    have = call(tok, "apps/%s/betaAppLocalizations?limit=50" % aid).get("data", [])
    for x in have:
        call(tok, "betaAppLocalizations/" + x["id"], {"data": {"type": "betaAppLocalizations", "id": x["id"],
             "attributes": {"description": DESCRIPTION, "feedbackEmail": email}}}, method="PATCH")
    if not have:
        call(tok, "betaAppLocalizations", {"data": {"type": "betaAppLocalizations",
             "attributes": {"locale": loc, "description": DESCRIPTION, "feedbackEmail": email},
             "relationships": {"app": {"data": {"type": "apps", "id": aid}}}}}, ok=(409,))
    # who Apple's beta reviewers can contact
    rd = call(tok, "apps/%s/betaAppReviewDetail" % aid)["data"]
    call(tok, "betaAppReviewDetails/" + rd["id"], {"data": {"type": "betaAppReviewDetails", "id": rd["id"], "attributes": {
         "contactFirstName": first, "contactLastName": last, "contactPhone": phone, "contactEmail": email,
         "demoAccountRequired": False, "notes": NOTES}}}, method="PATCH")
    print("test information saved")

    # the build: this run's (waiting while Apple processes it), or the newest one that is ready
    while True:
        q = "builds?filter[app]=%s&sort=-uploadedDate&limit=10" % aid
        if build_no:
            q += "&filter[version]=%s" % build_no
        bl = [b for b in call(tok, q).get("data", []) if not b["attributes"].get("expired")]
        ready = [b for b in bl if b["attributes"].get("processingState") == "VALID"]
        if ready:
            b = ready[0]
            break
        if time.time() - t0 > wait_min * 60:
            raise SystemExit("::error::No ready build of the customer app yet (Apple may still be processing it). Run this again in a while.")
        print("waiting for Apple to finish processing the build ...")
        time.sleep(60)
        tok = token()
    bid, bv = b["id"], b["attributes"]["version"]
    print("build", bv)

    # what to test, on that build
    bl10 = call(tok, "builds/%s/betaBuildLocalizations?limit=50" % bid).get("data", [])
    for x in bl10:
        call(tok, "betaBuildLocalizations/" + x["id"], {"data": {"type": "betaBuildLocalizations", "id": x["id"],
             "attributes": {"whatsNew": WHAT_TO_TEST}}}, method="PATCH")
    if not bl10:
        call(tok, "betaBuildLocalizations", {"data": {"type": "betaBuildLocalizations",
             "attributes": {"locale": loc, "whatsNew": WHAT_TO_TEST},
             "relationships": {"build": {"data": {"type": "builds", "id": bid}}}}}, ok=(409,))

    # the external group with a public link
    groups = [g for g in call(tok, "apps/%s/betaGroups?limit=200" % aid).get("data", [])
              if not g["attributes"].get("isInternalGroup") and g["attributes"].get("name") == BETA_GROUP]
    if groups:
        g = groups[0]
        if not g["attributes"].get("publicLinkEnabled"):
            g = call(tok, "betaGroups/" + g["id"], {"data": {"type": "betaGroups", "id": g["id"],
                     "attributes": {"publicLinkEnabled": True, "publicLinkLimitEnabled": False}}}, method="PATCH")["data"]
    else:
        g = call(tok, "betaGroups", {"data": {"type": "betaGroups",
                 "attributes": {"name": BETA_GROUP, "publicLinkEnabled": True, "publicLinkLimitEnabled": False},
                 "relationships": {"app": {"data": {"type": "apps", "id": aid}}}}})["data"]
        print("made the external group", BETA_GROUP)
    call(tok, "betaGroups/%s/relationships/builds" % g["id"], {"data": [{"type": "builds", "id": bid}]}, ok=(409,))

    # TestFlight App Review (the first build takes about a day; later ones are usually quick)
    sub = call(tok, "builds/%s/betaAppReviewSubmission" % bid, ok=(404,))
    if sub and sub.get("data"):
        state = sub["data"]["attributes"].get("betaReviewState")
    else:
        r = call(tok, "betaAppReviewSubmissions", {"data": {"type": "betaAppReviewSubmissions",
                 "relationships": {"build": {"data": {"type": "builds", "id": bid}}}}}, ok=(409, 422))
        state = r["data"]["attributes"].get("betaReviewState") if r else "already sent"
    g = call(tok, "betaGroups/" + g["id"])["data"]
    link = g["attributes"].get("publicLink") or "(not given yet — run again later)"
    msg = "Customer app build %s: beta review %s. Public TestFlight link: %s" % (bv, state, link)
    print("::notice::" + msg)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write("## TestFlight — Why! (customer)\n\n- Build: %s\n- Beta review: %s\n- Public link: %s\n" % (bv, state, link))
    return 0


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "beta":
        sys.exit(beta(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] != "-" else None,
                      int(sys.argv[4]) if len(sys.argv) > 4 else 0))
    if len(sys.argv) >= 3 and sys.argv[1] == "prepare":
        sys.exit(prepare(sys.argv[2], sys.argv[3:]))
    sys.exit(__doc__)
