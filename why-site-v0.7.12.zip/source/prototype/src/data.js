'use strict';
/* Sample content. Bean names and prices follow the public store; drinks, branches and news are examples.
   CATS and PRODUCTS are only the first menu: the server keeps the real one (the admin edits it) and every page takes it from there.
   They are what a page shows before it has heard from the server for the first time, and what the server starts from. */

const MEMBER = {ar:'عضوية أساسية', en:'Basic membership'};
/* membership tiers (0.5.1): the points of the last TIER_DAYS days that open a tier (min) and the points earned for every
   10 SAR paid (per10). The admin changes them on the management page and the server sends the current ones (SRV.tiers);
   these are only the start values, the same as the server's. */
const TIERS = [{id:'basic', min:0, per10:8}, {id:'silver', min:500, per10:9}, {id:'gold', min:1000, per10:10}];
const TIER_NAME = {basic:{ar:'عضوية أساسية', en:'Basic membership', to:{ar:'للعضوية الأساسية', en:'to Basic'}},
  silver:{ar:'عضوية فضية', en:'Silver membership', to:{ar:'للعضوية الفضية', en:'to Silver'}},
  gold:{ar:'عضوية ذهبية', en:'Gold membership', to:{ar:'للعضوية الذهبية', en:'to Gold'}}};
const TIER_DAYS = 30;

const CATS = [
  {id:'hot',    ar:'المشروبات الساخنة', en:'Hot drinks',      kind:'drink'},
  {id:'cold',   ar:'المشروبات الباردة', en:'Cold drinks',     kind:'drink'},
  {id:'filter', ar:'المشروبات المقطرة', en:'Filter drinks',   kind:'drink'},
  {id:'matcha', ar:'الماتشا',           en:'Matcha',          kind:'drink'},
  {id:'sweet',  ar:'الحلويات',          en:'Desserts',        kind:'food'},
  {id:'esp',    ar:'محاصيل الإسبريسو',      en:'Espresso crops', kind:'retail'},
  {id:'fil',    ar:'محاصيل القهوة المقطرة', en:'Filter crops',   kind:'retail'},
  {id:'prem',   ar:'المحاصيل الفاخرة',      en:'Premium crops',  kind:'retail'},
  {id:'kg',     ar:'محاصيل 1000 جرام',      en:'1 kg crops',     kind:'retail'},
  {id:'goods',  ar:'منتجات واي!',           en:'Why! products',  kind:'retail'}
];
const CAT = {}; CATS.forEach(c => CAT[c.id] = c);

const OPT = {
  size:  {ar:'الحجم', en:'Size', type:'radio', items:[
    {id:'s', ar:'صغير', en:'Small',  d:0},
    {id:'m', ar:'وسط',  en:'Medium', d:3},
    {id:'l', ar:'كبير', en:'Large',  d:5}]},
  shots: {ar:'عدد الشوتات', en:'Shots', type:'radio', items:[
    {id:'1', ar:'سنجل', en:'Single', d:0},
    {id:'2', ar:'دبل',  en:'Double', d:4}]},
  milk:  {ar:'نوع الحليب', en:'Milk', type:'radio', items:[
    {id:'whole',  ar:'كامل الدسم', en:'Whole',    d:0},
    {id:'low',    ar:'قليل الدسم', en:'Low fat',  d:0},
    {id:'oat',    ar:'شوفان',      en:'Oat',      d:3},
    {id:'almond', ar:'لوز',        en:'Almond',   d:3}]},
  extras:{ar:'إضافات', en:'Extras', type:'check', items:[
    {id:'shot',    ar:'شوت إضافي',     en:'Extra shot',      d:4},
    {id:'vanilla', ar:'سيروب فانيلا',  en:'Vanilla syrup',   d:3},
    {id:'caramel', ar:'سيروب كراميل',  en:'Caramel syrup',   d:3}]},
  temp:  {ar:'الحرارة', en:'Temperature', type:'radio', items:[
    {id:'hot',  ar:'ساخن', en:'Hot',  d:0},
    {id:'iced', ar:'بارد', en:'Iced', d:1}]},
  origin:{ar:'المحصول', en:'Origin', type:'radio', items:[
    {id:'yirg', ar:'يرقاتشيف شلشلي',  en:'Yirgacheffe Chelchele', d:0},
    {id:'arsi', ar:'محصول اثيوبي ويست ارسي',  en:'Ethiopia West Arsi',   d:0},
    {id:'col',  ar:'كولومبي عنب واي', en:'Colombia Grape Why',  d:8}]}
};

const P = (id, cat, ar, en, price, cal, art, tone, opts = [], x = {}) =>
  Object.assign({id, cat, ar, en, price, cal, art, tone, opts}, x);

/* roastery product helper: R(id, [categories], ar, en, price, art, tone, extras). Detail rows come from D(). */
const G250 = {ar:'250 جرام', en:'250 g'}, G1K = {ar:'1 كجم', en:'1 kg'};
const LB = {use:['الاستخدام','Use'], origin:['المنشأ','Origin'], variety:['السلالة','Variety'], alt:['الارتفاع','Altitude'], proc:['المعالجة','Process'], notes:['النكهات','Flavours'], contents:['المحتوى','Contents'], brew:['التحضير','Brewing']};
const D = (...rows) => rows.map(([k, ar, en]) => ({k:{ar:LB[k][0], en:LB[k][1]}, v:{ar, en:en || ar}}));
const R = (id, cats, ar, en, price, art, tone, x = {}) => P(id, cats[0], ar, en, price, 0, art, tone, [], Object.assign({cats}, x));

const PRODUCTS = [
  P('espresso','hot','إسبريسو','Espresso',10,5,'espresso','#8A5232',['shots']),
  P('americano','hot','أمريكانو','Americano',12,10,'hot','#8A5232',['size','extras']),
  P('flat','hot','فلات وايت','Flat white',16,130,'hot','#C8965A',['size','milk','extras']),
  P('cap','hot','كابتشينو','Cappuccino',16,120,'hot','#C8965A',['size','milk','extras']),
  P('latte','hot','لاتيه','Latte',17,190,'hot','#D9B98C',['size','milk','extras']),
  P('spanish','hot','لاتيه إسباني','Spanish latte',20,260,'hot','#E0A33B',['size','milk','extras']),
  P('iamericano','cold','ايسد امريكانو','Iced americano',13,2,'iced','#4A2A1A',['size','extras']),
  P('ilatte','cold','ايسد لاتيه','Iced latte',18,170,'iced','#D9B98C',['size','milk','extras']),
  P('coldbrew','cold','كولد برو','Cold brew',19,15,'iced','#3A2218',['size']),
  P('tonic','cold','إسبريسو تونك','Espresso tonic',21,40,'iced','#C8965A'),
  P('batch','filter','قهوة اليوم','Coffee of the day',11,5,'filter','#8A5232',['size']),
  P('v60','filter','V60 (اختر المحصول)','V60 (pick an origin)',22,5,'filter','#6B3A22',['origin']),
  P('chemex','filter','كيمكس لشخصين','Chemex for two',38,10,'filter','#6B3A22',['origin']),
  P('matchalatte','matcha','ماتشا لاتيه','Matcha latte',22,170,'matcha','#8DAE55',['temp','milk']),
  P('matchatonic','matcha','ماتشا تونك','Matcha tonic',23,60,'iced','#8DAE55'),
  P('brownie','sweet','براونيز','Brownie',14,320,'brownie','#4A2A1A'),
  P('cookie','sweet','كوكيز شوكولاتة','Chocolate cookie',10,280,'cookie','#C8965A'),
  P('datecake','sweet','كيكة التمر','Date cake',16,350,'cake','#8A5232'),
  /* roastery products: names, prices and notes follow the public store (whyroasteryco.com) */
  R('arsi', ['esp','fil'], 'محصول اثيوبي ويست ارسي', 'Ethiopia West Arsi', 63, 'bag', '#5C8A3A', {sub:G250, d:D(['use','فلتر وإسبريسو','Filter and espresso'], ['origin','إثيوبيا','Ethiopia'], ['variety','74110'], ['alt','1850 - 2200'], ['proc','مجففة','Dried'], ['notes','خوخ، توت بري، توت أحمر','Peach, wild berries, red berries'])}),
  R('collection', ['esp','fil'], 'عرض مجموعة المذاق', 'Taste collection offer', 109, 'box', '#ECB444', {fship:true, badge:{ar:'شحن مجاني',en:'Free shipping'}, d:D(['contents','محصول ويست آرسي 250 جرام، محصول ماما بيتي 250 جرام، كوب ستيل، استيكرات','West Arsi 250 g, Mama Betty 250 g, a steel cup and stickers'])}),
  R('palma', ['esp','fil'], 'بالما | كولمبي', 'Palma | Colombia', 66, 'bag', '#8A5232', {sub:G250, d:D(['notes','حلاوة، جوافة، فواكه استوائية، شوكولاتة داكنة','Sweetness, guava, tropical fruit, dark chocolate'])}),
  R('sachets', ['fil'], 'أظرف القهوة / اثيوبي ويست آرسي', 'Coffee envelopes / Ethiopia West Arsi', 33, 'box', '#5C8A3A', {sub:{ar:'5 أظرف في كل عبوة',en:'5 envelopes per pack'}, d:D(['brew','قهوة جاهزة خلال دقيقتين تقريبًا','Ready in about two minutes'])}),
  R('mango', ['fil','prem'], 'كولومبي - مانقوخا', 'Colombia - Manqokha', 90, 'bag', '#D8A31E', {sub:G250, d:D(['use','التقطير','Filter'], ['origin','كولومبيا','Colombia'], ['variety','بوربون','Bourbon'], ['alt','1800 - 2000'], ['proc','تخمير مع المانجو والخوخ','Fermented with mango and peach'], ['notes','خوخ، مانجو','Peach, mango'])}),
  R('yirg', ['fil','prem'], 'يرقاتشيف شلشلي', 'Yirgacheffe Chelchele', 59, 'bag', '#3F7D4E', {sub:G250, d:D(['alt','1800 - 2000'], ['proc','مجففة','Dried'], ['notes','شاي، زهور، برقوق، توت بري','Tea, flowers, plum, wild berries'])}),
  R('grape', ['prem'], 'كولومبي عنب واي', 'Colombia Grape Why', 90, 'bag', '#6B3A7A', {badge:{ar:'محصول فاخر',en:'Premium'}, sub:G250, d:D(['use','التقطير','Filter'], ['origin','كولومبيا','Colombia'], ['variety','بوربون','Bourbon'], ['alt','1900 - 2100'], ['proc','مجففة','Dried'], ['notes','فانيلا، بطيخ، برتقال','Vanilla, watermelon, orange'])}),
  R('candy', ['prem'], 'كاندي | برازيلي', 'Candy | Brazil', 56, 'bag', '#D58F2B', {d:D(['proc','تخمير','Fermented'], ['notes','حلاوة','Sweetness'])}),
  R('candy2', ['prem'], 'كاندي | برازيلي', 'Candy | Brazil', 90, 'bag', '#D58F2B'),
  R('candy1kg', ['prem','kg'], 'كاندي | برازيلي - 1 Kg', 'Candy | Brazil - 1 kg', 400, 'bag', '#D58F2B', {sub:G1K}),
  R('pineapple', ['prem'], 'كولومبي - أناناس', 'Colombia - Pineapple', 90, 'bag', '#D8A31E', {stock:false}),
  R('coconut', ['prem'], 'كولومبي - كوكونات واي!', 'Colombia - Coconut Why!', 90, 'bag', '#3E8A7A', {stock:false}),
  R('palma1', ['kg'], 'بالما | 1KG', 'Palma | 1 kg', 172, 'bag', '#8A5232', {sub:G1K}),
  R('grape1', ['kg'], 'عنب واي | 1KG', 'Grape Why | 1 kg', 380, 'bag', '#6B3A7A', {sub:G1K, badge:{ar:'منتج مميز',en:'Featured'}}),
  R('arsi1', ['kg'], 'ويست آرسي | 1KG', 'West Arsi | 1 kg', 160, 'bag', '#5C8A3A', {sub:G1K, badge:{ar:'يباع سريعًا',en:'Selling fast'}}),
  R('yirg1', ['kg'], 'يرقاتشيف تشيلشلي | 1KG', 'Yirgacheffe Chelchele | 1 kg', 160, 'bag', '#3F7D4E', {sub:G1K}),
  R('mama1', ['kg'], 'ماما بيتي - أوغندي | 1KG', 'Mama Betty - Uganda | 1 kg', 160, 'bag', '#A0522D', {sub:G1K}),
  R('mango1', ['kg'], 'مانقوخا | 1KG', 'Manqokha | 1 kg', 380, 'bag', '#D8A31E', {sub:G1K}),
  R('coconut1', ['kg'], 'كوكونات | 1KG', 'Coconut | 1 kg', 380, 'bag', '#3E8A7A', {sub:G1K, stock:false}),
  R('matchapowder', ['goods'], 'مسحوق الماتشا 30', 'Matcha powder 30', 49, 'tin', '#8DAE55', {badge:{ar:'منتج جديد',en:'New'}, sub:{ar:'30 جرام',en:'30 g'}}),
  R('cup16', ['goods'], 'أكواب ورقية 16OZ', 'Paper cups 16 oz', 23, 'cups', '#2A1810'),
  R('cup12', ['goods'], 'أكواب ورقية 12OZ', 'Paper cups 12 oz', 19, 'cups', '#2A1810'),
  R('cup8', ['goods'], 'أكواب ورقية 8OZ', 'Paper cups 8 oz', 16, 'cups', '#2A1810'),
  R('steelcup', ['goods'], 'كوب ستيل', 'Steel cup', 32, 'cups', '#7A7F85', {sub:{ar:'ثلاثة أكواب ستيل',en:'Set of three steel cups'}})
];
const PROD = {}; PRODUCTS.forEach(p => PROD[p.id] = p);
const GIFT_ITEMS = ['latte','spanish','ilatte','brownie','grape','collection'];

/* Rewards: an item goes into the cart for free (points are deducted at checkout); a credit goes straight to the wallet. */
const REWARDS = [
  {id:'r1', pts:120, pid:'batch',  ar:'قهوة اليوم',               en:'Coffee of the day'},
  {id:'r2', pts:200, pid:'latte',  ar:'لاتيه (صغير)',             en:'Latte (small)'},
  {id:'r3', pts:220, pid:'ilatte', ar:'ايسد لاتيه (صغير)',        en:'Iced latte (small)'},
  {id:'r4', pts:150, pid:'cookie', ar:'كوكيز شوكولاتة',           en:'Chocolate cookie'},
  {id:'r5', pts:400, credit:20,    ar:'رصيد 20 ريال في المحفظة',  en:'20 SAR wallet credit'}
];
const RW = id => REWARDS.find(r => r.id === id);

/* h: opening hours as minutes after midnight [open, close] (close past 1440 = after midnight), or '24' for all day.
   lat/lng: where it is (null until the admin sets it); with it the customer gets directions and the distance. */
const BRANCHES = [
  {id:'b1', ar:'فرع الخزامى (مثال)', en:'Al Khuzama branch (sample)', addr:{ar:'الحي الأول، الشارع الرئيسي، المدينة المنورة، السعودية (عنوان تجريبي)', en:'First district, Main St, Madinah, Saudi Arabia (sample address)'}, h:[360,1560], lat:null, lng:null},
  {id:'b2', ar:'فرع النخيل (مثال)',  en:'Al Nakheel branch (sample)', addr:{ar:'حي النخيل، طريق الخدمة، المدينة المنورة، السعودية (عنوان تجريبي)', en:'Al Nakheel, service road, Madinah, Saudi Arabia (sample address)'}, h:'24', lat:null, lng:null},
  {id:'b3', ar:'فرع السلام (مثال)',  en:'Al Salam branch (sample)',   addr:{ar:'حي السلام، شارع الأمير، المدينة المنورة، السعودية (عنوان تجريبي)', en:'Al Salam, Prince St, Madinah, Saudi Arabia (sample address)'}, h:[960,1380], lat:null, lng:null}
];
const BR = {}; BRANCHES.forEach(b => BR[b.id] = b);

/* a: what the banner opens. beans and menu open the menu; points and gift open those pages; a product id opens that product */
/* the two tiles of the home page (0.7.12: the admin may give each its own photo and words; these are the app's own) */
const HOME_TILES = {
  order:{t:{ar:'اطلب الآن', en:'Order now'}, s:{ar:'احجز طلبك المفضل مسبقًا و إختر طريقة الإستلام.', en:'Order your favourite ahead and choose how to get it.'}, art:'hot', tone:'#C8965A'},
  gift: {t:{ar:'أرسل هدية', en:'Send a gift'}, s:{ar:'فاجئ أصدقاءك بهدية من واي!', en:'Surprise your friends with a gift from Why!'}, art:'box', tone:'#ECB444'}
};

const BANNERS = [
  {id:'bn1', bg:'linear-gradient(135deg,#6F7F2E,#9AA24A)', t:{ar:'مسحوق الماتشا',en:'Matcha powder'}, s:{ar:'منتج جديد في واي!',en:'New at Why!'}, a:'matchapowder'},
  {id:'bn2', ink:'#0F0F0F', bg:'linear-gradient(135deg,#ECB444,#D49A1C)', t:{ar:'اجمع النقاط مع كل عملية شراء',en:'Earn points with every purchase'}, s:{ar:'استبدل نقاطك بمنتجاتك المفضلة',en:'Redeem them for your favourites'}, a:'points'},
  {id:'bn3', bg:'linear-gradient(135deg,#1A1A1A,#3A3A3A)', t:{ar:'أرسل هدية',en:'Send a gift'}, s:{ar:'فاجئ أصدقاءك بهدية من واي!',en:'Surprise your friends with a gift from Why!'}, a:'gift'},
  {id:'bn4', ink:'#0F0F0F', bg:'linear-gradient(135deg,#ECB444,#F3CB6E)', t:{ar:'عرض مجموعة المذاق',en:'Taste collection offer'}, s:{ar:'شحن مجاني على العرض',en:'Free shipping on this offer'}, a:'collection'},
  {id:'bn5', bg:'linear-gradient(135deg,#1A1A1A,#3A3A3A)', t:{ar:'قهوة اليوم',en:'Coffee of the day'}, s:{ar:'محصول جديد كل أسبوع',en:'A new crop every week'}, a:'menu'}
];

const NEWS = [
  {id:'n1', ts:'2026-11-10T08:55:00', bg:'linear-gradient(135deg,#6F7F2E,#ECB444)',
   t:{ar:'وصل محصول يرقاتشيف شلشلي',en:'Yirgacheffe Chelchele has arrived'},
   b:{ar:['وصلت الدفعة الجديدة من يرقاتشيف شلشلي وحُمّصت هذا الأسبوع.','تجدها في قسم محاصيل القهوة المقطرة.'],
      en:['The new Yirgacheffe Chelchele lot has arrived and was roasted this week.','Find it under Filter crops.']}},
  {id:'n2', ts:'2026-11-03T12:35:00', bg:'linear-gradient(135deg,#ECB444,#D49A1C)',
   t:{ar:'قهوة اليوم تتغير كل أسبوع',en:'Coffee of the day changes weekly'},
   b:{ar:['كل أسبوع نختار محصولًا مختلفًا لقهوة اليوم.','اسأل الباريستا في الفرع عن محصول هذا الأسبوع.'],
      en:['Every week we pick a different crop for the coffee of the day.','Ask the barista at the branch what is on this week.']}},
  {id:'n3', ts:'2026-10-25T10:00:00', bg:'linear-gradient(135deg,#0F0F0F,#3A3A3A)',
   t:{ar:'تدشين تطبيق واي!',en:'The Why! app is here'},
   b:{ar:['اطلب مسبقًا، اجمع النقاط، وأرسل هدية لمن تحب.','تجربة رقمية فريدة، مكافآت مميزة ومزايا حصرية.'],
      en:['Order ahead, collect points and send a gift to someone you like.','A unique digital experience with special rewards and exclusive perks.']}}
];

const FAQ = [
  {q:{ar:'كيف أجمع النقاط؟',en:'How do I earn points?'}, a:{ar:'تحصل على نقاط عن كل ريال تدفعه، وعددها حسب مستوى عضويتك. التفاصيل في صفحة العضوية من الرئيسية.',en:'You earn points for every riyal you pay; how many depends on your membership tier. See the membership page on the home screen.'}},
  {q:{ar:'كيف أستلم طلبي؟',en:'How do I pick up my order?'}, a:{ar:'اختر استلام من الفرع عند إستكمال الطلب، وأظهر رمز الطلب للموظف عند الاستلام.',en:'Choose pickup from a branch at checkout and show your order code to the staff.'}},
  {q:{ar:'كيف تعمل الهدايا؟',en:'How do gifts work?'}, a:{ar:'أرسل منتجًا أو بطاقة إلى رقم جوال صديقك، ويستلمها من تبويب الهدايا في حسابه.',en:'Send a product or a card to your friend’s mobile number and they collect it from the Gifts tab.'}},
  {q:{ar:'كيف يصلني طلب الحبوب؟',en:'How does a bean order reach me?'}, a:{ar:'نشحنه عبر شركات الشحن المتاحة عند إستكمال الطلب، أو تستلمه من الفرع.',en:'We ship it with the carriers offered at checkout, or you can pick it up at a branch.'}}
];

const TERMS = [
  {h:{ar:'استخدام التطبيق',en:'Using the app'}, p:{ar:'نص تجريبي يُستبدل بالشروط الرسمية لمحمصة واي!.',en:'Sample text to be replaced with the official terms of Why Roastery.'}},
  {h:{ar:'الطلبات والدفع',en:'Orders and payment'}, p:{ar:'الأسعار شاملة ضريبة القيمة المضافة 15%. الدفع يتم عبر وسائل الدفع المعروضة عند إستكمال الطلب.',en:'Prices include 15% VAT. Payment uses the methods shown at checkout.'}},
  {h:{ar:'النقاط والهدايا',en:'Points and gifts'}, p:{ar:'النقاط والهدايا غير قابلة للتحويل إلى نقد، ولها شروط استخدام تُحدّد لاحقًا.',en:'Points and gifts cannot be exchanged for cash and follow terms to be defined later.'}},
  {h:{ar:'الخصوصية',en:'Privacy'}, p:{ar:'نحتفظ برقم جوالك واسمك لإدارة حسابك وطلباتك فقط.',en:'We keep your mobile number and name only to manage your account and orders.'}}
];

const CARRIERS = ['Redbox','Aramex','SMSA','Naqel'];
const SHIP_FEE = 25;
const DELIVERY_FEE = 12;   /* local delivery by the café's own drivers, SAR incl. VAT; the admin can change it */
const SITE = {phone:'+966 50 816 4307', wa:'966508164307', email:'whycafe.sa@gmail.com'};
