/* Customer page: navigation, sign in, menu, cart, orders, points, gifts, branches. */

/* ---------- navigation ---------- */
function setStack(arr) { Object.keys(UI.sc).forEach(k => { if (k.startsWith('pg-')) delete UI.sc[k]; }); UI.stack = arr; UI.fresh.page = arr.length > 0; }
function push(pg) { UI.stack.push(pg); delete UI.sc['pg-' + (UI.stack.length - 1)]; UI.fresh.page = true; render(); }
function pop() {
  const top = UI.stack[UI.stack.length - 1];
  if (top && top.p === 'giftsend' && UI.g.step > 1) { UI.g.step--; render(); return; }
  UI.stack.pop();
  if (top && top.p === 'notifs') { S.notifs.forEach(n => { n.read = true; }); save(); }
  render();
}
function needLogin(why) { if (S.session) return false; openSheet({k:'login', why}); return true; }
function afterLogin() {
  UI.auth = authInit(); UI.otp = ['', '', '', '', '']; clearSignup(); UI.tab = 'home';
  setStack(UI.after === 'cart' ? [{p:'cart'}] : []); UI.after = null; UI.sheet = null; render();
  syncSoon(300);
}

/* ---------- 0.7.16: the opening: every time the app opens, the big w, then the why! wordmark takes its place, then the app ---------- */
(function splash() {
  if (APP !== 'cust' || !IMG.logo || (navigator.webdriver && !/[?&]splash\b/.test(location.search))) return;   /* the automatic checks skip it, except the one that looks at it */
  const el = document.createElement('div');
  el.id = 'splash'; el.setAttribute('aria-hidden', 'true');
  el.innerHTML = `${IMG.mark ? '<span class="sp-mark im-mark"></span>' : ''}<span class="sp-logo im-logo" style="aspect-ratio:${IMG.logo.r}"></span>`;
  document.body.appendChild(el);
  setTimeout(() => el.classList.add('out'), 2300);
  setTimeout(() => el.remove(), 2750);
})();

/* ---------- onboarding helpers ---------- */
function updIntro() {
  const i = UI.intro.i;
  $$('#segs i').forEach((e, k) => e.classList.toggle('on', k <= i));
  const c = $('#cnt'); if (c) c.textContent = (i + 1) + '/3';
}

/* what the sign-up form still has to ask for: field → message (empty = all good) */
function signupErrors() {
  const f = UI.f, e = {};
  if (!validPhone(f.phone)) e.phone = T('أدخل رقم جوال سعودي صحيح (05XXXXXXXX)', 'Enter a valid Saudi mobile number (05XXXXXXXX)');
  if ((f.name || '').trim().length < 2) e.name = T('أدخل اسمك', 'Enter your name');
  if (!validEmail((f.email || '').trim())) e.email = T('أدخل بريدًا إلكترونيًا صحيحًا', 'Enter a valid email address');
  if ((f.invite || '').trim() && !/^[A-Za-z0-9]{3,20}$/.test(f.invite.trim())) e.invite = T('رمز الدعوة غير صحيح (حروف إنجليزية وأرقام فقط)', 'The invite code is not valid (English letters and digits only)');
  if (!validBirth(f.birth)) e.birth = T('اختر تاريخ ميلادك', 'Choose your date of birth');
  if (!f.gender) e.gender = T('اختر الجنس', 'Choose your gender');
  if (!f.terms) e.terms = T('يجب الموافقة على الشروط والأحكام للمتابعة', 'You need to agree to the terms and conditions to continue');
  return e;
}
const clearSignup = () => Object.assign(UI.f, {name:'', email:'', invite:'', birth:'', gender:'', terms:false, mk:false});

/* ---------- auth helpers ----------
   The server checks the code and signs this phone in (0.7). Until the WhatsApp codes are switched on (before launch) the code
   is the test code 12345. A phone that was signed in before 0.7 hands over what it counted, once. */
/* 0.7.6: the server sends the code by WhatsApp ('wa'), or says the test code 12345 is the one ('test') */
async function sendCode(phone) {
  const r = await api('/my/code', {phone}, {timeout:20000});
  return r.via === 'wa' ? 'wa' : 'test';
}
async function login(phone, code, signup) {
  const f = UI.f, body = {phone, code};
  if (S.user && S.user.phone === phone && legacyAcct()) body.legacy = legacyBody();
  if (signup) Object.assign(body, {signup:true, name:f.name.trim(), email:f.email.trim().toLowerCase(), birth:f.birth, gender:f.gender, invite:(f.invite || '').trim().toUpperCase(), mk:!!f.mk});
  UI.auth.busy = true; syncBtns();
  try { return await api('/my/login', body, {timeout:15000}); }
  finally { UI.auth.busy = false; }
}
function signedIn(r) {
  const cart = S.cart, pub = S.pub, cat = S.cat, sameUser = S.user && S.user.phone === r.user.phone;
  if (!sameUser) { resetData(); S.cart = cart; S.pub = pub; S.cat = cat; } else { S.orders = []; S.arev = null; }
  S.user = r.user; S.session = true; S.guest = false; S.gseen = r.new ? [] : null;
  applyAcct(r.acct); mergeHistory(r.history || []);
  if (typeof r.rev === 'number') S.since = r.rev;
  if (r.new) note({ar:'أهلًا بك في واي!', en:'Welcome to Why!'}, {ar:`أضفنا ${WELCOME_PTS} نقطة هدية التسجيل.`, en:`We added ${WELCOME_PTS} points as a welcome gift.`}, 'star', {p:'points'});
  save(); afterLogin();
  toast(r.new ? T(`أهلًا بك ${r.user.name}`, `Welcome, ${r.user.name}`) : T(`أهلًا بعودتك ${r.user.name}`, `Welcome back, ${r.user.name}`));
}
async function verifyOtp() {
  const code = UI.otp.join('');
  if (code.length < 5 || UI.auth.busy) return;
  const ph = UI.f.phone, signup = UI.auth.mode === 'signup';
  try {
    const r = await login(ph, code, signup);
    if (r.need === 'signup') {   /* a number we do not know: the code proved it is theirs, so only the rest of the details are asked */
      UI.auth = Object.assign(authInit('signup'), {verified:ph, code, note:T('لا يوجد حساب بهذا الرقم. أكمل بياناتك لإنشاء حساب.', 'There is no account for this number yet. Complete your details to create one.')});
      UI.otp = ['', '', '', '', '']; UI.focus = '#nm'; render(); return;
    }
    signedIn(r);
  } catch (e) {
    if (e.code === 'bad_otp') { UI.auth.err = T('رمز الأمان غير صحيح، حاول مرة أخرى', 'Wrong security code, try again'); UI.auth.bad = true; }
    else toast(errText(e));
    UI.otp = ['', '', '', '', '']; UI.focus = '[data-otp="0"]'; render();
  }
}
function otpInput(t) {
  const i = Number(t.dataset.otp);
  const v = toLatin(t.value).replace(/\D/g, '');
  if (v.length > 1) {
    v.slice(0, 5 - i).split('').forEach((ch, k) => { UI.otp[i + k] = ch; const el = $(`[data-otp="${i + k}"]`); if (el) el.value = ch; });
    const nx = $(`[data-otp="${Math.min(4, i + v.length)}"]`); if (nx) nx.focus();
  } else {
    UI.otp[i] = v; t.value = v;
    if (v && i < 4) { const nx = $(`[data-otp="${i + 1}"]`); if (nx) nx.focus(); }
  }
  syncBtns();
  if (UI.otp.every(x => x)) verifyOtp();
}

/* ---------- placing an order: the server prices it again and keeps it ---------- */
/* what is booked on this phone once the server has the order: the server counted the points and the wallet (acct) */
function orderPlaced(o, q, acct) {
  o.driver = o.driver || null;
  S.orders.unshift(o);
  if (!applyAcct(acct)) {   /* the phone still counts (an account from before 0.7 the server has not taken over) */
    q.lines.forEach(l => { if (l.c.gift) { const g = S.gifts.find(x => x.id === l.c.gift); if (g) g.state = 'used'; } });
    S.bal = r2(S.bal - o.bal);
    if (o.spent) addPts(-o.spent, {ar:`إستبدال مكافأة (${o.no})`, en:`Reward redeemed (${o.no})`}, 'spend');
    if (o.earn) addPts(o.earn, {ar:`طلب ${o.no}`, en:`Order ${o.no}`}, 'earn');
  }
  note({ar:`تم استلام طلبك ${o.no}`, en:`Order ${o.no} received`}, {ar:'سنوافيك بالتحديثات أولاً بأول.', en:'We will keep you posted.'}, 'receipt', {p:'order', id:o.id});
  if (o.addr) S.addr = {city:o.addr.city, street:o.addr.street, note:o.addr.note || ''};
  S.cart = []; UI.co = newCo(); save();
}
async function sendOrder() {
  const q = calc(), co = UI.co;
  const items = q.lines.map(l => ({pid:l.p.id, sel:l.c.sel, qty:l.c.qty, rw:l.c.rw || null, gift:l.c.gift || null}));
  /* the same attempt keeps the same id, so a lost reply never books the order twice */
  const sig = JSON.stringify([q.mode, S.branch, items, co.codeOk ? co.code : '', q.bal, q.total, co.carrier, co.serve, co.pick]);
  if (!co.cid || co.sig !== sig) { co.cid = newDev().slice(0, 24); co.sig = sig; }
  const body = {cid:co.cid, mode:q.mode, branch:S.branch, serve:co.serve, carrier:co.carrier, code:co.codeOk ? co.code : '', bal:q.bal, payM:co.pay, total:q.total,
    cust:{name:S.user.name, phone:S.user.phone}, items, legacy:legacyBody()};
  if (q.mode !== 'pickup') body.addr = {city:co.addr.city.trim(), street:co.addr.street.trim(), note:(co.addr.note || '').trim(), lat:co.addr.lat, lng:co.addr.lng};
  if (q.mode === 'pickup' && co.pick) body.pick = co.pick;
  if (q.mode === 'pickup' && UI.myLoc) body.me = {lat:r6(UI.myLoc.lat), lng:r6(UI.myLoc.lng)};
  if (q.mode === 'pickup' && co.serve === 'car') { body.car = {plate:co.car.plate.trim(), color:co.car.color.trim(), kind:co.car.kind.trim()}; S.car = body.car; }
  UI.proc = {msg:q.pay > 0 ? T('جاري تأكيد الدفع…', 'Confirming payment…') : T('جاري تأكيد الطلب…', 'Placing your order…')}; render();
  try {
    const r = await api('/orders', body, {timeout:20000});
    UI.proc = null;
    orderPlaced(r.order, q, r.acct);
    setStack([{p:'success', id:r.order.id}]); UI.tab = 'orders'; UI.seg = 'orders'; render();
    syncSoon(1500);
  } catch (e) {
    UI.proc = null;
    toast(errText(e));
    if (e.code === 'bad_customer') { signedOut(); return; }
    if (e.code === 'bad_pick') { co.pick = 0; }
    if (e.code === 'too_far' || e.code === 'need_pin') UI.co.locOk = false;
    if (e.code === 'pickup_far') { custSync(); openSheet({k:'far', id:S.branch}); return; }
    if (e.code === 'car_off') { UI.co.serve = 'in'; custSync(); }
    if (['price_changed', 'stock', 'paused', 'delivery_off', 'bad_code', 'no_points', 'no_balance', 'gift_used', 'not_here', 'below_min', 'too_far'].includes(e.code)) {
      if (e.code === 'bad_code') { UI.co.codeOk = false; UI.co.codeErr = T('كود الخصم غير صالح', 'This discount code is not valid'); }
      custSync();
    }
    render();
  }
}

/* an amount the customer types (gift card, wallet top-up): whole riyals; the chips and the pay button follow without a re-render */
function typedAmount(st, sumSel) {
  st.amt = st.amtx ? Number(st.amtx) : 0;
  $$('.amts .chip').forEach(c => c.classList.toggle('on', !st.amtx && Number(c.dataset.id) === st.amt));
  const ok = Number.isInteger(st.amt) && st.amt >= GIFT_MIN && st.amt <= GIFT_MAX;
  if (sumSel) { const s = $(sumSel); if (s) s.innerHTML = ok ? money2(st.amt) : ''; }
  syncBtns();
}

/* a product gift brought to the recipient: a real delivery order, paid by the sender, with the recipient's name, number and message.
   The sender keeps the order (and its code to pass on); the points are the sender's, like any order. */
async function sendGiftOrder() {
  const g = UI.g, p = PROD[g.pid];
  if (!p || !NEED.gphone()) return;
  const total = giftPrice(g), items = [{pid:g.pid, sel:defSel(p), qty:1, rw:null, gift:null}];
  const addr = {city:g.addr.city.trim(), street:g.addr.street.trim(), note:(g.addr.note || '').trim(), lat:g.addr.lat, lng:g.addr.lng};
  const sig = JSON.stringify([S.branch, g.pid, addr, g.phone, total]);
  if (!g.cid || g.sig !== sig) { g.cid = newDev().slice(0, 24); g.sig = sig; }
  const body = {cid:g.cid, mode:'delivery', branch:S.branch, serve:'', carrier:'', code:'', bal:0, payM:g.pay, total, items, addr,
    cust:{name:S.user.name, phone:S.user.phone}, gift:{name:g.name.trim(), phone:g.phone, msg:g.msg.trim()}, legacy:legacyBody()};
  UI.proc = {msg:T('جاري تأكيد الدفع…', 'Confirming payment…')}; render();
  try {
    const r = await api('/orders', body, {timeout:20000}), o = r.order;
    o.driver = o.driver || null;
    S.orders.unshift(o);
    let rec = null;
    if (applyAcct(r.acct)) rec = S.sent.find(x => x.id === o.gid);
    if (!rec) {   /* the phone still counts */
      if (o.earn) addPts(o.earn, {ar:`هدية ${o.no}`, en:`Gift ${o.no}`}, 'earn');
      rec = {id:o.gid || uid(), ts:Date.now(), to:g.phone, toName:g.name.trim(), kind:'item', pid:g.pid, amt:0, msg:g.msg.trim(), price:o.total, earn:o.earn || 0, oid:o.id, state:'del'};
      S.sent.unshift(rec);
    }
    note({ar:'تم إرسال الهدية', en:'Your gift was sent'}, {ar:`طلب ${o.no}: يوصلها مندوبنا إلى ${phoneFmt(g.phone)}.`, en:`Order ${o.no}: our driver brings it to ${phoneFmt(g.phone)}.`}, 'gift', {tab:'gifts', seg:'sent', sub:'item'});
    save(); UI.proc = null; UI.g = newG(); UI.gseg = 'sent'; UI.gsub = 'item'; UI.tab = 'gifts'; setStack([{p:'giftdone', id:rec.id}]); render();
    syncSoon(1500);
  } catch (e) {
    UI.proc = null; toast(errText(e));
    if (e.code === 'bad_customer') { signedOut(); return; }
    if (['price_changed', 'stock', 'paused', 'delivery_off'].includes(e.code)) custSync();
    render();
  }
}

/* a call about the account (top-up, redeem, gifts, cancel, rate): the account comes back with it */
async function acctCall(path, body, msg) {
  if (UI.proc) return null;
  UI.proc = {msg:msg || T('لحظات…', 'One moment…')}; render();
  try {
    const r = await api(path, body, {timeout:20000});
    UI.proc = null;
    if (r.acct) applyAcct(r.acct);
    if (r.order) mergeStatus(r.order);
    save();
    return r;
  } catch (e) {
    UI.proc = null; toast(errText(e));
    if (e.code === 'bad_customer') signedOut();
    else { if (['no_points', 'no_balance', 'gift_used', 'bad_state', 'not_found'].includes(e.code)) custSync(); render(); }
    return null;
  }
}
/* the server no longer knows this phone (signed out elsewhere, or the account was deleted): back to a guest */
function signedOut(msg) {
  clearAcct(); save();
  UI.sheet = null; setStack([]); UI.tab = 'home'; UI.auth = authInit(); UI.f.phone = ''; clearSignup();
  toast(msg || T('سجّل الدخول من جديد للمتابعة', 'Sign in again to continue'));
  render();
}

/* ---------- the menu changed (the admin edited it): tidy what pointed at the old one ----------
   A deleted product leaves the cart, a choice that no longer exists goes back to the first one,
   an open product sheet closes if the product is gone, and the gift picker moves to something that still exists. */
function afterCatalog(quiet) {
  const n = S.cart.length;
  S.cart = S.cart.filter(c => liveP(c.pid));
  S.cart.forEach(c => { c.sel = normSel(PROD[c.pid], c.sel); });
  if (UI.sheet && UI.sheet.k === 'product') {
    const p = liveP(UI.sheet.pid);
    if (!p || p.stock === false) { UI.sheet = null; if (!quiet) toast(T('لم يعد هذا المنتج متوفرًا', 'This product is no longer available')); }
    else UI.sheet.sel = normSel(p, UI.sheet.sel);
  }
  if (!liveP(UI.g.pid)) UI.g.pid = giftItems()[0] || UI.g.pid;
  if (!liveB(S.branch) && BRANCHES.length) { S.branch = BRANCHES[0].id; save(); }   /* the chosen branch was closed down */
  if (S.cart.length < n && !quiet) toast(T('أزلنا من السلة منتجًا لم يعد في القائمة', 'We took out of your cart a product that is no longer on the menu'));
  if (S.cart.length < n) save();
  UI.dirty = true;
}

/* ---------- actions (data-a) ---------- */
Object.assign(A, {
  /* navigation */
  tab(d) { UI.tab = d.id; setStack([]); UI.sheet = null; render(); },
  push(d) {
    if ((d.p === 'points' || d.p === 'rewards' || d.p === 'hist') && needLogin('points')) return;
    if (d.p === 'giftsend') { if (needLogin('gift')) return; UI.g = newG(); }
    if (d.p === 'topup') { if (needLogin('points')) return; UI.tp = newTp(); }
    if (d.p === 'hist') UI.hf = 'all';
    if (d.p === 'myprofile') UI.f.pname = S.user ? S.user.name : '';
    push({p:d.p, id:d.id});
  },
  back() { pop(); },
  home() { setStack([]); UI.tab = 'home'; UI.sheet = null; render(); },
  toMenu(d) { if (d) UI.cat = d.c || CATS[0].id; UI.f.q = ''; UI.sheet = null; setStack([{p:'menu'}]); render(); },
  toCheckout() { push({p:'checkout'}); },
  go(d) { UI.sheet = null; A.push(d); },
  setLang(d) { S.lang = d.id; applyLang(); save(); UI.sheet = null; render(); },
  news(d) { push({p:'article', id:d.id}); },
  invite() {
    const msg = T('جرب تطبيق واي! https://whyroasteryco.com', 'Try the Why! app https://whyroasteryco.com');
    try { if (navigator.clipboard) navigator.clipboard.writeText(msg).catch(() => {}); } catch (e) {}
    toast(T('تم نسخ رابط الدعوة', 'Invite link copied'));
  },
  bn(d) {
    const t = d.t;
    if (t === 'beans') { UI.cat = 'fil'; A.toMenu(); }
    else if (t === 'menu') { UI.cat = 'filter'; A.toMenu(); }
    else if (t === 'points') A.push({p:'points'});
    else if (t === 'gift') A.push({p:'giftsend'});
    else if (liveP(t)) A.product({id:t});
    else A.toMenu();
  },

  /* sign in, sign up, guest */
  openAuth(d) { UI.auth = authInit(d.m); UI.otp = ['', '', '', '', '']; openSheet({k:'auth'}); },
  login() { UI.after = UI.sheet && UI.sheet.why === 'order' ? 'cart' : null; A.openAuth({m:'login'}); },
  signup() { UI.after = UI.sheet && UI.sheet.why === 'order' ? 'cart' : null; A.openAuth({m:'signup'}); },
  authMode() { UI.auth = authInit(UI.auth.mode === 'login' ? 'signup' : 'login'); render(); },
  async sendOtp() {
    const a = UI.auth, mode = a.mode;
    if (mode === 'signup') {
      a.errs = signupErrors();
      const bad = Object.keys(a.errs);
      if (bad.length) {
        const first = ['phone', 'name', 'email', 'invite', 'birth', 'gender', 'terms'].find(k => a.errs[k]);
        UI.focus = {phone:'#ph', name:'#nm', email:'#em', invite:'#iv'}[first] || null;
        render();
        const el = $('.sheet .er'); if (el && el.scrollIntoView) el.scrollIntoView({block:'center'});
        return;
      }
      if (a.verified && a.verified === UI.f.phone) { A.finishSignup(); return; }
    } else if (!validPhone(UI.f.phone)) return;
    if (a.busy) return;
    a.busy = true; syncBtns();
    let via;
    try { via = await sendCode(UI.f.phone); }
    catch (e) { a.busy = false; toast(errText(e)); render(); return; }
    a.busy = false;
    UI.auth = Object.assign(authInit(mode), {step:'otp', secs:30, via}); UI.otp = ['', '', '', '', '']; UI.focus = '[data-otp="0"]'; render();
  },
  verify() { verifyOtp(); },
  authBack() { UI.auth = authInit(UI.auth.mode); UI.otp = ['', '', '', '', '']; render(); },
  async resend() {
    const a = UI.auth;
    if (a.busy) return;
    a.busy = true;
    try { a.via = await sendCode(UI.f.phone); }
    catch (e) { a.busy = false; toast(errText(e)); return; }
    a.busy = false; a.secs = 30; a.err = ''; a.bad = false; UI.otp = ['', '', '', '', '']; UI.focus = '[data-otp="0"]';
    toast(T('تم إرسال رمز جديد', 'A new code was sent')); render();
  },
  guest() { S.guest = true; S.session = false; save(); UI.tab = 'home'; render(); },
  welGo() { UI.welDone = true; UI.intro.i = 0; render(); },   /* 0.7.13: the welcome screen: to the slides, or past them */
  welSkip() { UI.welDone = true; UI.intro.i = 2; render(); },
  /* the code was checked already (a number we did not know): the details are sent with it */
  async finishSignup() {
    if (Object.keys(signupErrors()).length || UI.auth.busy) return;
    try { signedIn(await login(UI.f.phone, UI.auth.code || '', true)); }
    catch (e) {
      if (e.code === 'bad_otp') { UI.auth = Object.assign(authInit('signup'), {step:'otp', secs:30}); UI.otp = ['', '', '', '', '']; UI.focus = '[data-otp="0"]'; }
      toast(errText(e)); render();
    }
  },
  /* the sign-up form */
  authEdit(d, t) {
    const k = t && t.dataset && t.dataset.bind ? t.dataset.bind.split('.')[1] : '';
    if (!UI.auth.errs[k]) return;
    delete UI.auth.errs[k];
    const box = t.closest('.fl'); if (box) { box.classList.remove('er'); const em = box.nextElementSibling; if (em && em.classList.contains('em')) em.remove(); }
  },
  birthSet(d, t) { const box = t.closest('.fl'); if (box) box.classList.toggle('has', !!t.value); A.authEdit(d, t); },
  gender(d) { UI.f.gender = d.v; delete UI.auth.errs.gender; render(); },
  tg(d) { UI.f[d.k] = !UI.f[d.k]; delete UI.auth.errs[d.k]; render(); },
  showTerms() { openSheet({k:'terms'}); },
  termsBack() { openSheet({k:'auth'}); },
  logout() {
    UI.dlg = {t:T('تسجيل الخروج', 'Log out'), b:T('هل أنت متأكد من تسجيل الخروج؟ يمكنك العودة بنفس الرقم والعثور على نقاطك وطلباتك.', 'Are you sure you want to log out? Log back in with the same number to find your points and orders.'), ok:T('تسجيل الخروج', 'Log out'), danger:true,
      fn() { pushUnsubscribe(); api('/my/logout', {}).catch(() => {}); clearAcct(); save(); UI.sheet = null; setStack([]); UI.tab = 'home'; UI.auth = authInit(); UI.f.phone = ''; clearSignup(); }};
    render();
  },
  deleteAcct() {
    UI.dlg = {t:T('حذف الحساب نهائيًا', 'Delete the account for good'), b:T('سيُحذف حسابك مع نقاطك ورصيد محفظتك والهدايا التي وصلتك، ولا يمكن التراجع. تبقى فواتير طلباتك السابقة لدى المتجر بدون اسمك ورقمك.', 'Your account goes with your points, wallet balance and the gifts you received, and this cannot be undone. The store keeps the invoices of your past orders without your name or number.'), ok:T('حذف نهائيًا', 'Delete for good'), danger:true,
      async fn() {
        const r = await acctCall('/my/delete', {}, T('جاري حذف الحساب…', 'Deleting the account…'));
        if (!r) return;
        pushUnsubscribe();
        clearAcct(); save(); UI.sheet = null; setStack([]); UI.tab = 'home'; UI.auth = authInit(); UI.f = newF();
        toast(T('تم حذف حسابك', 'Your account was deleted')); render();
      }};
    render();
  },
  saveName() {
    const n = (UI.f.pname || '').trim(); if (n.length < 2 || !S.user) return;
    S.user.name = n; save(); toast(T('تم حفظ التغييرات', 'Changes saved')); render(); syncSoon(300);
  },

  /* menu and product sheet */
  cat(d) { UI.cat = d.id; UI.f.q = ''; delete UI.sc['pg-' + (UI.stack.length - 1)]; render(); },
  search() { const m = $('#menuin'); if (m) m.innerHTML = menuBody(); const c = $('#clr'); if (c) c.hidden = !UI.f.q; },
  clearSearch() { UI.f.q = ''; UI.focus = '.srch input'; render(); },
  product(d) {
    const p = liveP(d.id); if (!p) return;
    if (p.stock === false) { toast(T('غير متوفر حاليًا', 'Currently unavailable')); return; }
    if (offAt(p) && (CAT[p.cat] || {}).kind !== 'retail') { toast(T(`غير متوفر في ${L(BR[S.branch])}، اختر فرعًا آخر`, `Not available at ${L(BR[S.branch])}. Pick another branch`)); return; }
    openSheet({k:'product', pid:p.id, sel:defSel(p), qty:1});
  },
  fav(d) {   /* 0.7.18: a heart on the product page; the menu shows them first under «المفضلة» (kept on this phone) */
    const was = isFav(d.id);
    S.fav = (S.fav || []).filter(x => x !== d.id);
    if (!was) S.fav.unshift(d.id);
    save(); toast(was ? T('أزلناه من المفضلة', 'Removed from favourites') : T('أضفناه إلى المفضلة', 'Added to favourites')); render();
  },
  opt(d) {
    const s = UI.sheet, G = OPT[d.g];
    if (G.type === 'check') { const a = s.sel[d.g] || []; const i = a.indexOf(d.id); if (i >= 0) a.splice(i, 1); else a.push(d.id); s.sel[d.g] = a; }
    else s.sel[d.g] = d.id;
    render();
  },
  sq(d) { const s = UI.sheet; s.qty = Math.max(1, Math.min(20, s.qty + Number(d.d))); render(); },
  sadd() { const s = UI.sheet; addCart(s.pid, s.sel, s.qty); UI.sheet = null; toast(T('تمت الإضافة إلى السلة', 'Added to cart')); render(); },
  pickBranch(d) { UI.sheet = null; confirmBranch(d.id); },

  /* cart and checkout */
  cq(d) { const c = S.cart.find(x => x.uid === d.id); if (!c) return; c.qty = Math.max(1, Math.min(20, c.qty + Number(d.d))); save(); render(); },
  crm(d) { S.cart = S.cart.filter(x => x.uid !== d.id); save(); render(); },
  clearCart() {
    UI.dlg = {t:T('تفريغ السلة', 'Empty the cart'), b:T('سيتم حذف كل ما في السلة.', 'Everything in your cart will be removed.'), ok:T('تفريغ', 'Empty'), danger:true, fn() { S.cart = []; save(); }};
    render();
  },
  mode(d) {
    if (d.id === 'car') { UI.co.mode = 'pickup'; UI.co.serve = 'car'; }
    else { UI.co.mode = d.id; if (d.id === 'pickup' && UI.co.serve === 'car') UI.co.serve = 'in'; }
    render();
  },
  carrier(d) { UI.co.carrier = d.id; render(); },
  serve(d) { UI.co.serve = d.id; render(); },
  payM(d) { UI.co.pay = d.id; render(); },
  useBal() { UI.co.useBal = !UI.co.useBal; render(); },
  farDel() { UI.co.mode = 'delivery'; UI.sheet = null; if (UI.stack.some(p => p.p === 'checkout')) render(); else { setStack([{p:'cart'}]); render(); } },
  toFav() {   /* 0.7.20: the heart at the top of the home page: the menu opens on «المفضلة» */
    if (!favList().length) { toast(T('ما عندك منتجات مفضلة بعد، اضغط القلب في صفحة أي منتج', 'No favourites yet: tap the heart on a product page')); return; }
    UI.cat = 'fav'; UI.f.q = ''; UI.sheet = null; setStack([{p:'menu'}]); render();
  },
  locYes() { UI.co.locOk = true; toast(T('تم تأكيد موقع التوصيل', 'Delivery spot confirmed')); render(); },
  useLoc(d) {
    const key = (d && d.k) || 'co', addr = key === 'gift' ? UI.g.addr : UI.co.addr;
    if (!navigator.geolocation) { toast(T('الموقع غير مدعوم في هذا المتصفح، أدخل العنوان يدويًا', 'Location is not supported here. Enter the address by hand')); return; }
    navigator.geolocation.getCurrentPosition(
      p => { addr.lat = r6(p.coords.latitude); addr.lng = r6(p.coords.longitude); if (key === 'co') UI.co.locOk = false; mapCenterOn(key, addr.lat, addr.lng, 17); toast(T('تم تحديد موقعك، حرّك الخريطة لو تبغى تعدّله', 'Your location is set. Move the map to adjust it')); render(); },
      () => toast(T('تعذّر تحديد موقعك، أدخل العنوان يدويًا', 'Could not get your location. Enter the address by hand')),
      {enableHighAccuracy:true, timeout:10000, maximumAge:60000});
  },
  applyCode() {
    const c = (UI.co.code || '').trim().toUpperCase();
    const cd = SRV.codes[c];
    if (cd && cd.on) { UI.co.codeOk = true; UI.co.codeErr = ''; UI.co.code = c; toast(T('تم تطبيق الخصم', 'Discount applied')); }
    else { UI.co.codeOk = false; UI.co.codeErr = c ? T('كود الخصم غير صحيح', 'Invalid discount code') : T('أدخل كود الخصم أولاً', 'Enter a discount code first'); }
    render();
  },
  placeOrder() {
    if (UI.proc) return;
    if (!S.session) { UI.after = 'cart'; openSheet({k:'login', why:'order'}); return; }
    const q = calc(), co = UI.co;
    if (!q.lines.length) return;
    if (q.mode === 'delivery' && !deliveryOn()) { toast(T('التوصيل متوقف مؤقتًا', 'Delivery is paused for now')); return; }
    if (q.mode !== 'ship' && !isOpen(BR[S.branch])) { toast(T('الفرع مغلق حاليًا، إختر فرعًا آخر', 'This branch is closed. Pick another one')); return; }
    if (q.mode !== 'pickup' && !(q.mode === 'delivery' && co.addr.lat != null) && (!co.addr.city.trim() || !co.addr.street.trim())) { toast(q.mode === 'ship' ? T('أكمل عنوان الشحن', 'Complete the shipping address') : T('أكمل عنوان التوصيل', 'Complete the delivery address')); return; }
    if (q.ptsCost > S.pts) { toast(T('نقاطك لا تكفي', 'Not enough points')); return; }
    if (q.lines.some(l => l.p.stock === false)) { toast(T('بعض الأصناف لم تعد متوفرة، عدّل السلة', 'Some items are no longer available. Update your cart')); return; }
    if (q.mode !== 'ship' && q.lines.some(l => offAt(l.p))) { toast(T('بعض الأصناف غير متوفرة في هذا الفرع، غيّر الفرع أو احذفها', 'Some items are not available at this branch. Change the branch or remove them')); return; }
    if (q.mode === 'delivery') { const why = deliveryBlock(q.sub, co.addr, BR[S.branch]); if (why) { toast(why); return; } }
    if (q.mode === 'pickup' && pickupKm() && hasLoc(BR[S.branch])) {   /* 0.7.20: only from near the branch */
      if (!co.locFresh) { UI.proc = {msg:T('جاري تحديد موقعك…', 'Finding you…')}; render(); whereAmI(ok => { UI.proc = null; if (!ok) { toast(T('اسمح للتطبيق بالموقع لتطلب من الفرع', 'Allow location to order from the branch')); render(); return; } co.locFresh = true; A.placeOrder(); }); return; }
      co.locFresh = false;
      if (pickupFar(BR[S.branch])) { openSheet({k:'far', id:S.branch}); return; }
    }
    if (q.mode === 'pickup' && co.serve === 'car') {
      if (!carOn()) { co.serve = 'in'; toast(T('التوصيل إلى السيارة غير متاح الآن', 'Bringing orders to the car is not available now')); render(); return; }
      if (!co.car.kind.trim() || !co.car.color.trim() || co.car.plate.trim().length < 2) { toast(T('أكمل نوع السيارة ولونها ورقم اللوحة', 'Fill in the car, its colour and the plate number')); return; }
    }
    /* 0.7.18: the customer says yes to the spot before the order goes */
    if (q.mode === 'delivery' && !co.locOk) {
      const b = deliveryBase(BR[S.branch]), d = co.addr.lat != null && hasLoc(b) ? kmBetween(co.addr, b) : null;
      UI.dlg = {t:T('هل تريد التوصيل إلى هذا الموقع؟', 'Deliver to this spot?'),
        b:`${esc([co.addr.city.trim(), co.addr.street.trim()].filter(Boolean).join('، ') || T('الموقع على الخريطة', 'The spot on the map'))}${co.addr.lat != null ? '' : `<br>${T('لم تحدد الموقع على الخريطة', 'You did not set the spot on the map')}`}${d != null ? `<br>${T(`يبعد عن الفرع ${d.toFixed(1)} كم تقريبًا`, `About ${d.toFixed(1)} km from the branch`)}` : ''}`,
        ok:T('تأكيد الموقع', 'Confirm the spot'), no:T('تعديل الموقع', 'Change the spot'),
        fn() { UI.co.locOk = true; A.placeOrder(); }};
      render(); return;
    }
    if (q.mode === 'pickup' && co.pick && !pickSlots(BR[S.branch]).includes(co.pick)) {   /* the time passed while the page was open */
      const sl = pickSlots(BR[S.branch]); co.pick = sl[0] || 0;
      toast(T('تغيّرت الأوقات المتاحة، راجع وقت الاستلام', 'The times available changed. Check the pickup time')); render(); return;
    }
    if (q.mode !== 'pickup') co.pick = 0;
    sendOrder();
  },
  pickMode(d) { const sl = pickSlots(BR[S.branch]); UI.co.pick = d.id === 'later' ? (sl.includes(UI.co.pick) ? UI.co.pick : sl[0] || 0) : 0; render(); },
  pickSet() { const t = Number(UI.co.pickx); if (t) UI.co.pick = t; },

  /* orders */
  seg(d) { UI.seg = d.id; render(); },
  cancelOrder(d) {
    const o = ORD(d.id); if (!o || o.st !== 0 || o.rej || o.fin) return;
    UI.dlg = {t:T('إلغاء الطلب', 'Cancel the order'), b:T(`هل تريد إلغاء الطلب ${o.no}؟ ترجع إلى حسابك النقاط والرصيد المستخدمان، ويُرد المدفوع إلى وسيلة الدفع.`, `Cancel order ${o.no}? The points and balance you used come back, and your payment is refunded.`), ok:T('إلغاء الطلب', 'Cancel order'), danger:true,
      async fn() {
        const r = await acctCall('/my/cancel', {id:o.id}, T('جاري إلغاء الطلب…', 'Cancelling the order…'));
        if (r) { toast(T('تم إلغاء طلبك', 'Your order was cancelled')); render(); }
      }};
    render();
  },
  async pushOn() {
    try { await pushSubscribe('/my/push'); toast(T('تم تفعيل الإشعارات على هذا الجهاز', 'Notifications are on for this device')); }
    catch (e) { toast(errText(e)); }
    render();
  },
  async pushOff() { await pushUnsubscribe(); toast(T('تم إيقاف الإشعارات', 'Notifications are off')); render(); },
  printInv(d) { const o = ORD(d.id); if (o && o.inv) printHTML(`<div class="paper">${invoiceHTML(o)}</div>`); },
  rateStar(d) { UI.rate = {id:d.id, s:Number(d.s), c:UI.rate.id === d.id ? UI.rate.c : ''}; render(); },
  async rateSend(d) {
    const r = UI.rate; if (r.id !== d.id || !r.s) return;
    const x = await acctCall('/my/rate', {id:d.id, stars:r.s, note:(r.c || '').trim()}, T('جاري إرسال التقييم…', 'Sending your rating…'));
    if (x) { UI.rate = {id:null, s:0, c:''}; toast(T('شكرًا لتقييمك', 'Thank you for your rating')); render(); }
  },
  async iAmHere(d) {
    const o = ORD(d.id); if (!o || o.serve !== 'car' || o.fin || o.rej) return;
    if (o.here && Date.now() - o.here < 60000) { toast(T('أبلغناهم قبل قليل', 'They were told a moment ago')); return; }
    const x = await acctCall('/my/here', {id:o.id}, T('جاري إبلاغ الفرع…', 'Telling the branch…'));
    if (x) { toast(T('أبلغنا الفرع إنك وصلت', 'The branch knows you are here')); render(); }
  },
  trackOrder(d) { UI.tab = 'orders'; setStack([{p:'order', id:d.id}]); render(); },
  noteGo(d) {
    const n = S.notifs.find(x => x.id === d.id); if (!n) return;
    S.notifs.forEach(x => { x.read = true; }); save();   /* the list was seen, as when leaving it with back */
    if (!goTarget(noteTarget(n))) render();
  },
  async confirmPickup(d) {
    const o = ORD(d.id); if (!o || o.mode !== 'pickup' || o.st !== 2 || UI.busy) return;
    UI.busy = true;
    try { const r = await api('/my/collect', {id:o.id}); mergeStatus(r.order); save(); }
    catch (e) { toast(errText(e)); if (e.code === 'bad_state') custSync(); }
    UI.busy = false; render();
  },
  reorder(d) {
    const o = ORD(d.id); if (!o) return;
    let left = 0;
    o.items.forEach(it => {
      if (it.rw || it.gift) return;
      const p = liveP(it.pid);
      if (p && p.stock !== false) addCart(it.pid, normSel(p, it.sel), it.qty); else left++;
    });
    toast(left ? T('أضفنا المتوفر فقط، بعض الأصناف لم تعد متوفرة', 'Only what is available was added; some items are no longer offered') : T('تمت إضافة الأصناف إلى السلة', 'Items added to your cart'));
    setStack([{p:'cart'}]); render();
  },

  /* points */
  tierInfo(d) { openSheet({k:'member', id:d.id}); },
  histF(d) { UI.hf = d.id; render(); },
  /* the wallet top-up: a chip or a typed amount, then the payment (a prototype, like every payment for now) */
  tpAmt(d) { UI.tp.amt = Number(d.id); UI.tp.amtx = ''; render(); },
  tpAmtX() { typedAmount(UI.tp, '#tpsum'); },
  tpPayM(d) { UI.tp.pay = d.id; render(); },
  async tpPay() {
    if (!NEED.tpamt()) return;
    const t = UI.tp, amt = t.amt;
    if (!t.cid || t.sig !== amt) { t.cid = newDev().slice(0, 24); t.sig = amt; }   /* the same attempt twice tops up once */
    const r = await acctCall('/my/topup', {amt, cid:t.cid, payM:t.pay}, T('جاري تأكيد الدفع…', 'Confirming payment…'));
    if (!r) return;
    note({ar:'تم شحن محفظتك', en:'Your wallet was topped up'}, {ar:`أضفنا ${amt} ر.س، رصيدك الآن ${fmt2(S.bal)} ر.س.`, en:`We added ${amt} SAR; your balance is now ${fmt2(S.bal)} SAR.`}, 'wallet', {p:'topup'});
    save(); UI.tp = newTp(); pop();
    toast(T(`تمت إضافة ${amt} ر.س إلى محفظتك`, `${amt} SAR added to your wallet`)); render();
  },
  redeem(d) {
    if (needLogin('points')) return;
    const r = RW(d.id); if (!r) return;
    if (r.pid && !(liveP(r.pid) && liveP(r.pid).stock !== false)) { toast(T('غير متوفر حاليًا', 'Currently unavailable')); return; }
    if (S.pts - cartPts() < r.pts) { toast(T('نقاطك لا تكفي', 'Not enough points')); return; }
    if (r.credit) {
      acctCall('/my/redeem', {id:r.id}).then(x => { if (x) { toast(T(`تمت إضافة ${x.credit} ر.س إلى محفظتك`, `${x.credit} SAR added to your wallet`)); render(); } });
      return;
    } else {
      addCart(r.pid, defSel(PROD[r.pid]), 1, {rw:r.id});
      toast(T('تمت الإضافة إلى السلة، وتخصم النقاط عند إتمام الطلب', 'Added to cart. Points are deducted when you place the order'));
    }
    render();
  },

  /* gifts */
  gseg(d) { UI.gseg = d.id; render(); },
  gsub(d) { UI.gsub = d.id; render(); },
  async gUse(d) {
    const g = S.gifts.find(x => x.id === d.id); if (!g || g.state !== 'new') return;
    if (g.kind === 'card') {
      const r = await acctCall('/my/gift', {op:'claim', id:g.id}); if (!r) return;
      const fr = txt(g.from) || T('صديق', 'a friend');
      note({ar:'تمت إضافة رصيد إلى محفظتك', en:'Credit added to your wallet'}, {ar:`${r.amt} ر.س من ${fr}.`, en:`${r.amt} SAR from ${fr}.`}, 'wallet', {p:'topup'});
      save(); toast(T(`تمت إضافة ${r.amt} ر.س إلى رصيدك`, `${r.amt} SAR added to your balance`));
    } else {
      if (S.cart.some(c => c.gift === g.id)) return;
      const p = liveP(g.pid);
      if (!p || p.stock === false) { toast(T('هذا المنتج غير متوفر حاليًا', 'This product is not available right now')); return; }
      addCart(g.pid, defSel(p), 1, {gift:g.id}); toast(T('تمت إضافة الهدية إلى السلة', 'Gift added to your cart'));
    }
    render();
  },
  gType(d) { UI.g.type = d.id; render(); },
  gItem(d) { UI.g.pid = d.id; render(); },
  gAmt(d) { UI.g.amt = Number(d.id); UI.g.amtx = ''; render(); },
  gAmtX() { typedAmount(UI.g); },
  gDel(d) { UI.g.del = d.id === '1' && deliveryOn(); render(); },
  gNext() { const g = UI.g; if (g.step === 1 && !NEED.gstep1()) return; if (g.step === 2 && !NEED.gphone()) return; g.step = Math.min(3, g.step + 1); render(); },
  gPayM(d) { UI.g.pay = d.id; render(); },
  /* a gift card or a product to another number: the server keeps it until that number signs in (a trial payment until the gateway comes) */
  async gPay() {
    if (giftDel()) { sendGiftOrder(); return; }
    const g = UI.g, price = giftPrice(g);
    const body = {op:'send', to:g.phone, kind:g.type, name:g.name.trim(), msg:g.msg.trim(), payM:g.pay, total:price};
    if (g.type === 'card') body.amt = g.amt; else body.pid = g.pid;
    const sig = JSON.stringify(body);
    if (!g.cid || g.sig !== sig) { g.cid = newDev().slice(0, 24); g.sig = sig; }
    body.cid = g.cid;
    const r = await acctCall('/my/gift', body, T('جاري تأكيد الدفع…', 'Confirming payment…'));
    if (!r) return;
    note({ar:'تم إرسال الهدية', en:'Your gift was sent'}, {ar:`تصل إلى ${phoneFmt(g.phone)} في تبويب الهدايا.`, en:`It reaches ${phoneFmt(g.phone)} in the Gifts tab.`}, 'gift', {tab:'gifts', seg:'sent', sub:r.gift.kind});
    save(); UI.g = newG(); UI.gseg = 'sent'; UI.gsub = r.gift.kind; UI.tab = 'gifts'; setStack([{p:'giftdone', id:r.gift.id}]); render();
  },
  giftsBack() { setStack([]); UI.tab = 'gifts'; render(); },

  /* branches */
  selBranch(d) {
    const b = BR[d.id]; if (!b) return;
    if (hasLoc(b)) mapCenterOn('br', b.lat, b.lng, Math.max(14, (MAPS.br || {}).z || 14));
    confirmBranch(d.id);
  },
  nearMe(quiet) {
    UI.locTried = true;   /* asked once each time the app opens; a "no" is not asked again */
    if (!navigator.geolocation) { if (quiet !== true) toast(T('تحديد الموقع غير مدعوم في هذا المتصفح', 'Location is not supported in this browser')); return; }
    UI.locating = true;
    navigator.geolocation.getCurrentPosition(
      p => { UI.locating = false; UI.myLoc = {lat:p.coords.latitude, lng:p.coords.longitude}; const geo = BRANCHES.filter(hasLoc); if (MAPS.br) MAPS.br.fit = [UI.myLoc].concat(geo.map(b => ({lat:b.lat, lng:b.lng}))); render(); },
      () => { UI.locating = false; if (quiet !== true) toast(T('تعذّر تحديد موقعك، اسمح للتطبيق بالموقع ثم حاول مرة أخرى', 'Could not find you. Allow location and try again')); },
      {enableHighAccuracy:false, timeout:12000, maximumAge:300000});
  }
});

/* ---------- events of the customer page ---------- */
document.addEventListener('input', e => { if (e.target.dataset.otp !== undefined) otpInput(e.target); });
document.addEventListener('focusin', e => { const t = e.target; if (t.dataset && t.dataset.otp !== undefined && t.select) t.select(); });
document.addEventListener('keydown', e => {
  const t = e.target;
  if (t.dataset && t.dataset.otp !== undefined && e.key === 'Backspace' && !t.value) {
    const i = Number(t.dataset.otp);
    if (i > 0) { const p = $(`[data-otp="${i - 1}"]`); if (p) { p.value = ''; UI.otp[i - 1] = ''; p.focus(); } e.preventDefault(); }
  }
  if (e.key === 'Enter' && t.classList && t.classList.contains('br')) { e.preventDefault(); A.selBranch(t.dataset); }
});
/* 0.7.19: the customer says yes to the branch he picked (on the list, on the map or in the checkout) */
function whereAmI(cb) {   /* 0.7.20: the phone's place, for the pickup range */
  if (!navigator.geolocation) { cb(false); return; }
  navigator.geolocation.getCurrentPosition(p => { UI.myLoc = {lat:p.coords.latitude, lng:p.coords.longitude}; cb(true); }, () => cb(false), {enableHighAccuracy:true, timeout:12000, maximumAge:120000});
}
function confirmBranch(id) {
  const b = BR[id]; if (!b) return;
  if (pickupKm() && hasLoc(b)) {   /* 0.7.20: too far to order from it: he may still browse */
    if (!UI.myLoc && !UI.locAsked) { UI.locAsked = true; whereAmI(() => confirmBranch(id)); return; }
    if (pickupFar(b)) { S.branch = id; save(); openSheet({k:'far', id}); return; }
  }
  if (id === S.branch) { render(); return; }
  const d = UI.myLoc && hasLoc(b) ? kmBetween(UI.myLoc, b) : null;
  UI.dlg = {t:T(`هل تريد الطلب من ${L(b)}؟`, `Order from ${L(b)}?`),
    b:`${esc(L(b.addr))}${d != null ? `<br>${T(`يبعد عنك ${d.toFixed(1)} كم`, `${d.toFixed(1)} km from you`)}` : ''}<br>${esc(T('أوقات العمل', 'Hours'))}: ${esc(hoursText(b))}`,
    ok:T('تأكيد الفرع', 'Confirm the branch'), no:T('اختيار فرع آخر', 'Pick another'),
    fn() { S.branch = id; save(); toast(T('تم اختيار الفرع', 'Branch selected')); }};
  render();
}
let bnWrap = 0;
/* 0.7.21: on the copy of the first banner, go to the real first one with no movement at all: the snapping is switched off
   for that one frame (a scrollTo with 'instant' still slid back on some iPhones, which looked like a long wait) */
function bnHome(t) {
  t.style.scrollSnapType = 'none'; t.style.scrollBehavior = 'auto';
  t.scrollLeft = 0;
  requestAnimationFrame(() => { t.style.scrollSnapType = ''; t.style.scrollBehavior = ''; });
  UI.bn = 0; $$('#bnd i').forEach((d, k) => d.classList.toggle('on', k === 0));
}
document.addEventListener('scroll', e => {
  const t = e.target; if (!t || !t.id) return;
  if (t.id === 'bn' && t.firstElementChild) {   /* 0.7.18: after the last banner comes the first again (a copy of it, then a jump back) */
    const n = bannersLive().length, w = t.firstElementChild.offsetWidth + 12, raw = Math.round(Math.abs(t.scrollLeft) / w), i = n ? raw % n : 0;
    if (i !== UI.bn) { UI.bn = i; $$('#bnd i').forEach((d, k) => d.classList.toggle('on', k === i)); }
    clearTimeout(bnWrap);
    if (n > 1 && raw >= n) bnWrap = setTimeout(() => { if (Math.round(Math.abs(t.scrollLeft) / w) >= n) bnHome(t); }, 120);
  }
  if (t.id === 'slides' && t.clientWidth) {
    const i = Math.max(0, Math.min(2, Math.round(Math.abs(t.scrollLeft) / t.clientWidth)));
    if (i !== UI.intro.i) { UI.intro.i = i; updIntro(); }
  }
}, true);

/* the branch list is a bottom sheet: drag the handle to resize it, tap it to expand or collapse */
let drag = null;
document.addEventListener('pointerdown', e => {
  const g = e.target.closest('#bsgrab'); if (!g) return;
  const sh = $('#bsheet'); if (!sh) return;
  drag = {y:e.clientY, h:sh.offsetHeight, sh, max:Math.max(200, $('#view').offsetHeight - 190), moved:false};
  if (g.setPointerCapture) { try { g.setPointerCapture(e.pointerId); } catch (x) {} }
});
document.addEventListener('pointermove', e => {
  if (!drag) return;
  const dy = drag.y - e.clientY; if (Math.abs(dy) > 4) drag.moved = true;
  const h = Math.max(150, Math.min(drag.max, drag.h + dy));
  drag.sh.style.setProperty('--bh', h + 'px'); UI.bsh = h;
});
const endDrag = () => {
  if (!drag) return;
  if (!drag.moved) { const big = drag.h > drag.max * .8; UI.bsh = big ? null : drag.max; if (big) drag.sh.style.removeProperty('--bh'); else drag.sh.style.setProperty('--bh', drag.max + 'px'); }
  drag = null;
};
document.addEventListener('pointerup', endDrag);
document.addEventListener('pointercancel', endDrag);

/* ---------- timers ---------- */
setInterval(() => $$('[data-ago]').forEach(el => { el.textContent = ago(Number(el.dataset.ago)); }), 15000);
setInterval(() => {
  const a = UI.auth;
  if (UI.sheet && UI.sheet.k === 'auth' && a.step === 'otp' && a.secs > 0) {
    a.secs--;
    const cd = $('#cd'); if (cd) cd.textContent = '0:' + pad2(a.secs);
    if (a.secs === 0) { const r = $('#resend'); if (r) r.innerHTML = `<button class="btn text" data-a="resend">${T('إعادة إرسال الرمز', 'Resend code')}</button>`; }
  }
}, 1000);
setInterval(() => {   /* the banners move on by themselves, round and round: the last one is followed by the first */
  const bn = $('#bn'); if (!bn || !bn.firstElementChild || UI.sheet || UI.dlg || UI.proc || UI.stack.length || UI.bnHold > Date.now()) return;
  const n = bannersLive().length; if (n < 2) return;
  const w = bn.firstElementChild.offsetWidth + 12, at = Math.round(Math.abs(bn.scrollLeft) / w);
  if (at >= n) bnHome(bn);   /* still on the copy: back to the real first one before moving on */
  const next = Math.min(n, (at >= n ? 0 : at) + 1);   /* n is the copy of the first one */
  bn.scrollTo({left:(S.lang === 'ar' ? -1 : 1) * next * w, behavior:'smooth'});
  if (next === n) { clearTimeout(bnWrap); bnWrap = setTimeout(() => { if (Math.round(Math.abs(bn.scrollLeft) / w) >= n - 0.5) bnHome(bn); }, 700); }
}, 3000);   /* 0.7.22: every 3 seconds */
document.addEventListener('pointerdown', e => { if (e.target.closest && e.target.closest('#bn')) UI.bnHold = Date.now() + 4000; }, true);   /* a finger on them: wait a little */

/* ---------- boot ---------- */
/* where a notification leads. Older ones (from before they kept it) are read from their words and icon. */
function noteTarget(n) {
  if (n.go) return n.go;
  const t = `${(n.t && n.t.ar) || ''} ${(n.t && n.t.en) || ''}`, m = t.match(/#\d+/);
  const o = m && S.orders.find(x => String(x.no).replace(/\u200e/g, '') === m[0]);
  if (o) return {p:'order', id:o.id};
  if (n.ico === 'gift') return {tab:'gifts', seg:/وصلتك|sent you|received/.test(t) ? 'recv' : 'sent'};
  if (n.ico === 'wallet') return {p:'topup'};
  if (n.ico === 'star') return {p:'points'};
  return null;
}
function goTarget(g) {
  if (!g) return false;
  UI.sheet = null;
  if (g.p === 'order') {
    if (S.orders.some(o => o.id === g.id)) A.trackOrder({id:g.id}); else { UI.tab = 'orders'; setStack([]); render(); }
    return true;
  }
  if (g.tab === 'gifts') { UI.tab = 'gifts'; UI.gseg = g.seg === 'sent' ? 'sent' : 'recv'; if (g.sub === 'card' || g.sub === 'item') UI.gsub = g.sub; setStack([]); render(); return true; }
  if (g.p === 'points' || g.p === 'topup') { push({p:g.p}); return true; }
  return false;
}
/* a phone notification's link: #o=<order>  #g=recv.card | sent.item  #p=points */
function goHash(h) {
  const m = /^#([ogp])=([\w.-]{1,64})$/.exec(h || '');
  if (!m) return false;
  if (m[1] === 'o') return goTarget({p:'order', id:m[2]});
  if (m[1] === 'g') { const [seg, sub] = m[2].split('.'); return goTarget({tab:'gifts', seg, sub}); }
  return goTarget({p:m[2]});
}
function boot() {
  applyLang(); render(); custSync(); pushInit(S.session ? '/my/push' : null);
  if (location.hash) { const h = location.hash; history.replaceState(null, '', location.pathname + location.search); goHash(h); }
  if (navigator.serviceWorker) {
    navigator.serviceWorker.addEventListener('message', e => { if (e.data && e.data.t === 'go') goHash(e.data.hash); });
    if (navigator.serviceWorker.startMessages) navigator.serviceWorker.startMessages();
  }
}
