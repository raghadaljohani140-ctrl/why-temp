"""Build deploy/menu/why-menu.json: Why!'s real menu, for  why_server.py importmenu  (install.sh adds it once).

Where it comes from (Nov 2026):
  - the items, their Arabic descriptions and their photos: the café's page on Keeta (screenshots; the photos are cut by
    tools/menu_photos.py into assets/menu/)
  - price, calories and English name: the café's own menu board in the shop, for the items on it ("board"). The board
    is two years old; Keeta's prices are about 2 SAR higher than it. Items that are not on the board keep Keeta's price
    ("keeta"): the café checks those in MANAGEMENT.
  - espresso and macchiato are on the board but not on Keeta: no photo yet (the drawing shows until one is added);
    the hot Spanish latte uses the latte photo, as Keeta itself uses one photo for latte, cappuccino and flat white.
  - left out: board items Keeta no longer has (cola brew, the premium crop, maritozzi, mango cheesecake, San Sebastian
    tiramisu); the café adds them back in MANAGEMENT if they are still sold.
The first import also takes the sample products of the first menu off (as the admin's delete does: old orders keep
them), drops the sample matcha category once it is empty, and moves the loyalty rewards that used a sample product to
the real one.

usage: python3 tools/build_menu.py
"""
import base64, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PHOTOS = ROOT / "assets" / "menu"
OUT = ROOT / "deploy" / "menu" / "why-menu.json"

CATS = [
    {"key": "hot", "id": "hot", "ar": "المشروبات الساخنة", "en": "Hot drinks", "kind": "drink"},
    {"key": "cold", "id": "cold", "ar": "المشروبات الباردة", "en": "Cold drinks", "kind": "drink"},
    {"key": "drip", "id": "filter", "ar": "قهوة مقطرة", "en": "Drip coffee", "kind": "drink"},
    {"key": "sandwiches", "ar": "الساندويتشات", "en": "Sandwiches", "kind": "food"},
    {"key": "sweet", "id": "sweet", "ar": "الحلويات", "en": "Desserts", "kind": "food"},
]

D = lambda ar, en: {"ar": ar, "en": en}
# key, category, Arabic, English, price, calories, description, photo, drawing, colour, price from
PRODUCTS = [
    ("espresso", "hot", "اسبريسو", "Espresso", 11, 2, None, None, "espresso", "#8A5232", "board"),
    ("macchiato", "hot", "ميكاتو", "Macchiato", 14, 6, None, None, "espresso", "#A0683C", "board"),
    ("americano", "hot", "امريكانو", "Americano", 14, 2, D("جرعة من قهوة الإسبريسو يضاف إليها الماء", "A shot of espresso topped up with water"), "americano", "hot", "#4A2A1A", "board"),
    ("cortado", "hot", "كورتادو", "Cortado", 14, 64, D("كمية متساوية من قهوة الإسبريسو والحليب المبخر", "Equal parts espresso and steamed milk"), "cortado", "hot", "#B07A4A", "board"),
    ("flatwhite", "hot", "فلات وايت", "Flat white", 15, 65, D("قهوة الإسبريسو مع الحليب المبخر والرغوة", "Espresso with steamed milk and foam"), "latte", "hot", "#C8965A", "board"),
    ("cappuccino", "hot", "كابتشينو", "Cappuccino", 16, 87, D("قهوة الإسبريسو مع الحليب المبخر والرغوة", "Espresso with steamed milk and foam"), "latte", "hot", "#C8965A", "board"),
    ("latte", "hot", "لاتيه", "Latte", 16, 138, D("قهوة الإسبريسو مع الحليب المبخر", "Espresso with steamed milk"), "latte", "hot", "#D9B98C", "board"),
    ("spanish", "hot", "سبانيش لاتيه", "Spanish latte", 18, 225, None, "latte", "hot", "#E0A33B", "board"),

    ("iced_americano", "cold", "ايس امريكانو", "Iced americano", 14, 2, D("جرعة من قهوة الإسبريسو يضاف إليها الماء والثلج", "A shot of espresso with water and ice"), "iced_americano", "iced", "#4A2A1A", "board"),
    ("iced_latte", "cold", "ايس لاتيه", "Iced latte", 18, 224, D("قهوة الإسبريسو مع الحليب البارد", "Espresso with cold milk"), "iced_latte", "iced", "#D9B98C", "board"),
    ("iced_spanish", "cold", "ايس سبانيش لاتيه", "Iced Spanish latte", 20, 135, D("سبانيش لاتيه بارد", "Spanish latte over ice"), "iced_latte", "iced", "#E0A33B", "board"),
    ("iced_matcha", "cold", "ايس ماتشا لاتيه", "Iced matcha latte", 22, 154, D("ماتشا بالفانيلا", "Matcha with vanilla"), "iced_matcha", "iced", "#8DB255", "board"),
    ("iced_tea_cherry", "cold", "ايس تي كرز", "Iced tea cherry", 20, 190, D("ايس تي بطعم الكرز", "Iced tea with a cherry flavour"), "iced_tea_cherry", "iced", "#9E2B4E", "board"),
    ("roselle", "cold", "كركديه واي!", "Why! roselle", 18, 190, D("كركديه واي المنعش", "Why!'s refreshing roselle (hibiscus)"), "roselle", "iced", "#B3263E", "board"),

    ("v60_hot", "drip", "في 60 حار", "Hot V60", 18, 2, D("قهوة سوداء محضرة بطريقة التقطير", "Black coffee brewed by pour-over"), "v60_hot", "filter", "#8A5232", "board"),
    ("v60_cold", "drip", "في 60 بارد", "Cold V60", 20, 2, D("قهوة سوداء مثلجة محضرة بطريقة التقطير", "Iced black coffee brewed by pour-over"), "ice_drip", "iced", "#3A2218", "board"),
    ("today_hot_s", "drip", "قهوة اليوم حار (صغير)", "Today's coffee, hot (small)", 12, 2, None, "v60_hot", "filter", "#8A5232", "keeta"),
    ("today_hot_m", "drip", "قهوة اليوم حار (وسط)", "Today's coffee, hot (medium)", 14, 2, None, "v60_hot", "filter", "#8A5232", "keeta"),
    ("today_hot_l", "drip", "قهوة اليوم حار (كبير)", "Today's coffee, hot (large)", 17, 2, None, "today_hot_l", "filter", "#8A5232", "keeta"),
    ("today_cold_m", "drip", "قهوة اليوم بارد (وسط)", "Today's coffee, iced (medium)", 14, 2, None, "ice_drip", "iced", "#3A2218", "keeta"),
    ("today_cold_l", "drip", "قهوة اليوم بارد (كبير)", "Today's coffee, iced (large)", 17, 2, None, "ice_drip", "iced", "#3A2218", "keeta"),

    ("halloumi", "sandwiches", "حلومي ساندوتش", "Halloumi sandwich", 23, 0, None, "halloumi", "cake", "#D9A55B", "keeta"),
    ("feta", "sandwiches", "فيتا إيقز", "Feta eggs", 23, 0, D("جبنة فيتا مع البيض المخفوق والجبنة الفرنسية", "Feta cheese with scrambled eggs and French cheese"), "feta", "cake", "#D9A55B", "keeta"),
    ("tuna", "sandwiches", "ملتد تونة", "Tuna melt", 23, 0, D("تونة مع جبنة فرنسية وصوص الرانش", "Tuna with French cheese and ranch sauce"), "tuna", "cake", "#D9A55B", "keeta"),
    ("turkey", "sandwiches", "ساندوتش تيركي", "Turkey sandwich", 25, 0, D("تيركي بصوص الزيتون والبيستو", "Turkey with olive sauce and pesto"), "turkey", "cake", "#D9A55B", "keeta"),

    ("cookies", "sweet", "كوكيز", "Cookies", 9, 262, D("كوكيز تشوكلت", "Chocolate cookies"), "cookies", "cookie", "#C8965A", "board"),
    ("french_toast", "sweet", "فرنش توست كريم بروليه", "French toast crème brûlée", 26, 662, D("فرنش توست بصوص الكريم بروليه", "French toast with crème brûlée sauce"), "french_toast", "cake", "#D9A55B", "board"),
    ("cinnabon", "sweet", "سينابون كيك", "Cinnabon cake", 26, 0, D("كيكة من طبقات السينابون والصوص الأبيض وصوص الكراميل", "Layers of cinnamon roll with white sauce and caramel sauce"), "cinnabon", "cake", "#D9A55B", "keeta"),
    ("waffle_cheesecake", "sweet", "وافل تشيز كيك", "Waffle cheesecake", 18, 0, D("وافل بلجيكي بطبقات من التشيز كيك والتوت", "Belgian waffle with layers of cheesecake and berries"), "waffle_cheesecake", "cake", "#E8C48A", "keeta"),
    ("rocky_road", "sweet", "روكي رود", "Rocky road", 18, 0, D("خمس قطع من الروكي رود اللذيذ", "Five pieces of rocky road"), "rocky_road", "brownie", "#6B3A22", "keeta"),
    ("tiramisu", "sweet", "تيراميسو واي!", "Why! tiramisu", 27, 0, None, "tiramisu", "cake", "#B07A4A", "keeta"),
    ("fondant", "sweet", "فاوندانت شوكلت", "Chocolate fondant", 24, 566, D("كيكة شوكلت بثلاثة أنواع شوكلت فاخرة", "Chocolate cake made with three kinds of fine chocolate"), "fondant", "brownie", "#6B3A22", "board"),
    ("cherry_cheesecake", "sweet", "تشيز كرز واي!", "Why! cherry cheesecake", 27, 0, D("تشيز كيك بصوص الكرز الطبيعي", "Cheesecake with natural cherry sauce"), "cherry_cheesecake", "cake", "#F3E3C3", "keeta"),
    ("marble", "sweet", "ماربل كيك", "Marble cake", 13, 288, D("مزيج متوازن بين الطراوة والمذاق الغني الفاخر", "A balance of softness and a rich, fine taste"), "marble", "cake", "#8A5232", "board"),
    ("pudding", "sweet", "بودنق واي", "Why! pudding", 26, 0, None, "pudding", "cake", "#C8965A", "keeta"),
]

# the sample products of the first menu (catalog.json) in these categories, and the matcha category they leave empty
RETIRE = ["espresso", "americano", "flat", "cap", "latte", "spanish", "iamericano", "ilatte", "coldbrew", "tonic", "batch", "v60",
          "chemex", "matchalatte", "matchatonic", "brownie", "cookie", "datecake"]
RETIRE_CATS = ["matcha"]
# a reward (or an unused gift) of a sample product moves to the same drink on the real menu
REMAP = {"batch": "today_hot_s", "latte": "latte", "ilatte": "iced_latte", "cookie": "cookies", "cap": "cappuccino", "flat": "flatwhite",
         "americano": "americano", "iamericano": "iced_americano", "spanish": "spanish", "espresso": "espresso", "v60": "v60_hot",
         "matchalatte": "iced_matcha"}


def main():
    meta = json.loads((PHOTOS / "photos.json").read_text())
    used = sorted({p[7] for p in PRODUCTS if p[7]})
    photos = {}
    for k in used:
        photos[k] = {"bg": meta[k]["bg"], "f": meta[k]["f"],
                     "full": base64.b64encode((PHOTOS / f"{k}.webp").read_bytes()).decode(),
                     "thumb": base64.b64encode((PHOTOS / f"{k}-t.webp").read_bytes()).decode()}
    unused = set(meta) - set(used)
    if unused:
        raise SystemExit("photos no product uses: %s" % ", ".join(sorted(unused)))
    menu = {
        "format": "why-menu/1",
        "name": "Why! menu (Keeta + the shop's menu board), Nov 2026",
        "cats": CATS,
        "order": [c["key"] for c in CATS],
        "products": [{"key": k, "cat": c, "ar": ar, "en": en, "price": pr, "cal": cal, "desc": desc, "photo": ph, "art": art, "tone": tone, "src": src}
                     for k, c, ar, en, pr, cal, desc, ph, art, tone, src in PRODUCTS],
        "retire": RETIRE,
        "retire_cats": RETIRE_CATS,
        "remap": REMAP,
        "photos": photos,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(menu, ensure_ascii=False, indent=1, sort_keys=False) + "\n", encoding="utf-8")
    print("%s: %d products in %d categories, %d photos, %d KB" % (OUT.relative_to(ROOT), len(PRODUCTS), len(CATS), len(photos), OUT.stat().st_size // 1024))


if __name__ == "__main__":
    main()
