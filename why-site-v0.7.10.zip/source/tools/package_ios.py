#!/usr/bin/env python3
"""Build the zip that goes to the GitHub repository of the iPhone apps:  dist/why-ios-v<VERSION>.zip

  why-ios/   project.yml (XcodeGen), Shared/ (the Swift code), Apps/ (each app's icons, from assets/store),
             build.sh + asc.py (run on a Mac at GitHub), testflight.yml (the workflow), README.txt

The workflow (testflight.yml) is added to the repository once, as .github/workflows/testflight.yml; after that,
uploading a new why-ios.zip is enough. Same files always give the same zip (fixed dates).

usage: python3 tools/package_ios.py
"""
import hashlib
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IOS = ROOT / "ios"
VERSION = (ROOT / "deploy" / "VERSION").read_text().strip()
STAMP = (2026, 11, 15, 18, 0, 0)
APPS = {"WhyCustomer": "cust", "WhyOrderDesk": "recv", "WhyManagement": "admin", "WhyDelivery": "driver"}

# each app's icons come from assets/store (made by tools/brand/brand.py): refresh the copies first
for target, app in APPS.items():
    src = ROOT / "assets" / "store" / app / "ios" / "AppIcon.appiconset"
    if not (src / "AppIcon-1024.png").is_file():
        sys.exit(f"missing iPhone icons for {app}: run  python3 tools/brand/brand.py")
    dst = IOS / "Apps" / target / "Assets.xcassets" / "AppIcon.appiconset"
    shutil.rmtree(dst, ignore_errors=True)
    shutil.copytree(src, dst)

files = []
for p in sorted(IOS.rglob("*")):
    rel = p.relative_to(IOS)
    if p.is_dir() or "__pycache__" in rel.parts or rel.parts[0] in ("Plists", "build") or rel.suffix in (".xcodeproj",):
        continue
    files.append((p, rel))

out = ROOT / "dist" / f"why-ios-v{VERSION}.zip"
out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, rel in files:
        info = zipfile.ZipInfo(f"why-ios/{rel.as_posix()}", STAMP)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o755 if rel.suffix in (".sh", ".py") else 0o644) << 16
        z.writestr(info, p.read_bytes())
sha = hashlib.sha256(out.read_bytes()).hexdigest()
print(f"{out.name}: {out.stat().st_size:,} bytes, {len(files)} files\nsha256 {sha}")
