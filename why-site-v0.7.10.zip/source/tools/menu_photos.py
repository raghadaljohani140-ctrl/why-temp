"""Cut the product photos of Why!'s real menu out of screenshots of its Keeta page (Nov 2026) into assets/menu/.

Each screenshot shows a product sheet: the photo fills the top (1179 x 819 on the iPhone) with Keeta's close button on
its top-right corner. The square in the middle (816 x 816) has the whole product and not the button. One screenshot is
Keeta's full-screen viewer (the whole square photo): the same middle part is taken, so every photo has the same scale.
Keeta uses one photo for several drinks (latte, cappuccino and flat white; the small hot coffee of the day and V60;
the cold coffee of the day and the iced drip; the iced latte and the iced Spanish latte): each photo is kept once.

  assets/menu/<key>.webp     the large copy (816 px)     assets/menu/<key>-t.webp   the small copy (320 px)
  assets/menu/photos.json    {key: {bg, f}}: the tile colour and how the photo sits in it, worked out as the admin page
                             does for an uploaded photo (admin.js drawPhoto): the four corners

usage: python3 tools/menu_photos.py      (the screenshots are the files sent in the chat, under /mnt/user-data/uploads)
"""
import io, json
from pathlib import Path
import numpy as np
from PIL import Image

UP = Path("/mnt/user-data/uploads")
OUT = Path(__file__).resolve().parent.parent / "assets" / "menu"
SIDE = 816
# key: (screenshot, the photo's top edge in it); None = the full-screen viewer, the square photo at y 689..1867
SRC = {
    "today_hot_l": ("c09750d0", 210), "americano": ("1c7fdeab", 210), "cortado": ("15949cda", 210), "latte": ("56842b69", 210),
    "iced_americano": ("c60e34a2", 210), "iced_latte": ("03b06f89", 210),
    "iced_matcha": ("79495a9b", 210), "iced_tea_cherry": ("af6b6911", 210), "roselle": ("bedf929a", 210),
    "v60_hot": ("8a3be47c", 210), "ice_drip": ("cc16267e", 210),
    "turkey": ("49174dee", 210), "halloumi": ("bce11eef", 210), "tuna": ("520328e4", 210), "feta": ("f175661c", None),
    "cookies": ("38a72158", 297), "french_toast": ("b1268c9d", 210), "cinnabon": ("89c2b567", 210),
    "waffle_cheesecake": ("e00f3ccd", 210), "rocky_road": ("cc64edf7", 210), "tiramisu": ("180d7142", 210),
    "fondant": ("73c3679f", 210), "cherry_cheesecake": ("a177f010", 210), "marble": ("99ccc03c", 210), "pudding": ("cdb6c537", 210),
}


def square(name, top):
    im = Image.open(UP / f"{name}-image.png").convert("RGB")
    x0 = (im.width - SIDE) // 2 + 1
    y0 = 689 + (1179 - SIDE) // 2 if top is None else top + 2   # 2 px below the sheet's rounded edge
    return im.crop((x0, y0, x0 + SIDE, y0 + SIDE))


def webp(im, q):
    b = io.BytesIO()
    im.save(b, "WEBP", quality=q, method=6)
    return b.getvalue()


def tile(im):
    """the tile colour behind the photo and contain ('c', the corners are alike) or cover ('v'), as admin.js drawPhoto"""
    a = np.asarray(im).astype(float)
    h, w = a.shape[:2]
    n = max(4, min(w, h) // 40)
    px = [a[y:y + n, x:x + n].reshape(-1, 3).mean(0) for x, y in ((0, 0), (w - n, 0), (0, h - n), (w - n, h - n))]
    avg = np.floor(np.mean(px, 0)).astype(int)
    spread = max(np.abs(p - avg).max() for p in px)
    return "#%02x%02x%02x" % tuple(avg), ("c" if spread <= 26 else "v")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    meta = {}
    for key, (name, top) in SRC.items():
        im = square(name, top)
        (OUT / f"{key}.webp").write_bytes(webp(im, 84))                                   # as the admin page: quality .84
        (OUT / f"{key}-t.webp").write_bytes(webp(im.resize((320, 320), Image.LANCZOS), 80))   # and .8 for the small one
        bg, f = tile(im)
        meta[key] = {"bg": bg, "f": f}
        print(key, bg, f)
    (OUT / "photos.json").write_text(json.dumps(meta, indent=1, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
