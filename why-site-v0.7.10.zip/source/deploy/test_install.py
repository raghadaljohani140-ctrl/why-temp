#!/usr/bin/env python3
"""Runs install.sh against fake system commands (ss, systemctl, caddy, curl, getent, useradd, runuser, apt-get ...) in
every situation that can happen on the server. Nothing real is touched: all paths live in a temp folder.

The Why! server program itself is NOT faked: the fake "systemctl start why-server" really starts it, from the service
file the installer wrote, so the self-test, the secret codes, the health check and the updates all run for real.

   python3 -I test_install.py            (from the deploy folder, or from an unzipped package: source/deploy)
"""
import json, os, pty, select, re, shutil, socket, subprocess, sys, tempfile, textwrap, time, unittest, urllib.error, urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SERVER = HERE.parent / "server"          # the same place in the repository and in the unzipped package (source/server)
DOMAIN = "whycoffee.duckdns.org"
BEGIN = "# >>> why-site"
OTHER_SITES = textwrap.dedent("""\
    {
    \temail ops@example.com
    }

    example.com {
    \trespond "other site" 200
    }

    sslip-host.sslip.io {
    \treverse_proxy 127.0.0.1:8088
    }
    """)
DEFAULT_CADDYFILE = textwrap.dedent("""\
    # The Caddyfile is an easy way to configure your Caddy web server.
    :80 {
    \t# Set this path to your site's directory.
    \troot * /usr/share/caddy
    \tfile_server
    }
    """)
SS_HEADER = "State  Recv-Q Send-Q Local Address:Port Peer Address:Port Process\n"
SS_SSH = 'LISTEN 0 128 0.0.0.0:22 0.0.0.0:* users:(("sshd",pid=1,fd=3))\n'
SS_CADDY = ('LISTEN 0 4096 0.0.0.0:80 0.0.0.0:* users:(("caddy",pid=812,fd=7))\n'
            'LISTEN 0 4096 *:443 *:* users:(("caddy",pid=812,fd=8))\n'
            'LISTEN 0 4096 127.0.0.1:2019 0.0.0.0:* users:(("caddy",pid=812,fd=3))\n')
SS_DOCKER = ('LISTEN 0 4096 0.0.0.0:80 0.0.0.0:* users:(("docker-proxy",pid=900,fd=4))\n'
             'LISTEN 0 4096 [::]:443 [::]:* users:(("docker-proxy",pid=910,fd=4))\n')
SS_NGINX = 'LISTEN 0 511 0.0.0.0:80 0.0.0.0:* users:(("nginx",pid=700,fd=6))\n'

ADMIN_PIN, RECV_PIN = "482916", "735019"


def png(w, h, rgb=(200, 120, 40)):
    """a real (tiny) PNG file"""
    import struct, zlib
    rows = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))
    chunk = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b"")


def menu_file():
    """a menu file as tools/build_menu.py makes them (0.7.9), small"""
    import base64
    b = lambda x: base64.b64encode(x).decode()
    return json.dumps({"format": "why-menu/1", "cats": [{"key": "sandw", "ar": "الساندويتشات", "en": "Sandwiches", "kind": "food"}],
                       "photos": {"t": {"full": b(png(64, 64)), "thumb": b(png(32, 32)), "bg": "#eeeeee", "f": "c"}},
                       "products": [{"key": "toast", "cat": "sandw", "ar": "توست", "en": "Toast", "price": 23, "photo": "t"}],
                       "retire": ["cookie"]}, ensure_ascii=False)
PINS = [("Code:", ADMIN_PIN), ("Again:", ADMIN_PIN), ("Code:", RECV_PIN), ("Again:", RECV_PIN)]

FAKES = {
"id": r'''#!/usr/bin/env bash
if [ "$1" = "-u" ] && [ -z "${2:-}" ]; then echo "${FAKE_UID:-0}"; fi
''',
"hostname": r'''#!/usr/bin/env bash
echo "${FAKE_HOST:-Mazad-bot}"
''',
"sleep": "#!/usr/bin/env bash\nexec /bin/sleep 0.05\n",
"getent": r'''#!/usr/bin/env bash
case "$1" in
  ahostsv4) [ -n "${FAKE_DNS_IP:-}" ] || exit 2; printf '%s    STREAM %s\n' "$FAKE_DNS_IP" "$2" ;;
  ahostsv6)   # like the real one: an IPv4-only name comes back v4-mapped
    if [ -n "${FAKE_DNS_IPV6:-}" ]; then printf '%s    STREAM %s\n' "$FAKE_DNS_IPV6" "$2"
    elif [ -n "${FAKE_DNS_IP:-}" ]; then printf '::ffff:%s    STREAM %s\n' "$FAKE_DNS_IP" "$2"
    else exit 2; fi ;;
  passwd) [ -f "$FAKE_STATE/user" ] && [ "$2" = "why" ] && echo "why:x:998:998::/var/lib/why:/usr/sbin/nologin" || exit 2 ;;
  *) exit 2 ;;
esac
''',
"useradd": r'''#!/usr/bin/env bash
echo "useradd $*" >> "$FAKE_STATE/calls"
[ -n "${FAKE_USERADD_FAIL:-}" ] && { echo "useradd: cannot lock /etc/passwd" >&2; exit 1; }
touch "$FAKE_STATE/user"
''',
"chown": r'''#!/usr/bin/env bash
echo "chown $*" >> "$FAKE_STATE/calls"
''',
"runuser": r'''#!/usr/bin/env bash
# runuser -u USER -- command ...      (the test cannot switch users, so it only records who was asked for)
[ "$1" = "-u" ] || exit 2
echo "$2" >> "$FAKE_STATE/ran_as"
shift 3
exec "$@"
''',
"ss": r'''#!/usr/bin/env bash
cat "$FAKE_STATE/ss.txt"
''',
"journalctl": r'''#!/usr/bin/env bash
[ -f "$FAKE_STATE/journal.txt" ] && cat "$FAKE_STATE/journal.txt"
exit 0
''',
"gpg": r'''#!/usr/bin/env bash
while [ $# -gt 0 ]; do [ "$1" = "-o" ] && out="$2"; shift; done
cat > "$out"
''',
"ufw": r'''#!/usr/bin/env bash
case "$1" in
  status) [ -n "${FAKE_UFW_ACTIVE:-}" ] && echo "Status: active" || echo "Status: inactive" ;;
  allow) echo "ufw allow $2" >> "$FAKE_STATE/calls" ;;
esac
''',
"curl": r'''#!/usr/bin/env bash
ARGS=("$@")
out=""; url=""
while [ $# -gt 0 ]; do
  case "$1" in
    -o) out="$2"; shift ;;
    -w|--resolve|--max-time) shift ;;
    -*) ;;
    *) url="$1" ;;
  esac
  shift
done
S="$FAKE_STATE"
case "$url" in
  *metadata/v1/interfaces/public/0/ipv4/address) [ -n "${FAKE_IP:-}" ] && printf '%s' "$FAKE_IP" || exit 22 ;;
  *metadata/v1/reserved_ip/ipv4/active) printf '%s' "${FAKE_RESERVED_ACTIVE:-false}" ;;
  *metadata/v1/reserved_ip/ipv4/ip_address) printf '%s' "${FAKE_RESERVED_IP:-}" ;;
  https://api.ipify.org*) [ -n "${FAKE_IP:-}" ] && printf '%s' "$FAKE_IP" || exit 22 ;;
  *gpg.key) printf 'FAKEKEY' ;;
  *debian.deb.txt) printf 'deb [signed-by=/usr/share/keyrings/caddy-stable-archive-keyring.gpg] https://dl.cloudsmith.io/public/caddy/stable/deb/debian any-version main\n' ;;
  http://127.0.0.1:*) exec /usr/bin/curl "${ARGS[@]}" ;;       # the real server program, for the health check
  https://*)
    rest="${url#https://}"; domain="${rest%%/*}"; path="/${rest#*/}"
    if [ "${FAKE_HTTPS:-ok}" = ok ] && [ -f "$S/loaded" ] && grep -q "^$domain {" "$S/loaded"; then
      case "$path" in
        /api/*)   # what Caddy does with the block: hand /api to the server program
          grep -q "reverse_proxy /api/\* 127.0.0.1:$(cat "$S/port" 2>/dev/null)" "$S/loaded" || { printf '404'; exit 0; }
          exec /usr/bin/curl -sS --max-time 5 -o "${out:-/dev/null}" -w '%{http_code}' "http://127.0.0.1:$(cat "$S/port")$path" ;;
        *)
          f="$FAKE_WEBROOT$path"; case "$f" in */) f="${f}index.html" ;; esac
          if [ -f "$f" ]; then [ -n "$out" ] && cat "$f" > "$out"; printf '200'; else [ -n "$out" ] && : > "$out"; printf '404'; fi ;;
      esac
    else
      printf '000'; echo "fake curl: connection failed" >&2; exit 35
    fi ;;
  *) exit 22 ;;
esac
''',
"systemctl": r'''#!/usr/bin/env bash
S="$FAKE_STATE"
alive_pid() {   # a process that has ended but was not collected yet (a zombie) is not alive
  local st; st="$(sed -n 's/^[0-9]* (.*) \(.\) .*/\1/p' "/proc/$1/stat" 2>/dev/null)"; [ -n "$st" ] && [ "$st" != Z ]
}
why_up()   { [ -f "$S/why.pid" ] && alive_pid "$(cat "$S/why.pid")"; }
why_stop() {
  [ -f "$S/why.pid" ] || return 0
  local pid i; pid="$(cat "$S/why.pid")"; kill "$pid" 2>/dev/null
  for i in $(seq 1 40); do alive_pid "$pid" || break; /bin/sleep 0.1; done
  kill -9 "$pid" 2>/dev/null; rm -f "$S/why.pid"
}
why_start() {   # really starts the program, from the ExecStart line of the service file the installer wrote
  if [ -n "${FAKE_WHY_START_FAIL:-}" ]; then echo "Job for why-server.service failed because the control process exited with error code." >&2; exit 1; fi
  local cmd; cmd="$(grep -m1 '^ExecStart=' "$FAKE_UNIT_DIR/why-server.service" 2>/dev/null | cut -d= -f2-)"
  [ -n "$cmd" ] || { echo "Unit why-server.service not found." >&2; exit 5; }
  nohup $cmd </dev/null >>"$S/why.log" 2>&1 &
  echo $! > "$S/why.pid"
  echo "$cmd" | grep -o -e '--port [0-9]*' | awk '{print $2}' > "$S/port"
}
case "$*" in
  "is-active --quiet caddy") [ -f "$S/active" ] ;;
  "reload caddy")
    [ -n "${FAKE_RELOAD_FAIL:-}" ] && { echo "Job for caddy.service failed" >&2; exit 1; }
    cp "$FAKE_CADDYFILE" "$S/loaded"; echo reload >> "$S/calls" ;;
  "restart caddy"|"start caddy")
    [ -n "${FAKE_RESTART_FAIL:-}" ] && { echo "start failed" >&2; exit 1; }
    touch "$S/active"; cp "$FAKE_CADDYFILE" "$S/loaded"; echo restart >> "$S/calls" ;;
  "enable caddy") echo enable >> "$S/calls" ;;
  "cat caddy.service")
    [ -f "$S/installed" ] || { echo "No files found for caddy.service." >&2; exit 1; }
    echo "[Service]"; echo "ExecStart=/usr/bin/caddy run --environ --config ${FAKE_UNIT_CONFIG:-$FAKE_CADDYFILE}" ;;
  "daemon-reload") echo "daemon-reload" >> "$S/calls" ;;
  "is-active --quiet why-server") why_up ;;
  "enable why-server") echo "enable why-server" >> "$S/calls" ;;
  "disable why-server") echo "disable why-server" >> "$S/calls" ;;
  "start why-server") echo "start why-server" >> "$S/calls"; why_start ;;
  "restart why-server") echo "restart why-server" >> "$S/calls"; why_stop; why_start ;;
  "stop why-server") echo "stop why-server" >> "$S/calls"; why_stop ;;
  *) echo "systemctl $*" >> "$S/calls_other"; exit 0 ;;
esac
''',
"caddy": r'''#!/usr/bin/env bash
S="$FAKE_STATE"
cmd="$1"; f=""
while [ $# -gt 0 ]; do [ "$1" = "--config" ] && f="$2"; shift; done
case "$cmd" in
  version) echo "v2.10.0 h1:fakehash" ;;
  validate)
    [ -n "${FAKE_VALIDATE_ALWAYS_FAIL:-}" ] && { echo "Error: adapting config using caddyfile: parse error" >&2; exit 1; }
    if [ -n "${FAKE_VALIDATE_FAIL:-}" ] && grep -q 'why-site' "$f"; then echo "Error: unknown directive" >&2; exit 1; fi
    python3 -c "import sys; t=open(sys.argv[1]).read(); sys.exit(0 if t.count('{')==t.count('}') else 1)" "$f" || { echo "Error: unbalanced braces" >&2; exit 1; }
    echo "Valid configuration" ;;
  reload)
    [ -n "${FAKE_RELOAD_FAIL:-}" ] && { echo "Error: sending configuration to Caddy: HTTP 403" >&2; exit 1; }
    cp "$f" "$S/loaded"; echo api-reload >> "$S/calls" ;;
esac
''',
"apt-get": r'''#!/usr/bin/env bash
S="$FAKE_STATE"
echo "apt-get $*" >> "$S/calls"
[ -n "${FAKE_APT_FAIL:-}" ] && { echo "E: Unable to locate package" >&2; exit 100; }
case " $* " in
  *" install caddy "*|*" install caddy")
    cp "$FAKE_AFTER/caddy" "$FAKE_BIN/caddy"
    mkdir -p "$(dirname "$FAKE_CADDYFILE")"; printf '%s' "$FAKE_DEFAULT_CADDYFILE" > "$FAKE_CADDYFILE"
    touch "$S/active" "$S/installed"; cp "$FAKE_CADDYFILE" "$S/loaded" ;;
esac
exit 0
''',
}


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class Env:
    def __init__(self, caddy_installed=False, caddyfile=None, ss=SS_SSH, dns="203.0.113.7", ip="203.0.113.7", **extra):
        self.tmp = Path(tempfile.mkdtemp(prefix="whytest-"))
        t = self.tmp
        for d in ("bin", "after", "state", "app"):
            (t / d).mkdir()
        for name, body in FAKES.items():
            dest = t / ("after" if name == "caddy" else "bin") / name
            dest.write_text(body); dest.chmod(0o755)
        self.caddyfile = t / "etc" / "caddy" / "Caddyfile"
        self.webroot = t / "www" / "why"
        self.rundir = t / "opt" / "why-server"
        self.datadir = t / "var" / "lib" / "why"
        self.unitdir = t / "etc" / "systemd" / "system"
        self.unitdir.mkdir(parents=True)
        self.unit = self.unitdir / "why-server.service"
        self.state = t / "state"
        self.start_port = free_port()
        if caddy_installed:
            shutil.copy(t / "after" / "caddy", t / "bin" / "caddy")
            (self.state / "installed").touch()
        if caddyfile is not None:
            self.caddyfile.parent.mkdir(parents=True)
            self.caddyfile.write_text(caddyfile)
        (self.state / "ss.txt").write_text(SS_HEADER + ss)
        if ss == SS_CADDY or SS_CADDY in ss:
            (self.state / "active").touch()
            if caddyfile is not None:
                shutil.copy(self.caddyfile, self.state / "loaded")
        # the package, as unzipped on the server
        app = t / "app"
        for f in ("install.sh", "caddy-block.tpl", "why-server.service.tpl", "VERSION"):
            shutil.copy(HERE / f, app / f)
        (app / "source" / "server").mkdir(parents=True)
        for f in ("why_server.py", "catalog.json"):
            shutil.copy(SERVER / f, app / "source" / "server" / f)
        (app / "site").mkdir()
        self.set_site("<!doctype html><html><body><div id=\"app\">v1</div></body></html>")
        base = {"PATH": f"{t / 'bin'}:{os.environ['PATH']}", "FAKE_STATE": str(self.state), "FAKE_BIN": str(t / "bin"),
                "FAKE_AFTER": str(t / "after"), "FAKE_CADDYFILE": str(self.caddyfile), "FAKE_WEBROOT": str(self.webroot),
                "FAKE_UNIT_DIR": str(self.unitdir), "FAKE_DEFAULT_CADDYFILE": DEFAULT_CADDYFILE, "FAKE_IP": ip, "FAKE_DNS_IP": dns or "",
                "WHY_WEB_ROOT": str(self.webroot), "WHY_CADDYFILE": str(self.caddyfile), "WHY_RUN_DIR": str(self.rundir),
                "WHY_DATA_DIR": str(self.datadir), "WHY_UNIT_DIR": str(self.unitdir), "WHY_PORT_START": str(self.start_port),
                "WHY_PBKDF2_ITERS": "2000", "WHY_WAIT_SECS": "8", "HOME": str(t), "TMPDIR": str(t)}
        base.update({k: str(v) for k, v in extra.items()})
        self.env = base

    # ----- the package
    def set_site(self, html):
        site = self.tmp / "app" / "site"
        for sub, label in (("", "customers"), ("reception", "reception"), ("admin", "admin"), ("driver", "driver")):
            d = site / sub if sub else site
            d.mkdir(exist_ok=True)
            (d / "index.html").write_text(html.replace("</div>", f" {label}</div>", 1) if "</div>" in html else html)
            (d / "manifest.webmanifest").write_text("{}")

    def set_menu(self, text):
        d = self.tmp / "app" / "source" / "deploy" / "menu"
        d.mkdir(parents=True, exist_ok=True)
        (d / "why-menu.json").write_text(text, encoding="utf-8")

    def edit_server(self, text):
        (self.tmp / "app" / "source" / "server" / "why_server.py").write_text(text)

    def server_text(self):
        return (self.tmp / "app" / "source" / "server" / "why_server.py").read_text()

    # ----- running the installer
    def run(self, *args, env=None, stdin=""):
        e = dict(self.env); e.update({k: str(v) for k, v in (env or {}).items()})
        p = subprocess.run(["bash", str(self.tmp / "app" / "install.sh"), *args], input=stdin, capture_output=True, text=True, env=e, timeout=120)
        return p.returncode, p.stdout + p.stderr

    def run_tty(self, answers, *args, env=None):
        """Run with a real terminal on stdin. answers: a string answers "(y/n)", a pair (text to wait for, what to type) answers that.
        Everything the terminal itself echoes back is kept in self.echo (secret codes must never appear there)."""
        e = dict(self.env); e.update({k: str(v) for k, v in (env or {}).items()})
        master, slave = pty.openpty()
        p = subprocess.Popen(["bash", str(self.tmp / "app" / "install.sh"), *args], stdin=slave, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=e)
        os.close(slave)
        pending = [a if isinstance(a, tuple) else ("(y/n)", a) for a in answers]
        out, echo, pos, t0 = b"", b"", 0, time.time()
        while time.time() - t0 < 120:
            r, _, _ = select.select([p.stdout, master], [], [], 0.2)
            got = False
            if p.stdout in r:
                chunk = os.read(p.stdout.fileno(), 4096)
                if not chunk and p.poll() is not None:
                    break
                out += chunk; got = bool(chunk)
            if master in r:
                try:
                    echo += os.read(master, 4096)
                except OSError:
                    pass
            if pending:
                expect, text = pending[0]
                i = out.find(expect.encode(), pos)
                if i >= 0:
                    time.sleep(0.2)          # let bash switch the terminal echo off before the code is typed
                    os.write(master, (text + "\n").encode()); pos = i + len(expect); pending.pop(0)
            if p.poll() is not None and not r and not got:
                break
        p.wait(timeout=20)
        try:
            os.close(master)
        except OSError:
            pass
        p.stdout.close()
        self.echo = echo.decode("utf-8", "replace")
        return p.returncode, out.decode("utf-8", "replace")

    def install(self, *args, env=None, pins=None):
        """A first install: --yes skips the question, the two secret codes are typed on a terminal."""
        return self.run_tty(PINS if pins is None else pins, "--yes", *args, env=env)

    # ----- looking at what happened
    def cf(self):
        return self.caddyfile.read_text() if self.caddyfile.exists() else None

    def calls(self):
        f = self.state / "calls"
        return f.read_text().splitlines() if f.exists() else []

    def baks(self):
        return sorted(self.caddyfile.parent.glob("Caddyfile.bak-*")) if self.caddyfile.parent.exists() else []

    def settings(self):
        f = self.tmp / "app" / "settings.txt"
        return f.read_text() if f.exists() else ""

    def pid(self):
        f = self.state / "why.pid"
        return int(f.read_text()) if f.exists() else None

    def alive(self):
        p = self.pid()
        if not p:
            return False
        try:
            st = re.sub(r"^\d+ \(.*\) (.).*$", r"\1", Path(f"/proc/{p}/stat").read_text().strip(), flags=re.S)
        except OSError:
            return False
        return st != "Z"        # an ended program that nobody collected yet is not alive

    def port(self):
        f = self.state / "port"
        return int(f.read_text()) if f.exists() else None

    def api(self, path, body=None, headers=None):
        req = urllib.request.Request(f"http://127.0.0.1:{self.port()}/api{path}", data=None if body is None else json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json", **(headers or {})})
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def program(self, *args, stdin=None):
        """the server program's own commands, as the installer runs them"""
        env = dict(os.environ, WHY_PBKDF2_ITERS="2000")
        return subprocess.run([sys.executable, "-I", str(self.rundir / "why_server.py"), *args, "--db", str(self.datadir / "why.db"), "--catalog", str(self.rundir / "catalog.json")],
                              input=stdin, capture_output=True, text=True, env=env, timeout=60)

    def other_calls(self):
        f = self.state / "calls_other"
        return f.read_text().splitlines() if f.exists() else []

    def cleanup(self):
        p = self.pid()
        if p:
            try:
                os.kill(p, 9)
            except OSError:
                pass
        shutil.rmtree(self.tmp, ignore_errors=True)


class InstallerTests(unittest.TestCase):
    def env(self, **kw):
        e = Env(**kw); self.addCleanup(e.cleanup); return e

    # ---------- the happy paths ----------
    def test_new_server_installs_caddy_the_service_and_publishes(self):
        e = self.env(FAKE_UFW_ACTIVE=1)
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        self.assertIn(f"DONE. Open: https://{DOMAIN}", out)
        for p in ("/", "/reception/", "/admin/", "/driver/"):
            self.assertIn(f"https://{DOMAIN}{p}", out)
        self.assertNotIn("IPv6", out, "an IPv4-only name must not trigger the IPv6 warning")
        self.assertTrue(any("install caddy" in c for c in e.calls()), e.calls())
        self.assertIn("ufw allow 80/tcp", e.calls()); self.assertIn("ufw allow 443/tcp", e.calls())
        cf = e.cf()
        self.assertEqual(cf.count(BEGIN), 1); self.assertIn(f"{DOMAIN} {{", cf)
        self.assertIn(f"root * {e.webroot}", cf)
        self.assertIn(f"reverse_proxy /api/* 127.0.0.1:{e.port()}", cf)
        self.assertNotIn("/usr/share/caddy", cf, "the sample site of the package should be replaced")
        self.assertEqual(len(e.baks()), 1, "the package's default file is kept as a backup")
        self.assertIn("/usr/share/caddy", e.baks()[0].read_text())
        for sub in ("", "reception/", "admin/", "driver/"):
            self.assertTrue((e.webroot / sub / "index.html").exists(), sub)
            self.assertTrue((e.webroot / sub / "manifest.webmanifest").exists(), sub)
        s = e.settings()
        self.assertIn(f"DOMAIN={DOMAIN}", s); self.assertIn("CONFIRMED_HOST=Mazad-bot", s); self.assertIn("MODE=new", s)
        self.assertIn(f"PORT={e.start_port}", s)
        self.assertTrue(e.alive()); self.assertEqual(e.api("/health")[1]["ok"], True)

    def test_existing_caddy_keeps_the_other_sites(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        cf = e.cf()
        self.assertTrue(cf.startswith(OTHER_SITES.rstrip("\n")), "everything that was there stays, byte for byte")
        self.assertEqual(cf.count(BEGIN), 1); self.assertIn(f"{DOMAIN} {{", cf)
        self.assertEqual(len(e.baks()), 1); self.assertEqual(e.baks()[0].read_text(), OTHER_SITES)
        self.assertIn("reload", e.calls()); self.assertNotIn("restart", e.calls(), "a running Caddy is reloaded, never restarted")
        self.assertFalse(any("install caddy" in c for c in e.calls()), "Caddy is not installed again")
        self.assertIn("MODE=existing", e.settings())

    def test_running_it_again_updates_without_duplicates_or_restarts(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        pid = e.pid()
        e.set_site("<!doctype html><html><body><div id=\"app\">v2 NEW</div></body></html>")
        rc, out = e.run()      # no --yes and no terminal: it was confirmed before for this version, so it must not ask again
        self.assertEqual(rc, 0, out)
        self.assertIn("confirmed before", out)
        self.assertIn("already up to date", out)
        self.assertEqual(e.pid(), pid, "same program, same service file: the server is left running")
        self.assertEqual(e.calls().count("start why-server"), 1); self.assertNotIn("restart why-server", e.calls())
        self.assertEqual(e.cf().count(BEGIN), 1); self.assertEqual(e.cf().count("# <<< why-site"), 1)
        self.assertEqual(e.cf().count(f"{DOMAIN} {{"), 1)
        self.assertIn("v2 NEW", (e.webroot / "index.html").read_text())
        self.assertFalse(list(e.webroot.parent.glob("why.new.*")) or list(e.webroot.parent.glob("why.old.*")), "no leftovers")
        self.assertFalse(list(e.rundir.parent.glob("why-server.new.*")) or list(e.rundir.parent.glob("why-server.old.*")), "no leftovers")

    def test_caddy_installed_but_stopped_is_started(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH)
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        self.assertIn("restart", e.calls()); self.assertTrue(e.cf().startswith(OTHER_SITES.rstrip("\n")))
        self.assertFalse(any("install caddy" in c for c in e.calls()))

    def test_reserved_ip_counts_as_this_server(self):
        e = self.env(dns="198.51.100.5", FAKE_RESERVED_ACTIVE="true", FAKE_RESERVED_IP="198.51.100.5")
        rc, out = e.install()
        self.assertEqual(rc, 0, out)

    # ---------- the server program: a small, limited, separate service ----------
    def test_server_runs_as_a_limited_service_of_its_own(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        u = e.unit.read_text()
        for want in ("User=why", "Group=why", "MemoryMax=96M", "MemoryHigh=64M", "CPUQuota=40%", "TasksMax=128", "OOMScoreAdjust=500", "Nice=10",
                     "NoNewPrivileges=true", "ProtectSystem=strict", "ProtectHome=true", "PrivateTmp=true", "PrivateDevices=true",
                     f"ReadWritePaths={e.datadir}", "Restart=on-failure", "WantedBy=multi-user.target", "--host 127.0.0.1", f"--port {e.port()}",
                     f"--db {e.datadir}/why.db", f"{e.rundir}/why_server.py"):
            self.assertIn(want, u)
        self.assertNotIn("__", u, "every placeholder was filled in")
        self.assertIn("-I -B", u)
        self.assertTrue((e.rundir / "why_server.py").exists() and (e.rundir / "catalog.json").exists())
        self.assertEqual(oct(e.datadir.stat().st_mode & 0o777), "0o700", "only the service user can open the data folder")
        self.assertIn("useradd --system --user-group --no-create-home", " ".join(c for c in e.calls() if c.startswith("useradd")))
        self.assertIn("--shell /usr/sbin/nologin", " ".join(e.calls()))
        self.assertTrue(any(c.startswith("chown why:why") and str(e.datadir) in c for c in e.calls()), e.calls())
        ran = (e.state / "ran_as").read_text().split()
        self.assertTrue(ran and set(ran) == {"why"}, "every command of the program ran as the service user: %s" % ran)
        for c in ("daemon-reload", "enable why-server", "start why-server"):
            self.assertIn(c, e.calls())
        self.assertEqual(e.other_calls(), [], "no other service was asked for anything")
        self.assertEqual(e.api("/health")[1]["v"], re.search(r'^VERSION = "([^"]+)"', e.server_text(), re.M).group(1))

    def test_other_services_are_never_touched(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        e.edit_server(e.server_text() + "\n# a new version\n")
        self.assertEqual(e.run("--yes")[0], 0)
        self.assertEqual(e.run("remove", "--yes")[0], 0)
        units = set()
        for c in e.calls():
            m = re.match(r"(enable|disable|start|restart|stop) (\S+)$", c)
            if m:
                units.add(m.group(2))
        self.assertTrue(units <= {"why-server"}, "only the Why! service was started, stopped or restarted: %s" % units)
        self.assertNotIn("restart", e.calls(), "Caddy was never restarted, only reloaded")
        self.assertNotIn("stop caddy", " ".join(e.calls()))
        self.assertEqual(e.other_calls(), [])

    def test_port_in_use_picks_the_next_free_one_and_keeps_it_afterwards(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        busy = e.start_port
        (e.state / "ss.txt").write_text(SS_HEADER + SS_SSH + SS_CADDY + f'LISTEN 0 128 127.0.0.1:{busy} 0.0.0.0:* users:(("some-other-app",pid=5,fd=3))\n')
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        self.assertEqual(e.port(), busy + 1)
        self.assertIn(f"--port {busy + 1}", e.unit.read_text()); self.assertIn(f"127.0.0.1:{busy + 1}", e.cf())
        self.assertIn(f"PORT={busy + 1}", e.settings())
        # later the port shows as used - by our own service. It stays ours.
        (e.state / "ss.txt").write_text(SS_HEADER + SS_SSH + SS_CADDY + f'LISTEN 0 128 127.0.0.1:{busy} 0.0.0.0:* users:(("some-other-app",pid=5,fd=3))\n'
                                        + f'LISTEN 0 128 127.0.0.1:{busy + 1} 0.0.0.0:* users:(("python3",pid=77,fd=3))\n')
        e.edit_server(e.server_text() + "\n# a new version\n")
        rc, out = e.run("--yes")
        self.assertEqual(rc, 0, out)
        self.assertEqual(e.port(), busy + 1)

    def test_no_free_port_changes_nothing(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        lines = "".join(f'LISTEN 0 128 127.0.0.1:{e.start_port + i} 0.0.0.0:* users:(("x",pid=5,fd=3))\n' for i in range(13))
        (e.state / "ss.txt").write_text(SS_HEADER + SS_SSH + SS_CADDY + lines)
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("No free local port", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.unit.exists())

    def test_the_unit_file_is_accepted_by_systemd(self):
        if not shutil.which("systemd-analyze"):
            self.skipTest("systemd-analyze is not available here")
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        p = subprocess.run(["systemd-analyze", "verify", "--man=no", str(e.unit)], capture_output=True, text=True)
        bad = [l for l in (p.stdout + p.stderr).splitlines() if re.search(r"unknown|invalid|not valid|failed to parse|ignoring|bad", l, re.I) and "why-server.service" in l]
        self.assertEqual(bad, [], p.stdout + p.stderr)

    def test_the_policy_in_the_caddy_block_is_the_servers_own(self):
        tpl = (HERE / "caddy-block.tpl").read_text()
        src = (SERVER / "why_server.py").read_text()
        mine = re.search(r'Content-Security-Policy "([^"]+)"', tpl).group(1)
        theirs = "".join(re.findall(r'"([^"]*)"', re.search(r"CSP = \((.*?)\)\n", src, re.S).group(1)))
        self.assertEqual(mine, theirs)
        for must in ("script-src 'unsafe-inline'", "connect-src 'self'", "frame-ancestors 'none'", "img-src 'self' data:", "fonts.googleapis.com", "fonts.gstatic.com"):
            self.assertIn(must, mine)
        self.assertNotIn("geolocation", tpl, "the café pages may ask for the phone's location")
        self.assertIn("header_up X-Forwarded-Proto {scheme}", tpl); self.assertIn("header_up X-Forwarded-Host {host}", tpl)
        for p in ("/reception", "/admin", "/driver"):
            self.assertIn(p + "/index.html", tpl); self.assertIn(p + "/manifest.webmanifest", tpl)

    # ---------- the secret codes ----------
    def test_secret_codes_are_hidden_stored_scrambled_and_really_work(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        self.assertIn("Secret code for the MANAGEMENT screen", out); self.assertIn("Secret code for the ORDER DESK screen", out); self.assertNotIn("RECEPTION", out.upper().replace("/RECEPTION/", ""))
        for code in (ADMIN_PIN, RECV_PIN):
            self.assertNotIn(code, out, "the installer never prints a code")
            self.assertNotIn(code, e.echo, "the terminal never shows what was typed")
            for f in (e.unit, e.caddyfile, e.tmp / "app" / "settings.txt"):
                self.assertNotIn(code, f.read_text())
            self.assertNotIn(code.encode(), (e.datadir / "why.db").read_bytes(), "only a scrambled form is stored")
            self.assertFalse(any(code in c for c in e.calls()), "a code is never on a command line")
        self.assertIn("staff: admin admin active", e.program("check").stdout)
        self.assertIn("staff: recv recv active", e.program("check").stdout)
        self.assertEqual(e.api("/admin/login", {"pin": ADMIN_PIN})[0], 200)
        self.assertEqual(e.api("/recv/login", {"pin": RECV_PIN})[0], 200)
        self.assertEqual(e.api("/admin/login", {"pin": RECV_PIN})[0], 401, "the two codes are not interchangeable")

    def test_easy_mismatching_and_repeated_codes_are_asked_again(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        answers = [("Code:", "12345"),                          # too short
                   ("Code:", "123456"),                         # too easy
                   ("Code:", "777777"),                         # too easy
                   ("Code:", "456789"),                         # too easy (a run of digits)
                   ("Code:", ADMIN_PIN), ("Again:", "000000"),  # the two do not match
                   ("Code:", ADMIN_PIN), ("Again:", ADMIN_PIN),
                   ("Code:", ADMIN_PIN),                        # the reception code may not be the admin code
                   ("Code:", RECV_PIN), ("Again:", RECV_PIN)]
        rc, out = e.install(pins=answers)
        self.assertEqual(rc, 0, out)
        self.assertIn("6 to 10 digits only", out); self.assertEqual(out.count("Too easy to guess"), 3)
        self.assertIn("did not match", out); self.assertIn("different from the MANAGEMENT code", out)
        self.assertEqual(e.api("/admin/login", {"pin": ADMIN_PIN})[0], 200)
        self.assertEqual(e.api("/recv/login", {"pin": RECV_PIN})[0], 200)

    def test_giving_up_on_the_codes_leaves_nothing_running(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.install(pins=[("Code:", "1")] * 6)
        self.assertNotEqual(rc, 0); self.assertIn("No MANAGEMENT code was set", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.webroot.exists()); self.assertFalse(e.unit.exists())
        self.assertFalse(e.alive()); self.assertFalse(e.rundir.exists())
        self.assertFalse(list(e.rundir.parent.glob("why-server.new.*")), "the staged copy of the program is cleaned up")
        self.assertEqual(e.settings(), "")

    def test_codes_cannot_be_typed_without_a_keyboard(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.run("--yes")      # no terminal and no codes yet
        self.assertNotEqual(rc, 0); self.assertIn("typed by a person", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.alive()); self.assertFalse(e.webroot.exists())

    def test_codes_that_exist_are_kept_and_not_asked_again(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        e.edit_server(e.server_text() + "\n# a new version\n")
        rc, out = e.run("--yes")            # no terminal at all: nothing to type
        self.assertEqual(rc, 0, out); self.assertIn("already set", out); self.assertNotIn("Secret code for", out)
        self.assertEqual(e.api("/admin/login", {"pin": ADMIN_PIN})[0], 200)

    # ---------- updates keep the data and go back when something is wrong ----------
    def customer(self, e, phone="566000111"):
        dev = "ab" * 16
        st, j = e.api("/my/sync", {"since": 0, "srev": -1, "name": "Khaled", "phone": phone}, {"X-Dev": dev})
        self.assertEqual(st, 200, j)

    def test_update_backs_up_keeps_the_data_and_restarts_only_the_service(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        self.customer(e)
        self.assertIn("customers: 1", e.program("check").stdout)
        pid = e.pid()
        e.edit_server(e.server_text() + "\n# a newer version of the program\n")
        rc, out = e.run("--yes")
        self.assertEqual(rc, 0, out)
        self.assertIn("database backed up first", out)
        backups = list((e.datadir / "backups").glob("why-*.db"))
        self.assertEqual(len(backups), 1, backups)
        self.assertIn("restart why-server", e.calls()); self.assertNotEqual(e.pid(), pid)
        self.assertIn("a newer version of the program", (e.rundir / "why_server.py").read_text())
        self.assertIn("customers: 1", e.program("check").stdout, "the data came through the update")
        self.assertEqual(e.api("/admin/login", {"pin": ADMIN_PIN})[0], 200, "the codes came through too")
        self.assertNotIn("restart", e.calls(), "Caddy was reloaded, never restarted")
        import sqlite3
        con = sqlite3.connect(str(backups[0]))
        self.assertEqual(con.execute("SELECT COUNT(*) FROM customers").fetchone()[0], 1, "the backup holds the customer too")
        con.close()

    def test_a_menu_in_the_package_is_added_once_after_a_copy_of_the_data(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        e.set_menu(menu_file())
        rc, out = e.install()
        self.assertEqual(rc, 0, out)
        self.assertIn("add the café's menu of this package, once", out)
        self.assertIn("the café's menu was added (1 products, 1 new categories, 1 photos)", out)
        self.assertEqual([c for c in e.calls() if c.endswith("why-server") and "able" not in c], ["start why-server", "restart why-server"],
                         "started, then once more so it shows the new menu")
        st, cat = e.api("/catalog")
        self.assertEqual(st, 200, cat)
        live = {p["ar"]: p for p in cat["products"] if not p.get("gone")}
        self.assertTrue(live["توست"]["img"], "the photo came with it")
        self.assertNotIn("كوكيز شوكولاتة", live, "the sample product it replaces is off the menu")
        self.assertIn("menu: from a menu file", e.program("check").stdout)
        self.assertEqual(len(list((e.datadir / "backups").glob("why-*-before-menu.db"))), 1, "a copy was taken first")
        self.customer(e)
        n = len(e.calls())
        rc, out = e.run("--yes")   # the same package again
        self.assertEqual(rc, 0, out)
        self.assertIn("the café's menu is already in (nothing changed)", out)
        self.assertNotIn("restart why-server", e.calls()[n:])
        e.set_menu('{"format": "why-menu/1", "products": "broken"}')   # a broken menu never stops an update
        rc, out = e.run("--yes")
        self.assertEqual(rc, 0, out)
        self.assertIn("the menu file was not added; the menu stays as it was", out)
        self.assertIn("customers: 1", e.program("check").stdout)
        self.assertEqual(e.api("/catalog")[1]["crev"], cat["crev"], "nothing changed in the menu")

    def test_program_that_fails_its_self_test_changes_nothing(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        pid, old = e.pid(), (e.rundir / "why_server.py").read_text()
        cf_before = e.cf()
        e.edit_server("this is not python ((\n")
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("did not pass its self-test", out); self.assertIn("Nothing was changed", out)
        self.assertEqual(e.pid(), pid); self.assertTrue(e.alive()); self.assertEqual(e.api("/health")[0], 200)
        self.assertEqual((e.rundir / "why_server.py").read_text(), old)
        self.assertEqual(e.cf(), cf_before)
        self.assertFalse(list(e.rundir.parent.glob("why-server.new.*")), "the staged copy is cleaned up")
        self.assertNotIn("restart why-server", e.calls())

    def test_program_that_does_not_come_up_is_rolled_back(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        old, cf_before, unit_before = (e.rundir / "why_server.py").read_text(), e.cf(), e.unit.read_text()
        old_page = (e.webroot / "index.html").read_text()
        # passes the self-test ("check") but stops as soon as it is started as a server
        e.edit_server(e.server_text().replace("def main(argv=None):", "def main(argv=None):\n    if 'serve' in (argv or sys.argv[1:]):\n        sys.exit(3)", 1))
        e.set_site("<!doctype html><html><body><div id=\"app\">v2 NEW</div></body></html>")
        (e.state / "journal.txt").write_text("why_server.py: exited with status 3\n")
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("did not come up", out); self.assertIn("previous state was put back", out)
        self.assertIn("exited with status 3", out, "the log is shown")
        self.assertEqual((e.rundir / "why_server.py").read_text(), old)
        self.assertEqual(e.unit.read_text(), unit_before)
        self.assertTrue(e.alive()); self.assertEqual(e.api("/health")[0], 200, "the previous version is running again")
        self.assertEqual(e.cf(), cf_before); self.assertEqual((e.webroot / "index.html").read_text(), old_page, "the pages were not touched")
        self.assertFalse(list(e.rundir.parent.glob("why-server.old.*")))

    def test_first_install_that_cannot_start_leaves_nothing_behind(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_WHY_START_FAIL=1)
        (e.state / "journal.txt").write_text("systemd: why-server.service: Failed with result 'exit-code'.\n")
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("could not start", out); self.assertIn("Failed with result", out)
        self.assertFalse(e.unit.exists()); self.assertFalse(e.rundir.exists()); self.assertFalse(e.webroot.exists())
        self.assertEqual(e.cf(), OTHER_SITES); self.assertEqual(e.settings(), "")
        self.assertIn("disable why-server", e.calls())

    def test_service_that_is_stopped_gets_started_again_by_an_update(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        subprocess.run(["bash", "-c", f'kill $(cat {e.state}/why.pid); sleep 0.5'], check=True)
        self.assertFalse(e.alive())
        rc, out = e.run("--yes")
        self.assertEqual(rc, 0, out)
        self.assertTrue(e.alive()); self.assertEqual(e.api("/health")[0], 200)

    def test_an_install_from_the_earlier_version_asks_the_question_again(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        (e.tmp / "app" / "settings.txt").write_text(f"DOMAIN={DOMAIN}\nCONFIRMED_HOST=Mazad-bot\nVERSION=0.2.0\nMODE=existing\n")
        rc, out = e.run()            # it is a bigger change now (a server program), so "confirmed before" does not apply
        self.assertNotEqual(rc, 0); self.assertIn("--yes", out); self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.unit.exists())
        rc, out = e.run_tty(["y"] + PINS)
        self.assertEqual(rc, 0, out); self.assertIn("(first time)", out)
        self.assertIn(f"{DOMAIN} {{", e.cf()); self.assertEqual(e.cf().count(BEGIN), 1)

    def test_upgrade_from_the_first_version_replaces_its_block_and_keeps_everything(self):
        """The real situation of the café's server: version 0.2.0 (pages only, no server program) is already live."""
        old_block = (f"{DOMAIN} {{\n\troot * WEBROOT\n\tencode zstd gzip\n\theader {{\n\t\tX-Content-Type-Options nosniff\n\t\tReferrer-Policy no-referrer\n"
                     "\t\tX-Robots-Tag \"noindex, nofollow\"\n\t\t-Server\n\t}\n\t@html path / /index.html\n\theader @html Cache-Control \"no-cache\"\n"
                     "\t@manifest path /manifest.webmanifest\n\theader @manifest Content-Type \"application/manifest+json\"\n\tfile_server\n}")
        marked = ("# >>> why-site (managed by install.sh in /opt/why-site; do not edit between the markers)\n" + old_block + "\n# <<< why-site\n")
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES + "\n" + marked.replace("WEBROOT", "/placeholder"), ss=SS_SSH + SS_CADDY)
        e.caddyfile.write_text(OTHER_SITES.rstrip("\n") + "\n\n" + marked.replace("WEBROOT", str(e.webroot)))
        shutil.copy(e.caddyfile, e.state / "loaded")
        e.webroot.mkdir(parents=True)
        (e.webroot / "index.html").write_text("<html><div id=\"app\">the old customer page</div></html>")
        (e.webroot / "manifest.webmanifest").write_text("{}")
        (e.tmp / "app" / "settings.txt").write_text(f"DOMAIN={DOMAIN}\nCONFIRMED_HOST=Mazad-bot\nVERSION=0.2.0\nMODE=existing\n")
        rc, out = e.run_tty(["y"] + PINS)
        self.assertEqual(rc, 0, out)
        cf = e.cf()
        self.assertEqual(cf.count(BEGIN), 1, "the old block was replaced, not repeated")
        self.assertEqual(cf.count(f"{DOMAIN} {{"), 1)
        self.assertTrue(cf.startswith(OTHER_SITES.rstrip("\n")), "the other sites are exactly as they were")
        self.assertIn("reverse_proxy /api/*", cf); self.assertIn("/driver/index.html", cf)
        self.assertNotIn("the old customer page", (e.webroot / "index.html").read_text())
        for sub in ("", "reception/", "admin/", "driver/"):
            self.assertTrue((e.webroot / sub / "index.html").exists(), sub)
        self.assertIn("reload", e.calls()); self.assertNotIn("restart", e.calls(), "Caddy is reloaded, never restarted")
        self.assertTrue(e.alive()); self.assertEqual(e.api("/health")[0], 200)
        self.assertEqual(e.api("/admin/login", {"pin": ADMIN_PIN})[0], 200)
        self.assertIn("VERSION=" + (HERE / "VERSION").read_text().strip(), e.settings())
        self.assertEqual(len(e.baks()), 1)
        self.assertEqual(e.other_calls(), [])

    # ---------- things that must stop, without changing anything ----------
    def assertUntouched(self, e, before_cf):
        self.assertEqual(e.cf(), before_cf)
        self.assertFalse(e.webroot.exists(), "no site files were published")
        self.assertFalse(any("install caddy" in c for c in e.calls()), "nothing was installed")
        self.assertFalse((e.tmp / "app" / "settings.txt").exists())
        self.assertFalse(e.unit.exists()); self.assertFalse(e.rundir.exists()); self.assertFalse(e.alive())
        self.assertFalse(any(c.startswith("useradd") for c in e.calls()), "no user was created")

    def test_name_points_to_another_server(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, dns="198.51.100.9")
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("ERROR", out)
        self.assertIn("points to 198.51.100.9", out); self.assertIn("this server is 203.0.113.7", out)
        self.assertUntouched(e, OTHER_SITES)

    def test_name_does_not_exist_yet(self):
        e = self.env(dns="")
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("does not exist yet", out); self.assertIn("203.0.113.7", out)
        self.assertUntouched(e, None)

    def test_docker_gateway_is_left_alone(self):
        e = self.env(caddyfile=OTHER_SITES, ss=SS_SSH + SS_DOCKER)
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("Docker gateway", out)
        self.assertUntouched(e, OTHER_SITES)

    def test_other_web_server_is_left_alone(self):
        e = self.env(ss=SS_SSH + SS_NGINX)
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("nginx", out)
        self.assertUntouched(e, None)

    def test_not_root(self):
        e = self.env(FAKE_UID=1000)
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("as root", out)
        self.assertUntouched(e, None)

    def test_no_internet_for_the_address(self):
        e = self.env(ip="")
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("public address", out)

    def test_caddy_json_config_is_refused(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_UNIT_CONFIG="/etc/caddy/caddy.json")
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("JSON", out)
        self.assertUntouched(e, OTHER_SITES)

    def test_a_package_without_the_server_program_is_caught_before_anything_changes(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        (e.tmp / "app" / "source" / "server" / "why_server.py").unlink()
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("server program is missing", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.webroot.exists()); self.assertFalse(e.unit.exists())

    def test_user_that_cannot_be_created_stops_the_install(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_USERADD_FAIL=1)
        rc, out = e.run("--yes")
        self.assertNotEqual(rc, 0); self.assertIn("Could not create the service user", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.unit.exists()); self.assertFalse(e.webroot.exists())

    # ---------- failures half way: everything goes back ----------
    def test_name_already_in_the_caddyfile(self):
        mine = OTHER_SITES + f"\n{DOMAIN} {{\n\trespond \"manual\"\n}}\n"
        e = self.env(caddy_installed=True, caddyfile=mine, ss=SS_SSH + SS_CADDY)
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("already written", out)
        self.assertEqual(e.cf(), mine)
        self.assertFalse(e.webroot.exists(), "the pages that were just published are taken down again")

    def test_current_settings_already_invalid_are_not_touched(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_VALIDATE_ALWAYS_FAIL=1)
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("did not touch the Caddyfile", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertEqual(e.baks(), []); self.assertFalse(e.webroot.exists())

    def test_check_fails_so_the_old_file_comes_back(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_VALIDATE_FAIL=1)
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("old file was put back", out)
        self.assertEqual(e.cf(), OTHER_SITES)
        self.assertNotIn("reload", e.calls(), "Caddy was never asked to load the bad file")
        self.assertFalse(e.webroot.exists())

    def test_reload_fails_so_the_old_file_comes_back(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_RELOAD_FAIL=1)
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("could not reload", out); self.assertIn("other sites keep running", out)
        self.assertEqual(e.cf(), OTHER_SITES)

    def test_update_whose_caddy_step_fails_puts_the_old_pages_back(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        cf_before, page = e.cf(), (e.webroot / "index.html").read_text()
        e.set_site("<!doctype html><html><body><div id=\"app\">v2 NEW</div></body></html>")
        rc, out = e.run("--yes", env={"FAKE_RELOAD_FAIL": 1})
        self.assertNotEqual(rc, 0); self.assertIn("could not reload", out)
        self.assertEqual(e.cf(), cf_before)
        self.assertEqual((e.webroot / "index.html").read_text(), page, "the visitors keep the pages they had")
        self.assertFalse(list(e.webroot.parent.glob("why.old.*")) or list(e.webroot.parent.glob("why.new.*")))

    def test_install_of_caddy_fails(self):
        e = self.env(FAKE_APT_FAIL=1)
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("ERROR", out)
        self.assertEqual(e.settings(), "")

    def test_https_never_comes_up_gives_the_firewall_hint(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_HTTPS="never")
        (e.state / "journal.txt").write_text('{"level":"error","msg":"obtaining certificate","error":"Timeout during connect (likely firewall problem)"}\n')
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("Firewalls", out); self.assertIn("bash install.sh status", out)
        self.assertIn(BEGIN, e.cf(), "the settings stay: Caddy keeps trying in the background")
        self.assertEqual(e.settings(), "", "not marked as installed")
        self.assertTrue(e.alive() and (e.webroot / "index.html").exists(), "the server and the pages stay in place too")

    def test_stray_ipv6_on_the_name_is_reported(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_DNS_IPV6="2001:db8::5")
        rc, out = e.install()
        self.assertEqual(rc, 0, out)      # a warning only: it can still work
        self.assertIn("IPv6 address (2001:db8::5)", out)

    def test_stray_ipv6_is_the_first_hint_when_https_fails(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY, FAKE_HTTPS="never", FAKE_DNS_IPV6="2001:db8::5")
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("clear the IPv6 box", out)

    def test_server_that_does_not_answer_through_caddy_is_reported(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        # Caddy loads a block that does not hand /api to the program (as if the template were wrong)
        tpl = e.tmp / "app" / "caddy-block.tpl"
        tpl.write_text(tpl.read_text().replace("reverse_proxy /api/*", "reverse_proxy /nothing/*"))
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("does not answer through", out)
        self.assertEqual(e.settings(), "")

    def test_other_sites_are_never_reformatted(self):
        odd = "{\n\temail me@example.com\n}\n\n\n\n\nolder.example.com {\n\trespond \"a\"\n\n\n\n\trespond \"b\"\n}\n"
        e = self.env(caddy_installed=True, caddyfile=odd, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        self.assertTrue(e.cf().startswith(odd.rstrip("\n")), "blank lines of the other sites are left alone")
        e.caddyfile.write_text(e.cf() + "\n\nafter.example.com {\n\trespond \"c\"\n}\n")   # something added after our block
        self.assertEqual(e.run("--yes")[0], 0)
        self.assertEqual(e.cf().count(BEGIN), 1)
        self.assertIn("after.example.com {", e.cf())
        rc, out = e.run("remove", "--yes")
        self.assertEqual(rc, 0, out)
        self.assertEqual(e.cf(), odd.rstrip("\n") + "\n\nafter.example.com {\n\trespond \"c\"\n}\n")

    # ---------- the question ----------
    def test_answering_n_changes_nothing(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.run_tty(["n"])
        self.assertEqual(rc, 1, out); self.assertIn("Is this the right server?", out); self.assertIn("Nothing was changed", out)
        self.assertUntouched(e, OTHER_SITES)

    def test_the_plan_says_what_will_happen(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.run_tty(["n"])
        for want in ("Why! installer", "This server:  Mazad-bot", "service \"why-server\"", f"127.0.0.1:{e.start_port}", "96 MB", "40% of one CPU",
                     "secret codes", "/reception/", "/admin/", "/driver/", "marked block", "does not stop, restart or change any other service", "(first time)"):
            self.assertIn(want, out)

    def test_answering_y_installs(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.run_tty(["y"] + PINS)
        self.assertEqual(rc, 0, out); self.assertIn(f"DONE. Open: https://{DOMAIN}", out)
        self.assertIn("This server:  Mazad-bot", out)

    def test_without_a_keyboard_it_refuses_instead_of_guessing(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.run()
        self.assertNotEqual(rc, 0); self.assertIn("--yes", out); self.assertEqual(e.cf(), OTHER_SITES)

    # ---------- status and remove ----------
    def test_status_before_and_after(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.run("status")
        self.assertEqual(rc, 0, out); self.assertIn("MISSING", out); self.assertIn("server:      not installed", out); self.assertEqual(e.cf(), OTHER_SITES)
        self.assertFalse(e.unit.exists())
        self.assertEqual(e.install()[0], 0)
        rc, out = e.run("status")
        self.assertEqual(rc, 0, out); self.assertIn("the Why! block is present", out); self.assertIn("HTTP 200", out)
        self.assertIn("name -> here: yes", out)
        self.assertIn("server:      running (service why-server", out); self.assertIn("server test: answers (version", out)
        for p in ("/", "/reception/", "/admin/", "/driver/"):
            self.assertRegex(out, rf"page {re.escape(p)}\s+present")

    def test_status_says_so_when_the_server_is_down(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        subprocess.run(["bash", "-c", f'kill $(cat {e.state}/why.pid); sleep 0.5'], check=True)
        rc, out = e.run("status")
        self.assertEqual(rc, 0, out); self.assertIn("server:      NOT running", out); self.assertIn("does NOT answer", out)

    def test_status_warns_when_the_block_was_wiped(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        e.caddyfile.write_text(OTHER_SITES)       # e.g. another setup script rewrote the whole file
        rc, out = e.run("status")
        self.assertIn("block is MISSING", out)
        self.assertEqual(e.run("--yes")[0], 0)    # running the installer again puts it back
        self.assertEqual(e.cf().count(BEGIN), 1)

    def test_remove_takes_only_our_part_away_and_keeps_the_data(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        self.assertEqual(e.install()[0], 0)
        self.customer(e)
        rc, out = e.run("remove", "--yes")
        self.assertEqual(rc, 0, out); self.assertIn("DONE", out)
        self.assertEqual(e.cf().strip(), OTHER_SITES.strip())
        self.assertFalse(e.webroot.exists()); self.assertFalse(e.unit.exists()); self.assertFalse(e.rundir.exists()); self.assertFalse(e.alive())
        self.assertIn("stop why-server", e.calls()); self.assertIn("disable why-server", e.calls())
        self.assertTrue((e.datadir / "why.db").exists(), "the customers and orders are kept")
        self.assertTrue((e.tmp / "app" / "site" / "index.html").exists(), "the package itself stays")
        self.assertEqual(e.other_calls(), [])
        # and it can be brought back with the data and the codes still there
        rc, out = e.run("--yes")
        self.assertEqual(rc, 0, out); self.assertIn("already set", out)
        self.assertIn("customers: 1", e.program("check").stdout)

    def test_other_domain_option(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        rc, out = e.install("--domain", "Why-Test.duckdns.org")
        self.assertEqual(rc, 0, out); self.assertIn("why-test.duckdns.org {", e.cf())
        rc, out = e.run("--yes", "--domain", "not a name")
        self.assertNotEqual(rc, 0); self.assertIn("looks wrong", out)

    def test_damaged_package_is_caught(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        e.set_site("<html>no app here</html>")
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("site folder is missing or damaged", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.webroot.exists())

    def test_one_missing_page_is_caught(self):
        e = self.env(caddy_installed=True, caddyfile=OTHER_SITES, ss=SS_SSH + SS_CADDY)
        (e.tmp / "app" / "site" / "driver" / "index.html").unlink()
        rc, out = e.install()
        self.assertNotEqual(rc, 0); self.assertIn("site folder is missing or damaged", out); self.assertIn("driver", out)
        self.assertEqual(e.cf(), OTHER_SITES); self.assertFalse(e.webroot.exists())

    def test_help(self):
        e = self.env()
        rc, out = e.run("--help")
        self.assertEqual(rc, 0); self.assertIn("bash install.sh status", out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
