// Reads prototype/src/data.js and prints what the server needs from it, as JSON:
//   the option groups (prices of sizes, milk ...), rewards, banners, carriers and fees,
//   and "seed": the first menu (categories and products) and the first branches. The server copies the seed into its database once;
//   from then on the admin edits the menu there and the seed is not read again.
// The product photos are added by tools/export_catalog.py, which calls this and writes server/catalog.json.
// usage: node tools/export_catalog.js [out.json | -]      (- = print)
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.resolve(__dirname, '..');
const src = fs.readFileSync(path.join(root, 'prototype/src/data.js'), 'utf8');
const out = process.argv[2] || '-';
const pick = `JSON.stringify({
  opts: Object.fromEntries(Object.entries(OPT).map(([k, g]) => [k, {type:g.type, items:g.items.map(i => ({id:i.id, d:i.d}))}])),
  rewards: REWARDS.map(r => Object.assign(r.credit ? {id:r.id, pts:r.pts, credit:r.credit} : {id:r.id, pts:r.pts, pid:r.pid}, {ar:r.ar, en:r.en})),
  banners: BANNERS.map(b => b.id),
  news: NEWS.map(n => n.id),
  carriers: CARRIERS,
  ship_fee: SHIP_FEE,
  delivery_fee: DELIVERY_FEE,
  seed: {
    cats: CATS.map(c => ({id:c.id, ar:c.ar, en:c.en, kind:c.kind})),
    branches: BRANCHES.map(b => ({id:b.id, ar:b.ar, en:b.en, addr:b.addr, h:b.h, lat:b.lat, lng:b.lng})),
    products: PRODUCTS.map(p => ({id:p.id, cats:p.cats || [p.cat], ar:p.ar, en:p.en, price:p.price, cal:p.cal || 0, art:p.art, tone:p.tone, opts:p.opts,
      desc:p.desc || null, sub:p.sub || null, d:p.d || null, badge:p.badge || null, stock:p.stock !== false, fship:!!p.fship}))
  }
})`;
const ctx = vm.createContext({});
const cat = JSON.parse(vm.runInContext(src + '\n;' + pick, ctx));
if (!cat.seed.products.length) throw new Error('no products found');
const ids = new Set();
cat.seed.products.forEach(p => { if (ids.has(p.id)) throw new Error('two products with the id ' + p.id); ids.add(p.id); });
const text = JSON.stringify(cat, null, 1) + '\n';
if (out === '-') process.stdout.write(text);
else { fs.writeFileSync(out, text); console.log('catalog:', cat.seed.products.length, 'products ->', out); }
