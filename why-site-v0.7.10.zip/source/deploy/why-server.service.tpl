[Unit]
Description=Why! cafe server (orders and accounts, one SQLite file)
After=network.target
StartLimitIntervalSec=300
StartLimitBurst=10

[Service]
Type=simple
User=__USER__
Group=__USER__
WorkingDirectory=__DATA_DIR__
ExecStart=__PYTHON__ -I -B __RUN_DIR__/why_server.py serve --db __DATA_DIR__/why.db --catalog __RUN_DIR__/catalog.json --host 127.0.0.1 --port __PORT__
Restart=on-failure
RestartSec=5
KillSignal=SIGINT
TimeoutStopSec=15

# Limits: this program shares a small machine with other programs (the auction bot ...) and must never starve them.
# Past MemoryHigh it is slowed down; past MemoryMax only this service is stopped (and started again), nothing else.
MemoryHigh=64M
MemoryMax=96M
CPUQuota=40%
TasksMax=128
LimitNOFILE=1024
Nice=10
OOMScoreAdjust=500
LogRateLimitIntervalSec=30s
LogRateLimitBurst=400

# Sandbox: it listens on 127.0.0.1 only, can read its own program folder and write only its own data folder.
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=__DATA_DIR__
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
LockPersonality=true
UMask=0077

[Install]
WantedBy=multi-user.target
