import SwiftUI

// The iPhone app: the same page as on the web (customers, ORDER DESK, MANAGEMENT or DELIVERY), in a full-screen web view.
// Which page, and what the phone does for it, comes from this app's Info.plist (WhyStartURL, WhyKeepAwake, WhyBackgroundLocation).
@main
struct WhyApp: App {
    var body: some Scene {
        WindowGroup {
            WebScreen().ignoresSafeArea()
        }
    }
}

struct WebScreen: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> WebViewController { WebViewController() }
    func updateUIViewController(_ controller: WebViewController, context: Context) {}
}
