#!/bin/bash
# Talabak landing page: one static page at https://talabak.duckdns.org, served by the Caddy already on this server.
# It only adds ONE marked block to the Caddyfile (a backup first, checked before it is applied, put back if anything fails)
# and copies the page to /var/www/talabak. It does not touch Why!, the auction bot or any other site.
#   bash install.sh           install or update
#   bash install.sh remove    take the block out (the page folder stays)
set -uo pipefail
DOMAIN="talabak.duckdns.org"
ROOT="/var/www/talabak"
BEGIN_MARK="# >>> talabak landing page (managed by its install.sh) >>>"
END_MARK="# <<< talabak landing page <<<"
HERE="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
say(){ printf '%s\n' "$*"; }; ok(){ printf '  [ok] %s\n' "$*"; }
die(){ printf '\n[STOP] %b\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "Run this as root."
[ -f "$HERE/site/index.html" ] || die "site/index.html is missing next to install.sh."
command -v caddy >/dev/null 2>&1 || die "Caddy is not installed on this server. Nothing was changed."
systemctl is-active --quiet caddy || die "Caddy is not running. Nothing was changed."

CF="$(systemctl cat caddy.service 2>/dev/null | grep -Eo -- '--config[= ]+[^ ]+' | head -n 1 | sed -E 's/--config[= ]+//')"
CF="${CF:-/etc/caddy/Caddyfile}"
case "$CF" in *.json) die "Caddy uses a JSON file ($CF). Nothing was changed." ;; esac
[ -f "$CF" ] || die "Caddyfile not found ($CF). Nothing was changed."

owners="$(ss -ltnp 2>/dev/null | awk '{n=split($4,a,":"); if (a[n]=="443"||a[n]=="80") print}' | grep -o 'users:(("[^"]*' | sed 's/users:(("//' | sort -u)"
if printf '%s\n' "$owners" | grep -q docker-proxy; then die "Ports 80/443 belong to a Docker gateway, not this Caddy. Nothing was changed."; fi

edit() {   # $1 add|remove
python3 - "$CF" "$1" "$DOMAIN" "$ROOT" "$BEGIN_MARK" "$END_MARK" <<'PY'
import os, re, sys
path, mode, domain, root, BEGIN, END = sys.argv[1:7]
text = open(path, encoding="utf-8").read()
pat = re.compile(r"\n*" + re.escape(BEGIN) + r".*?" + re.escape(END) + r"[ \t]*\n?", re.S)
while True:
    m = pat.search(text)
    if not m: break
    head, tail = text[:m.start()].rstrip("\n"), text[m.end():].lstrip("\n")
    text = head + ("\n\n" if head and tail else "") + tail
used = re.compile(r"^\s*(https?://)?" + re.escape(domain) + r"(:\d+)?\s*(,|\{|$)", re.I)
if mode == "add":
    for i, line in enumerate(text.splitlines(), 1):
        if used.match(line):
            print("line %d: %s" % (i, line.strip())); sys.exit(3)
    block = """%s {
	root * %s
	encode zstd gzip
	header {
		X-Content-Type-Options nosniff
		Referrer-Policy strict-origin-when-cross-origin
		Content-Security-Policy "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
		Cache-Control "no-cache"
		-Server
	}
	file_server
}""" % (domain, root)
    text = text.rstrip("\n") + "\n\n" + BEGIN + "\n" + block + "\n" + END
tmp = path + ".talabak-new"
open(tmp, "w", encoding="utf-8").write(text.rstrip("\n") + "\n")
os.replace(tmp, path)
PY
}

MODE="${1:-add}"
[ "$MODE" = remove ] || MODE=add
if [ "$MODE" = add ]; then
  ip="$(getent ahostsv4 "$DOMAIN" | awk '{print $1; exit}')"
  me="$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || true)"
  [ -n "$ip" ] || die "$DOMAIN does not exist yet. Set it at duckdns.org, wait a minute, run again."
  [ -z "$me" ] || [ "$ip" = "$me" ] || die "$DOMAIN points to $ip but this server is $me.\n       At duckdns.org set the IP of talabak to $me, press update ip, wait a minute, run again. Nothing was changed."
  ok "$DOMAIN points to this server ($ip)"
  mkdir -p "$ROOT" && install -m 644 "$HERE/site/index.html" "$ROOT/index.html" && chmod 755 "$ROOT" || die "Could not copy the page."
  ok "page copied to $ROOT"
fi

caddy validate --config "$CF" --adapter caddyfile >"$TMP/v0" 2>&1 || { tail -n 6 "$TMP/v0"; die "Caddy's current settings do not pass its check. I did not touch them."; }
bak="$CF.bak-$(date +%Y%m%d-%H%M%S)"; cp -p "$CF" "$bak" || die "Could not back up $CF"; ok "backup: $bak"
edit "$MODE" >"$TMP/e" 2>&1; rc=$?
if [ $rc -ne 0 ]; then cp -p "$bak" "$CF"; die "Could not edit the Caddyfile ($(cat "$TMP/e")). The old file is back."; fi
if ! caddy validate --config "$CF" --adapter caddyfile >"$TMP/v1" 2>&1; then cp -p "$bak" "$CF"; tail -n 8 "$TMP/v1"; die "Caddy did not accept the new block. The old file is back; nothing changed."; fi
ok "the new settings are valid"
if ! systemctl reload caddy >"$TMP/r" 2>&1; then cp -p "$bak" "$CF"; systemctl reload caddy >/dev/null 2>&1; tail -n 8 "$TMP/r"; die "Caddy could not reload. The old file is back; your other sites keep running."; fi
ok "Caddy reloaded (the other sites were not interrupted)"
[ "$MODE" = remove ] && { say ""; say "REMOVED"; exit 0; }

say "   waiting for the https certificate (up to 2 minutes) ..."
for i in $(seq 1 24); do
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 6 "https://$DOMAIN/" || true)"
  [ "$code" = 200 ] && { ok "https://$DOMAIN answers"; say ""; say "DONE  https://$DOMAIN"; exit 0; }
  sleep 5
done
say ""; say "The page and the settings are in place, but https://$DOMAIN did not answer yet."
say "Caddy keeps trying in the background; open the link again in a few minutes."
