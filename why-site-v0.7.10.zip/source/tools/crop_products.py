"""Cut the product photos and the banner out of the store screenshot and clean the shop-UI overlays
(heart / eye buttons, rating pill, 'new product' stamp) off the photos."""
import numpy as np
from PIL import Image, ImageDraw
from skimage.restoration import inpaint_biharmonic

SRC = '/mnt/user-data/uploads/d1b533a9-image.png'
OUT = '/home/claude/why-app/assets'
im = Image.open(SRC).convert('RGB')

def clean(box, shapes, name):
    x0, y0, x1, y1 = box
    crop = im.crop(box)
    m = Image.new('L', crop.size, 0)
    d = ImageDraw.Draw(m)
    for s in shapes:
        kind, *a = s
        a = [a[0] - x0, a[1] - y0] + ([a[2] - x0, a[3] - y0] if len(a) > 3 else [a[2]])
        if kind == 'disk':
            cx, cy, r = a
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)
        else:
            d.rounded_rectangle(tuple(a), radius=20, fill=255)
    mask = np.asarray(m) > 0
    arr = np.asarray(crop).astype(np.float64) / 255.0
    out = inpaint_biharmonic(arr, mask, channel_axis=-1)
    res = Image.fromarray((np.clip(out, 0, 1) * 255).round().astype(np.uint8))
    res.save(f'{OUT}/products/{name}.png')
    # side-by-side preview of the mask for checking
    prev = arr.copy(); prev[mask] = [1, 0, 0]
    Image.fromarray((prev * 255).astype(np.uint8)).save(f'/home/claude/why-app/work/mask_{name}.png')
    print(name, crop.size)

import os
os.makedirs(f'{OUT}/products', exist_ok=True)
os.makedirs(f'{OUT}/banners', exist_ok=True)

# matcha powder card: photo area is x 610..1126, y 1144..1713 in the screenshot
clean((610, 1144, 1126, 1713),
      [('disk', 682, 1218, 58), ('disk', 682, 1330, 58),
       ('rect', 628, 1608, 795, 1693),
       ('rect', 993, 1166, 1126, 1266)], 'matchapowder')
# 16oz cups card: photo area x 52..568
clean((52, 1144, 568, 1713),
      [('disk', 125, 1218, 58), ('disk', 125, 1330, 58)], 'cup16')

# home banner (matcha, new product): the yellow header edge above and the grey page strip below are left out
hero = im.crop((0, 519, 1179, 1064))
hero.save(f'{OUT}/banners/bn1.png')
print('hero', hero.size)
