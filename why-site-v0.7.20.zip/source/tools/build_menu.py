"""Build deploy/menu/why-menu.json: Why!'s real menu, for  why_server.py importmenu  (install.sh adds it once).

Where it comes from (Nov 2026):
  - the items, their Arabic descriptions and their photos: the café's page on Keeta (screenshots; the photos are cut by
    tools/menu_photos.py into assets/menu/)
  - price, calories and English name: the café's own menu board in the shop, for the items on it ("board"). The board
    is two years old; Keeta's prices are about 2 SAR higher than it. Items that are not on the board keep Keeta's price
    ("keeta"): the café checks those in MANAGEMENT.
  - espresso and macchiato are on the board but not on Keeta: no photo yet (the drawing shows until one is added);
    the hot Spanish latte uses the latte photo, as Keeta itself uses one photo for latte, cappuccino and flat white.
  - left out: board items Keeta no longer has (cola brew, the premium crop, maritozzi, mango cheesecake, San Sebastian
    tiramisu); the café adds them back in MANAGEMENT if they are still sold.
v0.7.18 (Nov 2026): the café's own menu story on Instagram ("story") is the newest: its prices, calories, descriptions
  and what each item has in it (allergens) win over the board and Keeta. New from it: Matcha Why!, the luxurious crop,
  chocolate waffle, French toast chocolate (French toast crème brûlée became French toast mix) and the two breakfast
  offers, whose sandwich the customer picks (option group "sw"). Their photos come from tools/story_photos.py.
  The server only ever adds a product it has not had; for one it already has, "was" (tools/menu_was.json: what the
  v0.7.9 file put in it) lets it change a field only while the admin has not changed that field himself.
The first import also takes the sample products of the first menu off (as the admin's delete does: old orders keep
them), drops the sample matcha category once it is empty, and moves the loyalty rewards that used a sample product to
the real one.

usage: python3 tools/build_menu.py
"""
import base64, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PHOTOS = ROOT / "assets" / "menu"
OUT = ROOT / "deploy" / "menu" / "why-menu.json"
WAS = Path(__file__).resolve().parent / "menu_was.json"   # what the first file (v0.7.9) set: see "was" below

CATS = [
    {"key": "hot", "id": "hot", "ar": "المشروبات الساخنة", "en": "Hot drinks", "kind": "drink"},
    {"key": "cold", "id": "cold", "ar": "المشروبات الباردة", "en": "Cold drinks", "kind": "drink"},
    {"key": "drip", "id": "filter", "ar": "قهوة مقطرة", "en": "Drip coffee", "kind": "drink"},
    {"key": "sandwiches", "ar": "الساندويتشات", "en": "Sandwiches", "kind": "food"},
    {"key": "breakfast", "ar": "عرض الفطور", "en": "Breakfast offer", "kind": "food"},
    {"key": "sweet", "id": "sweet", "ar": "الحلويات", "en": "Desserts", "kind": "food"},
]

D = lambda ar, en: {"ar": ar, "en": en}
# key, category, Arabic, English, price, calories, description, photo, drawing, colour, price from
PRODUCTS = [
    ("espresso", "hot", "اسبريسو", "Espresso", 11, 2, None, None, "espresso", "#8A5232", "board"),
    ("macchiato", "hot", "ميكاتو", "Macchiato", 14, 6, None, None, "espresso", "#A0683C", "board"),
    ("americano", "hot", "امريكانو", "Americano", 14, 2, D("جرعة من قهوة الإسبريسو يضاف إليها الماء", "A shot of espresso topped up with water"), "americano", "hot", "#4A2A1A", "board"),
    ("cortado", "hot", "كورتادو", "Cortado", 14, 64, D("كمية متساوية من قهوة الإسبريسو والحليب المبخر", "Equal parts espresso and steamed milk"), "cortado", "hot", "#B07A4A", "board"),
    ("flatwhite", "hot", "فلات وايت", "Flat white", 15, 65, D("قهوة الإسبريسو مع الحليب المبخر والرغوة", "Espresso with steamed milk and foam"), "latte", "hot", "#C8965A", "board"),
    ("cappuccino", "hot", "كابتشينو", "Cappuccino", 16, 87, D("قهوة الإسبريسو مع الحليب المبخر والرغوة", "Espresso with steamed milk and foam"), "latte", "hot", "#C8965A", "board"),
    ("latte", "hot", "لاتيه", "Latte", 16, 138, D("قهوة الإسبريسو مع الحليب المبخر", "Espresso with steamed milk"), "latte", "hot", "#D9B98C", "board"),
    ("spanish", "hot", "سبانيش لاتيه", "Spanish latte", 18, 225, None, "latte", "hot", "#E0A33B", "board"),

    ("iced_americano", "cold", "ايس امريكانو", "Iced americano", 14, 2, D("جرعة من قهوة الإسبريسو يضاف إليها الماء والثلج", "A shot of espresso with water and ice"), "iced_americano", "iced", "#4A2A1A", "board"),
    ("iced_latte", "cold", "ايس لاتيه", "Iced latte", 18, 224, D("قهوة الإسبريسو مع الحليب البارد", "Espresso with cold milk"), "iced_latte", "iced", "#D9B98C", "board"),
    ("iced_spanish", "cold", "ايس سبانيش لاتيه", "Iced Spanish latte", 20, 135, D("سبانيش لاتيه بارد", "Spanish latte over ice"), "iced_latte", "iced", "#E0A33B", "board"),
    ("iced_matcha", "cold", "ايس ماتشا لاتيه", "Iced matcha latte", 22, 154, D("ماتشا بالفانيلا", "Matcha with vanilla"), "iced_matcha", "iced", "#8DB255", "board"),
    ("iced_tea_cherry", "cold", "ايس تي كرز", "Iced tea cherry", 20, 190, D("ايس تي بطعم الكرز", "Iced tea with a cherry flavour"), "iced_tea_cherry", "iced", "#9E2B4E", "board"),
    ("roselle", "cold", "كركديه واي!", "Why! roselle", 18, 190, D("كركديه واي المنعش", "Why!'s refreshing roselle (hibiscus)"), "roselle", "iced", "#B3263E", "board"),
    ("matcha_why", "cold", "ماتشا واي!", "Matcha Why!", 25, 290, None, None, "iced", "#8DB255", "story"),

    ("v60_hot", "drip", "في 60 حار", "Hot V60", 18, 2, D("قهوة سوداء محضرة بطريقة التقطير", "Black coffee brewed by pour-over"), "v60_hot", "filter", "#8A5232", "board"),
    ("v60_cold", "drip", "في 60 بارد", "Cold V60", 20, 2, D("قهوة سوداء مثلجة محضرة بطريقة التقطير", "Iced black coffee brewed by pour-over"), "ice_drip", "iced", "#3A2218", "board"),
    ("today_hot_s", "drip", "قهوة اليوم حار (صغير)", "Today's coffee, hot (small)", 10, 2, None, "v60_hot", "filter", "#8A5232", "story"),
    ("today_hot_m", "drip", "قهوة اليوم حار (وسط)", "Today's coffee, hot (medium)", 12, 2, None, "v60_hot", "filter", "#8A5232", "story"),
    ("today_hot_l", "drip", "قهوة اليوم حار (كبير)", "Today's coffee, hot (large)", 15, 2, None, "today_hot_l", "filter", "#8A5232", "story"),
    ("today_cold_m", "drip", "قهوة اليوم بارد (وسط)", "Today's coffee, iced (medium)", 12, 2, None, "ice_drip", "iced", "#3A2218", "story"),
    ("today_cold_l", "drip", "قهوة اليوم بارد (كبير)", "Today's coffee, iced (large)", 15, 2, None, "ice_drip", "iced", "#3A2218", "story"),
    ("luxury", "drip", "محصول فاخر (بارد، حار)", "Luxurious coffee (iced or hot)", 26, 2, D("محصول قهوة فاخر، يُحضّر بارد أو حار", "A luxurious coffee crop, brewed iced or hot"), None, "filter", "#6B3A22", "story"),

    ("halloumi", "sandwiches", "ساندوتش حلومي", "Halloumi sandwich", 20, 370, D("ساندويتش حلومي مشوي بخبز حبوب محمّص ومقرمش مغطّى ببذور مشكلة، مع شرائح حلومي ذهبية مشوية وخس طازج وصوص خفيف يبرز النكهة.", "A grilled halloumi sandwich on toasted multigrain bread topped with mixed seeds, with golden grilled halloumi, fresh lettuce and a light sauce."), "halloumi", "cake", "#D9A55B", "story"),
    ("feta", "sandwiches", "فيتا ايقز", "Feta eggs", 20, 322, D("سندويتش دافئ يجمع بين البيض الطازج وجبن الفيتا الكريمي، بنكهة غنية ومتوازنة تعطيك بداية يوم لذيذة ومشبعة.", "A warm sandwich of fresh eggs and creamy feta cheese, rich and balanced for a satisfying start to your day."), "feta", "cake", "#D9A55B", "story"),
    ("tuna", "sandwiches", "ساندوتش ملتد تونة", "Tuna melt sandwich", 20, 322, D("ساندويتش ملتد تونة بخبز حبوب محمّص ومقرمش، محشو بخليط تونة متبل بعناية مع جبنة ذائبة، وخس طازج وصوص خفيف.", "A toasted tuna melt on crispy multigrain bread, with a well-seasoned tuna mix, melted cheese, fresh lettuce and a light sauce."), "tuna", "cake", "#D9A55B", "story"),
    ("turkey", "sandwiches", "ساندوتش تيركي المدخن", "Turkey sandwich", 22, 322, D("ساندويتش محمّص طازج بخبز ذهبي مقرمش، محشو بالشرائح الطرية مع خس طازج وصوص مميز يوازن بين الخفة والغنى.", "A freshly grilled sandwich on golden crispy bread, with tender slices, fresh lettuce and a signature sauce."), "turkey", "cake", "#D9A55B", "story"),

    ("bf_coffee", "breakfast", "عرض الفطور: ساندويتش + قهوة اليوم + ماء", "Breakfast: sandwich + today's coffee + water", 25, 0, D("أي نوع ساندويتش من اختيارك مع قهوة اليوم وماء.", "Any sandwich of your choice with today's coffee and water."), "breakfast", "cake", "#ECB444", "story"),
    ("bf_juice", "breakfast", "عرض الفطور: ساندويتش + عصير", "Breakfast: sandwich + juice", 29, 0, D("أي نوع ساندويتش من اختيارك مع عصير.", "Any sandwich of your choice with a juice."), "breakfast", "cake", "#ECB444", "story"),

    ("marble", "sweet", "ماربل كيك", "Marble cake", 11, 210, D("ماربل كيك طري وهش بطبقات ممزوجة من الفانيلا والشوكولاتة، بقوام خفيف ونكهة غنية في كل لقمة.", "A soft, fluffy marble cake swirled with vanilla and chocolate, light in texture and rich in every bite."), "marble", "cake", "#8A5232", "story"),
    ("cookies", "sweet", "كوكيز واي!", "Why! cookies", 9, 266, D("كوكيز طازج مخبوز بعناية، مقرمش من الخارج وطري من الداخل، محشو بقطع شوكولاتة غنية تذوب مع كل لقمة.", "Freshly baked cookies, crispy outside and soft inside, loaded with rich chocolate chunks that melt in every bite."), "cookies", "cookie", "#C8965A", "story"),
    ("fondant", "sweet", "فاوندانت شوكلت", "Chocolate fondant", 24, 566, D("فاوندانت شوكولاتة دافئ بطبقة خارجية ناعمة وقلب سائل غني، مغطّى بصوص الشوكولاتة الكريمي.", "A warm chocolate fondant with a soft outer layer and a rich molten centre, finished with a creamy chocolate sauce."), "fondant", "brownie", "#6B3A22", "story"),
    ("cherry_cheesecake", "sweet", "تشيز كرز واي!", "Why! cherry cheese", 25, 345, D("تشيز كيك كريمي ناعم على قاعدة بسكويت زبدية مقرمشة، مغطّى بصوص الكرز الغني بطعم حلو حامض.", "A smooth, creamy cheesecake on a buttery biscuit base, topped with a rich sweet-tart cherry sauce."), "cherry_cheesecake", "cake", "#F3E3C3", "story"),
    ("cinnabon", "sweet", "سينابون كيك", "Cinnamon cake", 21, 366, D("كيكة السينابون بطبقات إسفنجية طرية مغمورة بصوص القرفة الدافئ، مع طبقة كريمية ولمسة كراميل وتزيين مقرمش.", "Soft sponge layers soaked in warm cinnamon sauce, with a creamy layer, a drizzle of caramel and a crunchy topping."), "cinnabon", "cake", "#D9A55B", "story"),
    ("waffle_cheesecake", "sweet", "وافل تشيز كيك", "Waffle cheesecake", 16, 320, D("وافل بلجيكي طازج، مقرمش من الخارج وطري من الداخل، مغطّى بطبقة تشيز كيك كريمية مع صوص فواكه غني.", "A fresh Belgian waffle, crispy outside and soft inside, topped with a creamy cheesecake layer and a rich fruit sauce."), "waffle_cheesecake", "cake", "#E8C48A", "story"),
    ("choc_waffle", "sweet", "وافل شوكلت", "Chocolate waffle", 18, 320, D("وافل بلجيكي طازج، مقرمش من الخارج وطري من الداخل، مغطّى بصوص الشوكولاتة الغني والدافئ مع لمسة من السكر البودرة.", "A fresh Belgian waffle drizzled with rich, warm chocolate sauce and a light dusting of powdered sugar."), "choc_waffle", "cake", "#6B3A22", "story"),
    ("french_toast", "sweet", "فرنش توست مكس", "French toast mix", 28, 345, D("فرنش توست طري ومحمّص بعناية، مغطّى بمزيج من صوص الشوكولاتة الداكنة والبيضاء، مع لمسة سكر بودرة وفواكه طازجة.", "Soft toasted French toast topped with dark and white chocolate sauces, a dusting of powdered sugar and fresh fruit."), "french_toast_mix", "cake", "#D9A55B", "story"),
    ("french_toast_choc", "sweet", "فرنش توست شوكلت", "French toast chocolate", 28, 345, D("فرنش توست طري ومحمّص بعناية، مغطّى بصوص الشوكولاتة الغني والدافئ، مع لمسة سكر بودرة وفواكه طازجة.", "Soft toasted French toast with rich, warm chocolate sauce, a dusting of powdered sugar and fresh fruit."), "french_toast_choc", "brownie", "#6B3A22", "story"),
    ("rocky_road", "sweet", "روكي رود", "Rocky road", 15, 289, D("كرات شوكولاتة بلجيكية غنية محشوة بجوتي شوكولاتة كريمي مع قطع مارشميلو ناعمة.", "Rich Belgian chocolate bites filled with smooth chocolate ganache and soft marshmallow pieces."), "rocky_road", "brownie", "#6B3A22", "story"),
    ("tiramisu", "sweet", "تيراميسو واي!", "Why! tiramisu", 23, 422, D("كيكة ثلاثية الشوكولاتة بطبقات غنية: قاعدة شوكولاتة داكنة، ثم طبقة كراميل كريمية وكيك إسفنجي خفيف، ومغطاة بطبقة شوكولاتة ناعمة.", "A triple chocolate cake: a dark chocolate base, a creamy caramel layer, light sponge cake and a silky chocolate topping."), "tiramisu", "cake", "#B07A4A", "story"),
    ("pudding", "sweet", "بودنق واي!", "Why! pudding", 22, 566, D("بودنق كريمي ناعم بطبقات غنية، مغطّى بصوص شوكولاتة بلجيكية فاخر، مع لمسة قرمشة من البسكويت.", "A creamy layered pudding topped with velvety Belgian chocolate sauce and a hint of crunchy biscuit."), "pudding", "cake", "#C8965A", "story"),
]

# what each item has in it, as the café's menu story lists it ("مسببات الحساسية")
G, L, E, N = "gluten", "lactose", "egg", "nuts"
ALG = {"halloumi": [N, E, L, G], "tuna": [N, E, L, G], "feta": [E, L, G], "turkey": [E, L, G], "cookies": [E, L, G], "tiramisu": [E, L],
       "fondant": [E, L, G], "marble": [E, L, G], "waffle_cheesecake": [E, L, G], "choc_waffle": [E, L, G], "cinnabon": [N, E, L, G],
       "french_toast": [E, L, G], "cherry_cheesecake": [N, L, G], "french_toast_choc": [E, L, G], "pudding": [E, L, G], "rocky_road": [N, L]}
OPTS = {"bf_coffee": ["sw"], "bf_juice": ["sw"]}   # the customer picks the sandwich

# the sample products of the first menu (catalog.json) in these categories, and the matcha category they leave empty
RETIRE = ["espresso", "americano", "flat", "cap", "latte", "spanish", "iamericano", "ilatte", "coldbrew", "tonic", "batch", "v60",
          "chemex", "matchalatte", "matchatonic", "brownie", "cookie", "datecake"]
RETIRE_CATS = ["matcha"]
# a reward (or an unused gift) of a sample product moves to the same drink on the real menu
REMAP = {"batch": "today_hot_s", "latte": "latte", "ilatte": "iced_latte", "cookie": "cookies", "cap": "cappuccino", "flat": "flatwhite",
         "americano": "americano", "iamericano": "iced_americano", "spanish": "spanish", "espresso": "espresso", "v60": "v60_hot",
         "matchalatte": "iced_matcha"}


def main():
    meta = json.loads((PHOTOS / "photos.json").read_text())
    used = sorted({p[7] for p in PRODUCTS if p[7]})
    photos = {}
    for k in used:
        photos[k] = {"bg": meta[k]["bg"], "f": meta[k]["f"],
                     "full": base64.b64encode((PHOTOS / f"{k}.webp").read_bytes()).decode(),
                     "thumb": base64.b64encode((PHOTOS / f"{k}-t.webp").read_bytes()).decode()}
    unused = set(meta) - set(used)
    if unused:
        raise SystemExit("photos no product uses: %s" % ", ".join(sorted(unused)))
    menu = {
        "format": "why-menu/1",
        "name": "Why! menu (the café's menu story, Keeta and the shop's menu board), Nov 2026",
        "cats": CATS,
        "order": [c["key"] for c in CATS],
        "products": [{"key": k, "cat": c, "ar": ar, "en": en, "price": pr, "cal": cal, "desc": desc, "photo": ph, "art": art, "tone": tone, "src": src,
                      "alg": ALG.get(k, []), "opts": OPTS.get(k, [])}
                     for k, c, ar, en, pr, cal, desc, ph, art, tone, src in PRODUCTS],
        "was": json.loads(WAS.read_text())["products"],
        "retire": RETIRE,
        "retire_cats": RETIRE_CATS,
        "remap": REMAP,
        "photos": photos,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(menu, ensure_ascii=False, indent=1, sort_keys=False) + "\n", encoding="utf-8")
    print("%s: %d products in %d categories, %d photos, %d KB" % (OUT.relative_to(ROOT), len(PRODUCTS), len(CATS), len(photos), OUT.stat().st_size // 1024))


if __name__ == "__main__":
    main()
